// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.kit

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*

/// Returns the version of the app.
///
/// On iOS, uses the `CFBundleShortVersionString` of the main `Bundle's Info.plist`
///
/// On Android, uses the `versionName` property of the `android.content.pm.PackageManager`
val ProcessInfo.appVersionString: String?
    get() = _appVersionString

/// Returns the version of the app.
///
/// On iOS, uses the `CFBundleVersion` of the main `Bundle's Info.plist`
///
/// On Android, uses the `versionCode` property of the `android.content.pm.PackageManager`
val ProcessInfo.appVersionNumber: Int?
    get() = _appVersionNumber

private val packageInfo: android.content.pm.PackageInfo = linvoke l@{ ->
    val context = ProcessInfo.processInfo.androidContext.sref()
    val packageManager = context.getPackageManager()
    return@l packageManager.getPackageInfo(context.getPackageName(), android.content.pm.PackageManager.GET_META_DATA)
}

private val _appVersionString: String? = { -> packageInfo.versionName }()


private val _appVersionNumber: Int? = { -> packageInfo.versionCode }()

