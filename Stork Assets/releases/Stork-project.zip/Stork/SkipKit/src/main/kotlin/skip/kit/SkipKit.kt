// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.kit

import skip.lib.*

import skip.foundation.*

internal val logger: SkipLogger = SkipLogger(subsystem = "skip.kit", category = "SkipKit") // adb logcat '*:S' 'skip.kit.SkipKit:V'

open class SkipKitModule {

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

