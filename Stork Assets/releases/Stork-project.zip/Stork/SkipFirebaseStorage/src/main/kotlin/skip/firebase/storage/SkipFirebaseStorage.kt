// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.firebase.storage

import skip.lib.*

import skip.foundation.*
import skip.firebase.core.*
import kotlinx.coroutines.tasks.await
import android.net.Uri

// https://firebase.google.com/docs/reference/swift/firebasestorage/api/reference/Classes/Storage
// https://firebase.google.com/docs/reference/android/com/google/firebase/storage/FirebaseStorage

class Storage {
    val platformValue: com.google.firebase.storage.FirebaseStorage

    constructor(platformValue: com.google.firebase.storage.FirebaseStorage) {
        this.platformValue = platformValue.sref()
    }

    val app: FirebaseApp
        get() = FirebaseApp(app = platformValue.getApp())

    fun reference(): StorageReference = StorageReference(platformValue.reference)

    fun reference(for_: URL): StorageReference {
        val url = for_
        return reference(forURL = url.absoluteString)
    }

    fun reference(forURL: String, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null): StorageReference {
        val urlString = forURL
        return StorageReference(platformValue.getReferenceFromUrl(urlString))
    }

    fun reference(withPath: String): StorageReference {
        val path = withPath
        return StorageReference(platformValue.getReference(path))
    }

    fun useEmulator(withHost: String, port: Int) {
        val host = withHost
        platformValue.useEmulator(host, port)
    }

    companion object {

        fun storage(): Storage = Storage(com.google.firebase.storage.FirebaseStorage.getInstance())

        fun storage(app: FirebaseApp): Storage = Storage(com.google.firebase.storage.FirebaseStorage.getInstance(app.app))

        fun storage(url: String): Storage = Storage(com.google.firebase.storage.FirebaseStorage.getInstance(url))

        fun storage(app: FirebaseApp, url: String): Storage = Storage(com.google.firebase.storage.FirebaseStorage.getInstance(app.app, url))
    }
}

@Suppress("MUST_BE_INITIALIZED", "MUST_BE_INITIALIZED_OR_FINAL_OR_ABSTRACT")
open class StorageMetadata: KotlinConverting<com.google.firebase.storage.StorageMetadata> {
    open var platformValue: com.google.firebase.storage.StorageMetadata
        get() = field.sref({ this.platformValue = it })
        set(newValue) {
            field = newValue.sref()
        }

    constructor() {
        this.platformValue = com.google.firebase.storage.StorageMetadata()
    }

    constructor(platformValue: com.google.firebase.storage.StorageMetadata) {
        this.platformValue = platformValue
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.storage.StorageMetadata = platformValue.sref()

    open val description: String
        get() = platformValue.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is StorageMetadata) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.platformValue == rhs.platformValue
    }

    /// A builder for mutating the current underlying metadata
    /// https://firebase.google.com/docs/reference/android/com/google/firebase/storage/StorageMetadata.Builder
    private val builder: com.google.firebase.storage.StorageMetadata.Builder
        get() = com.google.firebase.storage.StorageMetadata.Builder(this.platformValue)

    open val bucket: String
        get() = platformValue.getBucket()!!

    open var cacheControl: String?
        get() = platformValue.getCacheControl()
        set(newValue) {
            platformValue = builder.setCacheControl(newValue).build()
        }

    open var contentDisposition: String?
        get() = platformValue.getContentDisposition()
        set(newValue) {
            platformValue = builder.setContentDisposition(newValue).build()
        }

    open var contentEncoding: String?
        get() = platformValue.getContentEncoding()
        set(newValue) {
            platformValue = builder.setContentEncoding(newValue).build()
        }

    open var contentLanguage: String?
        get() = platformValue.getContentLanguage()
        set(newValue) {
            platformValue = builder.setContentLanguage(newValue).build()
        }

    open var contentType: String?
        get() = platformValue.getContentType()
        set(newValue) {
            platformValue = builder.setContentType(newValue).build()
        }

    open val md5Hash: String?
        get() = platformValue.getMd5Hash()

    open val generation: Long
        get() = Long(platformValue.getGeneration()!!)!!

    open var customMetadata: Dictionary<String, String>?
        get() {
            val metadataKeys = platformValue.getCustomMetadataKeys()
            if (metadataKeys.isEmpty()) {
                return null
            }
            var metadata: Dictionary<String, String> = dictionaryOf()
            for (key in metadataKeys.sref()) {
                platformValue.getCustomMetadata(key)?.let { metadataValue ->
                    metadata[key] = metadataValue
                }
            }
            return metadata.sref({ this.customMetadata = it })
        }
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            // FIXME: this differs from the iOS API in that it will not clean any unused existing custom metadata key/values from the previous metadata; we would need to create and populate a fresh StorageMetadata.Builder rather than basing it on the existing metadata to do that
            val b = this.builder.sref()
            if (newValue != null) {
                for ((key, value) in newValue.sref()) {
                    b.setCustomMetadata(key, value)
                }
            }
            this.platformValue = b.build()
        }

    open val metageneration: Long
        get() = Long(platformValue.getMetadataGeneration()!!)!!

    open val name: String?
        get() = platformValue.getName()

    open val path: String?
        get() = platformValue.getPath()

    open val size: Long
        get() = Long(platformValue.getSizeBytes())

    open val timeCreated: Date?
        get() {
            val platformDate: java.util.Date = java.util.Date(platformValue.getCreationTimeMillis())
            return Date(platformValue = platformDate)
        }

    open val updated: Date?
        get() {
            val platformDate: java.util.Date = java.util.Date(platformValue.getUpdatedTimeMillis())
            return Date(platformValue = platformDate)
        }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class StorageReference: KotlinConverting<com.google.firebase.storage.StorageReference> {

    val platformValue: com.google.firebase.storage.StorageReference

    constructor(platformValue: com.google.firebase.storage.StorageReference) {
        this.platformValue = platformValue.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.storage.StorageReference = platformValue.sref()

    open val description: String
        get() = platformValue.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is StorageReference) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.platformValue == rhs.platformValue
    }

    open val storage: Storage
        get() = Storage(platformValue.storage)

    open val bucket: String
        get() = platformValue.bucket

    open val fullPath: String
        get() = platformValue.path

    open val name: String
        get() = platformValue.name

    open fun root(): StorageReference = StorageReference(platformValue.root)

    open fun parent(): StorageReference? {
        val parent_0 = platformValue.parent.sref()
        if (parent_0 == null) {
            return null
        }
        return StorageReference(parent_0)
    }

    open fun child(path: String): StorageReference = StorageReference(platformValue.child(path))

    open suspend fun downloadURL(): URL = Async.run l@{
        val uri: android.net.Uri = platformValue.downloadUrl.await()
        return@l URL(string = uri.toString())
    }

    open suspend fun getMetadata(): StorageMetadata = Async.run l@{
        val metadata = platformValue.getMetadata().await()
        return@l StorageMetadata(platformValue = metadata)
    }

    open suspend fun updateMetadata(metadata: StorageMetadata): StorageMetadata = Async.run l@{
        val metadata = platformValue.updateMetadata(metadata.platformValue).await()
        return@l StorageMetadata(platformValue = metadata)
    }

    open fun putFile(from: URL, metadata: StorageMetadata? = null, completion: (StorageMetadata?, Error?) -> Unit = { _, _ ->  }): StorageUploadTask {
        val fileURL = from
        val fileURI: android.net.Uri = android.net.Uri.parse(fileURL.kotlin().toString())

        val uploadTask = if (metadata == null) platformValue.putFile(fileURI) else platformValue.putFile(fileURI, metadata!!.platformValue, null)
        uploadTask.addOnFailureListener { exception -> completion(null, ErrorException(exception)) }.addOnSuccessListener { taskSnapshot ->
            val matchtarget_0 = taskSnapshot.metadata
            if (matchtarget_0 != null) {
                val metadata = matchtarget_0
                completion(StorageMetadata(platformValue = metadata), null)
            } else {
                completion(null, null)
            }
        }

        return StorageUploadTask(platformValue = uploadTask)
    }

    // TODO: Support onProgress once SKIP has support for Progress
    open suspend fun putFileAsync(from: URL, metadata: StorageMetadata? = null): StorageMetadata = Async.run l@{
        val url = from
        return@l withCheckedThrowingContinuation { continuation ->
            putFile(from = url, metadata = metadata) { metadata, error ->
                if (error != null) {
                    continuation.resume(throwing = error)
                } else {
                    continuation.resume(returning = metadata!!)
                }
            }
        }
    }

    open fun putData(uploadData: Data, metadata: StorageMetadata? = null, completion: (StorageMetadata?, Error?) -> Unit): StorageUploadTask {
        // putBytes(bytes, metadata) is @NonNull, so we need to use different methods for null vs. non-null metadata parameter
        val uploadTask = if (metadata == null) platformValue.putBytes(uploadData.platformValue) else platformValue.putBytes(uploadData.platformValue, metadata!!.platformValue)

        uploadTask.addOnFailureListener { exception -> completion(null, ErrorException(exception)) }.addOnSuccessListener { taskSnapshot ->
            val matchtarget_1 = taskSnapshot.metadata
            if (matchtarget_1 != null) {
                val metadata = matchtarget_1
                completion(StorageMetadata(platformValue = metadata), null)
            } else {
                completion(null, null)
            }
        }

        return StorageUploadTask(platformValue = uploadTask)
    }

    // TODO: Support onProgress once SKIP has support for Progress
    open suspend fun putDataAsync(uploadData: Data, metadata: StorageMetadata? = null): StorageMetadata = Async.run l@{
        return@l withCheckedThrowingContinuation { continuation ->
            putData(uploadData, metadata = metadata) { metadata, error ->
                if (error != null) {
                    continuation.resume(throwing = error)
                } else {
                    continuation.resume(returning = metadata!!)
                }
            }
        }
    }

    open fun write(toFile: URL, completion: ((URL?, Error?) -> Unit)? = null): StorageDownloadTask {
        val fileURL = toFile
        val fileURI: android.net.Uri = android.net.Uri.parse(fileURL.kotlin().toString())
        val downloadTask = platformValue.getFile(fileURI)

        downloadTask.addOnFailureListener { exception -> completion?.invoke(null, ErrorException(exception)) }.addOnSuccessListener { taskSnapshot: com.google.firebase.storage.FileDownloadTask.TaskSnapshot -> completion?.invoke(fileURL, null) }

        return StorageFileDownloadTask(platformValue = downloadTask)
    }

    /// Async version of getData(), but note that the iOS Firestore does not have an equivalent for some reason
    open suspend fun getDataAsync(maxSize: Long): Data = Async.run l@{
        val data: kotlin.ByteArray = platformValue.getBytes(maxSize).await()
        return@l Data(platformValue = data)
    }

    open fun getData(maxSize: Long, completion: (Data?, Error?) -> Unit): StorageDownloadTask {

        val downloadTask = platformValue.getBytes(maxSize)
        Task { ->
            try {
                val data: kotlin.ByteArray = downloadTask.await()
                completion(Data(platformValue = data), null)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                completion(null, error)
            }
        }
        return StoragBytesDownloadTask(platformValue = downloadTask)
    }

    open fun delete(completion: ((Error?) -> Unit)?) {
        Task { ->
            try {
                platformValue.delete().await()
                completion?.invoke(null)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                completion?.invoke(error)
            }
        }
    }

    open suspend fun delete(): Unit = Async.run {
        platformValue.delete().await()
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class StorageTask {
    internal constructor() {
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

interface StorageTaskManagement {
    fun pause()
    fun cancel()
    fun resume()
}

open class StorageObservableTask: StorageTask {
    internal constructor(): super() {
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass: StorageTask.CompanionClass() {
    }
}

class StorageUploadTask: StorageTaskManagement {
    val platformValue: com.google.firebase.storage.UploadTask

    internal constructor(platformValue: com.google.firebase.storage.UploadTask): super() {
        this.platformValue = platformValue.sref()
    }

    override fun cancel() {
        platformValue.cancel()
        return
    }

    override fun pause() {
        platformValue.pause()
        return
    }

    override fun resume() {
        platformValue.resume()
        return
    }

    companion object {
    }
}

open class StorageDownloadTask {

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

class StoragBytesDownloadTask: StorageDownloadTask {
    val platformValue: com.google.android.gms.tasks.Task<kotlin.ByteArray>

    internal constructor(platformValue: com.google.android.gms.tasks.Task<kotlin.ByteArray>): super() {
        this.platformValue = platformValue.sref()
    }

    companion object: StorageDownloadTask.CompanionClass() {
    }
}

class StorageFileDownloadTask: StorageDownloadTask, StorageTaskManagement {
    val platformValue: com.google.firebase.storage.FileDownloadTask

    internal constructor(platformValue: com.google.firebase.storage.FileDownloadTask): super() {
        this.platformValue = platformValue.sref()
    }

    override fun cancel() {
        platformValue.cancel()
        return
    }

    override fun pause() {
        platformValue.pause()
        return
    }

    override fun resume() {
        platformValue.resume()
        return
    }

    companion object: StorageDownloadTask.CompanionClass() {
    }
}

