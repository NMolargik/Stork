//
//  RegisterView.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.kit.*
import skip.foundation.*
import skip.model.*


@Suppress("MUST_BE_INITIALIZED")
internal class RegisterView: View, MutableStruct {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String> = skip.ui.AppStorage("", "errorMessage")
    internal var appState: AppState
        get() = _appState.wrappedValue
        set(newValue) {
            _appState.wrappedValue = newValue
        }
    internal var _appState: skip.ui.AppStorage<AppState> = skip.ui.AppStorage(AppState.register, "appState", serializer = { it.rawValue }, deserializer = { if (it is String) AppState(rawValue = it) else null })

    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    internal var showRegistration: Boolean
        get() = _showRegistration.wrappedValue
        set(newValue) {
            _showRegistration.wrappedValue = newValue
        }
    internal var _showRegistration: Binding<Boolean>

    internal var onAuthenticated: () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    constructor(showRegistration: Binding<Boolean>, onAuthenticated: () -> Unit) {
        this._showRegistration = showRegistration.sref()
        this.onAuthenticated = onAuthenticated
    }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            ZStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    NavigationStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ScrollView { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    VStack(alignment = HorizontalAlignment.leading, spacing = 10.0) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.tempProfile.email }, { it -> _profileViewModel.wrappedValue.tempProfile.email = it }), hintText = "Email Address", icon = Image(systemName = "envelope"), isSecure = false, iconColor = Color.blue).Compose(composectx)

                                            profileViewModel.emailError?.let { emailError ->
                                                Text(emailError)
                                                    .font(Font.caption)
                                                    .foregroundColor(Color.gray)
                                                    .padding(Edge.Set.top, -5.0).Compose(composectx)
                                            }

                                            CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.passwordText }, { it -> _profileViewModel.wrappedValue.passwordText = it }), hintText = "Password", icon = Image(systemName = "key"), isSecure = true, iconColor = Color.orange).Compose(composectx)

                                            profileViewModel.passwordError?.let { passwordError ->
                                                Text(passwordError)
                                                    .font(Font.caption)
                                                    .foregroundColor(Color.gray)
                                                    .padding(Edge.Set.top, -5.0).Compose(composectx)
                                            }

                                            CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.confirmPassword }, { it -> _profileViewModel.wrappedValue.confirmPassword = it }), hintText = "Confirm Password", icon = Image(systemName = "key"), isSecure = true, iconColor = Color.orange).Compose(composectx)

                                            profileViewModel.confirmPasswordError?.let { confirmPasswordError ->
                                                Text(confirmPasswordError)
                                                    .font(Font.caption)
                                                    .foregroundColor(Color.gray)
                                                    .padding(Edge.Set.top, -5.0).Compose(composectx)
                                            }

                                            CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.tempProfile.firstName }, { it -> _profileViewModel.wrappedValue.tempProfile.firstName = it }), hintText = "First Name", icon = Image(systemName = "1.square"), isSecure = false, iconColor = Color.green).Compose(composectx)

                                            profileViewModel.firstNameError?.let { firstNameError ->
                                                Text(firstNameError)
                                                    .font(Font.caption)
                                                    .foregroundColor(Color.gray)
                                                    .bold()
                                                    .padding(Edge.Set.top, -5.0).Compose(composectx)
                                            }

                                            CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.tempProfile.lastName }, { it -> _profileViewModel.wrappedValue.tempProfile.lastName = it }), hintText = "Last Name", icon = Image(systemName = "2.square"), isSecure = false, iconColor = Color.green).Compose(composectx)

                                            profileViewModel.lastNameError?.let { lastNameError ->
                                                Text(lastNameError)
                                                    .font(Font.caption)
                                                    .foregroundColor(Color.gray)
                                                    .padding(Edge.Set.top, -5.0).Compose(composectx)
                                            }

                                            Divider().Compose(composectx)

                                            Text(LocalizedStringKey(stringLiteral = "Select Your Birthday")).Compose(composectx)

                                            DatePicker(LocalizedStringKey(stringLiteral = "Select Birthday"), selection = Binding({ _profileViewModel.wrappedValue.tempProfile.birthday }, { it -> _profileViewModel.wrappedValue.tempProfile.birthday = it }), displayedComponents = DatePickerComponents.of(DatePickerComponents.date))
                                                .tint(Color.indigo)
                                                .labelsHidden()
                                                .environment({ it -> EnvironmentValues.shared.setlocale(it) }, Locale(identifier = "en_US"))
                                                .padding(Edge.Set.top, -15.0).Compose(composectx)

                                            profileViewModel.birthdayError?.let { birthdayError ->
                                                Text(birthdayError)
                                                    .font(Font.caption)
                                                    .foregroundColor(Color.gray)
                                                    .padding(Edge.Set.top, -5.0).Compose(composectx)
                                            }

                                            Divider().Compose(composectx)

                                            Text(LocalizedStringKey(stringLiteral = "Select Your Role")).Compose(composectx)

                                            Picker(LocalizedStringKey(stringLiteral = "Role"), selection = Binding({ _profileViewModel.wrappedValue.tempProfile.role }, { it -> _profileViewModel.wrappedValue.tempProfile.role = it })) { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    ForEach(ProfileRole.allCases, id = { it }) { role ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            Text(role.rawValue.capitalized).tag(role).Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }.Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }
                                            .pickerStyle(PickerStyle.segmented).Compose(composectx)

                                            Divider().Compose(composectx)

                                            HStack { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Spacer().Compose(composectx)

                                                    if ((profileViewModel.isWorking)) {
                                                        ProgressView()
                                                            .tint(Color.indigo)
                                                            .frame(height = 40.0)
                                                            .padding().Compose(composectx)
                                                    } else {
                                                        CustomButtonView(text = "Sign Up", width = 120.0, height = 40.0, color = Color.indigo, isEnabled = profileViewModel.isFormValid, onTapAction = { ->
                                                            Task(isMainActor = true) { ->
                                                                try {
                                                                    profileViewModel.registerWithEmail()
                                                                    onAuthenticated()
                                                                } catch (error: Throwable) {
                                                                    @Suppress("NAME_SHADOWING") val error = error.aserror()
                                                                    this.errorMessage = error.localizedDescription
                                                                    throw error as Throwable
                                                                }
                                                            }
                                                        }).Compose(composectx)
                                                    }

                                                    Spacer().Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding(20.0).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .navigationTitle(LocalizedStringKey(stringLiteral = "Sign Up"))
                            .toolbar(content = { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(action = { ->
                                        withAnimation { ->
                                            triggerHaptic()
                                            showRegistration = false
                                            appState = AppState.splash
                                        }
                                    }, label = { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(LocalizedStringKey(stringLiteral = "Log In Instead"))
                                                .fontWeight(Font.Weight.bold)
                                                .foregroundStyle(Color.orange).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }).Compose(composectx)
                                    ComposeResult.ok
                                }
                            })
                            .frame(maxWidth = Double.infinity).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onChange(of = profileViewModel.tempProfile.email) { _ -> profileViewModel.validateRegistrationForm() }
            .onChange(of = profileViewModel.passwordText) { _ -> profileViewModel.validateRegistrationForm() }
            .onChange(of = profileViewModel.confirmPassword) { _ -> profileViewModel.validateRegistrationForm() }
            .onChange(of = profileViewModel.tempProfile.firstName) { _ -> profileViewModel.validateRegistrationForm() }
            .onChange(of = profileViewModel.tempProfile.lastName) { _ -> profileViewModel.validateRegistrationForm() }
            .onChange(of = profileViewModel.tempProfile.birthday) { _ -> profileViewModel.validateRegistrationForm() }
            .onChange(of = profileViewModel.tempProfile.role) { _ ->
                triggerHaptic()
                profileViewModel.validateRegistrationForm()
            }
            .onAppear { -> profileViewModel.validateRegistrationForm() }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        val rememberedappState by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<AppState>, Any>) { mutableStateOf(_appState) }
        _appState = rememberedappState

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as RegisterView
        this._errorMessage = copy._errorMessage
        this._appState = copy._appState
        this._showRegistration = copy._showRegistration
        this.onAuthenticated = copy.onAuthenticated
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = RegisterView(this as MutableStruct)
}

// #Preview omitted
