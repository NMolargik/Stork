//
//  MusterAdminInviteUserView.swift
//
//
//  Created by Nick Molargik on 12/11/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class MusterAdminInviteUserView: View {
    private var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    private var _errorMessage: skip.ui.AppStorage<String>

    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    private lateinit var dismiss: DismissAction

    private var searchText: String
        get() = _searchText.wrappedValue
        set(newValue) {
            _searchText.wrappedValue = newValue
        }
    private var _searchText: skip.ui.State<String>
    private var searchEnabled: Boolean
        get() = _searchEnabled.wrappedValue
        set(newValue) {
            _searchEnabled.wrappedValue = newValue
        }
    private var _searchEnabled: skip.ui.State<Boolean>
    private var profiles: Array<Profile>
        get() = _profiles.wrappedValue.sref({ this.profiles = it })
        set(newValue) {
            _profiles.wrappedValue = newValue.sref()
        }
    private var _profiles: skip.ui.State<Array<Profile>>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            searchBar
                                .padding(Edge.Set.horizontal).Compose(composectx)

                            if (profiles.isEmpty && !profileViewModel.isWorking) {
                                Spacer().Compose(composectx)
                                VStack { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Image(systemName = "person.crop.badge.magnifyingglass")
                                            .foregroundStyle(Color.red).Compose(composectx)

                                        Text(LocalizedStringKey(stringLiteral = "No users found with that last name"))
                                            .multilineTextAlignment(TextAlignment.center)
                                            .font(Font.title3).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                                Spacer().Compose(composectx)
                            } else if (profileViewModel.isWorking) {
                                Spacer().Compose(composectx)
                                ProgressView()
                                    .tint(Color.indigo)
                                    .padding().Compose(composectx)
                                Spacer().Compose(composectx)
                            } else {
                                profilesListView.Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .navigationTitle(LocalizedStringKey(stringLiteral = "Invite User"))
                    .toolbar { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ToolbarItem(placement = ToolbarItemPlacement.cancellationAction) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(LocalizedStringKey(stringLiteral = "Close")) { -> dismiss() }
                                        .foregroundStyle(Color.red).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .onAppear { ->
                        refreshInvites()
                        updateSearchEnabled()
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedsearchText by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<String>, Any>) { mutableStateOf(_searchText) }
        _searchText = rememberedsearchText

        val rememberedsearchEnabled by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_searchEnabled) }
        _searchEnabled = rememberedsearchEnabled

        val rememberedprofiles by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Array<Profile>>, Any>) { mutableStateOf(_profiles) }
        _profiles = rememberedprofiles

        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        dismiss = EnvironmentValues.shared.dismiss

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    // MARK: - Search Bar
    private val searchBar: View
        get() {
            return HStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    CustomTextfieldView(text = Binding({ _searchText.wrappedValue }, { it -> _searchText.wrappedValue = it }), hintText = "Search by last name", icon = Image(systemName = "magnifyingglass"), isSecure = false, iconColor = Color.blue).Compose(composectx)

                    CustomButtonView(text = "Search", width = 80.0, height = 55.0, color = Color.indigo, isEnabled = searchEnabled, onTapAction = { ->
                        withAnimation { -> searchUsers() }
                    }).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onChange(of = searchText) { _ -> updateSearchEnabled() }
        }

    // MARK: - Profiles List View
    private val profilesListView: View
        get() {
            return ScrollView { ->
                ComposeBuilder { composectx: ComposeContext ->
                    LazyVStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ForEach(profiles, id = { it.id }) { profile ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ProfileRowView(existingInvitations = Binding({ _musterViewModel.wrappedValue.invites }, { it -> _musterViewModel.wrappedValue.invites = it }), profile = profile, currentUser = profileViewModel.profile, onInvite = { -> inviteUser(profile = profile) })
                                        .padding(Edge.Set.vertical, 5.0)
                                        .padding(Edge.Set.horizontal).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .refreshable { -> Async.run { searchUsers() } }
            .padding(Edge.Set.top)
        }

    // MARK: - Search Users
    private fun searchUsers() {
        if (profileViewModel.isWorking) {
            return
        }

        profileViewModel.isWorking = true
        Task { ->
            try {
                profiles = profileViewModel.listProfiles(id = null, firstName = null, lastName = searchText.trimmingCharacters(in_ = CharacterSet.whitespacesAndNewlines), email = null, birthday = null, role = null, primaryHospital = null, joinDate = null, musterId = null)
                print("Profiles found: ${profiles}")
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = "Failed to search for users. Please try again."
            }
            profileViewModel.isWorking = false
        }
    }

    // MARK: - Refresh Invitations
    private fun refreshInvites() {
        Task l@{ ->
            val muster_0 = musterViewModel.currentMuster.sref()
            if (muster_0 == null) {
                return@l
            }
            try {
                musterViewModel.getMusterInvitations(muster = muster_0)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
            }
        }
    }

    // MARK: - Invite User
    private fun inviteUser(profile: Profile) {
        Task { ->
            try {
                print("Inviting user: ${profile.firstName} ${profile.lastName}")
                musterViewModel.inviteUserToMuster(profile = profile, currentUser = profileViewModel.profile)
                refreshInvites()
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
            }
        }
    }

    // MARK: - Helper to Update Search Enabled State
    private fun updateSearchEnabled() {
        searchEnabled = !searchText.trimmingCharacters(in_ = CharacterSet.whitespacesAndNewlines).isEmpty
    }

    private constructor(errorMessage: String = "", searchText: String = "", searchEnabled: Boolean = false, profiles: Array<Profile> = arrayOf(), privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._searchText = skip.ui.State(searchText)
        this._searchEnabled = skip.ui.State(searchEnabled)
        this._profiles = skip.ui.State(profiles.sref())
    }

    constructor(): this(privatep = null) {
    }
}
