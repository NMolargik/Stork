//
//  TotalDeliveryAndBabyStatsView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 01/01/25.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

// MARK: - TotalDeliveryAndBabyStatsView
/// A SwiftUI view that displays the total number of deliveries and babies over the last six months.
internal class TotalDeliveryAndBabyStatsView: View {
    // MARK: - Properties

    /// Bindings to the grouped deliveries data, where each key is a month-year string and the value is an array of `Delivery` objects.
    internal var groupedDeliveries: Array<Tuple2<String, Array<Delivery>>>
        get() = _groupedDeliveries.wrappedValue.sref({ this.groupedDeliveries = it })
        set(newValue) {
            _groupedDeliveries.wrappedValue = newValue.sref()
        }
    internal var _groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>

    /// Total number of deliveries and babies.
    private var totalDeliveries: Int
        get() = _totalDeliveries.wrappedValue
        set(newValue) {
            _totalDeliveries.wrappedValue = newValue
        }
    private var _totalDeliveries: skip.ui.State<Int>
    private var totalBabies: Int
        get() = _totalBabies.wrappedValue
        set(newValue) {
            _totalBabies.wrappedValue = newValue
        }
    private var _totalBabies: skip.ui.State<Int>

    // MARK: - Body
    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Spacer().Compose(composectx)

                    Text(LocalizedStringKey(stringLiteral = "6 Month Stats"))
                        .fontWeight(Font.Weight.bold)
                        .foregroundStyle(Color.gray)
                        .offset(y = 25.0)
                        .frame(height = 10.0)
                        .padding(Edge.Set.bottom, 10.0).Compose(composectx)

                    HStack(spacing = 10.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Text({
                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                str.appendInterpolation(totalDeliveries)
                                str.appendLiteral(" Deliveries")
                                LocalizedStringKey(stringInterpolation = str)
                            }())
                                .font(Font.title)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.primary).Compose(composectx)

                            Text(LocalizedStringKey(stringLiteral = "&"))
                                .font(Font.title)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.primary).Compose(composectx)

                            Text({
                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                str.appendInterpolation(totalBabies)
                                str.appendLiteral(" Babies")
                                LocalizedStringKey(stringInterpolation = str)
                            }())
                                .font(Font.title)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.primary).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding().Compose(composectx)

                    Text(LocalizedStringKey(stringLiteral = "Recorded"))
                        .fontWeight(Font.Weight.bold)
                        .foregroundStyle(Color.gray)
                        .padding(Edge.Set.bottom, 10.0).Compose(composectx)

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onAppear { -> calculateTotalStats() }
            .onChange(of = groupedDeliveries.count) { _ -> calculateTotalStats() }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedtotalDeliveries by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Int>, Any>) { mutableStateOf(_totalDeliveries) }
        _totalDeliveries = rememberedtotalDeliveries

        val rememberedtotalBabies by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Int>, Any>) { mutableStateOf(_totalBabies) }
        _totalBabies = rememberedtotalBabies

        super.ComposeContent(composectx)
    }

    // MARK: - Helper Methods

    /// Calculates the total number of deliveries and babies from the grouped deliveries.
    private fun calculateTotalStats() {
        var deliveryCount = 0
        var babyCount = 0

        for ((_, deliveries) in groupedDeliveries.sref()) {
            deliveryCount += deliveries.count
            for (delivery in deliveries.sref()) {
                babyCount += delivery.babies.count
            }
        }

        totalDeliveries = deliveryCount
        totalBabies = babyCount
    }

    private constructor(groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>, totalDeliveries: Int = 0, totalBabies: Int = 0, privatep: Nothing? = null) {
        this._groupedDeliveries = groupedDeliveries
        this._totalDeliveries = skip.ui.State(totalDeliveries)
        this._totalBabies = skip.ui.State(totalBabies)
    }

    constructor(groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>): this(groupedDeliveries = groupedDeliveries, privatep = null) {
    }
}
