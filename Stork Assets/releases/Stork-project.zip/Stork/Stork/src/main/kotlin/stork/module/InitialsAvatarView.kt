//
//  SwiftUIView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 12/22/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class InitialsAvatarView: View, MutableStruct {
    internal lateinit var colorScheme: ColorScheme

    // MARK: - Properties

    /// The user's first name.
    internal val firstName: String

    /// The user's last name.
    internal val lastName: String

    /// Diameter of the avatar circle.
    internal var size: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Font of the initials.
    internal var font: Font
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    // MARK: - Computed Properties

    /// Extracts the first initial from the first name.
    private val firstInitial: String
        get() {
            val first_0 = firstName.first
            if (first_0 == null) {
                return ""
            }
            return String(first_0).uppercased()
        }

    /// Extracts the first initial from the last name.
    private val lastInitial: String
        get() {
            val first_1 = lastName.first
            if (first_1 == null) {
                return ""
            }
            return String(first_1).uppercased()
        }

    /// Combines the first and last initials.
    private val initials: String
        get() {
            val combined = firstInitial + lastInitial
            return if (combined.isEmpty) "?" else combined
        }

    // MARK: - Body

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            ZStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Circle()
                        .fill(Color.orange)
                        .frame(width = size, height = size).Compose(composectx)

                    Text(initials)
                        .font(font)
                        .foregroundColor(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                        .accessibilityLabel(Text({
                            val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                            str.appendLiteral("User initials: ")
                            str.appendInterpolation(initials)
                            LocalizedStringKey(stringInterpolation = str)
                        }())).Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        colorScheme = EnvironmentValues.shared.colorScheme

        super.ComposeContent(composectx)
    }

    constructor(firstName: String, lastName: String, size: Double = 40.0, font: Font = Font.headline) {
        this.firstName = firstName
        this.lastName = lastName
        this.size = size
        this.font = font
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = InitialsAvatarView(firstName, lastName, size, font)
}


// #Preview omitted
