//
//  MusterCreationView.swift
//
//  Created by Nick Molargik on 12/11/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class MusterCreationView: View {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    internal lateinit var dismiss: DismissAction
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()
    internal var hospitalViewModel: HospitalViewModel
        get() = _hospitalViewModel.wrappedValue
        set(newValue) {
            _hospitalViewModel.wrappedValue = newValue
        }
    internal var _hospitalViewModel = skip.ui.Environment<HospitalViewModel>()

    internal var showCreateMusterSheet: Boolean
        get() = _showCreateMusterSheet.wrappedValue
        set(newValue) {
            _showCreateMusterSheet.wrappedValue = newValue
        }
    internal var _showCreateMusterSheet: Binding<Boolean>

    private var selectedHospital: Hospital?
        get() = _selectedHospital.wrappedValue.sref({ this.selectedHospital = it })
        set(newValue) {
            _selectedHospital.wrappedValue = newValue.sref()
        }
    private var _selectedHospital: skip.ui.State<Hospital?> = skip.ui.State(null)

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            if ((musterViewModel.showHospitalSelection)) {
                HospitalListView(selectionMode = true, onSelection = { hospital ->
                    this.selectedHospital = hospital
                    musterViewModel.newMuster.primaryHospitalId = hospital.id
                    musterViewModel.showHospitalSelection = false
                    musterViewModel.validateCreationForm()

                }).Compose(composectx)
            } else {
                NavigationStack { ->
                    ComposeBuilder { composectx: ComposeContext ->
                        ScrollView { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                VStack(spacing = 20.0) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        // Muster Name Input
                                        Group { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                CustomTextfieldView(text = Binding({ _musterViewModel.wrappedValue.newMuster.name }, { it -> _musterViewModel.wrappedValue.newMuster.name = it }), hintText = "Enter Muster name", icon = Image(systemName = "tag.fill"), isSecure = false, iconColor = Color.indigo, characterLimit = 20).Compose(composectx)

                                                musterViewModel.nameError?.let { error ->
                                                    Text(error)
                                                        .foregroundStyle(Color.gray)
                                                        .font(Font.footnote).Compose(composectx)
                                                }
                                                ComposeResult.ok
                                            }
                                        }.Compose(composectx)

                                        // Hospital Selection
                                        VStack { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Text(this.selectedHospital?.facility_name ?: "Select A Primary Hospital")
                                                    .font(Font.headline)
                                                    .multilineTextAlignment(TextAlignment.center)
                                                    .foregroundStyle(Color.black).Compose(composectx)

                                                CustomButtonView(text = "Select A Hospital", width = 250.0, height = 40.0, color = Color.red, icon = Image(systemName = "building"), isEnabled = true, onTapAction = { -> musterViewModel.showHospitalSelection = true }).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }
                                        .frame(maxWidth = Double.infinity)
                                        .padding()
                                        .background { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Color.white
                                                    .cornerRadius(20.0)
                                                    .shadow(radius = 2.0).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }.Compose(composectx)

                                        Spacer().Compose(composectx)

                                        Text(LocalizedStringKey(stringLiteral = "It's that easy!\n\nYou'll be able to add members to your muster after creation."))
                                            .foregroundStyle(Color.black)
                                            .padding()
                                            .multilineTextAlignment(TextAlignment.center)
                                            .fontWeight(Font.Weight.semibold)
                                            .background { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Color.white
                                                        .cornerRadius(20.0)
                                                        .shadow(radius = 2.0).Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)

                                        Spacer().Compose(composectx)

                                        if ((musterViewModel.isWorking)) {
                                            ProgressView()
                                                .tint(Color.indigo)
                                                .frame(height = 70.0)
                                                .padding().Compose(composectx)
                                        } else {
                                            CustomButtonView(text = "Muster Up!", width = 200.0, height = 70.0, color = Color.indigo, icon = null, isEnabled = musterViewModel.creationFormValid, onTapAction = { ->
                                                withAnimation { -> createMuster() }
                                            }).Compose(composectx)
                                        }
                                        ComposeResult.ok
                                    }
                                }
                                .frame(maxWidth = Double.infinity)
                                .padding(20.0).Compose(composectx)

                                ComposeResult.ok
                            }
                        }
                        .navigationTitle(LocalizedStringKey(stringLiteral = "Create A Muster"))
                        .toolbar { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                ToolbarItem(placement = ToolbarItemPlacement.cancellationAction) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Button(action = { ->
                                            triggerHaptic()
                                            showCreateMusterSheet = false
                                            dismiss()
                                        }, label = { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Text(LocalizedStringKey(stringLiteral = "Cancel"))
                                                    .foregroundStyle(Color.orange).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        })
                                        .disabled(musterViewModel.isWorking).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)
                        ComposeResult.ok
                    }
                }
                .onChange(of = musterViewModel.newMuster.name) { _ -> musterViewModel.validateCreationForm() }.Compose(composectx)
            }
            ComposeResult.ok
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedselectedHospital by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Hospital?>, Any>) { mutableStateOf(_selectedHospital) }
        _selectedHospital = rememberedselectedHospital

        dismiss = EnvironmentValues.shared.dismiss
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!
        _hospitalViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = HospitalViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private fun createMuster() {
        Task(isMainActor = true) { ->
            try {
                musterViewModel.createMuster(profileId = profileViewModel.profile.id)

                val matchtarget_0 = musterViewModel.currentMuster
                if (matchtarget_0 != null) {
                    val muster = matchtarget_0
                    try {
                        profileViewModel.tempProfile = profileViewModel.profile
                        profileViewModel.tempProfile.musterId = muster.id

                        profileViewModel.updateProfile()

                        musterViewModel.musterMembers.append(profileViewModel.profile)

                    } catch (error: Throwable) {
                        @Suppress("NAME_SHADOWING") val error = error.aserror()
                        errorMessage = error.localizedDescription
                        musterViewModel.isWorking = false
                        throw error as Throwable
                    }
                } else {
                    musterViewModel.validateCreationForm()
                }
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                musterViewModel.validateCreationForm()
                musterViewModel.isWorking = false
            }

            musterViewModel.isWorking = false
            dismiss()
        }
    }

    private constructor(errorMessage: String = "", showCreateMusterSheet: Binding<Boolean>, selectedHospital: Hospital? = null, privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._showCreateMusterSheet = showCreateMusterSheet
        this._selectedHospital = skip.ui.State(selectedHospital.sref())
    }

    constructor(errorMessage: String = "", showCreateMusterSheet: Binding<Boolean>): this(errorMessage = errorMessage, showCreateMusterSheet = showCreateMusterSheet, privatep = null) {
    }
}
