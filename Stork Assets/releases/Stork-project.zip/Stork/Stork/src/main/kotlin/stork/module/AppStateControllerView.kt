//
//  AppStateControllerView.swift
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.foundation.*
import skip.ui.*
import stork.model.*
import skip.model.*

internal enum class AppState(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): RawRepresentable<String> {
    splash("splash"),
    register("register"),
    onboard("onboard"),
    paywall("paywall"),
    main("main");

    companion object {
        fun init(rawValue: String): AppState? {
            return when (rawValue) {
                "splash" -> AppState.splash
                "register" -> AppState.register
                "onboard" -> AppState.onboard
                "paywall" -> AppState.paywall
                "main" -> AppState.main
                else -> null
            }
        }
    }
}

internal fun AppState(rawValue: String): AppState? = AppState.init(rawValue = rawValue)

class AppStateControllerView: View {
    private var appState: AppState
        get() = _appState.wrappedValue
        set(newValue) {
            _appState.wrappedValue = newValue
        }
    private var _appState: skip.ui.AppStorage<AppState> = skip.ui.AppStorage(AppState.splash, "appState", serializer = { it.rawValue }, deserializer = { if (it is String) AppState(rawValue = it) else null })
    private var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    private var _errorMessage: skip.ui.AppStorage<String> = skip.ui.AppStorage("", "errorMessage")
    internal var selectedTab: Tab
        get() = _selectedTab.wrappedValue
        set(newValue) {
            _selectedTab.wrappedValue = newValue
        }
    internal var _selectedTab: skip.ui.AppStorage<Tab> = skip.ui.AppStorage(Tab.hospitals, "selectedTab", serializer = { it.rawValue }, deserializer = { if (it is String) Tab(rawValue = it) else null })
    private var isOnboardingComplete: Boolean
        get() = _isOnboardingComplete.wrappedValue
        set(newValue) {
            _isOnboardingComplete.wrappedValue = newValue
        }
    private var _isOnboardingComplete: skip.ui.AppStorage<Boolean> = skip.ui.AppStorage(false, "isOnboardingComplete")
    private var isPaywallComplete: Boolean
        get() = _isPaywallComplete.wrappedValue
        set(newValue) {
            _isPaywallComplete.wrappedValue = newValue
        }
    private var _isPaywallComplete: skip.ui.AppStorage<Boolean> = skip.ui.AppStorage(false, "isPaywallComplete")
    private var loggedIn: Boolean
        get() = _loggedIn.wrappedValue
        set(newValue) {
            _loggedIn.wrappedValue = newValue
        }
    private var _loggedIn: skip.ui.AppStorage<Boolean> = skip.ui.AppStorage(false, "loggedIn")

    private var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    private var _profileViewModel: skip.ui.State<ProfileViewModel>
    private var hospitalViewModel: HospitalViewModel
        get() = _hospitalViewModel.wrappedValue
        set(newValue) {
            _hospitalViewModel.wrappedValue = newValue
        }
    private var _hospitalViewModel: skip.ui.State<HospitalViewModel>
    private var deliveryViewModel: DeliveryViewModel
        get() = _deliveryViewModel.wrappedValue
        set(newValue) {
            _deliveryViewModel.wrappedValue = newValue
        }
    private var _deliveryViewModel: skip.ui.State<DeliveryViewModel>
    private var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    private var _musterViewModel: skip.ui.State<MusterViewModel>

    private var showRegistration: Boolean
        get() = _showRegistration.wrappedValue
        set(newValue) {
            _showRegistration.wrappedValue = newValue
        }
    private var _showRegistration: skip.ui.State<Boolean> = skip.ui.State(false)

    // Repositories
    private val deliveryRepository: DeliveryRepositoryInterface
    private val hospitalRepository: HospitalRepositoryInterface
    private val profileRepository: ProfileRepositoryInterface
    private val musterRepository: MusterRepositoryInterface
    private val locationProvider: LocationProviderInterface

    // Initializer
    constructor(deliveryRepository: DeliveryRepositoryInterface = DefaultDeliveryRepository(remoteDataSource = FirebaseDeliveryDataSource()), hospitalRepository: HospitalRepositoryInterface = DefaultHospitalRepository(remoteDataSource = FirebaseHospitalDatasource()), profileRepository: ProfileRepositoryInterface = DefaultProfileRepository(remoteDataSource = FirebaseProfileDataSource()), musterRepository: MusterRepositoryInterface = DefaultMusterRepository(remoteDataSource = FirebaseMusterDataSource()), locationProvider: LocationProviderInterface = LocationProvider()) {
        this.deliveryRepository = deliveryRepository.sref()
        this.hospitalRepository = hospitalRepository.sref()
        this.profileRepository = profileRepository.sref()
        this.musterRepository = musterRepository.sref()
        this.locationProvider = locationProvider.sref()

        // Initialize ViewModels with repositories
        _profileViewModel = State(wrappedValue = ProfileViewModel(profileRepository = profileRepository))
        _hospitalViewModel = State(wrappedValue = HospitalViewModel(hospitalRepository = hospitalRepository, locationProvider = locationProvider))
        _deliveryViewModel = State(wrappedValue = DeliveryViewModel(deliveryRepository = deliveryRepository))
        _musterViewModel = State(wrappedValue = MusterViewModel(musterRepository = musterRepository))
    }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            ZStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Group { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            when (appState) {
                                AppState.splash -> SplashView(showRegistration = Binding({ _showRegistration.wrappedValue }, { it -> _showRegistration.wrappedValue = it })).Compose(composectx)
                                AppState.register -> {
                                    RegisterView(showRegistration = Binding({ _showRegistration.wrappedValue }, { it -> _showRegistration.wrappedValue = it }), onAuthenticated = { ->
                                        withAnimation { ->
                                            this.loggedIn = true
                                            this.showRegistration = false

                                            if ((this.isOnboardingComplete)) {
                                                if ((this.isPaywallComplete)) {
                                                    appState = AppState.main
                                                } else {
                                                    appState = AppState.paywall
                                                }
                                            } else {
                                                appState = AppState.onboard
                                            }
                                        }
                                    }).Compose(composectx)
                                }
                                AppState.paywall -> PaywallView().Compose(composectx)
                                AppState.onboard -> OnboardingView().Compose(composectx)
                                AppState.main -> MainView().Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .onAppear { ->
                        print("Started")
                        checkAppState()
                    }.Compose(composectx)

                    if (!errorMessage.isEmpty) {
                        ErrorToastView().Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }
            .onChange(of = appState) { _ -> checkAppState() }
            .environmentObject(profileViewModel)
            .environmentObject(hospitalViewModel)
            .environmentObject(deliveryViewModel)
            .environmentObject(musterViewModel).Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedprofileViewModel by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<ProfileViewModel>, Any>) { mutableStateOf(_profileViewModel) }
        _profileViewModel = rememberedprofileViewModel

        val rememberedhospitalViewModel by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<HospitalViewModel>, Any>) { mutableStateOf(_hospitalViewModel) }
        _hospitalViewModel = rememberedhospitalViewModel

        val remembereddeliveryViewModel by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<DeliveryViewModel>, Any>) { mutableStateOf(_deliveryViewModel) }
        _deliveryViewModel = remembereddeliveryViewModel

        val rememberedmusterViewModel by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<MusterViewModel>, Any>) { mutableStateOf(_musterViewModel) }
        _musterViewModel = rememberedmusterViewModel

        val rememberedshowRegistration by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_showRegistration) }
        _showRegistration = rememberedshowRegistration

        val rememberedappState by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<AppState>, Any>) { mutableStateOf(_appState) }
        _appState = rememberedappState

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        val rememberedselectedTab by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Tab>, Any>) { mutableStateOf(_selectedTab) }
        _selectedTab = rememberedselectedTab

        val rememberedisOnboardingComplete by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_isOnboardingComplete) }
        _isOnboardingComplete = rememberedisOnboardingComplete

        val rememberedisPaywallComplete by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_isPaywallComplete) }
        _isPaywallComplete = rememberedisPaywallComplete

        val rememberedloggedIn by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_loggedIn) }
        _loggedIn = rememberedloggedIn

        super.ComposeContent(composectx)
    }

    internal fun checkAppState() {
        if (loggedIn) {
            withAnimation { ->
                if (profileViewModel.profile.email.isEmpty) {
                    Task { ->
                        try {
                            profileViewModel.fetchCurrentProfile()

                            if (deliveryViewModel.deliveries.isEmpty) {
                                deliveryViewModel.getUserDeliveries(profile = profileViewModel.profile)
                            }

                            if (!profileViewModel.profile.musterId.isEmpty && musterViewModel.currentMuster == null) {
                                musterViewModel.loadCurrentMuster(profileViewModel = profileViewModel)


                                musterViewModel.currentMuster.sref()?.let { muster ->
                                    deliveryViewModel.getMusterDeliveries(muster = muster)
                                }
                            }
                        } catch (error: Throwable) {
                            @Suppress("NAME_SHADOWING") val error = error.aserror()
                            errorMessage = error.localizedDescription
                        }
                    }
                } else if ((isOnboardingComplete)) {
                    selectedTab = Tab.home
                    appState = AppState.main
                } else {
                    appState = AppState.onboard
                }
            }
        } else {
            appState = if (showRegistration) AppState.register else AppState.splash
        }
    }

    companion object {
    }
}

// Preview with mock repositories
// #Preview omitted
