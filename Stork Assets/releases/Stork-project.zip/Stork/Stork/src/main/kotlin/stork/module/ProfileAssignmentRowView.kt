//
//  ProfileAssignmentRowView.swift
//
//
//  Created by Nick Molargik on 12/11/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class ProfileAssignmentRowView: View, MutableStruct {
    private var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    private var _errorMessage: skip.ui.AppStorage<String>

    /// The `Profile` displayed in this row.
    internal var profile: Profile
        get() = field.sref({ this.profile = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    /// A list (or set) of user IDs who are admins in the muster.
    /// We check whether `profile.id` is in this list to see if they're already an admin.
    internal var adminProfileIds: Set<String>
        get() = field.sref({ this.adminProfileIds = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    /// Called when we want to assign admin privileges to this user.
    internal var onAssign: () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            HStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    // Profile Information
                    VStack(alignment = HorizontalAlignment.leading, spacing = 4.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Text({
                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                str.appendInterpolation(profile.role.description)
                                str.appendLiteral(" ")
                                str.appendInterpolation(profile.firstName)
                                str.appendLiteral(" ")
                                str.appendInterpolation(profile.lastName)
                                LocalizedStringKey(stringInterpolation = str)
                            }())
                                .font(Font.title3)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.black).Compose(composectx)

                            HStack(spacing = 4.0) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Image(systemName = "birthday.cake.fill")
                                        .foregroundColor(Color.gray).Compose(composectx)

                                    Text(Companion.dateFormatter.string(from = profile.birthday))
                                        .foregroundColor(Color.gray).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)

                    Spacer().Compose(composectx)

                    // Single Button for Assignment or Admin Status
                    actionButton.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding()
            .frame(maxWidth = Double.infinity)
            .background(Color.white
                .cornerRadius(20.0)
                .shadow(radius = 2.0)).Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    // MARK: - Action Button
    private val actionButton: View
        get() {
            val isAdmin = adminProfileIds.contains(profile.id)

            return actionButton(text = if (isAdmin) "Admin" else "Assign", color = if (isAdmin) Color.gray else Color.blue, isEnabled = !isAdmin) { ->
                if (!isAdmin) {
                    onAssign()
                } else {
                    errorMessage = "User is already an admin."
                }
            }
        }

    // MARK: - Action Button Helper
    private fun actionButton(text: String, color: Color, isEnabled: Boolean, action: () -> Unit): View {
        return CustomButtonView(text = text, width = 120.0, height = 50.0, color = color, icon = null, isEnabled = isEnabled, onTapAction = { ->
            withAnimation { -> action() }
        })
    }

    private constructor(errorMessage: String = "", profile: Profile, adminProfileIds: Set<String>, onAssign: () -> Unit, privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this.profile = profile
        this.adminProfileIds = adminProfileIds
        this.onAssign = onAssign
    }

    constructor(profile: Profile, adminProfileIds: Set<String>, onAssign: () -> Unit): this(profile = profile, adminProfileIds = adminProfileIds, onAssign = onAssign, privatep = null) {
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = ProfileAssignmentRowView(errorMessage, profile, adminProfileIds, onAssign)

    companion object {

        private val dateFormatter: DateFormatter = linvoke l@{ ->
            val formatter = DateFormatter()
            formatter.dateFormat = "MM/dd/yyyy"
            return@l formatter
        }
    }
}

// #Preview omitted
