package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.foundation.*
import skip.ui.*
import stork.model.*
import skip.model.*

internal val logger: SkipLogger = SkipLogger(subsystem = "com.nickmolargik.stork", category = "Stork")

/// The Android SDK number we are running against, or `nil` if not running on Android
internal val androidSDK = ProcessInfo.processInfo.environment["android.os.Build.VERSION.SDK_INT"].optionalflatMap({ it -> Int(it) })

/// The shared top-level view for the app, loaded from the platform-specific App delegates below.
///
/// The default implementation merely loads the `ContentView` for the app and logs a message.
class RootView: View {
    private var useDarkMode: Boolean
        get() = _useDarkMode.wrappedValue
        set(newValue) {
            _useDarkMode.wrappedValue = newValue
        }
    private var _useDarkMode: skip.ui.AppStorage<Boolean> = skip.ui.AppStorage(false, "useDarkMode")

    internal var dailyResetManager: DailyResetManager
        get() = _dailyResetManager.wrappedValue
        set(newValue) {
            _dailyResetManager.wrappedValue = newValue
        }
    internal var _dailyResetManager: skip.ui.State<DailyResetManager> = skip.ui.State(DailyResetManager())

    constructor() {
    }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            AppStateControllerView()
                .preferredColorScheme(if (useDarkMode) ColorScheme.dark else ColorScheme.light)
                .task { -> MainActor.run {
                    logger.log("Welcome to Skip on ${if (androidSDK != null) "Android" else "Darwin"}!")
                    logger.warning("Skip app logs are viewable in the Xcode console for iOS; Android logs can be viewed in Studio or using adb logcat")
                } }
                .environmentObject(dailyResetManager).Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val remembereddailyResetManager by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<DailyResetManager>, Any>) { mutableStateOf(_dailyResetManager) }
        _dailyResetManager = remembereddailyResetManager

        val remembereduseDarkMode by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_useDarkMode) }
        _useDarkMode = remembereduseDarkMode

        super.ComposeContent(composectx)
    }

    companion object {
    }
}


