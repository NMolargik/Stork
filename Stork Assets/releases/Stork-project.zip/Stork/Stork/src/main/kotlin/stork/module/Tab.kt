//
//  Tab.swift
//
//  Created by Nick Molargik on 11/28/24.
//

package stork.module

import skip.lib.*

import skip.foundation.*

/// Represents the tabs available in the Stork app.
enum class Tab(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): RawRepresentable<String> {
    /// Home tab, showing user statistics and main information.
    home("home"),

    /// Deliveries tab, for managing and recording baby deliveries.
    deliveries("deliveries"),

    /// Hospitals tab, to view and manage hospital details.
    hospitals("hospitals"),

    /// Muster tab, for collaborating with and viewing muster details.
    muster("muster"),

    /// Settings tab, for managing app settings and preferences.
    settings("settings");

    /// The title displayed for the tab in the UI.
    internal val title: String
        get() {
            when (this) {
                Tab.home -> return "Home"
                Tab.deliveries -> return "Deliveries"
                Tab.hospitals -> return "Hospitals"
                Tab.muster -> return "Muster"
                Tab.settings -> return "Settings"
            }
        }

    /// The SF Symbol name used for the tab's icon.
    internal val icon: String
        get() {
            when (this) {
                Tab.home -> return "house"
                Tab.deliveries -> return "figure.child"
                Tab.hospitals -> return "building"
                Tab.muster -> return "person.3"
                Tab.settings -> return "gear"
            }
        }

    companion object {
        fun init(rawValue: String): Tab? {
            return when (rawValue) {
                "home" -> Tab.home
                "deliveries" -> Tab.deliveries
                "hospitals" -> Tab.hospitals
                "muster" -> Tab.muster
                "settings" -> Tab.settings
                else -> null
            }
        }
    }
}

fun Tab(rawValue: String): Tab? = Tab.init(rawValue = rawValue)
