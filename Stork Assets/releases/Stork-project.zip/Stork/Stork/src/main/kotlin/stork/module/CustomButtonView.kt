//
//  CustomButtonView.swift
//
//
//  Created by Nick Molargik on 11/27/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class CustomButtonView: View, MutableStruct {
    internal var text: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var width: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var height: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var color: Color
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var icon: Image? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var isEnabled: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    internal var onTapAction: () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            Button(action = { ->
                // Trigger haptic feedback when the button is pressed
                triggerHaptic()

                withAnimation { -> onTapAction() }
            }, label = { ->
                ComposeBuilder { composectx: ComposeContext ->
                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            icon?.let { icon ->
                                icon.Compose(composectx)
                            }

                            Text(text).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .foregroundStyle(Color.white)
                    .fontWeight(Font.Weight.bold)
                    .frame(width = width - 5, height = height - 5)
                    .background { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            (if (isEnabled) color else Color.gray)
                                .cornerRadius(20.0)
                                .shadow(radius = 2.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            })
            .disabled(!isEnabled).Compose(composectx)
        }
    }

    private fun triggerHaptic() = Unit

    constructor(text: String, width: Double, height: Double, color: Color, icon: Image? = null, isEnabled: Boolean, onTapAction: () -> Unit) {
        this.text = text
        this.width = width
        this.height = height
        this.color = color
        this.icon = icon
        this.isEnabled = isEnabled
        this.onTapAction = onTapAction
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = CustomButtonView(text, width, height, color, icon, isEnabled, onTapAction)
}

// #Preview omitted
