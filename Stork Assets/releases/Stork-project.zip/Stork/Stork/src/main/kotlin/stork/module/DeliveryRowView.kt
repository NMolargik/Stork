//
//  DeliveryRowView.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class DeliveryRowView: View, MutableStruct {
    internal var delivery: Delivery
        get() = field.sref({ this.delivery = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            HStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack(alignment = HorizontalAlignment.leading, spacing = 4.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Text(delivery.date.formatted(date = Date.FormatStyle.DateStyle.abbreviated, time = Date.FormatStyle.TimeStyle.shortened))
                                .font(Font.headline)
                                .foregroundColor(Color.black)
                                .padding(Edge.Set.horizontal, 5.0)
                                .padding(Edge.Set.vertical, 3.0)
                                .background { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Rectangle()
                                            .foregroundStyle(Color.white)
                                            .cornerRadius(20.0)
                                            .opacity(0.8).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)

                            // Baby summary
                            Text(babySummary(for_ = delivery.babies))
                                .font(Font.subheadline)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.white)
                                .padding(Edge.Set.leading, 6.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(8.0).Compose(composectx)

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .background { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Rectangle()
                        .foregroundStyle(LinearGradient(gradient = Gradient(colors = gradientColors(for_ = delivery.babies)), startPoint = UnitPoint.topLeading, endPoint = UnitPoint.bottomTrailing))
                        .overlay { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Rectangle()
                                    .foregroundStyle(Color.white)
                                    .opacity(0.1).Compose(composectx)
                                ComposeResult.ok
                            }
                        }
                        .cornerRadius(20.0)
                        .shadow(radius = 2.0).Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    /// Generates a summary of babies born in the delivery.
    /// - Parameter babies: The list of babies in the delivery.
    /// - Returns: A string summarizing the baby counts by sex.
    private fun babySummary(for_: Array<Baby>): String {
        val babies = for_
        // Initialize counters for each sex
        var maleCount = 0
        var femaleCount = 0
        var lossCount = 0

        // Manually count the number of each sex
        for (baby in babies.sref()) {
            when (baby.sex) {
                Sex.male -> maleCount += 1
                Sex.female -> femaleCount += 1
                Sex.loss -> lossCount += 1
            }
        }

        // Build the summary string
        var summary = Array<String>()

        if (maleCount > 0) {
            summary.append("${maleCount} boy${if (maleCount > 1) "s" else ""}    ")
        }

        if (femaleCount > 0) {
            summary.append("${femaleCount} girl${if (femaleCount > 1) "s" else ""}    ")
        }

        if (lossCount > 0) {
            summary.append("${lossCount} loss${if (lossCount > 1) "es" else ""}    ")
        }

        return if (summary.isEmpty) "No babies... somehow" else summary.joined(separator = " ")
    }

    /// Generates a gradient representing the distribution of sexes in the delivery.
    /// - Parameter babies: The list of babies in the delivery.
    /// - Returns: An array of `Color` objects representing the gradient stops.
    private fun gradientColors(for_: Array<Baby>): Array<Color> {
        val babies = for_
        // Group and sort colors by sex
        var colors: Array<Color> = arrayOf()
        colors.append(contentsOf = Array(repeating = Color.blue, count = babies.filter { it -> it.sex == Sex.male }.count))
        colors.append(contentsOf = Array(repeating = Color.pink, count = babies.filter { it -> it.sex == Sex.female }.count))
        colors.append(contentsOf = Array(repeating = Color.purple, count = babies.filter { it -> it.sex == Sex.loss }.count))
        return colors.sref()
    }

    constructor(delivery: Delivery) {
        this.delivery = delivery
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = DeliveryRowView(delivery)
}

// #Preview omitted
