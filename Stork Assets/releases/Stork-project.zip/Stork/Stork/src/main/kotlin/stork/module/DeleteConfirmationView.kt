//
//  DeleteConfirmationView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 12/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class DeleteConfirmationView: View, MutableStruct {
    internal var step: Int
        get() = _step.wrappedValue
        set(newValue) {
            _step.wrappedValue = newValue
        }
    internal var _step: Binding<Int>
    internal var showing: Boolean
        get() = _showing.wrappedValue
        set(newValue) {
            _showing.wrappedValue = newValue
        }
    internal var _showing: Binding<Boolean>
    internal var onDelete: () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack(spacing = 20.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if (step == 1) {
                                Text(LocalizedStringKey(stringLiteral = "Are you sure you want to delete your account?"))
                                    .font(Font.headline)
                                    .multilineTextAlignment(TextAlignment.center)
                                    .padding().Compose(composectx)

                                Text(LocalizedStringKey(stringLiteral = "This action will permanently delete all your personal information and your deliveries."))
                                    .font(Font.subheadline)
                                    .foregroundColor(Color.gray)
                                    .multilineTextAlignment(TextAlignment.center)
                                    .padding(Edge.Set.of(Edge.Set.leading, Edge.Set.trailing)).Compose(composectx)

                                HStack(spacing = 40.0) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        CustomButtonView(text = "Cancel", width = 120.0, height = 50.0, color = Color.blue, isEnabled = true, onTapAction = { ->
                                            triggerHaptic()
                                            showing = false
                                            step = 1
                                        }).Compose(composectx)

                                        CustomButtonView(text = "Continue", width = 120.0, height = 50.0, color = Color.red, isEnabled = true, onTapAction = { ->
                                            triggerHaptic()
                                            step = 2
                                        }).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            } else if (step == 2) {
                                Text(LocalizedStringKey(stringLiteral = "Are you absolutely sure you want to delete your account?"))
                                    .font(Font.headline)
                                    .multilineTextAlignment(TextAlignment.center)
                                    .padding().Compose(composectx)

                                Text(LocalizedStringKey(stringLiteral = "This will remove all your personal data and cannot be undone."))
                                    .font(Font.subheadline)
                                    .foregroundColor(Color.gray)
                                    .multilineTextAlignment(TextAlignment.center)
                                    .padding(Edge.Set.of(Edge.Set.leading, Edge.Set.trailing)).Compose(composectx)

                                HStack(spacing = 40.0) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        CustomButtonView(text = "Cancel", width = 120.0, height = 50.0, color = Color.blue, isEnabled = true, onTapAction = { ->
                                            triggerHaptic()
                                            showing = false
                                            step = 1
                                        }).Compose(composectx)

                                        CustomButtonView(text = "Delete", width = 120.0, height = 50.0, color = Color.red, isEnabled = true, onTapAction = { ->
                                            triggerHaptic()
                                            onDelete()
                                            showing = false
                                            step = 1
                                        }).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            }

                            Spacer().Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding()
                    .navigationTitle(LocalizedStringKey(stringLiteral = "Profile Deletion")).Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    private fun triggerHaptic() = Unit

    constructor(step: Binding<Int>, showing: Binding<Boolean>, onDelete: () -> Unit) {
        this._step = step
        this._showing = showing
        this.onDelete = onDelete
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = DeleteConfirmationView(_step, _showing, onDelete)
}

// #Preview omitted
