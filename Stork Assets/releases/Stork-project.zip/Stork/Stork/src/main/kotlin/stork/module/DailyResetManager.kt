//
//  DailyResetManager.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 12/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Set

import skip.ui.*
import skip.foundation.*
import skip.model.*

@Stable
internal open class DailyResetManager: ObservableObject {
    override val objectWillChange = ObservableObjectPublisher()
    private var timer: Timer? = null
    private var currentDate: Date = Date()
        get() = field.sref({ this.currentDate = it })
        set(newValue) {
            field = newValue.sref()
        }
    private var dailyLimit = 8 // or store this in a global config

    internal open var currentDeliveryCount: Int
        get() = _currentDeliveryCount.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _currentDeliveryCount.wrappedValue = newValue
        }
    internal var _currentDeliveryCount: skip.model.Published<Int> = skip.model.Published(0)

    internal constructor() {
        // On launch, check if we need to reset immediately
        resetCountIfNeeded()
        // Then schedule the next midnight reset
        scheduleMidnightReset()
    }

    open fun finalize() {
        // In some designs, you might NOT invalidate here if the manager is truly app-wide.
        // But typically, if the entire app is closing, there's no need to keep the timer alive anyway.
        timer?.invalidate()
    }

    /// If the date changed, reset the daily limit.
    private fun resetCountIfNeeded() {
        val calendar = Calendar.current.sref()
        if (!calendar.isDate(currentDate, inSameDayAs = Date())) {
            currentDeliveryCount = 0
            currentDate = Date()
        }
    }

    /// Sets up a timer that fires at midnight (12:01 AM) and resets the count.
    private fun scheduleMidnightReset() {
        timer?.invalidate()

        val now = Date()
        val calendar = Calendar.current.sref()

        // Extract the components for today
        val comps = calendar.dateComponents(setOf(Calendar.Component.year, Calendar.Component.month, Calendar.Component.day), from = now)

        // Make a date at 00:01
        var resetComps = comps.sref()
        resetComps.hour = 0
        resetComps.minute = 1
        resetComps.second = 0
        val resetDate_0 = calendar.date(from = resetComps)
        if (resetDate_0 == null) {
            return
        }

        // If resetDate is in the past for today, move to tomorrow
        val adjustedResetDate = (if ((resetDate_0 > now)) resetDate_0 else calendar.date(byAdding = Calendar.Component.day, value = 1, to = resetDate_0)!!).sref()

        val interval = adjustedResetDate.timeIntervalSince(now)

        // Schedule the timer to fire once at midnight
        timer = Timer.scheduledTimer(withTimeInterval = interval, repeats = false) l@{ _ ->
            if (this == null) {
                return@l
            }
            this.resetDailyLimit()
            this.scheduleMidnightReset() // schedule again for the next day
        }
    }

    private fun resetDailyLimit() {
        currentDeliveryCount = 0
        currentDate = Date()
        print("Daily limit has been reset at midnight.")
    }

    /// Example method that checks the daily limit
    internal open fun canSubmitDelivery(): Boolean = currentDeliveryCount < dailyLimit

    /// If user submits a delivery, increment
    internal open fun incrementDeliveryCount() {
        currentDeliveryCount += 1
    }
}
