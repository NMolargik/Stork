//
//  HospitalDetailView.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.foundation.*
import skip.ui.*
import stork.model.*
import skip.model.*

internal class HospitalDetailView: View {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    internal var hospitalViewModel: HospitalViewModel
        get() = _hospitalViewModel.wrappedValue
        set(newValue) {
            _hospitalViewModel.wrappedValue = newValue
        }
    internal var _hospitalViewModel = skip.ui.Environment<HospitalViewModel>()
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal lateinit var dismiss: DismissAction

    internal var location: Location?
        get() = _location.wrappedValue.sref({ this.location = it })
        set(newValue) {
            _location.wrappedValue = newValue.sref()
        }
    internal var _location: skip.ui.State<Location?> = skip.ui.State(null)

    internal val hospital: Hospital

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack(alignment = HorizontalAlignment.leading, spacing = 15.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    ZStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            val matchtarget_0 = location
                            if (matchtarget_0 != null) {
                                val location = matchtarget_0
                                MapView(latitude = location.latitude, longitude = location.longitude).Compose(composectx)
                            } else {
                                Rectangle().Compose(composectx)
                            }

                            VStack(alignment = HorizontalAlignment.leading) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    HStack(alignment = VerticalAlignment.top) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(hospital.facility_name)
                                                .font(Font.title2)
                                                .fontWeight(Font.Weight.bold)
                                                .foregroundStyle(Color.white)
                                                .padding(10.0)
                                                .background { ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        Rectangle()
                                                            .foregroundStyle(Color.black)
                                                            .cornerRadius(20.0)
                                                            .shadow(radius = 2.0)
                                                            .opacity(0.9).Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }.Compose(composectx)

                                            Spacer().Compose(composectx)

                                            Button(action = { ->
                                                triggerHaptic()

                                                withAnimation { -> managePrimaryHospital() }
                                            }, label = { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Image(systemName = if (profileViewModel.profile.primaryHospitalId == hospital.id) "star.fill" else "star")
                                                        .foregroundStyle(Color.yellow)
                                                        .font(Font.title2)
                                                        .padding(10.0)
                                                        .background { ->
                                                            ComposeBuilder { composectx: ComposeContext ->
                                                                Rectangle()
                                                                    .foregroundStyle(Color.black)
                                                                    .cornerRadius(20.0)
                                                                    .shadow(radius = 2.0)
                                                                    .opacity(0.9).Compose(composectx)
                                                                ComposeResult.ok
                                                            }
                                                        }.Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)

                                    Spacer().Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .padding(Edge.Set.horizontal).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .frame(height = 250.0).Compose(composectx)

                    VStack(alignment = HorizontalAlignment.leading, spacing = 15.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            HStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Image(systemName = "pin.fill")
                                        .foregroundStyle(Color.red)
                                        .frame(width = 30.0).Compose(composectx)

                                    Text({
                                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                        str.appendInterpolation(hospital.address)
                                        str.appendLiteral(" ")
                                        str.appendInterpolation(hospital.citytown)
                                        str.appendLiteral(", ")
                                        str.appendInterpolation(hospital.state)
                                        str.appendLiteral(" ")
                                        str.appendInterpolation(hospital.zip_code)
                                        str.appendLiteral(" - ")
                                        str.appendInterpolation(hospital.countyparish)
                                        LocalizedStringKey(stringInterpolation = str)
                                    }())
                                        .foregroundStyle(Color.black)
                                        .fontWeight(Font.Weight.semibold).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)

                            HStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Image(systemName = "phone.fill")
                                        .foregroundStyle(Color.green)
                                        .frame(width = 30.0).Compose(composectx)


                                    Text({
                                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                        str.appendInterpolation(hospital.telephone_number)
                                        LocalizedStringKey(stringInterpolation = str)
                                    }())
                                        .foregroundStyle(Color.black)
                                        .fontWeight(Font.Weight.semibold).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)

                            HStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Image(systemName = "info.square.fill")
                                        .foregroundStyle(Color.blue)
                                        .frame(width = 30.0).Compose(composectx)


                                    Text(hospital.hospital_type)
                                        .foregroundStyle(Color.black)
                                        .fontWeight(Font.Weight.semibold).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)

                            HStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Image(systemName = "dollarsign.square.fill")
                                        .foregroundStyle(Color.orange)
                                        .frame(width = 30.0).Compose(composectx)

                                    Text({
                                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                        str.appendLiteral("Owned by: ")
                                        str.appendInterpolation(hospital.hospital_ownership)
                                        LocalizedStringKey(stringInterpolation = str)
                                    }())
                                        .foregroundStyle(Color.black)
                                        .fontWeight(Font.Weight.semibold).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)

                            if ((hospital.meets_criteria_for_birthing_friendly_designation)) {
                                HStack { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Image(systemName = "figure.child")
                                            .foregroundStyle(Color.indigo)
                                            .frame(width = 30.0).Compose(composectx)

                                        Text(LocalizedStringKey(stringLiteral = "Birthing Center"))
                                            .foregroundStyle(Color.black)
                                            .fontWeight(Font.Weight.semibold).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            }

                            if ((hospital.emergency_services)) {
                                HStack { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Image(systemName = "cross.fill")
                                            .foregroundStyle(Color.red)
                                            .frame(width = 30.0).Compose(composectx)

                                        Text(LocalizedStringKey(stringLiteral = "Emergency Services"))
                                            .foregroundStyle(Color.black)
                                            .fontWeight(Font.Weight.semibold).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .font(Font.subheadline)
                    .padding()
                    .background { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Rectangle()
                                .cornerRadius(20.0)
                                .foregroundStyle(Color.white)
                                .shadow(radius = 2.0)
                                .opacity(0.9).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(Edge.Set.horizontal).Compose(composectx)

                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            // TODO: replace with a stork!
                            Image(systemName = "figure.child")
                                .foregroundStyle(Color.indigo)
                                .frame(width = 30.0).Compose(composectx)

                            // Text for delivery count
                            Text({
                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                str.appendInterpolation(hospital.deliveryCount)
                                str.appendLiteral(" reported deliver")
                                str.appendInterpolation(if (hospital.deliveryCount == 1) "y" else "ies")
                                LocalizedStringKey(stringInterpolation = str)
                            }())
                                .foregroundStyle(Color.black)
                                .fontWeight(Font.Weight.semibold).Compose(composectx)

                            ComposeResult.ok
                        }
                    }
                    .padding()
                    .background { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Rectangle()
                                .cornerRadius(20.0)
                                .foregroundStyle(Color.white)
                                .shadow(radius = 2.0)
                                .opacity(0.9).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(Edge.Set.horizontal).Compose(composectx)

                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ZStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Image(systemName = "figure.child")
                                        .foregroundStyle(Color.purple).Compose(composectx)

                                    Image(systemName = "figure.child")
                                        .foregroundStyle(Color.pink)
                                        .shadow(radius = 2.0)
                                        .offset(x = 8.0).Compose(composectx)

                                    Image(systemName = "figure.child")
                                        .foregroundStyle(Color.blue)
                                        .shadow(radius = 2.0)
                                        .offset(x = 15.0).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .offset(x = -5.0)
                            .frame(width = 30.0).Compose(composectx)

                            // Text for baby count
                            Text({
                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                str.appendInterpolation(hospital.babyCount)
                                str.appendLiteral(" reported bab")
                                str.appendInterpolation(if (hospital.babyCount == 1) "y" else "ies")
                                LocalizedStringKey(stringInterpolation = str)
                            }())
                                .foregroundStyle(Color.black)
                                .fontWeight(Font.Weight.semibold).Compose(composectx)

                            ComposeResult.ok
                        }
                    }
                    .padding()
                    .background { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Rectangle()
                                .cornerRadius(20.0)
                                .foregroundStyle(Color.white)
                                .shadow(radius = 2.0)
                                .opacity(0.9).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(Edge.Set.horizontal).Compose(composectx)

                    Spacer().Compose(composectx)

                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            CustomButtonView(text = "Back", width = 100.0, height = 40.0, color = Color.orange, icon = Image(systemName = "arrow.left"), isEnabled = true, onTapAction = { ->
                                withAnimation { -> dismiss() }
                            }).Compose(composectx)

                            Spacer().Compose(composectx)

                            CustomButtonView(text = if ((profileViewModel.profile.primaryHospitalId == hospital.id)) "Remove From Default" else "Set As Default", width = 200.0, height = 40.0, color = Color.indigo, isEnabled = true, onTapAction = { ->
                                withAnimation { -> managePrimaryHospital() }
                            }).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .toolbar(Visibility.hidden)
            .onAppear { ->
                triggerHaptic()
                Task(isMainActor = true) { ->
                    val address = makeAddress()
                    val location = hospitalViewModel.mainactor { it.locationProvider }.geocodeAddress(address)
                    this.location = Location(latitude = location.latitude, longitude = location.longitude)

                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedlocation by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Location?>, Any>) { mutableStateOf(_location) }
        _location = rememberedlocation

        _hospitalViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = HospitalViewModel::class)!!
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        dismiss = EnvironmentValues.shared.dismiss

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    internal fun makeAddress(): String = "${hospital.address} ${hospital.citytown}, ${hospital.state}, ${hospital.zip_code}"

    internal fun managePrimaryHospital() {
        if ((profileViewModel.profile.primaryHospitalId == hospital.id)) {
            profileViewModel.profile.primaryHospitalId = ""
        } else {
            profileViewModel.profile.primaryHospitalId = hospital.id
        }

        profileViewModel.tempProfile = profileViewModel.profile

        Task { ->
            try {
                profileViewModel.updateProfile()
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
            }
        }
    }

    constructor(errorMessage: String = "", location: Location? = null, hospital: Hospital) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._location = skip.ui.State(location.sref())
        this.hospital = hospital.sref()
    }
}

// #Preview omitted
