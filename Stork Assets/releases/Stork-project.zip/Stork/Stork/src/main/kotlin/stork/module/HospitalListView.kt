//
//  HospitalListView.swift
//
//
//  Created by Nick Molargik on 11/29/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class HospitalListView: View, MutableStruct {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    internal var hospitalViewModel: HospitalViewModel
        get() = _hospitalViewModel.wrappedValue
        set(newValue) {
            _hospitalViewModel.wrappedValue = newValue
        }
    internal var _hospitalViewModel = skip.ui.Environment<HospitalViewModel>()
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    private var navigationPath: Array<String>
        get() = _navigationPath.wrappedValue.sref({ this.navigationPath = it })
        set(newValue) {
            _navigationPath.wrappedValue = newValue.sref()
        }
    private var _navigationPath: skip.ui.State<Array<String>>

    internal var selectionMode: Boolean
        get() = _selectionMode.wrappedValue
        set(newValue) {
            _selectionMode.wrappedValue = newValue
        }
    internal var _selectionMode: skip.ui.State<Boolean>
    internal var onSelection: (Hospital) -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack(path = Binding({ _navigationPath.wrappedValue }, { it -> _navigationPath.wrappedValue = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            CustomTextfieldView(text = Binding({ _hospitalViewModel.wrappedValue.searchQuery }, { it -> _hospitalViewModel.wrappedValue.searchQuery = it }), hintText = "Search by name", icon = Image(systemName = if (hospitalViewModel.usingLocation) "location.fill" else "magnifyingglass"), isSecure = false, iconColor = if (hospitalViewModel.usingLocation) Color.blue else Color.orange)
                                .onChange(of = hospitalViewModel.searchQuery) { query ->
                                    withAnimation { -> hospitalViewModel.searchEnabled = query.count > 0 }
                                }
                                .onAppear { -> hospitalViewModel.searchEnabled = hospitalViewModel.searchQuery.count > 0 }.Compose(composectx)

                            if ((hospitalViewModel.searchEnabled)) {
                                CustomButtonView(text = "Search", width = 80.0, height = 55.0, color = Color.indigo, isEnabled = hospitalViewModel.searchEnabled, onTapAction = { ->
                                    Task(isMainActor = true) { ->
                                        hospitalViewModel.searchHospitals()
                                    }
                                }).Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .padding(Edge.Set.horizontal).Compose(composectx)

                    if ((hospitalViewModel.hospitals.count == 0 && !hospitalViewModel.isWorking)) {
                        Text(LocalizedStringKey(stringLiteral = "No hospitals found. Either Stork services are down, or you should change your search criteria.\n\nIf you feel your hospital is missing, report it using the button above."))
                            .padding()
                            .multilineTextAlignment(TextAlignment.center)
                            .background { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Color.white
                                        .cornerRadius(20.0)
                                        .shadow(radius = 2.0).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .padding().Compose(composectx)
                    }

                    List(hospitalViewModel.hospitals, id = { it.id }) { hospital ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if ((selectionMode)) {
                                Button(action = { ->
                                    withAnimation { ->
                                        print("Selecting ${hospital.facility_name}")
                                        onSelection(hospital)
                                    }
                                }, label = { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        HospitalRowView(selectionMode = Binding({ _selectionMode.wrappedValue }, { it -> _selectionMode.wrappedValue = it }), hospital = hospital).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }).Compose(composectx)
                            } else {
                                NavigationLink(destination = HospitalDetailView(hospital = hospital)) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        HospitalRowView(selectionMode = Binding({ _selectionMode.wrappedValue }, { it -> _selectionMode.wrappedValue = it }), hospital = hospital).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .navigationTitle(LocalizedStringKey(stringLiteral = "Hospitals"))
                    .navigationDestination(for_ = String::class) { value ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if (value == "ProfileView") {
                                Text(LocalizedStringKey(stringLiteral = "Shared Profile View")).Compose(composectx)
                            } else {
                                Text({
                                    val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                    str.appendLiteral("Other View: ")
                                    str.appendInterpolation(value)
                                    LocalizedStringKey(stringInterpolation = str)
                                }()).Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .toolbar { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if ((hospitalViewModel.usingLocation)) {
                                ToolbarItem(placement = ToolbarItemPlacement.topBarLeading) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        HStack { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Spacer().Compose(composectx)

                                                Text(LocalizedStringKey(stringLiteral = "Searching by location"))
                                                    .fontWeight(Font.Weight.bold).Compose(composectx)
                                                Image(systemName = "location.circle.fill").Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }
                                        .foregroundStyle(Color.blue)
                                        .padding(Edge.Set.trailing).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            } else {
                                ToolbarItem { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Button(action = { ->
                                            triggerHaptic()

                                            withAnimation { ->
                                                hospitalViewModel.searchQuery = ""
                                                this.getNearbyHospitals()
                                            }
                                        }, label = { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Text(LocalizedStringKey(stringLiteral = "Use Location"))
                                                    .fontWeight(Font.Weight.bold)
                                                    .foregroundStyle(Color.blue).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            }

                            ToolbarItem { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(action = { ->
                                        triggerHaptic()

                                        withAnimation { -> hospitalViewModel.isMissingHospitalSheetPresented = true }
                                    }, label = { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(LocalizedStringKey(stringLiteral = "Missing?"))
                                                .foregroundStyle(Color.orange)
                                                .fontWeight(Font.Weight.bold).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onAppear { ->
                if ((hospitalViewModel.hospitals.count == 0)) {
                    getNearbyHospitals()
                }
            }
            .sheet(isPresented = Binding({ _hospitalViewModel.wrappedValue.isMissingHospitalSheetPresented }, { it -> _hospitalViewModel.wrappedValue.isMissingHospitalSheetPresented = it }), content = { ->
                ComposeBuilder { composectx: ComposeContext ->
                    MissingHospitalSheetView(onSubmit = { hospitalName -> onSelection(hospitalViewModel.createMissingHospital(name = hospitalName)) })
                        .presentationDetents(setOf(PresentationDetent.medium)).Compose(composectx)
                    ComposeResult.ok
                }
            }).Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberednavigationPath by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Array<String>>, Any>) { mutableStateOf(_navigationPath) }
        _navigationPath = rememberednavigationPath

        val rememberedselectionMode by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_selectionMode) }
        _selectionMode = rememberedselectionMode

        _hospitalViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = HospitalViewModel::class)!!
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private fun getNearbyHospitals() {
        Task { ->
            try {
                hospitalViewModel.fetchHospitalsNearby()

            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
                throw error as Throwable
            }
        }
    }

    private constructor(errorMessage: String = "", navigationPath: Array<String> = arrayOf(), selectionMode: Boolean = false, onSelection: (Hospital) -> Unit, privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._navigationPath = skip.ui.State(navigationPath.sref())
        this._selectionMode = skip.ui.State(selectionMode)
        this.onSelection = onSelection
    }

    constructor(errorMessage: String = "", selectionMode: Boolean = false, onSelection: (Hospital) -> Unit): this(errorMessage = errorMessage, selectionMode = selectionMode, onSelection = onSelection, privatep = null) {
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = HospitalListView(errorMessage, navigationPath, selectionMode, onSelection)
}

// #Preview omitted
