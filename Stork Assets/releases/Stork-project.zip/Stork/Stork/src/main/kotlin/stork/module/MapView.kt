//
//  MapView.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
// skip.yml: implementation("com.google.maps.android:maps-compose:4.3.3")
import com.google.maps.android.compose.*
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import skip.foundation.*
import skip.model.*

internal class MapView: View {
    internal val latitude: Double
    internal val longitude: Double

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            ComposeView { ctx ->
                GoogleMap(cameraPositionState = rememberCameraPositionState { -> position = CameraPosition.fromLatLngZoom(LatLng(latitude, longitude), 12.0f) })
            }.Compose(composectx)
        }
    }

    constructor(latitude: Double, longitude: Double) {
        this.latitude = latitude
        this.longitude = longitude
    }
}
