//
//  DeliveryListView.swift
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class DeliveryListView: View {
    // MARK: - App Storage Variables
    internal var leftHanded: Boolean
        get() = _leftHanded.wrappedValue
        set(newValue) {
            _leftHanded.wrappedValue = newValue
        }
    internal var _leftHanded: skip.ui.AppStorage<Boolean>

    // MARK: - Environment Variables
    internal lateinit var colorScheme: ColorScheme
    internal var deliveryViewModel: DeliveryViewModel
        get() = _deliveryViewModel.wrappedValue
        set(newValue) {
            _deliveryViewModel.wrappedValue = newValue
        }
    internal var _deliveryViewModel = skip.ui.Environment<DeliveryViewModel>()

    // MARK: - Bindings
    internal var showingDeliveryAddition: Boolean
        get() = _showingDeliveryAddition.wrappedValue
        set(newValue) {
            _showingDeliveryAddition.wrappedValue = newValue
        }
    internal var _showingDeliveryAddition: Binding<Boolean>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            List { ->
                ComposeBuilder { composectx: ComposeContext ->
                    if (deliveryViewModel.deliveries.isEmpty) {
                        emptyStateView.Compose(composectx)
                    } else {
                        ForEach(deliveryViewModel.groupedDeliveries, id = { it.key }) { (monthYear, deliveries) ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Section(header = Text(monthYear)
                                    .font(Font.title)
                                    .foregroundStyle(Color.primary)
                                    .fontWeight(Font.Weight.bold)
                                    .opacity(0.2)
                                    .offset(x = -15.0)) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        if (deliveries.isEmpty) {
                                            Text(LocalizedStringKey(stringLiteral = "No deliveries found"))
                                                .font(Font.subheadline)
                                                .foregroundColor(Color.gray).Compose(composectx)
                                        } else {
                                            ForEach(deliveries, id = { it.id }) { delivery ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    NavigationLink(value = delivery) { ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            DeliveryRowView(delivery = delivery).Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }
                                                    .listRowSeparator(Visibility.hidden).Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)
                                        }
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        colorScheme = EnvironmentValues.shared.colorScheme
        _deliveryViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = DeliveryViewModel::class)!!

        val rememberedleftHanded by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_leftHanded) }
        _leftHanded = rememberedleftHanded

        super.ComposeContent(composectx)
    }

    private val emptyStateView: View
        get() {
            return VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Spacer().Compose(composectx)

                    ZStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "figure.child")
                                .foregroundStyle(Color.purple).Compose(composectx)

                            Image(systemName = "figure.child")
                                .foregroundStyle(Color.pink)
                                .shadow(radius = 2.0)
                                .offset(x = 16.0).Compose(composectx)

                            Image(systemName = "figure.child")
                                .foregroundStyle(Color.blue)
                                .shadow(radius = 2.0)
                                .offset(x = 32.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .font(Font.largeTitle)
                    .offset(x = -5.0)
                    .frame(width = 30.0).Compose(composectx)

                    Text(LocalizedStringKey(stringLiteral = "No deliveries recorded yet. Use the button above to get started!"))
                        .multilineTextAlignment(TextAlignment.center)
                        .font(Font.title3)
                        .fontWeight(Font.Weight.semibold).Compose(composectx)

                    Spacer(minLength = 300.0).Compose(composectx)

                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Spacer().Compose(composectx)
                            Image(systemName = "exclamationmark.circle")
                                .font(Font.title)
                                .foregroundStyle(Color.blue)
                                .padding(Edge.Set.trailing).Compose(composectx)

                            Text(LocalizedStringKey(stringLiteral = "You can submit up to 8 deliveries per day"))
                                .multilineTextAlignment(TextAlignment.center).Compose(composectx)

                            Spacer().Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(8.0)
                    .background { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Rectangle()
                                .foregroundStyle(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                                .cornerRadius(20.0)
                                .shadow(radius = 2.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding()
        }

    constructor(leftHanded: Boolean = false, showingDeliveryAddition: Binding<Boolean>) {
        this._leftHanded = skip.ui.AppStorage(wrappedValue = leftHanded, "leftHanded")
        this._showingDeliveryAddition = showingDeliveryAddition
    }
}

// #Preview omitted
