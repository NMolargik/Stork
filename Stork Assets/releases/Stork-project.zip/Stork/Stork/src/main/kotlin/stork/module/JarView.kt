//
//  JarView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 01/01/25.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class JarView: View, MutableStruct {
    internal lateinit var colorScheme: ColorScheme

    /// The deliveries coming in from elsewhere in the app
    internal var deliveries: Array<Delivery>
        get() = _deliveries.wrappedValue.sref({ this.deliveries = it })
        set(newValue) {
            _deliveries.wrappedValue = newValue.sref()
        }
    internal var _deliveries: Binding<Array<Delivery>>

    internal var headerText: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    // Marble simulation states
    private var marbles: Array<Marble>
        get() = _marbles.wrappedValue.sref({ this.marbles = it })
        set(newValue) {
            _marbles.wrappedValue = newValue.sref()
        }
    private var _marbles: skip.ui.State<Array<Marble>>
    private var pendingMarbles: Array<Marble>
        get() = _pendingMarbles.wrappedValue.sref({ this.pendingMarbles = it })
        set(newValue) {
            _pendingMarbles.wrappedValue = newValue.sref()
        }
    private var _pendingMarbles: skip.ui.State<Array<Marble>>
    private var displayedBabyIDs: Set<String>
        get() = _displayedBabyIDs.wrappedValue.sref({ this.displayedBabyIDs = it })
        set(newValue) {
            _displayedBabyIDs.wrappedValue = newValue.sref()
        }
    private var _displayedBabyIDs: skip.ui.State<Set<String>>
    private var isAddingMarbles: Boolean
        get() = _isAddingMarbles.wrappedValue
        set(newValue) {
            _isAddingMarbles.wrappedValue = newValue
        }
    private var _isAddingMarbles: skip.ui.State<Boolean>

    private val maxMarbleCount: Int
    private val marbleRadius: Double
    private val collisionIterations: Int
    private val gravity: Double
    private val damping: Double
    private val friction: Double

    private val timer: Publisher<Date, Never>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            GeometryReader { geometry ->
                ComposeBuilder { composectx: ComposeContext ->
                    ZStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Rectangle()
                                .foregroundColor(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                                .cornerRadius(20.0)
                                .shadow(color = if (colorScheme == ColorScheme.dark) Color.white else Color.black, radius = 2.0).Compose(composectx)

                            VStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Text(headerText)
                                        .padding(8.0)
                                        .foregroundStyle(Color.gray)
                                        .font(Font.headline)
                                        .fontWeight(Font.Weight.bold)
                                        .background { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Rectangle()
                                                    .foregroundStyle(Color.white)
                                                    .cornerRadius(20.0)
                                                    .shadow(radius = 2.0).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }
                                        .padding(Edge.Set.top, 20.0).Compose(composectx)

                                    Spacer().Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)

                            ForEach(marbles) { marble ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Circle()
                                        .fill(RadialGradient(gradient = Gradient(colors = arrayOf(
                                            marble.color.opacity(0.6),
                                            marble.color
                                        )), center = UnitPoint(x = 0.35, y = 0.35), startRadius = 5.0, endRadius = marble.diameter / 2))
                                        .shadow(color = Color.black.opacity(0.3), radius = 3.0, x = 2.0, y = 2.0)
                                        .frame(width = marble.diameter, height = marble.diameter)
                                        .position(marble.position).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .onAppear { -> refreshMarbles(in_ = geometry.size) }
                    .onChange(of = deliveries) { _ -> refreshMarbles(in_ = geometry.size) }
                    .onReceive(timer) { _ -> updateMarbles(in_ = geometry.size) }.Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedmarbles by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Array<Marble>>, Any>) { mutableStateOf(_marbles) }
        _marbles = rememberedmarbles

        val rememberedpendingMarbles by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Array<Marble>>, Any>) { mutableStateOf(_pendingMarbles) }
        _pendingMarbles = rememberedpendingMarbles

        val remembereddisplayedBabyIDs by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Set<String>>, Any>) { mutableStateOf(_displayedBabyIDs) }
        _displayedBabyIDs = remembereddisplayedBabyIDs

        val rememberedisAddingMarbles by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_isAddingMarbles) }
        _isAddingMarbles = rememberedisAddingMarbles

        colorScheme = EnvironmentValues.shared.colorScheme

        super.ComposeContent(composectx)
    }

    private fun refreshMarbles(in_: CGSize) {
        val size = in_
        val monthDeliveries = deliveriesForCurrentMonth(deliveries)

        // Filter babies not already displayed
        val newBabies = monthDeliveries.flatMap { it -> it.babies }.filter { it -> !displayedBabyIDs.contains(it.id) }

        // Add new marbles to pending list
        for (baby in newBabies.sref()) {
            if (marbles.count + pendingMarbles.count < maxMarbleCount) {
                val newMarble = createMarble(in_ = size, color = baby.sex.color)
                pendingMarbles.append(newMarble)
                displayedBabyIDs.insert(baby.id)
            }
        }

        // Add pending marbles sequentially
        addPendingMarblesSequentially()
    }


    // MARK: - Marble Addition Logic

    /// Adds pending marbles one at a time with a slight delay between each addition.
    private fun addPendingMarblesSequentially() {
        if (isAddingMarbles) {
            return
        }
        if (pendingMarbles.isEmpty) {
            return
        }

        isAddingMarbles = true

        Task { ->
            while (!pendingMarbles.isEmpty) {
                // Take the first pending marble
                val marble = pendingMarbles.removeFirst()

                // Add to marbles on the main thread
                MainActor.run { -> marbles.append(marble) }

                // Small delay to add marbles quickly but sequentially
                try { Task.sleep(nanoseconds = 50_000_000) } catch (_: Throwable) { null } // 0.05 seconds
            }

            // Mark as done
            MainActor.run { -> isAddingMarbles = false }
        }
    }

    // MARK: - Helpers

    /// Filters the given deliveries to only those that fall within the **current month**.
    /// For example, if today is Jan 6, 2025, this returns deliveries from Jan 1, 2025 to Jan 31, 2025.
    private fun deliveriesForCurrentMonth(all: Array<Delivery>): Array<Delivery> {
        val calendar = Calendar.current.sref()
        val now = Date()
        val startOfMonth_0 = calendar.date(from = calendar.dateComponents(setOf(Calendar.Component.year, Calendar.Component.month), from = now))
        if (startOfMonth_0 == null) {
            return arrayOf()
        }
        val startOfNextMonth_0 = calendar.date(byAdding = Calendar.Component.month, value = 1, to = startOfMonth_0)
        if (startOfNextMonth_0 == null) {
            return arrayOf()
        }

        // We want deliveries from [startOfMonth ..< startOfNextMonth)
        return all.filter { delivery -> delivery.date >= startOfMonth_0 && delivery.date < startOfNextMonth_0 }
    }

    /// Creates a marble with random x-position and velocity, ensuring no initial overlap.
    /// Positions it in the top half of the container so it can fall down.
    /// - Parameters:
    ///   - size: The size of the container.
    ///   - color: The color of the marble based on baby's sex.
    /// - Returns: A new `Marble` instance.
    private fun createMarble(in_: CGSize, color: Color): Marble {
        val size = in_
        val minX = marbleRadius
        val maxX = max(marbleRadius, size.width - marbleRadius)
        val minY = marbleRadius
        val maxY = max(marbleRadius, size.height / 2)

        var position: CGPoint
        var attempts = 0
        val maxAttempts = 100
        var isOverlapping: Boolean

        do {
            position = CGPoint(x = Double.random(in_ = minX..maxX), y = Double.random(in_ = minY..maxY))

            isOverlapping = marbles.contains l@{ existingMarble ->
                val dx = existingMarble.position.x - position.x
                val dy = existingMarble.position.y - position.y
                val distance = sqrt(dx * dx + dy * dy)
                return@l distance < (existingMarble.marbleRadius + marbleRadius + 2) // Small buffer to prevent immediate overlap
            }

            attempts += 1
            if (attempts >= maxAttempts) {
                // If unable to find a non-overlapping position, proceed anyway
                break
            }
        } while (isOverlapping)

        return Marble(id = UUID(), position = position, velocity = Velocity(dx = Double.random(in_ = -1.0..1.0), dy = Double.random(in_ = -1.0..1.0)), marbleRadius = marbleRadius, color = color)
    }

    /// Applies all the physics steps each frame
    private fun updateMarbles(in_: CGSize) {
        val size = in_
        // Gravity & friction
        for (i in marbles.indices.sref()) {
            marbles[i].velocity.dy += gravity
            marbles[i].velocity.dx *= friction
            marbles[i].velocity.dy *= friction
            marbles[i].velocity.dx = min(max(marbles[i].velocity.dx, -3.0), 3.0)
            marbles[i].velocity.dy = min(max(marbles[i].velocity.dy, -3.0), 3.0)
        }

        // Move marbles
        for (i in marbles.indices.sref()) {
            marbles[i].position.x += marbles[i].velocity.dx
            marbles[i].position.y += marbles[i].velocity.dy
        }

        // Collision resolution
        for (unusedbinding in 0..<collisionIterations) {
            for (i in 0..<marbles.count) {
                for (j in (i + 1)..<marbles.count) {
                    var m1 = marbles[i].sref()
                    var m2 = marbles[j].sref()
                    resolveCollision(between = InOut({ m1 }, { m1 = it }), and = InOut({ m2 }, { m2 = it }))
                    marbles[i] = m1.sref()
                    marbles[j] = m2.sref()
                }
            }
        }

        // Constrain to container
        for (i in marbles.indices.sref()) {
            val r = marbles[i].marbleRadius
            if (marbles[i].position.x < r) {
                marbles[i].position.x = r
                marbles[i].velocity.dx *= -damping
            } else if (marbles[i].position.x > size.width - r) {
                marbles[i].position.x = size.width - r
                marbles[i].velocity.dx *= -damping
            }

            if (marbles[i].position.y < r) {
                marbles[i].position.y = r
                marbles[i].velocity.dy *= -damping
            } else if (marbles[i].position.y > size.height - r) {
                marbles[i].position.y = size.height - r
                marbles[i].velocity.dy *= -damping
            }
        }

        // Apply additional stabilization
        applyPressureCompensation(for_ = size)
        applyDynamicFriction(for_ = size)
        preventBottomOverlap(for_ = size)

        // Stop jittering marbles
        val velocityThreshold: Double = 0.1
        for (i in marbles.indices.sref()) {
            if (abs(marbles[i].velocity.dx) < velocityThreshold && abs(marbles[i].velocity.dy) < velocityThreshold) {
                marbles[i].velocity = Velocity.zero
            }
        }
    }

    /// Collision resolution for two circles (marbles) of equal mass
    private fun resolveCollision(between: InOut<Marble>, and: InOut<Marble>) {
        val m1 = between
        val m2 = and
        val dx = m2.value.position.x - m1.value.position.x
        val dy = m2.value.position.y - m1.value.position.y
        val distance = sqrt(dx * dx + dy * dy)
        val minDist = m1.value.marbleRadius + m2.value.marbleRadius

        if (distance < minDist) {
            val overlap = 0.5 * (minDist - distance)
            val nx = dx / (if (distance == 0.0) 0.1 else distance)
            val ny = dy / (if (distance == 0.0) 0.1 else distance)

            m1.value.position.x -= overlap * nx
            m1.value.position.y -= overlap * ny
            m2.value.position.x += overlap * nx
            m2.value.position.y += overlap * ny

            // Prevent sinking under pressure
            if (m1.value.position.y > m2.value.position.y) {
                m1.value.position.y -= overlap * 0.5
            }

            // Velocity adjustments
            val relativeVelocityX = m1.value.velocity.dx - m2.value.velocity.dx
            val relativeVelocityY = m1.value.velocity.dy - m2.value.velocity.dy
            val velAlongNormal = relativeVelocityX * nx + relativeVelocityY * ny
            if (velAlongNormal > 0) {
                return
            }

            val restitution: Double = 0.4
            val impulse = -(1 + restitution) * velAlongNormal / 2

            val impulseX = impulse * nx
            val impulseY = impulse * ny
            m1.value.velocity.dx += impulseX
            m1.value.velocity.dy += impulseY
            m2.value.velocity.dx -= impulseX
            m2.value.velocity.dy -= impulseY
        }
    }

    private fun preventBottomOverlap(for_: CGSize) {
        val size = for_
        for (i in marbles.indices.sref()) {
            if (marbles[i].position.y > size.height - marbles[i].marbleRadius * 2) {
                marbles[i].position.y = size.height - marbles[i].marbleRadius * 2
                marbles[i].velocity.dy = 0.0
            }
        }
    }

    private fun applyPressureCompensation(for_: CGSize) {
        val size = for_
        val bottomThreshold = size.height * 0.9 // Near the bottom
        for (i in marbles.indices.sref()) {
            if (marbles[i].position.y > bottomThreshold) {
                // Apply resistance to downward velocity
                marbles[i].velocity.dy *= 0.5
            }
        }
    }

    private fun applyDynamicFriction(for_: CGSize) {
        val size = for_
        for (i in marbles.indices.sref()) {
            if (marbles[i].position.y > size.height * 0.8) {
                marbles[i].velocity.dx *= 0.9 // Increase friction horizontally
                marbles[i].velocity.dy *= 0.9 // Increase friction vertically
            }
        }
    }

    private constructor(deliveries: Binding<Array<Delivery>>, headerText: String, marbles: Array<Marble> = arrayOf(), pendingMarbles: Array<Marble> = arrayOf(), displayedBabyIDs: Set<String> = setOf(), isAddingMarbles: Boolean = false, privatep: Nothing? = null) {
        this.maxMarbleCount = 100
        this.marbleRadius = 12.0
        this.collisionIterations = 15
        this.gravity = 1.0
        this.damping = 0.98
        this.friction = 0.85
        this.timer = Timer.publish(every = 0.016, on = RunLoop.main, in_ = RunLoop.Mode.common).autoconnect()
        this._deliveries = deliveries
        this.headerText = headerText
        this._marbles = skip.ui.State(marbles.sref())
        this._pendingMarbles = skip.ui.State(pendingMarbles.sref())
        this._displayedBabyIDs = skip.ui.State(displayedBabyIDs.sref())
        this._isAddingMarbles = skip.ui.State(isAddingMarbles)
    }

    constructor(deliveries: Binding<Array<Delivery>>, headerText: String): this(deliveries = deliveries, headerText = headerText, privatep = null) {
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as JarView
        this._deliveries = copy._deliveries
        this.headerText = copy.headerText
        this._marbles = skip.ui.State(copy.marbles)
        this._pendingMarbles = skip.ui.State(copy.pendingMarbles)
        this._displayedBabyIDs = skip.ui.State(copy.displayedBabyIDs)
        this._isAddingMarbles = skip.ui.State(copy.isAddingMarbles)
        this.maxMarbleCount = copy.maxMarbleCount
        this.marbleRadius = copy.marbleRadius
        this.collisionIterations = copy.collisionIterations
        this.gravity = copy.gravity
        this.damping = copy.damping
        this.friction = copy.friction
        this.timer = copy.timer
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = JarView(this as MutableStruct)
}

// MARK: - Marble & Velocity
@Suppress("MUST_BE_INITIALIZED")
internal class Marble: Identifiable<UUID>, MutableStruct {
    override val id: UUID
    internal var position: CGPoint
        get() = field.sref({ this.position = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    internal var velocity: Velocity
        get() = field.sref({ this.velocity = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    internal var marbleRadius: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var color: Color
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    internal val diameter: Double
        get() = marbleRadius * 2

    constructor(id: UUID, position: CGPoint, velocity: Velocity, marbleRadius: Double, color: Color) {
        this.id = id
        this.position = position
        this.velocity = velocity
        this.marbleRadius = marbleRadius
        this.color = color
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Marble(id, position, velocity, marbleRadius, color)
}

@Suppress("MUST_BE_INITIALIZED")
internal class Velocity: MutableStruct {
    internal var dx: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var dy: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    constructor(dx: Double, dy: Double) {
        this.dx = dx
        this.dy = dy
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Velocity(dx, dy)

    companion object {

        internal val zero: Velocity
            get() = Velocity(dx = 0.0, dy = 0.0)
    }
}

/// A small helper to create a preview that has a mutable @State value.
@Suppress("MUST_BE_INITIALIZED")
internal class StatefulPreviewWrapper<Value, Content>: View, MutableStruct where Content: View {
    internal var value: Value
        get() = _value.wrappedValue.sref({ this.value = it })
        set(newValue) {
            _value.wrappedValue = newValue.sref()
        }
    internal var _value: skip.ui.State<Value>
    internal var content: (Binding<Value>) -> Content
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    internal constructor(initialValue: Value, content: (Binding<Value>) -> Content) {
        _value = State(wrappedValue = initialValue)
        this.content = content
    }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext -> content(Binding({ _value.wrappedValue }, { it -> _value.wrappedValue = it })).Compose(composectx) }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedvalue by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Value>, Any>) { mutableStateOf(_value) }
        _value = rememberedvalue

        super.ComposeContent(composectx)
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as StatefulPreviewWrapper<Value, Content>
        this._value = skip.ui.State(copy.value)
        this.content = copy.content
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = StatefulPreviewWrapper<Value, Content>(this as MutableStruct)
}

/// Generates sample deliveries for preview purposes.
internal fun Delivery.Companion.sampleDeliveries(): Array<Delivery> = arrayOf(
    Delivery(id = "1", userId = "user1", userFirstName = "Alice", hospitalId = "hospital1", hospitalName = "City Hospital", musterId = "muster1", date = Date(), babies = arrayOf(
        Baby(deliveryId = "1", nurseCatch = true, sex = Sex.male, weight = 7.5, height = 20.0),
        Baby(deliveryId = "1", nurseCatch = false, sex = Sex.female, weight = 6.8, height = 19.0)
    ), babyCount = 2, deliveryMethod = DeliveryMethod.vaginal, epiduralUsed = true)
)
