//
//  HomeTabView.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class HomeTabView: View {
    internal lateinit var colorScheme: ColorScheme
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal var deliveryViewModel: DeliveryViewModel
        get() = _deliveryViewModel.wrappedValue
        set(newValue) {
            _deliveryViewModel.wrappedValue = newValue
        }
    internal var _deliveryViewModel = skip.ui.Environment<DeliveryViewModel>()

    internal var navigationPath: Array<String>
        get() = _navigationPath.wrappedValue.sref({ this.navigationPath = it })
        set(newValue) {
            _navigationPath.wrappedValue = newValue.sref()
        }
    internal var _navigationPath: Binding<Array<String>>
    internal var selectedTab: Tab
        get() = _selectedTab.wrappedValue
        set(newValue) {
            _selectedTab.wrappedValue = newValue
        }
    internal var _selectedTab: Binding<Tab>
    internal var showingDeliveryAddition: Boolean
        get() = _showingDeliveryAddition.wrappedValue
        set(newValue) {
            _showingDeliveryAddition.wrappedValue = newValue
        }
    internal var _showingDeliveryAddition: Binding<Boolean>

    private var showProfileView: Boolean
        get() = _showProfileView.wrappedValue
        set(newValue) {
            _showProfileView.wrappedValue = newValue
        }
    private var _showProfileView: skip.ui.State<Boolean>
    private var graphTabIndex: Int
        get() = _graphTabIndex.wrappedValue
        set(newValue) {
            _graphTabIndex.wrappedValue = newValue
        }
    private var _graphTabIndex: skip.ui.State<Int>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack(path = Binding({ _navigationPath.wrappedValue }, { it -> _navigationPath.wrappedValue = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            HStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ZStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            JarView(deliveries = Binding.constant(deliveriesForCurrentWeek()), headerText = getCurrentWeekRange() ?: "")
                                                .frame(width = 180.0).Compose(composectx)

                                            VStack { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    getCurrentWeekRange()?.let { weekRange ->
                                                        Text(weekRange)
                                                            .padding(8.0)
                                                            .foregroundStyle(Color.gray)
                                                            .font(Font.headline)
                                                            .fontWeight(Font.Weight.bold)
                                                            .background { ->
                                                                ComposeBuilder { composectx: ComposeContext ->
                                                                    Rectangle()
                                                                        .foregroundStyle(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                                                                        .cornerRadius(20.0)
                                                                        .shadow(color = if (colorScheme == ColorScheme.dark) Color.white else Color.black, radius = 2.0).Compose(composectx)
                                                                    ComposeResult.ok
                                                                }
                                                            }
                                                            .padding(Edge.Set.top, 20.0).Compose(composectx)
                                                    }

                                                    Spacer().Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)

                                    Spacer().Compose(composectx)

                                    VStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            VStack { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Text(LocalizedStringKey(stringLiteral = "Your Jar")).Compose(composectx)

                                                    Divider()
                                                        .padding(Edge.Set.horizontal).Compose(composectx)

                                                    HStack { ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            Text({
                                                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                str.appendInterpolation(countBabies(of = Sex.male))
                                                                LocalizedStringKey(stringInterpolation = str)
                                                            }()).Compose(composectx)

                                                            Text({
                                                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                str.appendLiteral("Boy")
                                                                str.appendInterpolation(if (countBabies(of = Sex.male) == 1) "" else "s")
                                                                LocalizedStringKey(stringInterpolation = str)
                                                            }())
                                                                .frame(width = 100.0).Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }.Compose(composectx)

                                                    HStack { ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            Text({
                                                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                str.appendInterpolation(countBabies(of = Sex.female))
                                                                LocalizedStringKey(stringInterpolation = str)
                                                            }()).Compose(composectx)

                                                            Text({
                                                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                str.appendLiteral("Girl")
                                                                str.appendInterpolation(if (countBabies(of = Sex.female) == 1) "" else "s")
                                                                LocalizedStringKey(stringInterpolation = str)
                                                            }())
                                                                .frame(width = 100.0).Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }.Compose(composectx)

                                                    HStack { ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            Text({
                                                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                str.appendInterpolation(countBabies(of = Sex.loss))
                                                                LocalizedStringKey(stringInterpolation = str)
                                                            }()).Compose(composectx)

                                                            Text({
                                                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                str.appendLiteral("Loss")
                                                                str.appendInterpolation(if (countBabies(of = Sex.loss) == 1) "" else "es")
                                                                LocalizedStringKey(stringInterpolation = str)
                                                            }())
                                                                .frame(width = 100.0).Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }.Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }
                                            .padding(Edge.Set.vertical)
                                            .frame(maxWidth = Double.infinity)
                                            .font(Font.title2)
                                            .fontWeight(Font.Weight.bold)
                                            .foregroundStyle(Color.gray)
                                            .background { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Rectangle()
                                                        .foregroundStyle(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                                                        .cornerRadius(20.0)
                                                        .shadow(color = if (colorScheme == ColorScheme.dark) Color.white else Color.black, radius = 2.0).Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)

                                            Spacer().Compose(composectx)

                                            Button(action = { ->
                                                withAnimation { ->
                                                    triggerHaptic()
                                                    deliveryViewModel.startNewDelivery()

                                                    showingDeliveryAddition = true
                                                    selectedTab = Tab.deliveries
                                                }
                                            }, label = { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Image(systemName = "plus")
                                                        .foregroundStyle(Color.white)
                                                        .font(Font.title)
                                                        .fontWeight(Font.Weight.bold)
                                                        .padding(Edge.Set.vertical, 20.0)
                                                        .frame(maxWidth = Double.infinity)
                                                        .background { ->
                                                            ComposeBuilder { composectx: ComposeContext ->
                                                                Rectangle()
                                                                    .cornerRadius(20.0)
                                                                    .foregroundStyle(Color.indigo)
                                                                    .shadow(radius = 2.0).Compose(composectx)
                                                                ComposeResult.ok
                                                            }
                                                        }.Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding(Edge.Set.leading, 8.0).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .padding()
                            .frame(height = 320.0).Compose(composectx)

                            HomeCarouselView().Compose(composectx)

                            Spacer().Compose(composectx)

                            ComposeResult.ok
                        }
                    }
                    .navigationTitle(LocalizedStringKey(stringLiteral = "Stork"))
                    .toolbar { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ToolbarItem(placement = ToolbarItemPlacement.navigationBarTrailing) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(action = { ->
                                        triggerHaptic()

                                        withAnimation { -> showProfileView = true }
                                    }, label = { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            InitialsAvatarView(firstName = profileViewModel.profile.firstName, lastName = profileViewModel.profile.lastName).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .sheet(isPresented = Binding({ _showProfileView.wrappedValue }, { it -> _showProfileView.wrappedValue = it }), content = { ->
                ComposeBuilder { composectx: ComposeContext ->
                    ProfileView()
                        .interactiveDismissDisabled()
                        .presentationDetents(if (profileViewModel.editingProfile) setOf(PresentationDetent.fraction(0.75)) else setOf(PresentationDetent.fraction(0.3))).Compose(composectx)
                    ComposeResult.ok
                }
            }).Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedshowProfileView by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_showProfileView) }
        _showProfileView = rememberedshowProfileView

        val rememberedgraphTabIndex by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Int>, Any>) { mutableStateOf(_graphTabIndex) }
        _graphTabIndex = rememberedgraphTabIndex

        colorScheme = EnvironmentValues.shared.colorScheme
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        _deliveryViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = DeliveryViewModel::class)!!

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private fun countBabies(of: Sex): Int {
        val sex = of
        val calendar = Calendar.current.sref()
        val now = Date()
        val weekStart_0 = calendar.dateInterval(of = Calendar.Component.weekOfYear, for_ = now)?.start.sref()
        if (weekStart_0 == null) {
            return 0
        }
        val weekEnd_0 = calendar.date(byAdding = Calendar.Component.day, value = 6, to = weekStart_0)
        if (weekEnd_0 == null) {
            return 0
        }

        // Filter deliveries for the current week
        val weekDeliveries = deliveryViewModel.deliveries.filter { delivery -> delivery.date >= weekStart_0 && delivery.date <= weekEnd_0 }

        // Count babies of the specified sex
        return weekDeliveries.reduce(initialResult = 0) { count, delivery ->
            count + delivery.babies.filter { it -> it.sex == sex }.count
        }
    }

    private fun getCurrentWeekRange(): String? {
        val calendar = Calendar.current.sref()
        val now = Date()
        val weekStart_1 = calendar.dateInterval(of = Calendar.Component.weekOfYear, for_ = now)?.start.sref()
        if (weekStart_1 == null) {
            return null
        }
        val weekEnd_1 = calendar.date(byAdding = Calendar.Component.day, value = 6, to = weekStart_1)
        if (weekEnd_1 == null) {
            return null
        }

        val formatter = DateFormatter()
        formatter.dateFormat = "MMM d" // Example: "Aug 9"

        val startDate = formatter.string(from = weekStart_1)
        val endDate = formatter.string(from = weekEnd_1)

        return "${startDate} - ${endDate}"
    }

    private fun deliveriesForCurrentWeek(): Array<Delivery> {
        val calendar = Calendar.current.sref()
        val now = Date()
        val weekStart_2 = calendar.dateInterval(of = Calendar.Component.weekOfYear, for_ = now)?.start.sref()
        if (weekStart_2 == null) {
            return arrayOf()
        }
        val weekEnd_2 = calendar.date(byAdding = Calendar.Component.day, value = 6, to = weekStart_2)
        if (weekEnd_2 == null) {
            return arrayOf()
        }

        // Filter deliveries within the week range
        return deliveryViewModel.deliveries.filter { delivery -> delivery.date >= weekStart_2 && delivery.date <= weekEnd_2 }
    }

    private constructor(navigationPath: Binding<Array<String>>, selectedTab: Binding<Tab>, showingDeliveryAddition: Binding<Boolean>, showProfileView: Boolean = false, graphTabIndex: Int = 0, privatep: Nothing? = null) {
        this._navigationPath = navigationPath
        this._selectedTab = selectedTab
        this._showingDeliveryAddition = showingDeliveryAddition
        this._showProfileView = skip.ui.State(showProfileView)
        this._graphTabIndex = skip.ui.State(graphTabIndex)
    }

    constructor(navigationPath: Binding<Array<String>>, selectedTab: Binding<Tab>, showingDeliveryAddition: Binding<Boolean>): this(navigationPath = navigationPath, selectedTab = selectedTab, showingDeliveryAddition = showingDeliveryAddition, privatep = null) {
    }
}

// #Preview omitted
