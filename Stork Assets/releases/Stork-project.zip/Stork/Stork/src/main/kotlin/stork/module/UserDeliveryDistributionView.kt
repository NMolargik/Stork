//
//  UserDeliveryDistributionView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 1/2/25.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class UserDeliveryDistributionView: View {

    // MARK: - Input Data

    /// All users in the muster (following `Profile` model).
    internal val profiles: Array<Profile>

    /// All deliveries to consider (for instance, from `groupedMusterDeliveries`).
    internal val deliveries: Array<Delivery>

    // A dictionary to store a stable random color for each user
    private var userColors: Dictionary<String, Color>
        get() = _userColors.wrappedValue.sref({ this.userColors = it })
        set(newValue) {
            _userColors.wrappedValue = newValue.sref()
        }
    private var _userColors: skip.ui.State<Dictionary<String, Color>>

    // Date 6 months ago to filter recent deliveries
    private val sixMonthsAgo: Date
        get() = Calendar.current.date(byAdding = Calendar.Component.month, value = -6, to = Date()) ?: Date()

    // MARK: - Body
    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack(spacing = 10.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    userListView.Compose(composectx)

                    distributionBarView
                        .frame(height = 24.0)
                        .cornerRadius(20.0).Compose(composectx)
                    //                .overlay(
                    //                    RoundedRectangle(cornerRadius: 12)
                    //                        .stroke(Color.primary.opacity(0.3), lineWidth: 1)
                    //                )
                    ComposeResult.ok
                }
            }
            .padding()
            .onAppear { ->
                // Generate user colors if not already set
                assignRandomColorsIfNeeded()
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val remembereduserColors by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Dictionary<String, Color>>, Any>) { mutableStateOf(_userColors) }
        _userColors = remembereduserColors

        super.ComposeContent(composectx)
    }

    // MARK: - Subviews

    /// Displays a HORIZONTAL list of each user's initials + random-colored dot,
    /// sorted by who contributed the most deliveries to the least (over last 6 months).
    private val userListView: View
        get() {
            // 1) Filter deliveries to the last 6 months
            val recentDeliveries = deliveries.filter { it -> it.date >= sixMonthsAgo }

            // 2) Calculate how many deliveries each user contributed
            val userDeliveryCounts = recentDeliveries.reduce(into = Dictionary<String, Int>()) { dict, delivery -> dict.value[delivery.userId, { 0 }] += 1 }

            // 3) Sort profiles by descending delivery count
            val sortedProfiles = profiles.sorted l@{ it, it_1 ->
                val countA = userDeliveryCounts[it.id] ?: 0
                val countB = userDeliveryCounts[it_1.id] ?: 0
                return@l countA > countB // Descending order
            }

            // 4) Wrap the initials + dots in a horizontal scroll view
            return ScrollView(Axis.Set.horizontal) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    HStack(alignment = VerticalAlignment.center, spacing = 16.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ForEach(sortedProfiles, id = { it.id }) { profile ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    HStack(spacing = 8.0) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Circle()
                                                .fill(userColors[profile.id] ?: Color.gray)
                                                .frame(width = 12.0, height = 12.0).Compose(composectx)

                                            Text(profile.initials)
                                                .font(Font.body).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding(Edge.Set.horizontal, 4.0).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(Edge.Set.vertical, 8.0).Compose(composectx)
                    ComposeResult.ok
                }
            }
        }

    /// A stacked bar (horizontal) that indicates how many deliveries each user has in last 6 months
    private val distributionBarView: View
        get() {
            val recentDeliveries = deliveries.filter { it -> it.date >= sixMonthsAgo }
            val userDeliveryCounts = recentDeliveries.reduce(into = Dictionary<String, Int>()) { dict, delivery -> dict.value[delivery.userId, { 0 }] += 1 }
            val total = userDeliveryCounts.values.reduce(initialResult = 0, { it, it_1 -> it + it_1 })

            return GeometryReader { geo ->
                ComposeBuilder { composectx: ComposeContext ->
                    HStack(spacing = 0.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ForEach(profiles, id = { it.id }) { profile ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    val count = userDeliveryCounts[profile.id] ?: 0
                                    val fraction = if (total == 0) 0 else Double(count) / Double(total)

                                    Rectangle()
                                        .fill(userColors[profile.id] ?: Color.gray)
                                        .frame(width = geo.size.width * Double(fraction)).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
        }

    // MARK: - Helpers

    /// Assign a stable random color per user if not already set
    private fun assignRandomColorsIfNeeded() {
        var temp = userColors.sref()
        for (user in profiles.sref()) {
            if (temp[user.id] == null) {
                temp[user.id] = randomColor()
            }
        }
        userColors = temp
    }

    /// Return a random color using random RGB values
    private fun randomColor(): Color {
        val red = Double.random(in_ = 0.0..1.0)
        val green = Double.random(in_ = 0.0..1.0)
        val blue = Double.random(in_ = 0.0..1.0)
        return Color(red = red, green = green, blue = blue)
    }

    private constructor(profiles: Array<Profile>, deliveries: Array<Delivery>, userColors: Dictionary<String, Color> = dictionaryOf(), privatep: Nothing? = null) {
        this.profiles = profiles.sref()
        this.deliveries = deliveries.sref()
        this._userColors = skip.ui.State(userColors.sref())
    }

    constructor(profiles: Array<Profile>, deliveries: Array<Delivery>): this(profiles = profiles, deliveries = deliveries, privatep = null) {
    }
}
