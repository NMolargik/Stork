//
//  BabyEditorView.swift
//
//
//  Created by Nick Molargik on 12/1/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class BabyEditorView: View, MutableStruct {
    internal lateinit var colorScheme: ColorScheme
    private var useMetric: Boolean
        get() = _useMetric.wrappedValue
        set(newValue) {
            _useMetric.wrappedValue = newValue
        }
    private var _useMetric: skip.ui.AppStorage<Boolean>

    internal var baby: Baby
        get() = _baby.wrappedValue.sref({ this.baby = it })
        set(newValue) {
            _baby.wrappedValue = newValue.sref()
        }
    internal var _baby: Binding<Baby>

    // Internally store weight in ounces and length in inches
    private var weightInOunces: Double
        get() = _weightInOunces.wrappedValue
        set(newValue) {
            _weightInOunces.wrappedValue = newValue
        }
    private var _weightInOunces: skip.ui.State<Double> // Default
    private var lengthInInches: Double
        get() = _lengthInInches.wrappedValue
        set(newValue) {
            _lengthInInches.wrappedValue = newValue
        }
    private var _lengthInInches: skip.ui.State<Double> // Default

    internal var babyNumber: Int
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var removeBaby: (String) -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    // MARK: - Constants

    // Imperial
    internal val minWeightInOunces: Double // 12 oz (~0.75 lbs)
    internal val maxWeightInOunces: Double // 15 lbs in ounces
    internal val minLengthInInches: Double
    internal val maxLengthInInches: Double

    // Metric (approx)
    internal val minWeightInKg: Double
    internal val maxWeightInKg: Double
    internal val minLengthInCm: Double
    internal val maxLengthInCm: Double

    // Conversion
    private val ounceToKg: Double // 1 oz = ~0.0283495 kg
    private val cmPerInch: Double // 1 in = 2.54 cm

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack(alignment = HorizontalAlignment.center, spacing = 10.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    headerSection.Compose(composectx)

                    // MARK: - Sex Picker
                    Picker(LocalizedStringKey(stringLiteral = "Sex"), selection = Binding({ _baby.wrappedValue.sex }, { it -> _baby.wrappedValue.sex = it })) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ForEach(Sex.allCases, id = { it }) { sex ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Text(sex.rawValue.capitalized).tag(sex).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .foregroundStyle(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                    .pickerStyle(PickerStyle.segmented)
                    .background { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Rectangle()
                                .foregroundStyle(if (colorScheme == ColorScheme.dark) Color.black.opacity(0.8) else Color.clear)
                                .cornerRadius(8.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .onChange(of = baby.sex) { _ -> triggerHaptic() }.Compose(composectx)

                    // MARK: - Weight
                    if (useMetric) {
                        metricWeightStepper.Compose(composectx)
                    } else {
                        imperialWeightStepper.Compose(composectx)
                    }

                    // MARK: - Length
                    if (useMetric) {
                        metricLengthStepper.Compose(composectx)
                    } else {
                        imperialLengthStepper.Compose(composectx)
                    }

                    Toggle(LocalizedStringKey(stringLiteral = "Nurse Catch"), isOn = Binding({ _baby.wrappedValue.nurseCatch }, { it -> _baby.wrappedValue.nurseCatch = it }))
                        .fontWeight(Font.Weight.bold)
                        .foregroundStyle(Color.black)
                        .tint(Color.green)
                        .padding()
                        .background { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Rectangle()
                                    .cornerRadius(20.0)
                                    .foregroundStyle(Color.white.opacity(0.8)).Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding()
            .background(ZStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Color.white.Compose(composectx)
                    baby.sex.color.opacity(0.4).Compose(composectx)
                    ComposeResult.ok
                }
            })
            .cornerRadius(20.0)
            .shadow(radius = 2.0)
            .onAppear { ->
                weightInOunces = baby.weight
                lengthInInches = baby.height
            }
            .onChange(of = weightInOunces) { newValue -> baby.weight = newValue }
            .onChange(of = lengthInInches) { newValue -> baby.height = newValue }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedweightInOunces by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Double>, Any>) { mutableStateOf(_weightInOunces) }
        _weightInOunces = rememberedweightInOunces

        val rememberedlengthInInches by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Double>, Any>) { mutableStateOf(_lengthInInches) }
        _lengthInInches = rememberedlengthInInches

        colorScheme = EnvironmentValues.shared.colorScheme

        val remembereduseMetric by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_useMetric) }
        _useMetric = remembereduseMetric

        super.ComposeContent(composectx)
    }

    // MARK: - Steppers

    private val metricWeightStepper: View
        get() {
            return HStack(spacing = 20.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Button(action = { ->
                        triggerHaptic()
                        val newKg = weightInKg - 0.1
                        if (newKg >= minWeightInKg) {
                            weightInOunces = newKg / ounceToKg
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "minus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)

                    Text({
                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                        str.appendInterpolation(String(format = "%.2f", weightInKg))
                        str.appendLiteral(" kg")
                        LocalizedStringKey(stringInterpolation = str)
                    }())
                        .frame(minWidth = 70.0)
                        .font(Font.title3)
                        .foregroundStyle(Color.black)
                        .fontWeight(Font.Weight.semibold).Compose(composectx)

                    Button(action = { ->
                        triggerHaptic()
                        val newKg = weightInKg + 0.1
                        if (newKg <= maxWeightInKg) {
                            weightInOunces = newKg / ounceToKg
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "plus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding()
            .frame(maxWidth = Double.infinity)
            .background { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Rectangle()
                        .cornerRadius(20.0)
                        .foregroundStyle(Color.white.opacity(0.8)).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding(Edge.Set.horizontal)
        }

    private val imperialWeightStepper: View
        get() {
            return HStack(spacing = 2.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Button(action = { ->
                        triggerHaptic()
                        val newPounds = pounds - 1
                        val total = Double(newPounds * 16 + ounces)
                        if ((newPounds >= 0) && (total >= minWeightInOunces)) {
                            weightInOunces = total
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "minus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)

                    Text({
                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                        str.appendInterpolation(pounds)
                        str.appendLiteral(" lbs")
                        LocalizedStringKey(stringInterpolation = str)
                    }())
                        .frame(minWidth = 60.0)
                        .font(Font.title3)
                        .foregroundStyle(Color.black)
                        .fontWeight(Font.Weight.semibold).Compose(composectx)

                    Button(action = { ->
                        triggerHaptic()
                        val newPounds = pounds + 1
                        val total = Double(newPounds * 16 + ounces)
                        if (total <= maxWeightInOunces) {
                            weightInOunces = total
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "plus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)

                    Spacer().Compose(composectx)

                    Button(action = { ->
                        triggerHaptic()
                        val newOunces = ounces - 1
                        val total = Double(pounds * 16 + newOunces)
                        if ((newOunces >= 0) && (total >= minWeightInOunces)) {
                            weightInOunces = total
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "minus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)

                    Text({
                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                        str.appendInterpolation(ounces)
                        str.appendLiteral(" oz")
                        LocalizedStringKey(stringInterpolation = str)
                    }())
                        .frame(minWidth = 50.0)
                        .font(Font.title3)
                        .foregroundStyle(Color.black)
                        .fontWeight(Font.Weight.semibold).Compose(composectx)

                    Button(action = { ->
                        triggerHaptic()
                        val newOunces = ounces + 1
                        val total = Double(pounds * 16 + newOunces)
                        if ((newOunces <= 15) && (total <= maxWeightInOunces)) {
                            weightInOunces = total
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "plus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .frame(maxWidth = Double.infinity)
            .padding()
            .background { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Rectangle()
                        .cornerRadius(20.0)
                        .foregroundStyle(Color.white.opacity(0.8)).Compose(composectx)
                    ComposeResult.ok
                }
            }
        }

    private val metricLengthStepper: View
        get() {
            return HStack(spacing = 20.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Button(action = { ->
                        triggerHaptic()
                        val newCm = lengthInCm - 0.1
                        if (newCm >= minLengthInCm) {
                            lengthInInches = newCm / cmPerInch
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "minus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)

                    Text({
                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                        str.appendInterpolation(String(format = "%.1f", lengthInCm))
                        str.appendLiteral(" cm")
                        LocalizedStringKey(stringInterpolation = str)
                    }())
                        .frame(minWidth = 70.0)
                        .font(Font.title3)
                        .foregroundStyle(Color.black)
                        .fontWeight(Font.Weight.semibold).Compose(composectx)

                    Button(action = { ->
                        triggerHaptic()
                        val newCm = lengthInCm + 0.1
                        if (newCm <= maxLengthInCm) {
                            lengthInInches = newCm / cmPerInch
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "plus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding()
            .frame(maxWidth = Double.infinity)
            .background { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Rectangle()
                        .cornerRadius(20.0)
                        .foregroundStyle(Color.white.opacity(0.8)).Compose(composectx)
                    ComposeResult.ok
                }
            }
        }

    private val imperialLengthStepper: View
        get() {
            return HStack(spacing = 10.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Button(action = { ->
                        triggerHaptic()
                        val newValue = lengthInInches - 0.1
                        if (newValue >= minLengthInInches) {
                            lengthInInches = newValue
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "minus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)

                    Text({
                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                        str.appendInterpolation(String(format = "%.1f", lengthInInches))
                        str.appendLiteral(" in")
                        LocalizedStringKey(stringInterpolation = str)
                    }())
                        .frame(minWidth = 70.0)
                        .font(Font.title3)
                        .foregroundStyle(Color.black)
                        .fontWeight(Font.Weight.semibold).Compose(composectx)

                    Button(action = { ->
                        triggerHaptic()
                        val newValue = lengthInInches + 0.1
                        if (newValue <= maxLengthInInches) {
                            lengthInInches = newValue
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "plus.circle.fill")
                                .font(Font.title)
                                .foregroundStyle(Color.black).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding()
            .frame(maxWidth = Double.infinity)
            .background { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Rectangle()
                        .cornerRadius(20.0)
                        .foregroundStyle(Color.white.opacity(0.8)).Compose(composectx)
                    ComposeResult.ok
                }
            }
        }

    // MARK: - Header (Trash Button)
    private val headerSection: View
        get() {
            return HStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Text({
                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                        str.appendLiteral("Baby ")
                        str.appendInterpolation(babyNumber)
                        LocalizedStringKey(stringInterpolation = str)
                    }())
                        .font(Font.title2)
                        .foregroundStyle(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                        .fontWeight(Font.Weight.bold).Compose(composectx)

                    Spacer().Compose(composectx)

                    if ((babyNumber > 1)) {
                        Button(action = { ->
                            triggerHaptic()
                            withAnimation { -> removeBaby(baby.id) }
                        }) { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Image(systemName = "minus")
                                    .fontWeight(Font.Weight.bold)
                                    .padding(10.0)
                                    .foregroundStyle(Color.white)
                                    .background(Circle().foregroundStyle(Color.red)).Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }
            .frame(height = 40.0)
        }

    private fun triggerHaptic() = Unit

    // MARK: - Computed Properties

    private val weightInKg: Double
        get() = weightInOunces * ounceToKg

    private val pounds: Int
        get() = Int(weightInOunces) / 16

    private val ounces: Int
        get() = Int(weightInOunces) % 16

    private val lengthInCm: Double
        get() = lengthInInches * cmPerInch

    private constructor(useMetric: Boolean = false, baby: Binding<Baby>, weightInOunces: Double = 112.0, lengthInInches: Double = 19.0, babyNumber: Int, removeBaby: (String) -> Unit, privatep: Nothing? = null) {
        this.minWeightInOunces = 12.0
        this.maxWeightInOunces = 240.0
        this.minLengthInInches = 8.0
        this.maxLengthInInches = 24.0
        this.minWeightInKg = 0.34
        this.maxWeightInKg = 6.8
        this.minLengthInCm = 20.3
        this.maxLengthInCm = 61.0
        this.ounceToKg = 0.0283495
        this.cmPerInch = 2.54
        this._useMetric = skip.ui.AppStorage(wrappedValue = useMetric, "useMetric")
        this._baby = baby
        this._weightInOunces = skip.ui.State(weightInOunces)
        this._lengthInInches = skip.ui.State(lengthInInches)
        this.babyNumber = babyNumber
        this.removeBaby = removeBaby
    }

    constructor(baby: Binding<Baby>, babyNumber: Int, removeBaby: (String) -> Unit): this(baby = baby, babyNumber = babyNumber, removeBaby = removeBaby, privatep = null) {
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as BabyEditorView
        this._useMetric = copy._useMetric
        this._baby = copy._baby
        this._weightInOunces = skip.ui.State(copy.weightInOunces)
        this._lengthInInches = skip.ui.State(copy.lengthInInches)
        this.babyNumber = copy.babyNumber
        this.removeBaby = copy.removeBaby
        this.minWeightInOunces = copy.minWeightInOunces
        this.maxWeightInOunces = copy.maxWeightInOunces
        this.minLengthInInches = copy.minLengthInInches
        this.maxLengthInInches = copy.maxLengthInInches
        this.minWeightInKg = copy.minWeightInKg
        this.maxWeightInKg = copy.maxWeightInKg
        this.minLengthInCm = copy.minLengthInCm
        this.maxLengthInCm = copy.maxLengthInCm
        this.ounceToKg = copy.ounceToKg
        this.cmPerInch = copy.cmPerInch
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = BabyEditorView(this as MutableStruct)
}

// MARK: - Preview

// #Preview omitted
