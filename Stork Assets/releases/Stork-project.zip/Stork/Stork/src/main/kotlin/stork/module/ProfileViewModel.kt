//
//  ProfileViewModel.swift
//  Stork
//
//  Created by Nick Molargik on 11/8/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.model.*
import skip.ui.*
import stork.model.*

import java.util.regex.Pattern

@Stable
open class ProfileViewModel: ObservableObject {
    override val objectWillChange = ObservableObjectPublisher()
    // MARK: - AppStorage
    private var appState: AppState = AppState.splash
    internal open var loggedIn = false
    private var useMetric: Boolean = false
    private var isOnboardingComplete: Boolean = false
    private var isPaywallComplete: Boolean = false

    // MARK: - Published Core State
    internal open var profile: Profile
        get() = _profile.wrappedValue.sref({ this.profile = it })
        set(newValue) {
            objectWillChange.send()
            _profile.wrappedValue = newValue.sref()
        }
    internal var _profile: skip.model.Published<Profile>
    internal open var tempProfile: Profile
        get() = _tempProfile.wrappedValue.sref({ this.tempProfile = it })
        set(newValue) {
            objectWillChange.send()
            _tempProfile.wrappedValue = newValue.sref()
        }
    internal var _tempProfile: skip.model.Published<Profile>

    // MARK: - Published Error/Loading States
    internal open var errorMessage: String?
        get() = _errorMessage.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.model.Published<String?> = skip.model.Published(null)
    internal open var isWorking: Boolean
        get() = _isWorking.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _isWorking.wrappedValue = newValue
        }
    internal var _isWorking: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var editingProfile: Boolean
        get() = _editingProfile.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _editingProfile.wrappedValue = newValue
        }
    internal var _editingProfile: skip.model.Published<Boolean> = skip.model.Published(false)

    // MARK: - Validation States
    internal open var isFormValid: Boolean
        get() = _isFormValid.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _isFormValid.wrappedValue = newValue
        }
    internal var _isFormValid: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var firstNameError: String?
        get() = _firstNameError.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _firstNameError.wrappedValue = newValue
        }
    internal var _firstNameError: skip.model.Published<String?> = skip.model.Published(null)
    internal open var lastNameError: String?
        get() = _lastNameError.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _lastNameError.wrappedValue = newValue
        }
    internal var _lastNameError: skip.model.Published<String?> = skip.model.Published(null)
    internal open var birthdayError: String?
        get() = _birthdayError.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _birthdayError.wrappedValue = newValue
        }
    internal var _birthdayError: skip.model.Published<String?> = skip.model.Published(null)

    // MARK: - Registration & Login Fields
    internal open var emailError: String?
        get() = _emailError.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _emailError.wrappedValue = newValue
        }
    internal var _emailError: skip.model.Published<String?> = skip.model.Published(null)
    internal open var passwordText: String
        get() = _passwordText.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _passwordText.wrappedValue = newValue
        }
    internal var _passwordText: skip.model.Published<String> = skip.model.Published("")
    internal open var passwordError: String?
        get() = _passwordError.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _passwordError.wrappedValue = newValue
        }
    internal var _passwordError: skip.model.Published<String?> = skip.model.Published(null)
    internal open var confirmPassword: String
        get() = _confirmPassword.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _confirmPassword.wrappedValue = newValue
        }
    internal var _confirmPassword: skip.model.Published<String> = skip.model.Published("")
    internal open var confirmPasswordError: String?
        get() = _confirmPasswordError.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _confirmPasswordError.wrappedValue = newValue
        }
    internal var _confirmPasswordError: skip.model.Published<String?> = skip.model.Published(null)

    // MARK: - Dependency
    private val profileRepository: ProfileRepositoryInterface

    // MARK: - Initializer
    constructor(profileRepository: ProfileRepositoryInterface) {
        this.profileRepository = profileRepository.sref()
        this._profile = skip.model.Published(Profile())
        this._tempProfile = skip.model.Published(Profile())
    }

    // MARK: - Fetch Current Profile
    open suspend fun fetchCurrentProfile(): Unit = MainActor.run {
        var deferaction_0: (() -> Unit)? = null
        try {
            print("Fetching profile")
            isWorking = true
            deferaction_0 = {
                isWorking = false
            }

            try {
                val fetchedProfile = profileRepository.getCurrentProfile()
                print("Done fetching profile")
                this.profile = fetchedProfile
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                this.errorMessage = "Failed to load profile: ${error.localizedDescription}"
                // Sign out if fetching fails, to clear state
                this.signOut()
                throw error as Throwable
            }
        } finally {
            deferaction_0?.invoke()
        }
    }

    // MARK: - Register / Create Profile
    open suspend fun registerWithEmail(): Unit = MainActor.run {
        var deferaction_1: (() -> Unit)? = null
        try {
            // 1) Validate entire registration form
            validateRegistrationForm()
            if (!isFormValid) {
                throw ProfileError.creationFailed("Details are invalid. Please correct the form.")
            }

            // 2) Show loading indicator
            isWorking = true
            deferaction_1 = {
                isWorking = false
            }

            try {
                // Step A) Register user with email/password
                val newProfile = profileRepository.registerWithEmail(profile = tempProfile, password = passwordText)

                // Step B) Overwrite self.profile with returned profile
                this.profile = newProfile

                // Step C) Also explicitly create the profile in Firestore (if your logic requires it)
                this.profile = profileRepository.createProfile(profile = profile)

                // Mark user as logged in
                this.loggedIn = true

            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                this.errorMessage = "Registration failed: ${error.localizedDescription}"
                throw error as Throwable
            }

            // Clear sensitive fields
            this.passwordText = ""
            this.confirmPassword = ""
        } finally {
            deferaction_1?.invoke()
        }
    }

    // MARK: - Fetch Profiles (Generic List)
    open suspend fun listProfiles(id: String? = null, firstName: String? = null, lastName: String? = null, email: String? = null, birthday: Date? = null, role: ProfileRole? = null, primaryHospital: String? = null, joinDate: Date? = null, musterId: String? = null): Array<Profile> = MainActor.run l@{
        var deferaction_2: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_2 = {
                isWorking = false
            }

            try {
                return@l profileRepository.listProfiles(id = id, firstName = firstName, lastName = lastName, email = email, birthday = birthday, role = role, primaryHospital = primaryHospital, joinDate = joinDate, musterId = musterId)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                this.errorMessage = "Failed to fetch profiles: ${error.localizedDescription}"
                throw error as Throwable
            }
        } finally {
            deferaction_2?.invoke()
        }
    }

    // MARK: - Login
    open suspend fun signInWithEmail(): Unit = MainActor.run {
        var deferaction_3: (() -> Unit)? = null
        try {
            if (profile.email.isEmpty) {
                throw ProfileError.authenticationFailed("Email was not provided.")
            }
            if (passwordText.isEmpty) {
                throw ProfileError.authenticationFailed("Password was not provided.")
            }

            isWorking = true
            deferaction_3 = {
                isWorking = false
            }

            try {
                // Step 1) Sign in with email/password
                val signedInProfile = profileRepository.signInWithEmail(profile = profile, password = passwordText)
                this.profile = signedInProfile
                this.loggedIn = true

                // Step 2) Attempt to fetch the user’s full profile (if separate)
                val currentProfile = profileRepository.getCurrentProfile()
                this.profile = currentProfile

            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                // If sign-in fails or fetching the full profile fails, sign out to clear state
                this.errorMessage = "Failed to sign in: ${error.localizedDescription}"
                try { profileRepository.signOut() } catch (_: Throwable) { null }
                throw error as Throwable
            }
        } finally {
            deferaction_3?.invoke()
        }
    }

    // MARK: - Password Reset
    open suspend fun sendPasswordReset(): Unit = MainActor.run {
        var deferaction_4: (() -> Unit)? = null
        try {
            if (tempProfile.email.isEmpty) {
                throw ProfileError.passwordResetFailed("No email to send reset.")
            }

            isWorking = true
            deferaction_4 = {
                isWorking = false
            }

            try {
                profileRepository.sendPasswordReset(email = tempProfile.email)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                this.errorMessage = "Password reset failed: ${error.localizedDescription}"
                throw error as Throwable
            }
        } finally {
            deferaction_4?.invoke()
        }
    }

    // MARK: - Update Profile
    open suspend fun updateProfile(): Unit = MainActor.run {
        var deferaction_5: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_5 = {
                isWorking = false
            }

            try {
                // If editing, validate the form
                if (editingProfile) {
                    validateProfileForm(tempProfile)
                    if (!isFormValid) {
                        throw ProfileError.updateFailed("Invalid form data.")
                    }
                }

                // Actually update the profile
                val updated = profileRepository.updateProfile(profile = tempProfile)
                this.profile = updated

            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                this.errorMessage = "Failed to update profile: ${error.localizedDescription}"
                throw error as Throwable
            }
        } finally {
            deferaction_5?.invoke()
        }
    }

    /// Example of an “admin status” update call. If you need more logic, it can go here.
    open suspend fun updateProfileAdminStatus(profile: Profile): Unit = MainActor.run {
        var deferaction_6: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_6 = {
                isWorking = false
            }

            try {
                profileRepository.updateProfile(profile = tempProfile)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                this.errorMessage = "Failed to assign admin: ${error.localizedDescription}"
                throw error as Throwable
            }
        } finally {
            deferaction_6?.invoke()
        }
    }

    // MARK: - Delete / Terminate
    open suspend fun deleteProfile(password: String): Unit = MainActor.run {
        var deferaction_7: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_7 = {
                isWorking = false
            }

            try {
                // Delete the user’s profile
                profileRepository.deleteProfile(profile = profile)

                // If you also want to terminate the Auth user, uncomment:
                // try await profileRepository.terminateUser(password: password)

                resetTempProfile()
                isOnboardingComplete = false
                isPaywallComplete = false
                reset()
                signOut()

            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                this.errorMessage = "Failed to delete profile: ${error.localizedDescription}"
                throw error as Throwable
            }
        } finally {
            deferaction_7?.invoke()
        }
    }

    //    @MainActor
    //    public func terminateUser(password: String) async throws {
    //        isWorking = true
    //        do {
    //            try await profileRepository.terminateUser(password: password)
    //            resetTempProfile()
    //            reset()
    //            signOut()
    //        } catch {
    //            self.errorMessage = "Failed to terminate user: \(error.localizedDescription)"
    //            isWorking = false
    //            throw error
    //        }
    //        isWorking = false
    //    }

    // MARK: - Signing Out
    open fun signOut() {
        isWorking = true
        Task(isMainActor = true) { ->
            var deferaction_8: (() -> Unit)? = null
            try {
                deferaction_8 = {
                    isWorking = false
                }
                try {
                    profileRepository.signOut()
                    this.passwordText = ""
                    this.confirmPassword = ""
                    this.resetTempProfile()
                    this.reset()
                    this.isPaywallComplete = false
                    this.loggedIn = false
                    this.appState = AppState.splash
                } catch (error: Throwable) {
                    @Suppress("NAME_SHADOWING") val error = error.aserror()
                    this.errorMessage = "Failed to sign out: ${error.localizedDescription}"
                }
            } finally {
                deferaction_8?.invoke()
            }
        }
    }

    // MARK: - Form Validation
    internal open fun validateProfileForm(profile: Profile) {
        firstNameError = if (isNameValid(profile.firstName)) null else "First name cannot be empty"
        lastNameError = if (isNameValid(profile.lastName)) null else "Last name cannot be empty"
        birthdayError = if (isBirthdayValid(profile.birthday)) null else "Please select a valid birthday (16+)."

        withAnimation { -> isFormValid = firstNameError == null && lastNameError == null && birthdayError == null }
    }

    internal open fun validateRegistrationForm() {
        emailError = if (isEmailValid(tempProfile.email)) null else "Invalid email address"
        passwordError = if (isPasswordValid(passwordText)) null else "Password must be at least 8 chars w/ letter, number, symbol"
        confirmPasswordError = if ((passwordText == confirmPassword)) null else "Passwords do not match"
        firstNameError = if (isNameValid(tempProfile.firstName)) null else "First name cannot be empty"
        lastNameError = if (isNameValid(tempProfile.lastName)) null else "Last name cannot be empty"
        birthdayError = if (isBirthdayValid(tempProfile.birthday)) null else "Must be at least 16 years old"

        withAnimation { -> isFormValid = emailError == null && passwordError == null && confirmPasswordError == null && firstNameError == null && lastNameError == null && birthdayError == null }
    }

    // MARK: - Helper: Reset
    internal open fun resetTempProfile() {
        this.tempProfile = Profile(id = UUID().uuidString, primaryHospitalId = "", musterId = "", firstName = "", lastName = "", email = "", birthday = Date(), joinDate = Date().description, role = ProfileRole.nurse)
    }

    internal open fun reset() {
        profile = Profile()
        errorMessage = null
        isFormValid = false
        passwordText = ""
        confirmPassword = ""
    }

    // MARK: - Validation Helpers
    private fun isNameValid(name: String): Boolean = !name.trimmingCharacters(in_ = CharacterSet.whitespaces).isEmpty

    private fun isBirthdayValid(birthday: Date): Boolean {
        val minDate_0 = Calendar.current.date(byAdding = Calendar.Component.year, value = -16, to = Date())
        if (minDate_0 == null) {
            return false
        }
        return birthday <= minDate_0
    }

    internal open fun isEmailValid(email: String): Boolean {
        val emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        val emailPattern = Pattern.compile(emailFormat)
        return emailPattern.matcher(email).matches()
    }

    private fun isPasswordValid(password: String): Boolean {
        val passwordFormat = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[\\Q!@#\$%^&*()_+=<>?{}[]~`|/.,:;-\\E])[A-Za-z\\d\\Q!@#\$%^&*()_+=<>?{}[]~`|/.,:;-\\E]{8,}\$"
        val passwordPattern = Pattern.compile(passwordFormat)
        return passwordPattern.matcher(password).matches()
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
