//
//  EditProfileView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 12/22/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class EditProfileView: View {
    // MARK: - Environment Objects
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()
    internal var hospitalViewModel: HospitalViewModel
        get() = _hospitalViewModel.wrappedValue
        set(newValue) {
            _hospitalViewModel.wrappedValue = newValue
        }
    internal var _hospitalViewModel = skip.ui.Environment<HospitalViewModel>()
    internal lateinit var dismiss: DismissAction

    // MARK: - State Variables
    private var firstName: String
        get() = _firstName.wrappedValue
        set(newValue) {
            _firstName.wrappedValue = newValue
        }
    private var _firstName: skip.ui.State<String>
    private var lastName: String
        get() = _lastName.wrappedValue
        set(newValue) {
            _lastName.wrappedValue = newValue
        }
    private var _lastName: skip.ui.State<String>
    private var birthday: Date
        get() = _birthday.wrappedValue.sref({ this.birthday = it })
        set(newValue) {
            _birthday.wrappedValue = newValue.sref()
        }
    private var _birthday: skip.ui.State<Date>
    private var role: ProfileRole
        get() = _role.wrappedValue
        set(newValue) {
            _role.wrappedValue = newValue
        }
    private var _role: skip.ui.State<ProfileRole>
    private var errorMessage: String?
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    private var _errorMessage: skip.ui.State<String?> = skip.ui.State(null)
    private var isSaving: Boolean
        get() = _isSaving.wrappedValue
        set(newValue) {
            _isSaving.wrappedValue = newValue
        }
    private var _isSaving: skip.ui.State<Boolean>

    // Computed property to check if any changes have been made
    private val hasChanges: Boolean
        get() = firstName != profileViewModel.profile.firstName || lastName != profileViewModel.profile.lastName || birthday != profileViewModel.profile.birthday || role != profileViewModel.profile.role

    // MARK: - Body
    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            Form { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Section(header = Text(LocalizedStringKey(stringLiteral = "Name"))) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            TextField(LocalizedStringKey(stringLiteral = "First Name"), text = Binding({ _firstName.wrappedValue }, { it -> _firstName.wrappedValue = it })).Compose(composectx)

                            TextField(LocalizedStringKey(stringLiteral = "Last Name"), text = Binding({ _lastName.wrappedValue }, { it -> _lastName.wrappedValue = it })).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)

                    Section(header = Text(LocalizedStringKey(stringLiteral = "Birthday"))) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            DatePicker(LocalizedStringKey(stringLiteral = "Select Birthday"), selection = Binding({ _birthday.wrappedValue }, { it -> _birthday.wrappedValue = it }), displayedComponents = DatePickerComponents.date).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)

                    Section(header = Text(LocalizedStringKey(stringLiteral = "Role"))) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Picker(LocalizedStringKey(stringLiteral = "Role"), selection = Binding({ _role.wrappedValue }, { it -> _role.wrappedValue = it })) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ForEach(ProfileRole.allCases, id = { it }) { role ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(role.description).tag(role).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .onChange(of = role) { _ -> triggerHaptic() }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)

                    errorMessage?.let { errorMessage ->
                        Section { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Text(errorMessage)
                                    .foregroundColor(Color.red).Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }
            .navigationTitle(LocalizedStringKey(stringLiteral = "Edit Profile"))
            .toolbar { ->
                ComposeBuilder { composectx: ComposeContext ->
                    ToolbarItem(placement = ToolbarItemPlacement.navigationBarLeading) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Button(LocalizedStringKey(stringLiteral = "Cancel")) { ->
                                triggerHaptic()
                                dismiss()
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)

                    ToolbarItem(placement = ToolbarItemPlacement.navigationBarTrailing) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if (isSaving) {
                                Color.black.opacity(0.4)
                                    .ignoresSafeArea().Compose(composectx)
                                ProgressView(LocalizedStringKey(stringLiteral = "Saving..."))
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius = 20.0).fill(Color.white))
                                    .shadow(radius = 2.0).Compose(composectx)
                            } else {
                                Button(LocalizedStringKey(stringLiteral = "Save")) { ->
                                    triggerHaptic()
                                    Task(isMainActor = true) { -> saveProfile() }
                                }
                                .disabled(!hasChanges || isSaving).Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onAppear { -> loadCurrentProfile() }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedfirstName by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<String>, Any>) { mutableStateOf(_firstName) }
        _firstName = rememberedfirstName

        val rememberedlastName by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<String>, Any>) { mutableStateOf(_lastName) }
        _lastName = rememberedlastName

        val rememberedbirthday by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Date>, Any>) { mutableStateOf(_birthday) }
        _birthday = rememberedbirthday

        val rememberedrole by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<ProfileRole>, Any>) { mutableStateOf(_role) }
        _role = rememberedrole

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<String?>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        val rememberedisSaving by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_isSaving) }
        _isSaving = rememberedisSaving

        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!
        _hospitalViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = HospitalViewModel::class)!!
        dismiss = EnvironmentValues.shared.dismiss

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    // MARK: - Helper Functions

    /// Loads the current profile data into the editable fields.
    private fun loadCurrentProfile() {
        firstName = profileViewModel.profile.firstName
        lastName = profileViewModel.profile.lastName
        birthday = profileViewModel.profile.birthday
        role = profileViewModel.profile.role
    }

    /// Saves the updated profile data if there are changes.
    private suspend fun saveProfile(): Unit = Async.run l@{
        if (!hasChanges) {
            dismiss()
            return@l
        }

        isSaving = true
        errorMessage = null

        // Create a new Profile object with updated data
        var updatedProfile = profileViewModel.profile.sref()
        updatedProfile.firstName = firstName
        updatedProfile.lastName = lastName
        updatedProfile.birthday = birthday
        updatedProfile.role = role

        print("Profile changes found. Updating.")

        try {
            // Call the updateProfile method in ProfileViewModel
            profileViewModel.tempProfile = updatedProfile
            profileViewModel.updateProfile()
            dismiss()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            // Handle errors by displaying an error message
            val matchtarget_0 = error as? ProfileError
            if (matchtarget_0 != null) {
                val profileError = matchtarget_0
                errorMessage = profileError.localizedDescription
            } else {
                errorMessage = "An unexpected error occurred: ${error.localizedDescription}"
            }
        }

        isSaving = false
    }

    private constructor(firstName: String = "", lastName: String = "", birthday: Date = Date(), role: ProfileRole = ProfileRole.nurse, errorMessage: String? = null, isSaving: Boolean = false, privatep: Nothing? = null) {
        this._firstName = skip.ui.State(firstName)
        this._lastName = skip.ui.State(lastName)
        this._birthday = skip.ui.State(birthday.sref())
        this._role = skip.ui.State(role)
        this._errorMessage = skip.ui.State(errorMessage)
        this._isSaving = skip.ui.State(isSaving)
    }

    constructor(): this(privatep = null) {
    }
}
