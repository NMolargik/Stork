//
//  MusterAdminAssignAdminView.swift
//
//  Created by Nick Molargik on 12/11/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class MusterAdminAssignAdminView: View {
    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal lateinit var dismiss: DismissAction

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    List { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ForEach(musterViewModel.musterMembers, id = { it.id }) { profile ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ProfileAssignmentRowView(profile = profile, adminProfileIds = Set(musterViewModel.currentMuster?.administratorProfileIds ?: arrayOf()), onAssign = { ->
                                        Task(isMainActor = true) { ->
                                            musterViewModel.assignAdmin(userId = profile.id)
                                        }
                                    }).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .navigationTitle(LocalizedStringKey(stringLiteral = "Assign Admin"))
                    .toolbar { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ToolbarItem(placement = ToolbarItemPlacement.cancellationAction) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(LocalizedStringKey(stringLiteral = "Close")) { -> dismiss() }
                                        .foregroundStyle(Color.red).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        dismiss = EnvironmentValues.shared.dismiss

        super.ComposeContent(composectx)
    }
}

// #Preview omitted
