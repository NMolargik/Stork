package stork.module

import skip.lib.*


internal val <E0, E1> Tuple2<E0, E1>.city: E0
    get() = element0

internal val <E0, E1> Tuple2<E0, E1>.key: E0
    get() = element0

internal val <E0, E1> Tuple2<E0, E1>.latitude: E0
    get() = element0

internal val <E0, E1> Tuple2<E0, E1>.name: E0
    get() = element0

internal val <E0, E1> Tuple2<E0, E1>.longitude: E1
    get() = element1

internal val <E0, E1> Tuple2<E0, E1>.state: E1
    get() = element1

internal val <E0, E1> Tuple2<E0, E1>.value: E1
    get() = element1

internal val <E0, E1> Tuple2<E0, E1>.version: E1
    get() = element1
