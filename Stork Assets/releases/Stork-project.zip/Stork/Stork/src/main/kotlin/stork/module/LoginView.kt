//
//  LoginView.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class LoginView: View, MutableStruct {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String> = skip.ui.AppStorage("", "errorMessage")
    private var isOnboardingComplete: Boolean
        get() = _isOnboardingComplete.wrappedValue
        set(newValue) {
            _isOnboardingComplete.wrappedValue = newValue
        }
    private var _isOnboardingComplete: skip.ui.AppStorage<Boolean> = skip.ui.AppStorage(false, "isOnboardingComplete")

    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    private var isPasswordResetPresented: Boolean
        get() = _isPasswordResetPresented.wrappedValue
        set(newValue) {
            _isPasswordResetPresented.wrappedValue = newValue
        }
    private var _isPasswordResetPresented: skip.ui.State<Boolean> = skip.ui.State(false)

    internal var onAuthenticated: () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    constructor(onAuthenticated: () -> Unit) {
        this.onAuthenticated = onAuthenticated
    }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            ZStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.profile.email }, { it -> _profileViewModel.wrappedValue.profile.email = it }), hintText = "Email Address", icon = Image(systemName = "envelope"), isSecure = false, iconColor = Color.blue)
                                .padding(Edge.Set.bottom, 5.0)
                                .padding(Edge.Set.horizontal).Compose(composectx)

                            CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.passwordText }, { it -> _profileViewModel.wrappedValue.passwordText = it }), hintText = "Password", icon = Image(systemName = "key"), isSecure = true, iconColor = Color.red)
                                .padding(Edge.Set.bottom)
                                .onSubmit { ->
                                    Task(isMainActor = true) { ->
                                        try {
                                            this.signIn()
                                        } catch (error: Throwable) {
                                            @Suppress("NAME_SHADOWING") val error = error.aserror()
                                            throw error as Throwable
                                        }
                                    }
                                }
                                .padding(Edge.Set.horizontal).Compose(composectx)

                            if ((profileViewModel.isWorking)) {
                                ProgressView()
                                    .tint(Color.indigo)
                                    .frame(height = 40.0)
                                    .padding().Compose(composectx)

                            } else {
                                CustomButtonView(text = "Log In", width = 120.0, height = 50.0, color = Color.indigo, isEnabled = true, onTapAction = { ->
                                    Task(isMainActor = true) { ->
                                        try {
                                            this.signIn()
                                        } catch (error: Throwable) {
                                            @Suppress("NAME_SHADOWING") val error = error.aserror()
                                            throw error as Throwable
                                        }
                                    }
                                }).Compose(composectx)
                            }

                            Button(action = { ->
                                withAnimation { ->
                                    triggerHaptic()
                                    isPasswordResetPresented = true
                                }
                            }, label = { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Text(LocalizedStringKey(stringLiteral = "Forgot Your Password?"))
                                        .foregroundStyle(Color.red).Compose(composectx)
                                    ComposeResult.ok
                                }
                            })
                            .padding()
                            .disabled(profileViewModel.isWorking).Compose(composectx)

                            Spacer()
                                .frame(height = 50.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(Edge.Set.horizontal).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .sheet(isPresented = Binding({ _isPasswordResetPresented.wrappedValue }, { it -> _isPasswordResetPresented.wrappedValue = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    PasswordResetSheetView(isPasswordResetPresented = Binding({ _isPasswordResetPresented.wrappedValue }, { it -> _isPasswordResetPresented.wrappedValue = it }), email = Binding({ _profileViewModel.wrappedValue.profile.email }, { it -> _profileViewModel.wrappedValue.profile.email = it }))
                        .presentationDetents(setOf(PresentationDetent.medium)).Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedisPasswordResetPresented by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_isPasswordResetPresented) }
        _isPasswordResetPresented = rememberedisPasswordResetPresented

        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        val rememberedisOnboardingComplete by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_isOnboardingComplete) }
        _isOnboardingComplete = rememberedisOnboardingComplete

        super.ComposeContent(composectx)
    }

    private suspend fun signIn(): Unit = Async.run {
        try {
            profileViewModel.signInWithEmail()
            onAuthenticated()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            errorMessage = error.localizedDescription
            throw error as Throwable
        }
    }

    private fun triggerHaptic() = Unit

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as LoginView
        this._errorMessage = copy._errorMessage
        this._isOnboardingComplete = copy._isOnboardingComplete
        this._isPasswordResetPresented = skip.ui.State(copy.isPasswordResetPresented)
        this.onAuthenticated = copy.onAuthenticated
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = LoginView(this as MutableStruct)
}

// #Preview omitted
