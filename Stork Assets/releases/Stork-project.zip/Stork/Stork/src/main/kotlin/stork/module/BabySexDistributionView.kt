//
//  BabySexDistributionView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 01/01/25.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

// MARK: - BabySexDistributionData Model
/// Represents a data point in the pie chart.
internal class BabySexDistributionData: Identifiable<UUID> {
    override val id = UUID()
    internal val category: String
    internal val count: Int
    internal val color: Color

    constructor(category: String, count: Int, color: Color) {
        this.category = category
        this.count = count
        this.color = color
    }
}

// MARK: - BabySexDistributionView
/// A SwiftUI view that displays the distribution of baby sexes in a pie chart.
internal class BabySexDistributionView: View {
    // MARK: - Properties
    internal var groupedDeliveries: Array<Tuple2<String, Array<Delivery>>>
        get() = _groupedDeliveries.wrappedValue.sref({ this.groupedDeliveries = it })
        set(newValue) {
            _groupedDeliveries.wrappedValue = newValue.sref()
        }
    internal var _groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>
    private var distributionData: Array<BabySexDistributionData>
        get() = _distributionData.wrappedValue.sref({ this.distributionData = it })
        set(newValue) {
            _distributionData.wrappedValue = newValue.sref()
        }
    private var _distributionData: skip.ui.State<Array<BabySexDistributionData>>
    private var sliceAngles: Array<Double>
        get() = _sliceAngles.wrappedValue.sref({ this.sliceAngles = it })
        set(newValue) {
            _sliceAngles.wrappedValue = newValue.sref()
        }
    private var _sliceAngles: skip.ui.State<Array<Double>> // Store the end angles of slices for animation

    // MARK: - Body
    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Spacer().Compose(composectx)

                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            VStack(alignment = HorizontalAlignment.leading, spacing = 10.0) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Text(LocalizedStringKey(stringLiteral = "6 Month Sex \nDistribution"))
                                        .multilineTextAlignment(TextAlignment.leading)
                                        .fontWeight(Font.Weight.bold)
                                        .foregroundStyle(Color.gray).Compose(composectx)

                                    if (distributionData.isEmpty) {
                                        Text(LocalizedStringKey(stringLiteral = "No data available"))
                                            .font(Font.headline)
                                            .foregroundColor(Color.secondary).Compose(composectx)
                                    } else {
                                        ForEach(distributionData) { data ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                HStack { ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        Circle()
                                                            .fill(data.color)
                                                            .frame(width = 10.0, height = 10.0).Compose(composectx)

                                                        Text({
                                                            val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                            str.appendInterpolation(data.category)
                                                            str.appendLiteral(": ")
                                                            str.appendInterpolation(data.count)
                                                            LocalizedStringKey(stringInterpolation = str)
                                                        }())
                                                            .font(Font.headline)
                                                            .foregroundColor(Color.primary).Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }.Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }.Compose(composectx)
                                    }
                                    ComposeResult.ok
                                }
                            }
                            .padding().Compose(composectx)

                            GeometryReader { geometry ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ZStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            if (distributionData.isEmpty) {
                                                Circle()
                                                    .fill(Color.gray.opacity(0.2))
                                                    .frame(width = geometry.size.width * 0.9, height = geometry.size.height * 0.9).Compose(composectx)
                                            } else {
                                                ForEach(0..<distributionData.count, id = { it }) { index ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        val startAngle = if (index == 0) 0.0 else sliceAngles[index - 1]
                                                        val endAngle = sliceAngles[index]

                                                        Path { path ->
                                                            val center = CGPoint(x = geometry.size.width / 2, y = geometry.size.height / 2)
                                                            val radius = min(geometry.size.width, geometry.size.height) / 2

                                                            path.value.move(to = center)
                                                            path.value.addArc(center = center, radius = radius, startAngle = Angle(degrees = startAngle), endAngle = Angle(degrees = endAngle), clockwise = false)
                                                        }
                                                        .fill(distributionData[index].color)
                                                        .shadow(color = distributionData[index].color, radius = 5.0).Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }.Compose(composectx)
                                            }
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .aspectRatio(1.0, contentMode = ContentMode.fit)
                            .scaleEffect(0.9)
                            .padding()
                            .frame(width = 200.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .onAppear { -> aggregateBabySexData() }
                    .onChange(of = groupedDeliveries.count) { _ -> aggregateBabySexData() }.Compose(composectx)

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val remembereddistributionData by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Array<BabySexDistributionData>>, Any>) { mutableStateOf(_distributionData) }
        _distributionData = remembereddistributionData

        val rememberedsliceAngles by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Array<Double>>, Any>) { mutableStateOf(_sliceAngles) }
        _sliceAngles = rememberedsliceAngles

        super.ComposeContent(composectx)
    }

    // MARK: - Helper Methods
    private fun aggregateBabySexData() {
        var maleCount = 0
        var femaleCount = 0
        var lossCount = 0

        for ((_, deliveries) in groupedDeliveries.sref()) {
            for (delivery in deliveries.sref()) {
                for (baby in delivery.babies.sref()) {
                    when (baby.sex) {
                        Sex.male -> maleCount += 1
                        Sex.female -> femaleCount += 1
                        Sex.loss -> lossCount += 1
                    }
                }
            }
        }

        val newData = arrayOf(
            BabySexDistributionData(category = "Male", count = maleCount, color = Color.blue),
            BabySexDistributionData(category = "Female", count = femaleCount, color = Color.pink),
            BabySexDistributionData(category = "Loss", count = lossCount, color = Color.purple)
        ).filter { it -> it.count > 0 }

        withAnimation(Animation.easeInOut(duration = 1.0)) { ->
            distributionData = newData
            updateSliceAngles()
        }
    }

    private fun updateSliceAngles() {
        val total = distributionData.map { it -> it.count }.reduce(initialResult = 0, { it, it_1 -> it + it_1 })
        var cumulativeAngle: Double = 0.0
        sliceAngles = distributionData.map l@{ data ->
            var deferaction_0: (() -> Unit)? = null
            try {
                val angle = cumulativeAngle + (Double(data.count) / Double(total)) * 360.0
                deferaction_0 = {
                    cumulativeAngle = angle
                }
                return@l angle
            } finally {
                deferaction_0?.invoke()
            }
        }
    }

    private constructor(groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>, distributionData: Array<BabySexDistributionData> = arrayOf(), sliceAngles: Array<Double> = arrayOf(), privatep: Nothing? = null) {
        this._groupedDeliveries = groupedDeliveries
        this._distributionData = skip.ui.State(distributionData.sref())
        this._sliceAngles = skip.ui.State(sliceAngles.sref())
    }

    constructor(groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>): this(groupedDeliveries = groupedDeliveries, privatep = null) {
    }
}
