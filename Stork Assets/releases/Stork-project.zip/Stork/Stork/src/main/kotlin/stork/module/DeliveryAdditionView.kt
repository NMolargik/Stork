//
//  DeliveryAdditionView.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class DeliveryAdditionView: View {
    // MARK: - AppStorage
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    // MARK: - Environment Objects
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal var deliveryViewModel: DeliveryViewModel
        get() = _deliveryViewModel.wrappedValue
        set(newValue) {
            _deliveryViewModel.wrappedValue = newValue
        }
    internal var _deliveryViewModel = skip.ui.Environment<DeliveryViewModel>()
    internal var hospitalViewModel: HospitalViewModel
        get() = _hospitalViewModel.wrappedValue
        set(newValue) {
            _hospitalViewModel.wrappedValue = newValue
        }
    internal var _hospitalViewModel = skip.ui.Environment<HospitalViewModel>()
    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()
    internal var dailyResetManager: DailyResetManager
        get() = _dailyResetManager.wrappedValue
        set(newValue) {
            _dailyResetManager.wrappedValue = newValue
        }
    internal var _dailyResetManager = skip.ui.Environment<DailyResetManager>()

    // MARK: - Binding
    internal var showingDeliveryAddition: Boolean
        get() = _showingDeliveryAddition.wrappedValue
        set(newValue) {
            _showingDeliveryAddition.wrappedValue = newValue
        }
    internal var _showingDeliveryAddition: Binding<Boolean>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    ScrollView { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            VStack(spacing = 20.0) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    // MARK: - Baby Editor Views with Enhanced Transitions
                                    ForEach(Binding({ _deliveryViewModel.wrappedValue.newDelivery.babies }, { it -> _deliveryViewModel.wrappedValue.newDelivery.babies = it })) { baby ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            val babyIndex = deliveryViewModel.newDelivery.babies.firstIndex(where = { it -> it.id == baby.wrappedValue.id }) ?: 0
                                            val babyNumber = babyIndex + 1

                                            BabyEditorView(baby = baby, babyNumber = babyNumber, removeBaby = { babyId ->
                                                withAnimation(Animation.spring()) { ->
                                                    deliveryViewModel.newDelivery.babies.removeAll { it -> it.id == babyId }
                                                }
                                            })
                                            .id(baby.wrappedValue.id)
                                            .transition(AnyTransition.scale.combined(with = AnyTransition.opacity)).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)

                                    // MARK: - Add A Baby Button Positioned Below ScrollView
                                    CustomButtonView(text = "Add A Baby", width = 250.0, height = 50.0, color = Color.indigo, icon = null, isEnabled = true, onTapAction = { ->
                                        withAnimation(Animation.spring()) { -> deliveryViewModel.addBaby() }
                                    })
                                    .padding(Edge.Set.bottom).Compose(composectx)

                                    Divider().Compose(composectx)

                                    // MARK: - Epidural Used Toggle
                                    Toggle(LocalizedStringKey(stringLiteral = "Epidural Used"), isOn = Binding({ _deliveryViewModel.wrappedValue.newDelivery.epiduralUsed }, { it -> _deliveryViewModel.wrappedValue.newDelivery.epiduralUsed = it }))
                                        .padding()
                                        .fontWeight(Font.Weight.bold)
                                        .background(RoundedRectangle(cornerRadius = 20.0)
                                            .fill(Color.orange.opacity(0.2)))
                                        .tint(Color.green).Compose(composectx)

                                    // MARK: - Add To Muster Toggle (Conditional)
                                    if (!profileViewModel.profile.musterId.isEmpty) {
                                        Toggle(LocalizedStringKey(stringLiteral = "Add To Muster"), isOn = Binding({ _deliveryViewModel.wrappedValue.addToMuster }, { it -> _deliveryViewModel.wrappedValue.addToMuster = it }))
                                            .padding()
                                            .fontWeight(Font.Weight.bold)
                                            .background(RoundedRectangle(cornerRadius = 20.0)
                                                .fill(Color.orange.opacity(0.2)))
                                            .tint(Color.green).Compose(composectx)
                                    }

                                    // MARK: - Delivery Method Picker
                                    VStack(alignment = HorizontalAlignment.leading, spacing = 10.0) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(LocalizedStringKey(stringLiteral = "Delivery Method"))
                                                .font(Font.headline).Compose(composectx)

                                            Picker(LocalizedStringKey(stringLiteral = "Delivery Method"), selection = Binding({ _deliveryViewModel.wrappedValue.newDelivery.deliveryMethod }, { it -> _deliveryViewModel.wrappedValue.newDelivery.deliveryMethod = it })) { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    ForEach(DeliveryMethod.allCases, id = { it }) { method ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            Text(method.description).tag(method).Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }.Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }
                                            .onChange(of = deliveryViewModel.newDelivery.deliveryMethod) { _ -> triggerHaptic() }.Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding()
                                    .frame(maxWidth = Double.infinity)
                                    .background(RoundedRectangle(cornerRadius = 20.0)
                                        .fill(Color.orange.opacity(0.2))).Compose(composectx)

                                    // MARK: - Select Hospital Section
                                    VStack(alignment = HorizontalAlignment.center, spacing = 10.0) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(deliveryViewModel.selectedHospital?.facility_name ?: "No Hospital Selected")
                                                .font(Font.headline)
                                                .multilineTextAlignment(TextAlignment.center).Compose(composectx)

                                            CustomButtonView(text = "Select A Hospital", width = 250.0, height = 50.0, color = Color.red, icon = Image(systemName = "building"), isEnabled = true, onTapAction = { -> deliveryViewModel.isSelectingHospital = true }).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding()
                                    .frame(maxWidth = Double.infinity)
                                    .background(RoundedRectangle(cornerRadius = 20.0)
                                        .fill(Color.orange.opacity(0.2))).Compose(composectx)

                                    Spacer(minLength = 10.0).Compose(composectx)

                                    // MARK: - Submit Delivery Button or ProgressView
                                    if (deliveryViewModel.isWorking) {
                                        ProgressView()
                                            .frame(height = 40.0)
                                            .padding().Compose(composectx)
                                    } else {
                                        CustomButtonView(text = "Submit Delivery", width = 250.0, height = 50.0, color = Color.green, isEnabled = deliveryViewModel.canSubmitDelivery, onTapAction = { ->
                                            Task(isMainActor = true) { -> submitDelivery() }
                                        }).Compose(composectx)
                                    }
                                    ComposeResult.ok
                                }
                            }
                            .padding().Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onAppear { ->
                withAnimation(Animation.spring()) { ->
                    if (deliveryViewModel.newDelivery.babies.isEmpty) {
                        deliveryViewModel.addBaby()
                    }

                    if (!profileViewModel.profile.musterId.isEmpty) {
                        deliveryViewModel.addToMuster = true
                    }

                    initializeHospital()
                }
            }
            .sheet(isPresented = Binding({ _deliveryViewModel.wrappedValue.isSelectingHospital }, { it -> _deliveryViewModel.wrappedValue.isSelectingHospital = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    HospitalListView(selectionMode = true, onSelection = { selectedHospital ->
                        print("selectedHospital: ${selectedHospital.facility_name}")
                        deliveryViewModel.selectedHospital = selectedHospital
                        deliveryViewModel.newDelivery.hospitalId = selectedHospital.id
                        deliveryViewModel.newDelivery.hospitalName = selectedHospital.facility_name
                        deliveryViewModel.isSelectingHospital = false
                    })
                    .environmentObject(hospitalViewModel)
                    .environmentObject(profileViewModel).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onChange(of = deliveryViewModel.newDelivery.babies) { _ -> deliveryViewModel.additionPropertiesChanged() }
            .onChange(of = deliveryViewModel.selectedHospital) { _ -> deliveryViewModel.additionPropertiesChanged() }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        _deliveryViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = DeliveryViewModel::class)!!
        _hospitalViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = HospitalViewModel::class)!!
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!
        _dailyResetManager.wrappedValue = EnvironmentValues.shared.environmentObject(type = DailyResetManager::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    // MARK: - Helper Functions

    /// Initializes the selected hospital when the view appears.
    private fun initializeHospital() {
        Task { ->
            if (hospitalViewModel.primaryHospital == null) {
                hospitalViewModel.getUserPrimaryHospital(profile = profileViewModel.profile)
            }

            deliveryViewModel.selectedHospital = hospitalViewModel.primaryHospital
        }
    }

    /// Triggers haptic feedback for user interactions.
    private fun triggerHaptic() = Unit

    // MARK: - Submit Delivery Function

    private suspend fun submitDelivery(): Unit = MainActor.run l@{
        var deferaction_0: (() -> Unit)? = null
        try {
            deliveryViewModel.isWorking = true
            deferaction_0 = {
                deliveryViewModel.isWorking = false
            }
            val hospital_0 = deliveryViewModel.selectedHospital.sref()
            if (hospital_0 == null) {
                errorMessage = "No hospital selected"
                return@l
            }

            try {
                deliveryViewModel.submitDelivery(profile = profileViewModel.profile, dailyResetManager = dailyResetManager)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
                return@l
            }

            try {
                hospitalViewModel.updateHospitalWithNewDelivery(hospital = hospital_0, babyCount = deliveryViewModel.newDelivery.babies.count)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
                return@l
            }

            showingDeliveryAddition = false
        } finally {
            deferaction_0?.invoke()
        }
    }

    constructor(errorMessage: String = "", showingDeliveryAddition: Binding<Boolean>) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._showingDeliveryAddition = showingDeliveryAddition
    }
}

// #Preview omitted
