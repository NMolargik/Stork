//
//  ErrorToastView.swift
//
//
//  Created by Nick Molargik on 11/15/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*

internal class ErrorToastView: View {
    private var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    private var _errorMessage: skip.ui.AppStorage<String>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "exclamationmark.triangle.fill")
                                .foregroundStyle(Color.red).Compose(composectx)

                            Text(errorMessage)
                                .foregroundStyle(Color.red).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding()
                    .background { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Color.primary
                                .cornerRadius(20.0)
                                .shadow(color = Color.red, radius = 10.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .onTapGesture { it ->
                        withAnimation { -> errorMessage = "" }
                    }
                    .onAppear { ->
                        DispatchQueue.main.asyncAfter(deadline = Double.now() + 4.0) { ->
                            withAnimation { -> errorMessage = "" }
                        }
                    }.Compose(composectx)

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .transition(AnyTransition.move(edge = Edge.top)).Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private constructor(errorMessage: String = "", privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
    }

    constructor(): this(privatep = null) {
    }
}

// #Preview omitted
