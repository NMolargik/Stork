//
//  PaywallView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 12/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*

internal class PaywallView: View {
    private var appState: AppState
        get() = _appState.wrappedValue
        set(newValue) {
            _appState.wrappedValue = newValue
        }
    private var _appState: skip.ui.AppStorage<AppState>
    internal var selectedTab: Tab
        get() = _selectedTab.wrappedValue
        set(newValue) {
            _selectedTab.wrappedValue = newValue
        }
    internal var _selectedTab: skip.ui.AppStorage<Tab>
    private var isPaywallComplete: Boolean
        get() = _isPaywallComplete.wrappedValue
        set(newValue) {
            _isPaywallComplete.wrappedValue = newValue
        }
    private var _isPaywallComplete: skip.ui.AppStorage<Boolean>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Button(action = { ->
                        withAnimation { ->
                            isPaywallComplete = true
                            selectedTab = Tab.home
                            appState = AppState.main
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Text(LocalizedStringKey(stringLiteral = "Skip Onboarding"))
                                .foregroundStyle(Color.blue).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedappState by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<AppState>, Any>) { mutableStateOf(_appState) }
        _appState = rememberedappState

        val rememberedselectedTab by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Tab>, Any>) { mutableStateOf(_selectedTab) }
        _selectedTab = rememberedselectedTab

        val rememberedisPaywallComplete by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_isPaywallComplete) }
        _isPaywallComplete = rememberedisPaywallComplete

        super.ComposeContent(composectx)
    }

    private constructor(appState: AppState = AppState.splash, selectedTab: Tab = Tab.hospitals, isPaywallComplete: Boolean = false, privatep: Nothing? = null) {
        this._appState = skip.ui.AppStorage(wrappedValue = appState, "appState", serializer = { it.rawValue }, deserializer = { if (it is String) AppState(rawValue = it) else null })
        this._selectedTab = skip.ui.AppStorage(wrappedValue = selectedTab, "selectedTab", serializer = { it.rawValue }, deserializer = { if (it is String) Tab(rawValue = it) else null })
        this._isPaywallComplete = skip.ui.AppStorage(wrappedValue = isPaywallComplete, "isPaywallComplete")
    }

    constructor(selectedTab: Tab = Tab.hospitals): this(selectedTab = selectedTab, privatep = null) {
    }
}

// #Preview omitted
