//
//  MusterInvitationsView.swift
//
//
//  Created by Nick Molargik on 12/11/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class MusterInvitationsView: View, MutableStruct {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    internal lateinit var dismiss: DismissAction

    internal var showMusterInvitations: Boolean
        get() = _showMusterInvitations.wrappedValue
        set(newValue) {
            _showMusterInvitations.wrappedValue = newValue
        }
    internal var _showMusterInvitations: Binding<Boolean>

    internal var onRespond: (MusterInvite, Boolean) -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Group { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if ((musterViewModel.isWorking)) {
                                ProgressView()
                                    .tint(Color.indigo).Compose(composectx)
                            } else if ((musterViewModel.invites.count == 0)) {

                                VStack { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Image(systemName = "exclamationmark.magnifyingglass")
                                            .font(Font.largeTitle)
                                            .padding().Compose(composectx)

                                        Text(LocalizedStringKey(stringLiteral = "No invitations found. Ask a muster admin to send you an invitation!"))
                                            .multilineTextAlignment(TextAlignment.center)
                                            .font(Font.title3).Compose(composectx)

                                        ComposeResult.ok
                                    }
                                }
                                .padding().Compose(composectx)

                            } else {

                                ScrollView { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        ForEach(musterViewModel.invites) { invite ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                VStack(alignment = HorizontalAlignment.leading) { ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        Text(invite.senderName + " invited you to join " + invite.musterName)
                                                            .font(Font.headline)
                                                            .foregroundStyle(Color.black).Compose(composectx)

                                                        HStack { ->
                                                            ComposeBuilder { composectx: ComposeContext ->
                                                                CustomButtonView(text = "Accept", width = 100.0, height = 40.0, color = Color.blue, isEnabled = true, onTapAction = { ->

                                                                    Task(isMainActor = true) { ->
                                                                        musterViewModel.respondToUserInvite(profile = profileViewModel.profile, invite = invite, accepted = true, profileViewModel = profileViewModel)

                                                                        print("Invite Muster ID: ${invite.musterId}")
                                                                        profileViewModel.tempProfile = profileViewModel.profile
                                                                        profileViewModel.tempProfile.musterId = invite.musterId
                                                                        profileViewModel.updateProfile()

                                                                        print("New profile musterID: ${profileViewModel.profile.musterId}")

                                                                        musterViewModel.loadCurrentMuster(profileViewModel = profileViewModel)

                                                                        musterViewModel.isWorking = false
                                                                        musterViewModel.invites.removeAll(where = { it -> it.musterId == invite.musterId })
                                                                        showMusterInvitations = false

                                                                        dismiss()
                                                                    }
                                                                }).Compose(composectx)

                                                                CustomButtonView(text = "Decline", width = 100.0, height = 40.0, color = Color.red, isEnabled = true, onTapAction = { ->

                                                                    Task(isMainActor = true) { ->
                                                                        musterViewModel.respondToUserInvite(profile = profileViewModel.profile, invite = invite, accepted = false, profileViewModel = profileViewModel)

                                                                        musterViewModel.isWorking = false
                                                                        musterViewModel.invites.removeAll(where = { it -> it.musterId == invite.musterId })
                                                                    }
                                                                }).Compose(composectx)
                                                                ComposeResult.ok
                                                            }
                                                        }.Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }
                                                .padding()
                                                .background { ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        Color.white
                                                            .cornerRadius(20.0)
                                                            .shadow(radius = 2.0).Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }
                                                .padding(5.0).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }.Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .onAppear { ->
                        Task(isMainActor = true) { ->
                            try {
                                musterViewModel.fetchUserInvitations(profileId = profileViewModel.profile.id)
                            } catch (error: Throwable) {
                                @Suppress("NAME_SHADOWING") val error = error.aserror()
                                errorMessage = error.localizedDescription
                            }
                        }
                    }
                    .navigationTitle(LocalizedStringKey(stringLiteral = "Your Invitations"))
                    .toolbar { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ToolbarItem(placement = ToolbarItemPlacement.cancellationAction) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(LocalizedStringKey(stringLiteral = "Close")) { ->
                                        triggerHaptic()
                                        showMusterInvitations = false
                                        dismiss()
                                    }
                                    .foregroundStyle(Color.red).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        dismiss = EnvironmentValues.shared.dismiss

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    constructor(errorMessage: String = "", showMusterInvitations: Binding<Boolean>, onRespond: (MusterInvite, Boolean) -> Unit) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._showMusterInvitations = showMusterInvitations
        this.onRespond = onRespond
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = MusterInvitationsView(errorMessage, _showMusterInvitations, onRespond)
}

// #Preview omitted
