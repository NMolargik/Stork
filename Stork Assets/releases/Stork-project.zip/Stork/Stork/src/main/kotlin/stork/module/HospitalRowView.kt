//
//  HospitalRowView.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.foundation.*
import skip.ui.*
import stork.model.*
import skip.model.*

internal class HospitalRowView: View {
    internal lateinit var colorScheme: ColorScheme
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    internal var selectionMode: Boolean
        get() = _selectionMode.wrappedValue
        set(newValue) {
            _selectionMode.wrappedValue = newValue
        }
    internal var _selectionMode: Binding<Boolean>

    internal val hospital: Hospital

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            HStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack(alignment = HorizontalAlignment.leading) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Text(hospital.facility_name)
                                .font(Font.headline)
                                .foregroundStyle(if (selectionMode) Color.blue else (if (colorScheme == ColorScheme.dark) Color.white else Color.black)).Compose(composectx)

                            Text({
                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                str.appendInterpolation(hospital.citytown)
                                str.appendLiteral(", ")
                                str.appendInterpolation(hospital.state)
                                LocalizedStringKey(stringInterpolation = str)
                            }())
                                .font(Font.system(size = 12.0))
                                .fontWeight(Font.Weight.bold)
                                .foregroundStyle(Color.gray).Compose(composectx)

                            HStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Text({
                                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                        str.appendLiteral("Deliveries: ")
                                        str.appendInterpolation(hospital.deliveryCount)
                                        LocalizedStringKey(stringInterpolation = str)
                                    }()).Compose(composectx)

                                    Text({
                                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                        str.appendLiteral("Babies: ")
                                        str.appendInterpolation(hospital.babyCount)
                                        LocalizedStringKey(stringInterpolation = str)
                                    }()).Compose(composectx)

                                    ComposeResult.ok
                                }
                            }
                            .font(Font.system(size = 12.0))
                            .foregroundStyle(Color.gray).Compose(composectx)

                            ComposeResult.ok
                        }
                    }.Compose(composectx)

                    Spacer().Compose(composectx)

                    if ((profileViewModel.profile.primaryHospitalId == hospital.id)) {
                        Image(systemName = "star.fill")
                            .frame(width = 15.0)
                            .foregroundStyle(Color.yellow).Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        colorScheme = EnvironmentValues.shared.colorScheme
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!

        super.ComposeContent(composectx)
    }

    constructor(selectionMode: Binding<Boolean>, hospital: Hospital) {
        this._selectionMode = selectionMode
        this.hospital = hospital.sref()
    }
}

// #Preview omitted
