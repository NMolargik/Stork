//
//  MusterTabView.swift
//
//
//  Created by Nick Molargik on 11/29/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class MusterTabView: View {
    internal lateinit var colorScheme: ColorScheme
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()
    internal var deliveryViewModel: DeliveryViewModel
        get() = _deliveryViewModel.wrappedValue
        set(newValue) {
            _deliveryViewModel.wrappedValue = newValue
        }
    internal var _deliveryViewModel = skip.ui.Environment<DeliveryViewModel>()

    private var showingMusterInvitations: Boolean
        get() = _showingMusterInvitations.wrappedValue
        set(newValue) {
            _showingMusterInvitations.wrappedValue = newValue
        }
    private var _showingMusterInvitations: skip.ui.State<Boolean>
    private var navigationPath: NavigationPath
        get() = _navigationPath.wrappedValue.sref({ this.navigationPath = it })
        set(newValue) {
            _navigationPath.wrappedValue = newValue.sref()
        }
    private var _navigationPath: skip.ui.State<NavigationPath>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack(path = Binding({ _navigationPath.wrappedValue }, { it -> _navigationPath.wrappedValue = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    linvokeComposable l@{
                        val matchtarget_0 = musterViewModel.currentMuster
                        if (matchtarget_0 != null) {
                            val muster = matchtarget_0
                            return@l VStack(spacing = 0.0) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ScrollView(Axis.Set.horizontal) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            HStack(spacing = 16.0) { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    ForEach(musterViewModel.musterMembers, id = { it.id }) { member ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            HStack(alignment = VerticalAlignment.center) { ->
                                                                ComposeBuilder { composectx: ComposeContext ->
                                                                    if (muster.administratorProfileIds.contains(member.id)) {
                                                                        Image(systemName = "crown.fill")
                                                                            .foregroundColor(Color.yellow).Compose(composectx)
                                                                    }

                                                                    Text({
                                                                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                        str.appendInterpolation(member.firstName)
                                                                        str.appendLiteral(" ")
                                                                        str.appendInterpolation(member.lastName.first.optionalmap { it -> "${it}." } ?: "")
                                                                        LocalizedStringKey(stringInterpolation = str)
                                                                    }())
                                                                        .fontWeight(Font.Weight.bold).Compose(composectx)

                                                                    ComposeResult.ok
                                                                }
                                                            }
                                                            .padding(Edge.Set.horizontal, 12.0)
                                                            .padding(Edge.Set.vertical, 8.0)
                                                            .background(Color.gray.opacity(0.2))
                                                            .cornerRadius(20.0).Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }.Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }
                                            .padding(Edge.Set.horizontal).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding(Edge.Set.leading, -5.0)
                                    .frame(height = 30.0).Compose(composectx)

                                    ZStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            JarView(deliveries = Binding.constant(deliveriesForCurrentWeek()), headerText = getCurrentWeekRange() ?: "").Compose(composectx)

                                            VStack { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    getCurrentWeekRange()?.let { weekRange ->
                                                        Text(weekRange)
                                                            .padding(8.0)
                                                            .foregroundStyle(Color.gray)
                                                            .font(Font.headline)
                                                            .fontWeight(Font.Weight.bold)
                                                            .background { ->
                                                                ComposeBuilder { composectx: ComposeContext ->
                                                                    Rectangle()
                                                                        .foregroundStyle(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                                                                        .cornerRadius(20.0)
                                                                        .shadow(color = if (colorScheme == ColorScheme.dark) Color.white else Color.black, radius = 2.0).Compose(composectx)
                                                                    ComposeResult.ok
                                                                }
                                                            }
                                                            .padding(Edge.Set.top, 20.0).Compose(composectx)
                                                    }

                                                    Spacer().Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding().Compose(composectx)

                                    MusterCarouselView().Compose(composectx)

                                    UserDeliveryDistributionView(profiles = musterViewModel.musterMembers, deliveries = deliveryViewModel.musterDeliveries).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .navigationTitle(muster.name)
                            .confirmationDialog(LocalizedStringKey(stringLiteral = "Are you sure you want to leave this muster?"), isPresented = Binding({ _musterViewModel.wrappedValue.showLeaveConfirmation }, { it -> _musterViewModel.wrappedValue.showLeaveConfirmation = it }), titleVisibility = Visibility.visible) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(LocalizedStringKey(stringLiteral = "Leave"), role = ButtonRole.destructive) { -> leaveMuster() }.Compose(composectx)
                                    Button(LocalizedStringKey(stringLiteral = "Cancel"), role = ButtonRole.cancel) { ->  }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .sheet(isPresented = Binding({ _musterViewModel.wrappedValue.showInviteUserSheet }, { it -> _musterViewModel.wrappedValue.showInviteUserSheet = it })) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    MusterAdminInviteUserView()
                                        .interactiveDismissDisabled(true).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .sheet(isPresented = Binding({ _musterViewModel.wrappedValue.showAssignAdminSheet }, { it -> _musterViewModel.wrappedValue.showAssignAdminSheet = it })) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    MusterAdminAssignAdminView()
                                        .presentationDetents(setOf(PresentationDetent.medium))
                                        .interactiveDismissDisabled(true).Compose(composectx)

                                    ComposeResult.ok
                                }
                            }
                            .toolbar { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ToolbarItem(placement = ToolbarItemPlacement.navigationBarTrailing) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Menu(content = { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    if (musterViewModel.isUserAdmin(profile = profileViewModel.profile)) {

                                                        Button(action = { -> musterViewModel.showInviteUserSheet = true }, label = { ->
                                                            ComposeBuilder { composectx: ComposeContext ->
                                                                Label(LocalizedStringKey(stringLiteral = "Invite User"), systemImage = "person.badge.plus").Compose(composectx)
                                                                ComposeResult.ok
                                                            }
                                                        }).Compose(composectx)

                                                        Button(action = { -> musterViewModel.showAssignAdminSheet = true }, label = { ->
                                                            ComposeBuilder { composectx: ComposeContext ->
                                                                Label(LocalizedStringKey(stringLiteral = "Assign Admin"), systemImage = "person.badge.shield.exclamationmark.fill").Compose(composectx)
                                                                ComposeResult.ok
                                                            }
                                                        }).Compose(composectx)
                                                    }

                                                    Button(action = { -> leaveMuster() }, label = { ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            Label(LocalizedStringKey(stringLiteral = "Leave Muster"), systemImage = "door.left.hand.open").Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }).Compose(composectx)

                                                    ComposeResult.ok
                                                }
                                            }, label = { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Image(systemName = "gear")
                                                        .foregroundStyle(Color.orange)
                                                        .fontWeight(Font.Weight.bold).Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                        } else {
                            return@l MusterSplashView().Compose(composectx)
                        }
                    }
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedshowingMusterInvitations by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_showingMusterInvitations) }
        _showingMusterInvitations = rememberedshowingMusterInvitations

        val rememberednavigationPath by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<NavigationPath>, Any>) { mutableStateOf(_navigationPath) }
        _navigationPath = rememberednavigationPath

        colorScheme = EnvironmentValues.shared.colorScheme
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!
        _deliveryViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = DeliveryViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private fun countBabies(of: Sex): Int {
        val sex = of
        val calendar = Calendar.current.sref()
        val now = Date()
        val weekStart_0 = calendar.dateInterval(of = Calendar.Component.weekOfYear, for_ = now)?.start.sref()
        if (weekStart_0 == null) {
            return 0
        }
        val weekEnd_0 = calendar.date(byAdding = Calendar.Component.day, value = 6, to = weekStart_0)
        if (weekEnd_0 == null) {
            return 0
        }

        // Filter deliveries for the current week
        val weekDeliveries = deliveryViewModel.musterDeliveries.filter { delivery -> delivery.date >= weekStart_0 && delivery.date <= weekEnd_0 }

        // Count babies of the specified sex
        return weekDeliveries.reduce(initialResult = 0) { count, delivery ->
            count + delivery.babies.filter { it -> it.sex == sex }.count
        }
    }

    private fun getCurrentWeekRange(): String? {
        val calendar = Calendar.current.sref()
        val now = Date()
        val weekStart_1 = calendar.dateInterval(of = Calendar.Component.weekOfYear, for_ = now)?.start.sref()
        if (weekStart_1 == null) {
            return null
        }
        val weekEnd_1 = calendar.date(byAdding = Calendar.Component.day, value = 6, to = weekStart_1)
        if (weekEnd_1 == null) {
            return null
        }

        val formatter = DateFormatter()
        formatter.dateFormat = "MMM d" // Example: "Aug 9"

        val startDate = formatter.string(from = weekStart_1)
        val endDate = formatter.string(from = weekEnd_1)

        return "${startDate} - ${endDate}"
    }

    private fun deliveriesForCurrentWeek(): Array<Delivery> {
        val calendar = Calendar.current.sref()
        val now = Date()
        val weekStart_2 = calendar.dateInterval(of = Calendar.Component.weekOfYear, for_ = now)?.start.sref()
        if (weekStart_2 == null) {
            return arrayOf()
        }
        val weekEnd_2 = calendar.date(byAdding = Calendar.Component.day, value = 6, to = weekStart_2)
        if (weekEnd_2 == null) {
            return arrayOf()
        }

        // Filter deliveries within the week range
        return deliveryViewModel.musterDeliveries.filter { delivery -> delivery.date >= weekStart_2 && delivery.date <= weekEnd_2 }
    }

    private fun leaveMuster() {
        Task { ->
            musterViewModel.isWorking = true

            try {
                musterViewModel.leaveMuster(profileViewModel = profileViewModel)

                profileViewModel.tempProfile = profileViewModel.profile
                profileViewModel.tempProfile.musterId = ""

                profileViewModel.updateProfile()
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                musterViewModel.isWorking = false
                errorMessage = error.localizedDescription
                throw error as Throwable
            }

            musterViewModel.isWorking = false
        }
    }

    private constructor(errorMessage: String = "", showingMusterInvitations: Boolean = false, navigationPath: NavigationPath = NavigationPath(), privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._showingMusterInvitations = skip.ui.State(showingMusterInvitations)
        this._navigationPath = skip.ui.State(navigationPath.sref())
    }

    constructor(errorMessage: String = ""): this(errorMessage = errorMessage, privatep = null) {
    }
}

// #Preview omitted
