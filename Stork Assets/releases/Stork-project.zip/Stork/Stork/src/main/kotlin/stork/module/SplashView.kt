//
//  SplashView.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class SplashView: View {
    // MARK: App Storage Variables
    private var appState: AppState
        get() = _appState.wrappedValue
        set(newValue) {
            _appState.wrappedValue = newValue
        }
    private var _appState: skip.ui.AppStorage<AppState>
    private var loggedIn: Boolean
        get() = _loggedIn.wrappedValue
        set(newValue) {
            _loggedIn.wrappedValue = newValue
        }
    private var _loggedIn: skip.ui.AppStorage<Boolean>
    private var isOnboardingComplete: Boolean
        get() = _isOnboardingComplete.wrappedValue
        set(newValue) {
            _isOnboardingComplete.wrappedValue = newValue
        }
    private var _isOnboardingComplete: skip.ui.AppStorage<Boolean>

    // MARK: Environment Variables
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    // MARK: Bindings
    internal var showRegistration: Boolean
        get() = _showRegistration.wrappedValue
        set(newValue) {
            _showRegistration.wrappedValue = newValue
        }
    internal var _showRegistration: Binding<Boolean>

    // MARK: Local State Variables
    private var isAnimating: Boolean
        get() = _isAnimating.wrappedValue
        set(newValue) {
            _isAnimating.wrappedValue = newValue
        }
    private var _isAnimating: skip.ui.State<Boolean>
    private var showMore: Boolean
        get() = _showMore.wrappedValue
        set(newValue) {
            _showMore.wrappedValue = newValue
        }
    private var _showMore: skip.ui.State<Boolean>
    private var isInfoPresented: Boolean
        get() = _isInfoPresented.wrappedValue
        set(newValue) {
            _isInfoPresented.wrappedValue = newValue
        }
    private var _isInfoPresented: skip.ui.State<Boolean>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            ZStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            HStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Spacer().Compose(composectx)

                                    Button(action = { ->
                                        withAnimation { ->
                                            triggerHaptic()
                                            isInfoPresented = true
                                        }
                                    }, label = { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Image(systemName = "info.circle.fill")
                                                .foregroundStyle(Color.orange)
                                                .font(Font.title).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .padding(Edge.Set.trailing).Compose(composectx)

                            Spacer().Compose(composectx)

                            Text(LocalizedStringKey(stringLiteral = "Stork"))
                                .font(Font.system(size = 50.0))
                                .fontWeight(Font.Weight.bold)
                                .opacity(if (isAnimating) 1.0 else 0.0)
                                .animation(Animation.easeInOut(duration = 1.5), value = isAnimating).Compose(composectx)

                            if (showMore) {
                                Text(LocalizedStringKey(stringLiteral = "a labor and delivery app"))
                                    .font(Font.headline)
                                    .fontWeight(Font.Weight.bold)
                                    .padding(Edge.Set.bottom)
                                    .transition(AnyTransition.move(edge = Edge.bottom).combined(with = AnyTransition.opacity)).Compose(composectx)
                            }

                            LoginView(onAuthenticated = { ->
                                withAnimation { ->
                                    this.loggedIn = true
                                    appState = if ((isOnboardingComplete)) AppState.main else AppState.onboard
                                }
                            })
                            .opacity(if (showMore && !loggedIn) 1.0 else 0.0)
                            .transition(AnyTransition.move(edge = Edge.bottom).combined(with = AnyTransition.opacity)).Compose(composectx)

                            Divider()
                                .scaleEffect(y = 4.0)
                                .padding(Edge.Set.horizontal).Compose(composectx)

                            Text(LocalizedStringKey(stringLiteral = "Don't have an account yet?"))
                                .padding().Compose(composectx)

                            CustomButtonView(text = "Sign Up", width = 120.0, height = 50.0, color = Color.orange, isEnabled = true, onTapAction = { ->
                                withAnimation { ->
                                    profileViewModel.resetTempProfile()
                                    showRegistration = true
                                    appState = AppState.register
                                }
                            }).Compose(composectx)

                            Spacer().Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .toolbar { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if ((!loggedIn)) {
                                ToolbarItem(placement = ToolbarItemPlacement.navigationBarTrailing) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Button(action = { -> isInfoPresented = !isInfoPresented }) { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Image(systemName = "info.circle")
                                                    .font(Font.title2)
                                                    .foregroundColor(Color.indigo).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }
                                        .shadow(radius = 5.0).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .frame(maxWidth = Double.infinity).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onAppear { -> startAnimation() }
            .sheet(isPresented = Binding({ _isInfoPresented.wrappedValue }, { it -> _isInfoPresented.wrappedValue = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    SplashInfoView()
                        .transition(AnyTransition.scale.combined(with = AnyTransition.opacity))
                        .presentationDetents(setOf(PresentationDetent.fraction(0.3))).Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedisAnimating by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_isAnimating) }
        _isAnimating = rememberedisAnimating

        val rememberedshowMore by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_showMore) }
        _showMore = rememberedshowMore

        val rememberedisInfoPresented by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_isInfoPresented) }
        _isInfoPresented = rememberedisInfoPresented

        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!

        val rememberedappState by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<AppState>, Any>) { mutableStateOf(_appState) }
        _appState = rememberedappState

        val rememberedloggedIn by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_loggedIn) }
        _loggedIn = rememberedloggedIn

        val rememberedisOnboardingComplete by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_isOnboardingComplete) }
        _isOnboardingComplete = rememberedisOnboardingComplete

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private fun startAnimation() {
        isAnimating = true
        DispatchQueue.main.asyncAfter(deadline = Double.now() + 0.5) { ->
            withAnimation(Animation.easeIn(duration = 0.5)) { -> this.showMore = true }
        }
    }

    private constructor(appState: AppState = AppState.splash, loggedIn: Boolean = false, isOnboardingComplete: Boolean = false, showRegistration: Binding<Boolean>, isAnimating: Boolean = false, showMore: Boolean = false, isInfoPresented: Boolean = false, privatep: Nothing? = null) {
        this._appState = skip.ui.AppStorage(wrappedValue = appState, "appState", serializer = { it.rawValue }, deserializer = { if (it is String) AppState(rawValue = it) else null })
        this._loggedIn = skip.ui.AppStorage(wrappedValue = loggedIn, "loggedIn")
        this._isOnboardingComplete = skip.ui.AppStorage(wrappedValue = isOnboardingComplete, "isOnboardingComplete")
        this._showRegistration = showRegistration
        this._isAnimating = skip.ui.State(isAnimating)
        this._showMore = skip.ui.State(showMore)
        this._isInfoPresented = skip.ui.State(isInfoPresented)
    }

    constructor(showRegistration: Binding<Boolean>): this(showRegistration = showRegistration, privatep = null) {
    }
}

// #Preview omitted
