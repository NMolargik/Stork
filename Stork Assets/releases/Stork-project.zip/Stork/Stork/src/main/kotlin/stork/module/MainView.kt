//
//  MainView.swift
//
//
//  Created by Nick Molargik on 11/28/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import stork.model.*

import skip.ui.*
import skip.ui.List

class MainView: View {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>
    internal var selectedTab: Tab
        get() = _selectedTab.wrappedValue
        set(newValue) {
            _selectedTab.wrappedValue = newValue
        }
    internal var _selectedTab: skip.ui.AppStorage<Tab>

    internal lateinit var colorScheme: ColorScheme
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal var deliveryViewModel: DeliveryViewModel
        get() = _deliveryViewModel.wrappedValue
        set(newValue) {
            _deliveryViewModel.wrappedValue = newValue
        }
    internal var _deliveryViewModel = skip.ui.Environment<DeliveryViewModel>()
    internal var hospitalViewModel: HospitalViewModel
        get() = _hospitalViewModel.wrappedValue
        set(newValue) {
            _hospitalViewModel.wrappedValue = newValue
        }
    internal var _hospitalViewModel = skip.ui.Environment<HospitalViewModel>()
    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()

    private var navigationPath: Array<String>
        get() = _navigationPath.wrappedValue.sref({ this.navigationPath = it })
        set(newValue) {
            _navigationPath.wrappedValue = newValue.sref()
        }
    private var _navigationPath: skip.ui.State<Array<String>>
    private var showingDeliveryAddition: Boolean
        get() = _showingDeliveryAddition.wrappedValue
        set(newValue) {
            _showingDeliveryAddition.wrappedValue = newValue
        }
    private var _showingDeliveryAddition: skip.ui.State<Boolean>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            TabView(selection = _selectedTab.projectedValue) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    // HOME
                    HomeTabView(navigationPath = Binding({ _navigationPath.wrappedValue }, { it -> _navigationPath.wrappedValue = it }), selectedTab = _selectedTab.projectedValue, showingDeliveryAddition = Binding({ _showingDeliveryAddition.wrappedValue }, { it -> _showingDeliveryAddition.wrappedValue = it }))
                        .tabItem { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Label(Tab.home.title, systemImage = Tab.home.icon).Compose(composectx)
                                ComposeResult.ok
                            }
                        }
                        .tag(Tab.home).Compose(composectx)

                    // Deliveries
                    DeliveryTabView(showingDeliveryAddition = Binding({ _showingDeliveryAddition.wrappedValue }, { it -> _showingDeliveryAddition.wrappedValue = it }))
                        .tabItem { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Label(Tab.deliveries.title, systemImage = Tab.deliveries.icon).Compose(composectx)
                                ComposeResult.ok
                            }
                        }
                        .tag(Tab.deliveries).Compose(composectx)

                    // Hospitals
                    HospitalListView(onSelection = { _ ->  })
                        .tabItem { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Label(Tab.hospitals.title, systemImage = Tab.hospitals.icon).Compose(composectx)
                                ComposeResult.ok
                            }
                        }
                        .tag(Tab.hospitals).Compose(composectx)

                    // Muster
                    MusterTabView()
                        .tabItem { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Label(Tab.muster.title, systemImage = Tab.muster.icon).Compose(composectx)
                                ComposeResult.ok
                            }
                        }
                        .tag(Tab.muster).Compose(composectx)

                    // Settings
                    SettingsTabView()
                        .tabItem { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                Label(Tab.settings.title, systemImage = Tab.settings.icon).Compose(composectx)
                                ComposeResult.ok
                            }
                        }
                        .tag(Tab.settings).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .tint(Color.indigo)
            .onChange(of = selectedTab) { _ -> triggerHaptic() }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberednavigationPath by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Array<String>>, Any>) { mutableStateOf(_navigationPath) }
        _navigationPath = rememberednavigationPath

        val rememberedshowingDeliveryAddition by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_showingDeliveryAddition) }
        _showingDeliveryAddition = rememberedshowingDeliveryAddition

        colorScheme = EnvironmentValues.shared.colorScheme
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        _deliveryViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = DeliveryViewModel::class)!!
        _hospitalViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = HospitalViewModel::class)!!
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        val rememberedselectedTab by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Tab>, Any>) { mutableStateOf(_selectedTab) }
        _selectedTab = rememberedselectedTab

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private constructor(errorMessage: String = "", selectedTab: Tab = Tab.hospitals, navigationPath: Array<String> = arrayOf(), showingDeliveryAddition: Boolean = false, privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._selectedTab = skip.ui.AppStorage(wrappedValue = selectedTab, "selectedTab", serializer = { it.rawValue }, deserializer = { if (it is String) Tab(rawValue = it) else null })
        this._navigationPath = skip.ui.State(navigationPath.sref())
        this._showingDeliveryAddition = skip.ui.State(showingDeliveryAddition)
    }

    constructor(errorMessage: String = "", selectedTab: Tab = Tab.hospitals): this(errorMessage = errorMessage, selectedTab = selectedTab, privatep = null) {
    }

    companion object {
    }
}

// #Preview omitted
