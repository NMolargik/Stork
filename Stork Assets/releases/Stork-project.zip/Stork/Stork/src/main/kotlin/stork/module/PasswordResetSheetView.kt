//
//  PasswordResetSheetView.swift
//
//
//  Created by Nick Molargik on 11/28/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*

import java.util.regex.Pattern
import skip.foundation.*
import skip.model.*

internal class PasswordResetSheetView: View {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    internal var isPasswordResetPresented: Boolean
        get() = _isPasswordResetPresented.wrappedValue
        set(newValue) {
            _isPasswordResetPresented.wrappedValue = newValue
        }
    internal var _isPasswordResetPresented: Binding<Boolean>
    internal var email: String
        get() = _email.wrappedValue
        set(newValue) {
            _email.wrappedValue = newValue
        }
    internal var _email: Binding<String>

    private var validEmail: Boolean
        get() = _validEmail.wrappedValue
        set(newValue) {
            _validEmail.wrappedValue = newValue
        }
    private var _validEmail: skip.ui.State<Boolean>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Text(LocalizedStringKey(stringLiteral = "Forgot Your Password?"))
                        .font(Font.title)
                        .fontWeight(Font.Weight.bold).Compose(composectx)

                    Text(LocalizedStringKey(stringLiteral = "Provide an email address and we can send a password reset email."))
                        .font(Font.body)
                        .multilineTextAlignment(TextAlignment.center)
                        .padding().Compose(composectx)

                    CustomTextfieldView(text = Binding({ _email.wrappedValue }, { it -> _email.wrappedValue = it }), hintText = "Enter your email address...", icon = Image(systemName = "envelope"), isSecure = false, iconColor = Color.blue)
                        .padding(Edge.Set.bottom).Compose(composectx)

                    if ((profileViewModel.isWorking)) {
                        ProgressView()
                            .tint(Color.indigo)
                            .frame(height = 40.0)
                            .padding().Compose(composectx)
                    } else {
                        HStack(spacing = 40.0) { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                CustomButtonView(text = "Send", width = 120.0, height = 40.0, color = Color.indigo, isEnabled = validEmail, onTapAction = { ->
                                    Task(isMainActor = true) { ->
                                        try {
                                            profileViewModel.sendPasswordReset()
                                            isPasswordResetPresented = false
                                        } catch (error: Throwable) {
                                            @Suppress("NAME_SHADOWING") val error = error.aserror()
                                            errorMessage = error.localizedDescription
                                            throw error as Throwable
                                        }
                                    }
                                })
                                .onChange(of = email) { email ->
                                    withAnimation { -> validEmail = profileViewModel.isEmailValid(email) }
                                }.Compose(composectx)

                                CustomButtonView(text = "Cancel", width = 120.0, height = 40.0, color = Color.red, isEnabled = true, onTapAction = { ->
                                    withAnimation { -> isPasswordResetPresented = false }
                                }).Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }
            .padding()
            .onChange(of = email) { _ -> validEmail = profileViewModel.isEmailValid(email) }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedvalidEmail by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_validEmail) }
        _validEmail = rememberedvalidEmail

        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private constructor(errorMessage: String = "", isPasswordResetPresented: Binding<Boolean>, email: Binding<String>, validEmail: Boolean = false, privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._isPasswordResetPresented = isPasswordResetPresented
        this._email = email
        this._validEmail = skip.ui.State(validEmail)
    }

    constructor(errorMessage: String = "", isPasswordResetPresented: Binding<Boolean>, email: Binding<String>): this(errorMessage = errorMessage, isPasswordResetPresented = isPasswordResetPresented, email = email, privatep = null) {
    }
}

// #Preview omitted
