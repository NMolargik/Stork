//
//  DeliveryViewModel.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import skip.foundation.*
import stork.model.*
import skip.ui.*
import skip.model.*

@Stable
@Suppress("MUST_BE_INITIALIZED", "MUST_BE_INITIALIZED_OR_FINAL_OR_ABSTRACT")
internal open class DeliveryViewModel: ObservableObject {
    override val objectWillChange = ObservableObjectPublisher()
    internal open var deliveries: Array<Delivery>
        get() = _deliveries.wrappedValue.sref({ this.deliveries = it })
        set(newValue) {
            objectWillChange.send()
            _deliveries.wrappedValue = newValue.sref()
        }
    internal var _deliveries: skip.model.Published<Array<Delivery>> = skip.model.Published(arrayOf())
    internal open var musterDeliveries: Array<Delivery>
        get() = _musterDeliveries.wrappedValue.sref({ this.musterDeliveries = it })
        set(newValue) {
            objectWillChange.send()
            _musterDeliveries.wrappedValue = newValue.sref()
        }
    internal var _musterDeliveries: skip.model.Published<Array<Delivery>> = skip.model.Published(arrayOf())
    internal open var groupedDeliveries: Array<Tuple2<String, Array<Delivery>>>
        get() = _groupedDeliveries.wrappedValue.sref({ this.groupedDeliveries = it })
        set(newValue) {
            objectWillChange.send()
            _groupedDeliveries.wrappedValue = newValue.sref()
        }
    internal var _groupedDeliveries: skip.model.Published<Array<Tuple2<String, Array<Delivery>>>> = skip.model.Published(arrayOf())
    internal open var groupedMusterDeliveries: Array<Tuple2<String, Array<Delivery>>>
        get() = _groupedMusterDeliveries.wrappedValue.sref({ this.groupedMusterDeliveries = it })
        set(newValue) {
            objectWillChange.send()
            _groupedMusterDeliveries.wrappedValue = newValue.sref()
        }
    internal var _groupedMusterDeliveries: skip.model.Published<Array<Tuple2<String, Array<Delivery>>>> = skip.model.Published(arrayOf())
    internal open var newDelivery: Delivery
        get() = _newDelivery.wrappedValue.sref({ this.newDelivery = it })
        set(newValue) {
            objectWillChange.send()
            _newDelivery.wrappedValue = newValue.sref()
        }
    internal var _newDelivery: skip.model.Published<Delivery> = skip.model.Published(Delivery(sample = true))
    internal open var epiduralUsed: Boolean
        get() = _epiduralUsed.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _epiduralUsed.wrappedValue = newValue
        }
    internal var _epiduralUsed: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var deliveryMethod: DeliveryMethod
        get() = _deliveryMethod.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _deliveryMethod.wrappedValue = newValue
        }
    internal var _deliveryMethod: skip.model.Published<DeliveryMethod> = skip.model.Published(DeliveryMethod.vaginal)
    internal open var addToMuster: Boolean
        get() = _addToMuster.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _addToMuster.wrappedValue = newValue
        }
    internal var _addToMuster: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var selectedHospital: Hospital?
        get() = _selectedHospital.wrappedValue.sref({ this.selectedHospital = it })
        set(newValue) {
            objectWillChange.send()
            _selectedHospital.wrappedValue = newValue.sref()
        }
    internal var _selectedHospital: skip.model.Published<Hospital?> = skip.model.Published(null)
    internal open var possibleDuplicates: Array<Delivery>
        get() = _possibleDuplicates.wrappedValue.sref({ this.possibleDuplicates = it })
        set(newValue) {
            objectWillChange.send()
            _possibleDuplicates.wrappedValue = newValue.sref()
        }
    internal var _possibleDuplicates: skip.model.Published<Array<Delivery>> = skip.model.Published(arrayOf())
    internal open var isWorking: Boolean
        get() = _isWorking.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _isWorking.wrappedValue = newValue
        }
    internal var _isWorking: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var isSelectingHospital: Boolean
        get() = _isSelectingHospital.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _isSelectingHospital.wrappedValue = newValue
        }
    internal var _isSelectingHospital: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var canSubmitDelivery: Boolean
        get() = _canSubmitDelivery.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _canSubmitDelivery.wrappedValue = newValue
        }
    internal var _canSubmitDelivery: skip.model.Published<Boolean> = skip.model.Published(false)
    internal var currentDeliveryCount: Int
        get() = _currentDeliveryCount.wrappedValue
        private set(newValue) {
            objectWillChange.send()
            _currentDeliveryCount.wrappedValue = newValue
        }
    internal var _currentDeliveryCount: skip.model.Published<Int> = skip.model.Published(0)

    private var currentDate: Date = Date()
        get() = field.sref({ this.currentDate = it })
        set(newValue) {
            field = newValue.sref()
        }
    private var dailyLimit = 8
    private var timer: Timer? = null

    internal open var deliveryRepository: DeliveryRepositoryInterface
        get() = field.sref({ this.deliveryRepository = it })
        set(newValue) {
            field = newValue.sref()
        }

    // MARK: - Initializer
    constructor(deliveryRepository: DeliveryRepositoryInterface) {
        this.deliveryRepository = deliveryRepository
        resetCountIfNeeded()
        startDailyResetTimer()
        startNewDelivery()
        groupDeliveriesByMonth()
    }

    // MARK: - Delivery Management
    internal open suspend fun submitDelivery(profile: Profile, dailyResetManager: DailyResetManager): Unit = Async.run {
        if (!dailyResetManager.canSubmitDelivery()) {
            throw DeliveryError.creationFailed("You have reached the daily limit of 8 deliveries.")
        }
        if (this.selectedHospital == null) {
            throw DeliveryError.creationFailed("No hospital selected.")
        }

        newDelivery.babyCount = newDelivery.babies.count
        newDelivery.userFirstName = profile.firstName
        newDelivery.userId = profile.id

        if ((this.addToMuster)) {
            newDelivery.musterId = profile.musterId
        }

        print("Delivery: ${newDelivery}")

        try {
            newDelivery = deliveryRepository.createDelivery(delivery = newDelivery)
            this.deliveries.append(newDelivery)

            if ((this.addToMuster)) {
                this.musterDeliveries.append(newDelivery)
            }

            groupDeliveriesByMonth()
            groupMusterDeliveriesByMonth()

        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.creationFailed("Failed to submit delivery: ${error.localizedDescription}")
        }

        // TODO: post-release add to new muster timeline feature if chosen. remember to implement duplicate prevention system

        dailyResetManager.incrementDeliveryCount()
        print("New delivery successfully submitted")


        this.startNewDelivery()
    }

    internal open fun groupDeliveriesByMonth() {
        val dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM ''yy"

        val sortedDeliveries = deliveries.sorted(by = { it, it_1 -> it.date > it_1.date })

        var tempGroupedDeliveries: Array<Tuple2<String, Array<Delivery>>> = arrayOf()
        var currentKey: String? = null
        var currentGroup: Array<Delivery> = arrayOf()

        for (delivery in sortedDeliveries.sref()) {
            val key = dateFormatter.string(from = delivery.date)
            if (key != currentKey) {
                currentKey?.let { existingKey ->
                    tempGroupedDeliveries.append(Tuple2(existingKey, currentGroup.sref()))
                }

                currentKey = key
                currentGroup = arrayOf(delivery)
            } else {
                currentGroup.append(delivery)
            }
        }

        currentKey?.let { existingKey ->
            tempGroupedDeliveries.append(Tuple2(existingKey, currentGroup.sref()))
        }

        DispatchQueue.main.async { ->
            this.groupedDeliveries = tempGroupedDeliveries
            print("Grouped Deliveries Updated")
        }
    }

    internal open fun groupMusterDeliveriesByMonth() {
        val dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM ''yy"

        val sortedDeliveries = musterDeliveries.sorted(by = { it, it_1 -> it.date > it_1.date })

        var tempGroupedDeliveries: Array<Tuple2<String, Array<Delivery>>> = arrayOf()
        var currentKey: String? = null
        var currentGroup: Array<Delivery> = arrayOf()

        for (delivery in sortedDeliveries.sref()) {
            val key = dateFormatter.string(from = delivery.date)
            if (key != currentKey) {
                currentKey?.let { existingKey ->
                    tempGroupedDeliveries.append(Tuple2(existingKey, currentGroup.sref()))
                }

                currentKey = key
                currentGroup = arrayOf(delivery)
            } else {
                currentGroup.append(delivery)
            }
        }

        currentKey?.let { existingKey ->
            tempGroupedDeliveries.append(Tuple2(existingKey, currentGroup.sref()))
        }

        DispatchQueue.main.async { ->
            this.groupedMusterDeliveries = tempGroupedDeliveries
            print("Muster Grouped Deliveries Updated")
        }
    }

    internal open fun startNewDelivery() {
        this.newDelivery = Delivery(id = UUID().uuidString, userId = "", userFirstName = "", hospitalId = "", hospitalName = "", musterId = "", date = Date(), babies = arrayOf(), babyCount = 0, deliveryMethod = DeliveryMethod.vaginal, epiduralUsed = false)
    }

    internal open fun addBaby() {
        val newBaby = Baby(deliveryId = UUID().uuidString, nurseCatch = false, sex = Sex.male)
        newDelivery.babies.append(newBaby)
    }

    internal open suspend fun getUserDeliveries(profile: Profile): Unit = Async.run {
        try {
            val fetchedDeliveries = deliveryRepository.listDeliveries(userId = profile.id, userFirstName = null, hospitalId = null, hospitalName = null, musterId = null, date = null, babyCount = null, deliveryMethod = null, epiduralUsed = null)
            MainActor.run { ->
                this.deliveries = fetchedDeliveries
                groupDeliveriesByMonth()
            }
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw error as Throwable
        }
    }

    internal open suspend fun getMusterDeliveries(muster: Muster): Unit = Async.run {
        run {
            print("GETTING MUSTER DELIVERIES")

            val fetchedDeliveries = deliveryRepository.listDeliveries(userId = null, userFirstName = null, hospitalId = null, hospitalName = null, musterId = muster.id, date = null, babyCount = null, deliveryMethod = null, epiduralUsed = null)

            MainActor.run { ->
                this.musterDeliveries = fetchedDeliveries
                groupMusterDeliveriesByMonth()
            }
        }
    }

    internal open suspend fun searchForDuplicates(musterId: String): Array<Delivery> = Async.run l@{
        this.isWorking = true

        try {
            val duplicates = deliveryRepository.listDeliveries(userId = null, userFirstName = null, hospitalId = selectedHospital?.id, hospitalName = null, musterId = musterId, date = this.currentDate, babyCount = this.selectedHospital?.babyCount, deliveryMethod = this.deliveryMethod, epiduralUsed = this.epiduralUsed)

            this.isWorking = false
            return@l duplicates.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            this.isWorking = false
            return@l arrayOf()
        }
    }

    // MARK: - Daily Limit Handling
    private fun resetCountIfNeeded() {
        val calendar = Calendar.current.sref()
        if (!calendar.isDate(currentDate, inSameDayAs = Date())) {
            currentDate = Date()
            currentDeliveryCount = 0
        }
    }

    private fun startDailyResetTimer() {
        // Get the current date and calendar
        val now = Date()
        val calendar = Calendar.current.sref()

        // Extract components for today
        val currentDateComponents = calendar.dateComponents(setOf(Calendar.Component.year, Calendar.Component.month, Calendar.Component.day), from = now)

        // Manually create the next reset time at 12:01 AM
        var resetComponents = currentDateComponents.sref()
        resetComponents.hour = 0
        resetComponents.minute = 1
        resetComponents.second = 0
        val resetDate_0 = calendar.date(from = resetComponents)
        if (resetDate_0 == null) {
            return
        }

        // If the reset time is in the past for today, move to tomorrow
        val adjustedResetDate = (if (resetDate_0 > now) resetDate_0 else calendar.date(byAdding = Calendar.Component.day, value = 1, to = resetDate_0)!!).sref()

        // Calculate the time interval
        val timeInterval = adjustedResetDate.timeIntervalSince(now)

        // Schedule the timer
        timer = Timer.scheduledTimer(withTimeInterval = timeInterval, repeats = false) { _ ->
            this?.resetDailyLimit()
            this?.startDailyResetTimer() // Schedule the next reset
        }
    }

    internal open fun additionPropertiesChanged() {
        this.canSubmitDelivery = !newDelivery.babies.isEmpty && selectedHospital != null
        print(canSubmitDelivery)
    }

    private fun resetDailyLimit() {
        currentDeliveryCount = 0
        currentDate = Date()
    }
}
