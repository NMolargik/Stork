//
//  TotalWeightAndLengthStatsView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 01/01/25.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

// MARK: - TotalWeightAndLength
/// A SwiftUI view that displays the total weight and length of all babies recorded over the last six months.
internal class TotalWeightAndLengthStatsView: View {
    // MARK: - Properties

    /// Bindings to the grouped deliveries data, where each key is a month-year string and the value is an array of `Delivery` objects.
    internal var groupedDeliveries: Array<Tuple2<String, Array<Delivery>>>
        get() = _groupedDeliveries.wrappedValue.sref({ this.groupedDeliveries = it })
        set(newValue) {
            _groupedDeliveries.wrappedValue = newValue.sref()
        }
    internal var _groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>

    /// Whether to display the stats in metric units (kilograms and centimeters).
    private var useMetric: Boolean
        get() = _useMetric.wrappedValue
        set(newValue) {
            _useMetric.wrappedValue = newValue
        }
    private var _useMetric: skip.ui.AppStorage<Boolean>

    // Total weight and length variables
    private var totalWeight: Double
        get() = _totalWeight.wrappedValue
        set(newValue) {
            _totalWeight.wrappedValue = newValue
        }
    private var _totalWeight: skip.ui.State<Double> // In ounces by default
    private var totalLength: Double
        get() = _totalLength.wrappedValue
        set(newValue) {
            _totalLength.wrappedValue = newValue
        }
    private var _totalLength: skip.ui.State<Double> // In inches by default

    // MARK: - Body
    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Spacer().Compose(composectx)

                    Text(LocalizedStringKey(stringLiteral = "6 Month Stats"))
                        .fontWeight(Font.Weight.bold)
                        .foregroundStyle(Color.gray)
                        .offset(y = 25.0)
                        .frame(height = 10.0)
                        .padding(Edge.Set.bottom, 10.0).Compose(composectx)

                    HStack(spacing = 10.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Text(weightString)
                                .font(Font.title)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.primary).Compose(composectx)

                            Text(LocalizedStringKey(stringLiteral = "&"))
                                .font(Font.title)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.primary).Compose(composectx)

                            Text(lengthString)
                                .font(Font.title)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.primary).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding().Compose(composectx)

                    Text(LocalizedStringKey(stringLiteral = "Delivered"))
                        .fontWeight(Font.Weight.bold)
                        .foregroundStyle(Color.gray)
                        .padding(Edge.Set.bottom, 10.0).Compose(composectx)

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .onAppear { -> calculateTotalStats() }
            .onChange(of = groupedDeliveries.count) { _ -> calculateTotalStats() }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedtotalWeight by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Double>, Any>) { mutableStateOf(_totalWeight) }
        _totalWeight = rememberedtotalWeight

        val rememberedtotalLength by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Double>, Any>) { mutableStateOf(_totalLength) }
        _totalLength = rememberedtotalLength

        val remembereduseMetric by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_useMetric) }
        _useMetric = remembereduseMetric

        super.ComposeContent(composectx)
    }

    // MARK: - Computed Properties

    /// A formatted string for the total weight.
    private val weightString: String
        get() {
            if (useMetric) {
                val totalWeightKg = (totalWeight / 16) * 0.453592
                return "${Int(round(totalWeightKg))} kg"
            } else {
                val totalWeightLbs = totalWeight / 16
                return "${Int(round(totalWeightLbs))} lbs"
            }
        }

    /// A formatted string for the total length.
    private val lengthString: String
        get() {
            if (useMetric) {
                val totalLengthCm = totalLength * 2.54
                return "${Int(round(totalLengthCm))} cm"
            } else {
                return "${Int(round(totalLength))} in"
            }
        }

    // MARK: - Helper Methods

    /// Calculates the total weight and length of babies from the grouped deliveries.
    private fun calculateTotalStats() {
        var weightSum: Double = 0.0 // In ounces
        var lengthSum: Double = 0.0 // In inches

        for ((_, deliveries) in groupedDeliveries.sref()) {
            for (delivery in deliveries.sref()) {
                for (baby in delivery.babies.sref()) {
                    weightSum += baby.weight
                    lengthSum += baby.height
                }
            }
        }

        totalWeight = weightSum
        totalLength = lengthSum
    }

    private constructor(groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>, useMetric: Boolean = false, totalWeight: Double = 0.0, totalLength: Double = 0.0, privatep: Nothing? = null) {
        this._groupedDeliveries = groupedDeliveries
        this._useMetric = skip.ui.AppStorage(wrappedValue = useMetric, "useMetric")
        this._totalWeight = skip.ui.State(totalWeight)
        this._totalLength = skip.ui.State(totalLength)
    }

    constructor(groupedDeliveries: Binding<Array<Tuple2<String, Array<Delivery>>>>): this(groupedDeliveries = groupedDeliveries, privatep = null) {
    }
}
