//
//  DeliveryTabView.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class DeliveryTabView: View {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>
    internal var leftHanded: Boolean
        get() = _leftHanded.wrappedValue
        set(newValue) {
            _leftHanded.wrappedValue = newValue
        }
    internal var _leftHanded: skip.ui.AppStorage<Boolean>

    internal var deliveryViewModel: DeliveryViewModel
        get() = _deliveryViewModel.wrappedValue
        set(newValue) {
            _deliveryViewModel.wrappedValue = newValue
        }
    internal var _deliveryViewModel = skip.ui.Environment<DeliveryViewModel>()
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    internal var showingDeliveryAddition: Boolean
        get() = _showingDeliveryAddition.wrappedValue
        set(newValue) {
            _showingDeliveryAddition.wrappedValue = newValue
        }
    internal var _showingDeliveryAddition: Binding<Boolean>

    private var navigationPath: NavigationPath
        get() = _navigationPath.wrappedValue.sref({ this.navigationPath = it })
        set(newValue) {
            _navigationPath.wrappedValue = newValue.sref()
        }
    private var _navigationPath: skip.ui.State<NavigationPath>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack(path = Binding({ _navigationPath.wrappedValue }, { it -> _navigationPath.wrappedValue = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    DeliveryListView(showingDeliveryAddition = Binding({ _showingDeliveryAddition.wrappedValue }, { it -> _showingDeliveryAddition.wrappedValue = it }))
                        .refreshable { -> MainActor.run {
                            Task(isMainActor = true) { ->
                                try {
                                    deliveryViewModel.getUserDeliveries(profile = profileViewModel.profile)
                                } catch (error: Throwable) {
                                    @Suppress("NAME_SHADOWING") val error = error.aserror()
                                    errorMessage = error.localizedDescription
                                    throw error as Throwable
                                }
                            }
                        } }
                        .navigationTitle(LocalizedStringKey(stringLiteral = "Deliveries"))
                        .navigationDestination(for_ = Delivery::class) { delivery ->
                            ComposeBuilder { composectx: ComposeContext ->
                                linvokeComposable l@{
                                    val matchtarget_0 = deliveryViewModel.deliveries.firstIndex(where = { it -> it.id == delivery.id })
                                    if (matchtarget_0 != null) {
                                        val index = matchtarget_0
                                        return@l DeliveryDetailView(delivery = Binding({ _deliveryViewModel.wrappedValue.deliveries[index] }, { it -> _deliveryViewModel.wrappedValue.deliveries[index] = it })).Compose(composectx)
                                    } else {
                                        return@l Text(LocalizedStringKey(stringLiteral = "Delivery not found")).Compose(composectx)
                                    }
                                }
                                ComposeResult.ok
                            }
                        }
                        .toolbar { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                ToolbarItem { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Button(action = { ->
                                            withAnimation { ->
                                                triggerHaptic()
                                                this.showingDeliveryAddition = true
                                            }
                                        }, label = { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Text(LocalizedStringKey(stringLiteral = "New Delivery"))
                                                    .foregroundStyle(Color.orange)
                                                    .fontWeight(Font.Weight.bold).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .sheet(isPresented = Binding({ _showingDeliveryAddition.wrappedValue }, { it -> _showingDeliveryAddition.wrappedValue = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    NavigationStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            DeliveryAdditionView(showingDeliveryAddition = Binding({ _showingDeliveryAddition.wrappedValue }, { it -> _showingDeliveryAddition.wrappedValue = it }))
                                .toolbar { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        ToolbarItem(placement = ToolbarItemPlacement.navigationBarLeading) { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Text(LocalizedStringKey(stringLiteral = "New Delivery"))
                                                    .fontWeight(Font.Weight.bold).Compose(composectx)

                                                ComposeResult.ok
                                            }
                                        }.Compose(composectx)

                                        ToolbarItem(placement = ToolbarItemPlacement.navigationBarTrailing) { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Button(action = { ->
                                                    triggerHaptic()

                                                    withAnimation { -> showingDeliveryAddition = false }
                                                }) { ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        Text(LocalizedStringKey(stringLiteral = "Cancel"))
                                                            .fontWeight(Font.Weight.bold)
                                                            .foregroundStyle(Color.red).Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }.Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }.Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .interactiveDismissDisabled().Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberednavigationPath by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<NavigationPath>, Any>) { mutableStateOf(_navigationPath) }
        _navigationPath = rememberednavigationPath

        _deliveryViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = DeliveryViewModel::class)!!
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        val rememberedleftHanded by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_leftHanded) }
        _leftHanded = rememberedleftHanded

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private constructor(errorMessage: String = "", leftHanded: Boolean = false, showingDeliveryAddition: Binding<Boolean>, navigationPath: NavigationPath = NavigationPath(), privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._leftHanded = skip.ui.AppStorage(wrappedValue = leftHanded, "leftHanded")
        this._showingDeliveryAddition = showingDeliveryAddition
        this._navigationPath = skip.ui.State(navigationPath.sref())
    }

    constructor(errorMessage: String = "", leftHanded: Boolean = false, showingDeliveryAddition: Binding<Boolean>): this(errorMessage = errorMessage, leftHanded = leftHanded, showingDeliveryAddition = showingDeliveryAddition, privatep = null) {
    }
}

// #Preview omitted
