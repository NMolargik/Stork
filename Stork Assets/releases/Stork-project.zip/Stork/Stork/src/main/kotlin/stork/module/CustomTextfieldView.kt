//
//  CustomTextfieldView.swift
//
//
//  Created by Nick Molargik on 11/27/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class CustomTextfieldView: View, MutableStruct {
    internal lateinit var colorScheme: ColorScheme

    internal var text: String
        get() = _text.wrappedValue
        set(newValue) {
            _text.wrappedValue = newValue
        }
    internal var _text: Binding<String>

    internal var hintText: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var icon: Image
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var isSecure: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var iconColor: Color? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var characterLimit: Int? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack(alignment = HorizontalAlignment.leading, spacing = 2.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            icon
                                .foregroundStyle(iconColor ?: Color.white)
                                .frame(width = 20.0).Compose(composectx)

                            Group { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    if (isSecure) {
                                        SecureField(hintText, text = Binding({ _text.wrappedValue }, { it -> _text.wrappedValue = it }))
                                            .frame(height = 50.0).Compose(composectx)
                                    } else {
                                        TextField(hintText, text = Binding({ _text.wrappedValue }, { it -> _text.wrappedValue = it }))
                                            .frame(height = 50.0).Compose(composectx)

                                    }
                                    ComposeResult.ok
                                }
                            }
                            .padding(Edge.Set.leading, 2.0)
                            .padding(Edge.Set.trailing, 5.0)
                            .textInputAutocapitalization(TextInputAutocapitalization.never)
                            .onChange(of = text) { newValue ->
                                characterLimit?.let { limit ->
                                    if (newValue.count > limit) {
                                        text = String(newValue.prefix(limit))
                                    }
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(Edge.Set.leading)
                    .background { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if ((colorScheme == ColorScheme.dark)) {
                                Color.black
                                    .cornerRadius(20.0)
                                    .shadow(color = Color.gray, radius = 2.0).Compose(composectx)
                            } else {
                                Color.white
                                    .cornerRadius(20.0)
                                    .shadow(radius = 2.0).Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .frame(height = 50.0).Compose(composectx)

                    characterLimit?.let { limit ->
                        Text({
                            val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                            str.appendInterpolation(text.count)
                            str.appendLiteral("/")
                            str.appendInterpolation(limit)
                            LocalizedStringKey(stringInterpolation = str)
                        }())
                            .font(Font.caption)
                            .foregroundColor(if (text.count > limit) Color.red else Color.gray)
                            .frame(maxWidth = Double.infinity, alignment = Alignment.trailing).Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        colorScheme = EnvironmentValues.shared.colorScheme

        super.ComposeContent(composectx)
    }

    constructor(text: Binding<String>, hintText: String, icon: Image, isSecure: Boolean, iconColor: Color? = null, characterLimit: Int? = null) {
        this._text = text
        this.hintText = hintText
        this.icon = icon
        this.isSecure = isSecure
        this.iconColor = iconColor
        this.characterLimit = characterLimit
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = CustomTextfieldView(_text, hintText, icon, isSecure, iconColor, characterLimit)
}

// #Preview omitted
