//
//  SettingsTabView.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class SettingsTabView: View {
    private var useMetric: Boolean
        get() = _useMetric.wrappedValue
        set(newValue) {
            _useMetric.wrappedValue = newValue
        }
    private var _useMetric: skip.ui.AppStorage<Boolean>
    private var useDarkMode: Boolean
        get() = _useDarkMode.wrappedValue
        set(newValue) {
            _useDarkMode.wrappedValue = newValue
        }
    private var _useDarkMode: skip.ui.AppStorage<Boolean>
    private var appState: AppState
        get() = _appState.wrappedValue
        set(newValue) {
            _appState.wrappedValue = newValue
        }
    private var _appState: skip.ui.AppStorage<AppState>
    private var isOnboardingComplete: Boolean
        get() = _isOnboardingComplete.wrappedValue
        set(newValue) {
            _isOnboardingComplete.wrappedValue = newValue
        }
    private var _isOnboardingComplete: skip.ui.AppStorage<Boolean>
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    internal lateinit var colorScheme: ColorScheme
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()

    private var showingDeleteConfirmation: Boolean
        get() = _showingDeleteConfirmation.wrappedValue
        set(newValue) {
            _showingDeleteConfirmation.wrappedValue = newValue
        }
    private var _showingDeleteConfirmation: skip.ui.State<Boolean>
    private var deleteConfirmationStep: Int
        get() = _deleteConfirmationStep.wrappedValue
        set(newValue) {
            _deleteConfirmationStep.wrappedValue = newValue
        }
    private var _deleteConfirmationStep: skip.ui.State<Int>
    private var passwordString: String
        get() = _passwordString.wrappedValue
        set(newValue) {
            _passwordString.wrappedValue = newValue
        }
    private var _passwordString: skip.ui.State<String>

    private val appInfo: Tuple2<String, String>
        get() {
            val name = Bundle.main.object_(forInfoDictionaryKey = "CFBundleDisplayName") as? String ?: Bundle.main.object_(forInfoDictionaryKey = "CFBundleName") as? String ?: "App Name"
            val version = Bundle.main.object_(forInfoDictionaryKey = "CFBundleShortVersionString") as? String ?: "1.0"
            return Tuple2(name, version)
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    List { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Section(header = Text(LocalizedStringKey(stringLiteral = "Profile"))) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    HStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Button(action = { ->
                                                triggerHaptic()

                                                withAnimation { ->
                                                    isOnboardingComplete = false
                                                    appState = AppState.onboard
                                                }
                                            }) { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Text(LocalizedStringKey(stringLiteral = "Restart Onboarding"))
                                                        .fontWeight(Font.Weight.bold)
                                                        .foregroundStyle(Color.indigo).Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)

                                            Spacer().Compose(composectx)

                                            Image(systemName = "book.fill")
                                                .foregroundStyle(Color.indigo)
                                                .frame(width = 30.0).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)

                                    HStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Button(action = { ->
                                                triggerHaptic()

                                                showingDeleteConfirmation = true
                                            }) { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Text(LocalizedStringKey(stringLiteral = "Delete Profile"))
                                                        .fontWeight(Font.Weight.bold)
                                                        .foregroundStyle(Color.red).Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)

                                            Spacer().Compose(composectx)

                                            Image(systemName = "trash.fill")
                                                .foregroundStyle(Color.red)
                                                .frame(width = 30.0).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)

                            Section(header = Text(LocalizedStringKey(stringLiteral = "Preferences"))) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Toggle(LocalizedStringKey(stringLiteral = "Use Metric Units"), isOn = _useMetric.projectedValue)
                                        .tint(Color.green).Compose(composectx)

                                    Toggle(LocalizedStringKey(stringLiteral = "Dark Mode"), isOn = _useDarkMode.projectedValue)
                                        .tint(Color.green).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)

                            // New About Section
                            Section(header = Text(LocalizedStringKey(stringLiteral = "Stork"))) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    HStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(LocalizedStringKey(stringLiteral = "Version")).Compose(composectx)

                                            Spacer().Compose(composectx)

                                            Text(appInfo.version).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)

                                    HStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(LocalizedStringKey(stringLiteral = "Developer")).Compose(composectx)

                                            Spacer().Compose(composectx)

                                            Link(LocalizedStringKey(stringLiteral = "Nick Molargik"), destination = URL(string = "https://www.nickmolargik.tech"))
                                                .foregroundColor(Color.blue)
                                                .underline(false).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)

                                    HStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(LocalizedStringKey(stringLiteral = "Multiplatform Technology")).Compose(composectx)

                                            Spacer().Compose(composectx)

                                            Link(destination = URL(string = "https://skip.tools"), label = { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Text(LocalizedStringKey(stringLiteral = "Skip"))
                                                        .foregroundColor(Color.blue).Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }).Compose(composectx)

                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .navigationTitle(LocalizedStringKey(stringLiteral = "Settings"))
                    .toolbar { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ToolbarItem { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(action = { ->
                                        triggerHaptic()

                                        withAnimation { -> profileViewModel.signOut() }
                                    }) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(LocalizedStringKey(stringLiteral = "Sign Out"))
                                                .fontWeight(Font.Weight.bold)
                                                .foregroundStyle(Color.orange).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .sheet(isPresented = Binding({ _showingDeleteConfirmation.wrappedValue }, { it -> _showingDeleteConfirmation.wrappedValue = it })) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            DeleteConfirmationView(step = Binding({ _deleteConfirmationStep.wrappedValue }, { it -> _deleteConfirmationStep.wrappedValue = it }), showing = Binding({ _showingDeleteConfirmation.wrappedValue }, { it -> _showingDeleteConfirmation.wrappedValue = it }), onDelete = { -> deleteAccount() })
                                .interactiveDismissDisabled()
                                .presentationDetents(setOf(PresentationDetent.medium)).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedshowingDeleteConfirmation by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_showingDeleteConfirmation) }
        _showingDeleteConfirmation = rememberedshowingDeleteConfirmation

        val remembereddeleteConfirmationStep by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Int>, Any>) { mutableStateOf(_deleteConfirmationStep) }
        _deleteConfirmationStep = remembereddeleteConfirmationStep

        val rememberedpasswordString by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<String>, Any>) { mutableStateOf(_passwordString) }
        _passwordString = rememberedpasswordString

        colorScheme = EnvironmentValues.shared.colorScheme
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!

        val remembereduseMetric by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_useMetric) }
        _useMetric = remembereduseMetric

        val remembereduseDarkMode by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_useDarkMode) }
        _useDarkMode = remembereduseDarkMode

        val rememberedappState by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<AppState>, Any>) { mutableStateOf(_appState) }
        _appState = rememberedappState

        val rememberedisOnboardingComplete by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_isOnboardingComplete) }
        _isOnboardingComplete = rememberedisOnboardingComplete

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    /// Function to handle account deletion
    private fun deleteAccount() {
        profileViewModel.isWorking = true

        Task l@{ ->
            // Leave Muster
            if ((!profileViewModel.profile.musterId.isEmpty)) {
                try {
                    musterViewModel.leaveMuster(profileViewModel = profileViewModel)
                } catch (error: Throwable) {
                    @Suppress("NAME_SHADOWING") val error = error.aserror()
                    profileViewModel.isWorking = false
                    errorMessage = error.localizedDescription
                    return@l
                }
            }

            try {
                profileViewModel.deleteProfile(password = passwordString)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                profileViewModel.isWorking = false
                errorMessage = error.localizedDescription
                return@l
            }
        }
    }

    private constructor(useMetric: Boolean = false, useDarkMode: Boolean = false, appState: AppState = AppState.splash, isOnboardingComplete: Boolean = false, errorMessage: String = "", showingDeleteConfirmation: Boolean = false, deleteConfirmationStep: Int = 1, passwordString: String = "", privatep: Nothing? = null) {
        this._useMetric = skip.ui.AppStorage(wrappedValue = useMetric, "useMetric")
        this._useDarkMode = skip.ui.AppStorage(wrappedValue = useDarkMode, "useDarkMode")
        this._appState = skip.ui.AppStorage(wrappedValue = appState, "appState", serializer = { it.rawValue }, deserializer = { if (it is String) AppState(rawValue = it) else null })
        this._isOnboardingComplete = skip.ui.AppStorage(wrappedValue = isOnboardingComplete, "isOnboardingComplete")
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._showingDeleteConfirmation = skip.ui.State(showingDeleteConfirmation)
        this._deleteConfirmationStep = skip.ui.State(deleteConfirmationStep)
        this._passwordString = skip.ui.State(passwordString)
    }

    constructor(errorMessage: String = ""): this(errorMessage = errorMessage, privatep = null) {
    }
}

// #Preview omitted
