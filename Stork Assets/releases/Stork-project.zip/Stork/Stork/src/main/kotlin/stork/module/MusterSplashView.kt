//
//  MusterSplashView.swift
//
//
//  Created by Nick Molargik on 12/11/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Set

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class MusterSplashView: View {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            List { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Image(systemName = "person.3")
                                .font(Font.system(size = 50.0))
                                .navigationTitle(LocalizedStringKey(stringLiteral = "Join A Muster"))
                                .padding(Edge.Set.bottom).Compose(composectx)


                            Text(LocalizedStringKey(stringLiteral = "[ muhs-ter ] - noun\nA group of storks"))
                                .multilineTextAlignment(TextAlignment.center)
                                .font(Font.body)
                                .fontWeight(Font.Weight.semibold)
                                .foregroundStyle(Color.gray).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .frame(maxWidth = Double.infinity).Compose(composectx)

                    if ((musterViewModel.isWorking)) {
                        ProgressView().Compose(composectx)
                    } else {

                        Section { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                VStack { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        Text(LocalizedStringKey(stringLiteral = "Create a Muster or accept a pending invitation to an existing Muster to share statistics and gain insights with other nurses and doctors."))
                                            .multilineTextAlignment(TextAlignment.center)
                                            .font(Font.body)
                                            .padding(Edge.Set.bottom, 25.0).Compose(composectx)

                                        CustomButtonView(text = "Create New Muster", width = 300.0, height = 50.0, color = Color.indigo, icon = null, isEnabled = true, onTapAction = { -> musterViewModel.showCreateMusterSheet = true }).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }
                                .padding()
                                .frame(maxWidth = Double.infinity).Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }
            .toolbar { ->
                ComposeBuilder { composectx: ComposeContext ->
                    ToolbarItem { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Button(action = { ->
                                triggerHaptic()

                                Task(isMainActor = true) { ->
                                    try {
                                        musterViewModel.fetchUserInvitations(profileId = profileViewModel.profile.id)
                                        musterViewModel.showMusterInvitations = true
                                    } catch (error: Throwable) {
                                        @Suppress("NAME_SHADOWING") val error = error.aserror()
                                        errorMessage = error.localizedDescription
                                        throw error as Throwable
                                    }
                                }
                            }, label = { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Text(LocalizedStringKey(stringLiteral = "Invitations"))
                                        .fontWeight(Font.Weight.bold)
                                        .foregroundStyle(Color.orange).Compose(composectx)

                                    ComposeResult.ok
                                }
                            }).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .sheet(isPresented = Binding({ _musterViewModel.wrappedValue.showMusterInvitations }, { it -> _musterViewModel.wrappedValue.showMusterInvitations = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    MusterInvitationsView(showMusterInvitations = Binding({ _musterViewModel.wrappedValue.showMusterInvitations }, { it -> _musterViewModel.wrappedValue.showMusterInvitations = it }), onRespond = { invite, accepted ->
                        Task(isMainActor = true) { ->
                            try {
                                musterViewModel.respondToUserInvite(profile = profileViewModel.profile, invite = invite, accepted = accepted, profileViewModel = profileViewModel)
                                musterViewModel.showMusterInvitations = false
                            } catch (error: Throwable) {
                                @Suppress("NAME_SHADOWING") val error = error.aserror()
                                errorMessage = error.localizedDescription
                                throw error as Throwable
                            }
                        }
                    })
                    .presentationDetents(setOf(PresentationDetent.fraction(0.7)))
                    .interactiveDismissDisabled(true).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .sheet(isPresented = Binding({ _musterViewModel.wrappedValue.showCreateMusterSheet }, { it -> _musterViewModel.wrappedValue.showCreateMusterSheet = it })) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    MusterCreationView(showCreateMusterSheet = Binding({ _musterViewModel.wrappedValue.showCreateMusterSheet }, { it -> _musterViewModel.wrappedValue.showCreateMusterSheet = it }))
                        .interactiveDismissDisabled(true).Compose(composectx)

                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    constructor(errorMessage: String = "") {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
    }
}

// #Preview omitted
