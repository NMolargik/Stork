//
//  HospitalViewModel.swift
//
//
//  Created by Nick Molargik on 11/21/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.ui.*
import stork.model.*
import skip.model.*

@Stable
internal open class HospitalViewModel: ObservableObject {
    override val objectWillChange = ObservableObjectPublisher()
    // MARK: - AppStorage
    internal open var errorMessage: String = ""

    // MARK: - Published Properties
    internal open var hospitals: Array<Hospital>
        get() = _hospitals.wrappedValue.sref({ this.hospitals = it })
        set(newValue) {
            objectWillChange.send()
            _hospitals.wrappedValue = newValue.sref()
        }
    internal var _hospitals: skip.model.Published<Array<Hospital>> = skip.model.Published(arrayOf())
    internal open var primaryHospital: Hospital?
        get() = _primaryHospital.wrappedValue.sref({ this.primaryHospital = it })
        set(newValue) {
            objectWillChange.send()
            _primaryHospital.wrappedValue = newValue.sref()
        }
    internal var _primaryHospital: skip.model.Published<Hospital?> = skip.model.Published(null)

    internal open var isWorking: Boolean
        get() = _isWorking.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _isWorking.wrappedValue = newValue
        }
    internal var _isWorking: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var searchQuery: String
        get() = _searchQuery.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _searchQuery.wrappedValue = newValue
        }
    internal var _searchQuery: skip.model.Published<String> = skip.model.Published("")
    internal open var searchEnabled: Boolean
        get() = _searchEnabled.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _searchEnabled.wrappedValue = newValue
        }
    internal var _searchEnabled: skip.model.Published<Boolean> = skip.model.Published(true)
    internal open var usingLocation: Boolean
        get() = _usingLocation.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _usingLocation.wrappedValue = newValue
        }
    internal var _usingLocation: skip.model.Published<Boolean> = skip.model.Published(true)
    internal open var selectedHospital: Hospital?
        get() = _selectedHospital.wrappedValue.sref({ this.selectedHospital = it })
        set(newValue) {
            objectWillChange.send()
            _selectedHospital.wrappedValue = newValue.sref()
        }
    internal var _selectedHospital: skip.model.Published<Hospital?> = skip.model.Published(null)
    internal open var isMissingHospitalSheetPresented: Boolean
        get() = _isMissingHospitalSheetPresented.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _isMissingHospitalSheetPresented.wrappedValue = newValue
        }
    internal var _isMissingHospitalSheetPresented: skip.model.Published<Boolean> = skip.model.Published(false)

    // MARK: - Dependencies
    internal val hospitalRepository: HospitalRepositoryInterface
    internal val locationProvider: LocationProviderInterface

    // MARK: - Initializer
    constructor(hospitalRepository: HospitalRepositoryInterface, locationProvider: LocationProviderInterface) {
        this.hospitalRepository = hospitalRepository.sref()
        this.locationProvider = locationProvider.sref()

        Task { ->
            try {
                fetchHospitalsNearby()
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                // Error handling is done within `fetchHospitalsNearby()`
            }
        }
    }

    // MARK: - Fetch Hospitals Nearby
    /// Fetches hospitals near the user's current location.
    open suspend fun fetchHospitalsNearby(): Unit = MainActor.run {
        var deferaction_0: (() -> Unit)? = null
        try {
            searchQuery = ""
            usingLocation = true
            isWorking = true
            deferaction_0 = {
                isWorking = false
            }

            try {
                val location = MainActor.run { locationProvider }.fetchCurrentLocation()
                val cityState = MainActor.run { locationProvider }.fetchCityAndState(from = Location(latitude = location.latitude, longitude = location.longitude))

                this.hospitals = hospitalRepository.getHospitals(byCity = cityState.city ?: "San Francisco", andState = cityState.state ?: "CA")
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
                throw error as Throwable
            }
        } finally {
            deferaction_0?.invoke()
        }
    }

    // MARK: - Search Hospitals by Partial Name
    /// Searches hospitals by a partial name.
    open suspend fun searchHospitals(): Unit = MainActor.run {
        var deferaction_1: (() -> Unit)? = null
        try {
            usingLocation = false
            isWorking = true
            deferaction_1 = {
                isWorking = false
            }

            try {
                val results = MainActor.run { hospitalRepository }.searchHospitals(byPartialName = MainActor.run { searchQuery })
                this.hospitals = results
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
                throw error as Throwable
            }
        } finally {
            deferaction_1?.invoke()
        }
    }

    // Mark: - Create a missing hospital
    open suspend fun createMissingHospital(name: String): Hospital = MainActor.run l@{
        return@l hospitalRepository.createHospital(name = name)
    }

    // MARK: - Fetch User's Primary Hospital
    /// Loads the primary hospital for a given profile, if it exists.
    open suspend fun getUserPrimaryHospital(profile: Profile): Unit = MainActor.run l@{
        if (profile.primaryHospitalId.isEmpty) {
            return@l
        }
        try {
            this.primaryHospital = hospitalRepository.getHospital(byId = profile.primaryHospitalId)
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            errorMessage = error.localizedDescription
            throw error as Throwable
        }
    }

    // MARK: - Update Hospital with a New Delivery
    /// Updates hospital stats (deliveryCount, babyCount) after a new delivery.
    open suspend fun updateHospitalWithNewDelivery(hospital: Hospital, babyCount: Int): Unit = MainActor.run {
        var deferaction_2: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_2 = {
                isWorking = false
            }

            try {
                val updatedHospital = MainActor.run { hospitalRepository }.updateHospitalStats(hospital = hospital, additionalDeliveryCount = 1, additionalBabyCount = babyCount)

                // Replace the existing hospital in the local array
                hospitals.firstIndex(where = { it -> it.id == hospital.id })?.let { index ->
                    hospitals[index] = updatedHospital.sref()
                }
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                errorMessage = error.localizedDescription
                throw error as Throwable
            }
        } finally {
            deferaction_2?.invoke()
        }
    }
}
