//
//  MissingHospitalSheetView.swift
//
//
//  Created by Nick Molargik on 12/1/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*


//TODO: investigate effects of throwing here
@Suppress("MUST_BE_INITIALIZED")
internal class MissingHospitalSheetView: View, MutableStruct {
    internal lateinit var dismiss: DismissAction
    private var hospitalName: String
        get() = _hospitalName.wrappedValue
        set(newValue) {
            _hospitalName.wrappedValue = newValue
        }
    private var _hospitalName: skip.ui.State<String>
    private var isSubmitting: Boolean
        get() = _isSubmitting.wrappedValue
        set(newValue) {
            _isSubmitting.wrappedValue = newValue
        }
    private var _isSubmitting: skip.ui.State<Boolean>
    private var errorMessage: String?
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    private var _errorMessage: skip.ui.State<String?> = skip.ui.State(null)

    internal var onSubmit: suspend (String) -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack(alignment = HorizontalAlignment.center) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Text(LocalizedStringKey(stringLiteral = "Missing Hospital"))
                        .font(Font.title)
                        .fontWeight(Font.Weight.bold)
                        .padding().Compose(composectx)

                    Text(LocalizedStringKey(stringLiteral = "Sorry we are missing your hospital. Please provide its name and we will take it from there!"))
                        .multilineTextAlignment(TextAlignment.center)
                        .font(Font.headline).Compose(composectx)

                    CustomTextfieldView(text = Binding({ _hospitalName.wrappedValue }, { it -> _hospitalName.wrappedValue = it }), hintText = "Missing hospital name...", icon = Image(systemName = "building"), isSecure = false, iconColor = Color.orange)
                        .padding().Compose(composectx)

                    errorMessage?.let { errorMessage ->
                        Text(errorMessage)
                            .foregroundColor(Color.red)
                            .multilineTextAlignment(TextAlignment.center)
                            .padding(Edge.Set.bottom).Compose(composectx)
                    }

                    if ((isSubmitting)) {
                        ProgressView()
                            .frame(height = 40.0)
                            .padding().Compose(composectx)
                    } else {
                        HStack { ->
                            ComposeBuilder { composectx: ComposeContext ->
                                CustomButtonView(text = "Submit", width = 150.0, height = 40.0, color = if (hospitalName.isEmpty) Color.gray else Color.indigo, isEnabled = !hospitalName.isEmpty, onTapAction = { ->
                                    Task(isMainActor = true) { ->
                                        isSubmitting = true
                                        errorMessage = null
                                        try {
                                            onSubmit(hospitalName)
                                            dismiss()
                                        } catch (error: Throwable) {
                                            @Suppress("NAME_SHADOWING") val error = error.aserror()
                                            errorMessage = "Failed to add hospital: ${error.localizedDescription}"
                                        }
                                        isSubmitting = false
                                    }
                                }).Compose(composectx)

                                CustomButtonView(text = "Cancel", width = 150.0, height = 40.0, color = Color.red, isEnabled = true, onTapAction = { -> dismiss() }).Compose(composectx)
                                ComposeResult.ok
                            }
                        }.Compose(composectx)
                    }

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding().Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedhospitalName by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<String>, Any>) { mutableStateOf(_hospitalName) }
        _hospitalName = rememberedhospitalName

        val rememberedisSubmitting by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Boolean>, Any>) { mutableStateOf(_isSubmitting) }
        _isSubmitting = rememberedisSubmitting

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<String?>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        dismiss = EnvironmentValues.shared.dismiss

        super.ComposeContent(composectx)
    }

    private constructor(hospitalName: String = "", isSubmitting: Boolean = false, errorMessage: String? = null, onSubmit: suspend (String) -> Unit, privatep: Nothing? = null) {
        this._hospitalName = skip.ui.State(hospitalName)
        this._isSubmitting = skip.ui.State(isSubmitting)
        this._errorMessage = skip.ui.State(errorMessage)
        this.onSubmit = onSubmit
    }

    constructor(onSubmit: suspend (String) -> Unit): this(onSubmit = onSubmit, privatep = null) {
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = MissingHospitalSheetView(hospitalName, isSubmitting, errorMessage, onSubmit)
}
