package stork.module

import skip.lib.*

open class StorkModule {

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
