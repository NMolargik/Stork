//
//  ProfileRowView.swift
//
//  Created by Nick Molargik on 12/11/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

@Suppress("MUST_BE_INITIALIZED")
internal class ProfileRowView: View, MutableStruct {
    private var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    private var _errorMessage: skip.ui.AppStorage<String>

    internal var existingInvitations: Array<MusterInvite>
        get() = _existingInvitations.wrappedValue.sref({ this.existingInvitations = it })
        set(newValue) {
            _existingInvitations.wrappedValue = newValue.sref()
        }
    internal var _existingInvitations: Binding<Array<MusterInvite>>

    internal var profile: Profile
        get() = field.sref({ this.profile = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    internal var currentUser: Profile
        get() = field.sref({ this.currentUser = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    internal var onInvite: () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            HStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    // Profile Information
                    VStack(alignment = HorizontalAlignment.leading, spacing = 4.0) { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Text({
                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                str.appendInterpolation(profile.role.description)
                                str.appendLiteral(" ")
                                str.appendInterpolation(profile.firstName)
                                str.appendLiteral(" ")
                                str.appendInterpolation(profile.lastName)
                                LocalizedStringKey(stringInterpolation = str)
                            }())
                                .font(Font.title3)
                                .fontWeight(Font.Weight.bold)
                                .foregroundColor(Color.black).Compose(composectx)

                            HStack(spacing = 4.0) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Image(systemName = "birthday.cake.fill").Compose(composectx)
                                    Text(Companion.dateFormatter.string(from = profile.birthday))
                                        .foregroundColor(Color.gray).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)

                    Spacer().Compose(composectx)

                    // Action Buttons or Status Indicators
                    actionButtonGroup.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding()
            .frame(maxWidth = Double.infinity)
            .background(Color.white
                .cornerRadius(20.0)
                .shadow(radius = 2.0)).Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    // MARK: - Action Button Group
    private val actionButtonGroup: View
        get() {
            return Group { ->
                ComposeBuilder { composectx: ComposeContext ->
                    if (profile.id == currentUser.id) {
                        actionButton(text = "You", color = Color.gray, isEnabled = false) { -> errorMessage = "This... is you..." }.Compose(composectx)
                    } else if (profile.musterId == currentUser.musterId && !profile.musterId.isEmpty) {
                        actionButton(text = "Joined", color = Color.gray, isEnabled = false) { -> errorMessage = "User already joined muster" }.Compose(composectx)
                    } else if (!profile.musterId.isEmpty) {
                        actionButton(text = "Unavailable", color = Color.gray, isEnabled = false) { -> errorMessage = "This user is already in a muster." }.Compose(composectx)
                    } else if (existingInvitations.contains(where = { it -> it.recipientId == profile.id })) {
                        actionButton(text = "Sent", color = Color.gray, isEnabled = false) { -> errorMessage = "User already invited to muster" }.Compose(composectx)
                    } else {
                        actionButton(text = "Invite", color = Color.blue, isEnabled = true) { -> onInvite() }.Compose(composectx)
                    }
                    ComposeResult.ok
                }
            }
        }

    // MARK: - Action Button Helper
    private fun actionButton(text: String, color: Color, isEnabled: Boolean, action: () -> Unit): View {
        return CustomButtonView(text = text, width = 120.0, height = 50.0, color = color, icon = null, isEnabled = isEnabled, onTapAction = { ->
            withAnimation { -> action() }
        })
    }

    private constructor(errorMessage: String = "", existingInvitations: Binding<Array<MusterInvite>>, profile: Profile, currentUser: Profile, onInvite: () -> Unit, privatep: Nothing? = null) {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
        this._existingInvitations = existingInvitations
        this.profile = profile
        this.currentUser = currentUser
        this.onInvite = onInvite
    }

    constructor(existingInvitations: Binding<Array<MusterInvite>>, profile: Profile, currentUser: Profile, onInvite: () -> Unit): this(existingInvitations = existingInvitations, profile = profile, currentUser = currentUser, onInvite = onInvite, privatep = null) {
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = ProfileRowView(errorMessage, _existingInvitations, profile, currentUser, onInvite)

    companion object {

        private val dateFormatter: DateFormatter = linvoke l@{ ->
            val formatter = DateFormatter()
            formatter.dateFormat = "MM/dd/yyyy"
            return@l formatter
        }
    }
}

// #Preview omitted

