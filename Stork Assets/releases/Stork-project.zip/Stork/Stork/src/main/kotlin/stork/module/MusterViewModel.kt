//
//  MusterViewModel.swift
//  Stork
//
//  Created by Nick Molargik on 12/11/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.ui.*
import stork.model.*
import skip.model.*

@Stable
open class MusterViewModel: ObservableObject {
    override val objectWillChange = ObservableObjectPublisher()
    // MARK: - Published Properties

    internal open var currentMuster: Muster?
        get() = _currentMuster.wrappedValue.sref({ this.currentMuster = it })
        set(newValue) {
            objectWillChange.send()
            _currentMuster.wrappedValue = newValue.sref()
        }
    internal var _currentMuster: skip.model.Published<Muster?> = skip.model.Published(null)
    internal open var invites: Array<MusterInvite>
        get() = _invites.wrappedValue.sref({ this.invites = it })
        set(newValue) {
            objectWillChange.send()
            _invites.wrappedValue = newValue.sref()
        }
    internal var _invites: skip.model.Published<Array<MusterInvite>> = skip.model.Published(arrayOf())
    internal open var showMusterInvitations: Boolean
        get() = _showMusterInvitations.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _showMusterInvitations.wrappedValue = newValue
        }
    internal var _showMusterInvitations: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var showCreateMusterSheet: Boolean
        get() = _showCreateMusterSheet.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _showCreateMusterSheet.wrappedValue = newValue
        }
    internal var _showCreateMusterSheet: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var showLeaveConfirmation: Boolean
        get() = _showLeaveConfirmation.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _showLeaveConfirmation.wrappedValue = newValue
        }
    internal var _showLeaveConfirmation: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var isWorking: Boolean
        get() = _isWorking.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _isWorking.wrappedValue = newValue
        }
    internal var _isWorking: skip.model.Published<Boolean> = skip.model.Published(false)

    // Admin Sheets
    internal open var showInviteUserSheet: Boolean
        get() = _showInviteUserSheet.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _showInviteUserSheet.wrappedValue = newValue
        }
    internal var _showInviteUserSheet: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var showAssignAdminSheet: Boolean
        get() = _showAssignAdminSheet.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _showAssignAdminSheet.wrappedValue = newValue
        }
    internal var _showAssignAdminSheet: skip.model.Published<Boolean> = skip.model.Published(false)

    // Creation
    internal open var newMuster: Muster
        get() = _newMuster.wrappedValue.sref({ this.newMuster = it })
        set(newValue) {
            objectWillChange.send()
            _newMuster.wrappedValue = newValue.sref()
        }
    internal var _newMuster: skip.model.Published<Muster> = skip.model.Published(Muster(id = UUID().uuidString, profileIds = arrayOf(), primaryHospitalId = "", administratorProfileIds = arrayOf(), name = ""))
    internal open var showHospitalSelection: Boolean
        get() = _showHospitalSelection.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _showHospitalSelection.wrappedValue = newValue
        }
    internal var _showHospitalSelection: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var creationFormValid: Boolean
        get() = _creationFormValid.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _creationFormValid.wrappedValue = newValue
        }
    internal var _creationFormValid: skip.model.Published<Boolean> = skip.model.Published(false)
    internal open var nameError: String?
        get() = _nameError.wrappedValue
        set(newValue) {
            objectWillChange.send()
            _nameError.wrappedValue = newValue
        }
    internal var _nameError: skip.model.Published<String?> = skip.model.Published(null)
    internal open var musterMembers: Array<Profile>
        get() = _musterMembers.wrappedValue.sref({ this.musterMembers = it })
        set(newValue) {
            objectWillChange.send()
            _musterMembers.wrappedValue = newValue.sref()
        }
    internal var _musterMembers: skip.model.Published<Array<Profile>> = skip.model.Published(arrayOf())

    // Invitation
    internal open var invite: MusterInvite?
        get() = _invite.wrappedValue.sref({ this.invite = it })
        set(newValue) {
            objectWillChange.send()
            _invite.wrappedValue = newValue.sref()
        }
    internal var _invite: skip.model.Published<MusterInvite?> = skip.model.Published(null)

    // Predefined Colors
    internal val colors: Array<Color> = arrayOf(Color.red, Color.orange, Color.yellow, Color.green, Color.blue, Color.purple)

    // MARK: - Dependencies

    private val musterRepository: MusterRepositoryInterface

    // MARK: - Initializer
    constructor(musterRepository: MusterRepositoryInterface) {
        this.musterRepository = musterRepository.sref()
    }

    // MARK: - Creation Methods

    /// Validates the creation form and updates the form's validity state.
    internal open fun validateCreationForm() {
        if (newMuster.name.count > 25) {
            nameError = "Muster name cannot exceed 25 characters"
        } else {
            nameError = null
        }

        creationFormValid = !newMuster.name.isEmpty && newMuster.name.count <= 25 && !newMuster.primaryHospitalId.isEmpty
    }

    /// Creates a new muster with the provided profile ID.
    internal open suspend fun createMuster(profileId: String): Unit = MainActor.run {
        var deferaction_0: (() -> Unit)? = null
        try {
            if (newMuster.name.isEmpty) {
                throw MusterError.creationFailed("Muster must have a name!")
            }
            if (newMuster.primaryHospitalId.isEmpty) {
                throw MusterError.creationFailed("Muster must have a primary hospital!")
            }

            isWorking = true
            deferaction_0 = {
                isWorking = false
            }

            newMuster.profileIds.append(profileId)
            newMuster.administratorProfileIds.append(profileId)

            newMuster = musterRepository.createMuster(muster = newMuster)
            print("New muster successfully created")

            currentMuster = newMuster
            resetNewMuster()
        } finally {
            deferaction_0?.invoke()
        }
    }

    /// Resets the `newMuster` to its default state.
    private fun resetNewMuster() {
        newMuster = Muster(id = UUID().uuidString, profileIds = arrayOf(), primaryHospitalId = "", administratorProfileIds = arrayOf(), name = "")
    }

    // MARK: - Muster Management

    /// Loads the current muster based on the provided `ProfileViewModel`.
    internal open suspend fun loadCurrentMuster(profileViewModel: ProfileViewModel): Unit = MainActor.run l@{
        var deferaction_1: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_1 = {
                isWorking = false
            }

            if (profileViewModel.profile.musterId.isEmpty) {
                // The user is not in a muster
                return@l
            }

            try {
                currentMuster = musterRepository.getMuster(byId = profileViewModel.profile.musterId)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                print("Records indicate user is not currently in a muster")
                currentMuster = null
                return@l
            }
            val muster_0 = currentMuster.sref()
            if (muster_0 == null) {
                throw MusterError.updateFailed("Could not load muster")
            }

            musterMembers = profileViewModel.listProfiles(musterId = muster_0.id)
        } finally {
            deferaction_1?.invoke()
        }
    }

    /// Clears the current muster data.
    internal open fun clearCurrentMuster() {
        currentMuster = null
    }

    /// Allows a user to leave the current muster.
    internal open suspend fun leaveMuster(profileViewModel: ProfileViewModel): Unit = MainActor.run {
        var deferaction_2: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_2 = {
                isWorking = false
            }

            loadCurrentMuster(profileViewModel = profileViewModel)

            var muster = requireMuster() // Unwrap or throw

            muster.profileIds.removeAll { it -> it == profileViewModel.profile.id }
            muster.administratorProfileIds.removeAll { it -> it == profileViewModel.profile.id }

            // If no admins remain, assign the first member as admin
            if (muster.administratorProfileIds.isEmpty && !muster.profileIds.isEmpty) {
                muster.administratorProfileIds.append(muster.profileIds.first!!)
            }

            if (muster.profileIds.isEmpty) {
                // No members left, so delete the muster
                deleteMuster(muster = muster)
            } else {
                updateMuster(muster = muster)
            }

            clearCurrentMuster()
        } finally {
            deferaction_2?.invoke()
        }
    }

    /// Deletes the muster if no members are left.
    private suspend fun deleteMuster(muster: Muster): Unit = MainActor.run {
        musterRepository.deleteMuster(muster = muster)
        currentMuster = null

        musterRepository.deleteMusterInvites(musterId = muster.id)

        print("Muster deleted successfully")
    }

    /// Updates the muster with the provided changes and refreshes `currentMuster`.
    private suspend fun updateMuster(muster: Muster): Unit = MainActor.run {
        val updated = MainActor.run { musterRepository }.updateMuster(muster = muster)
        currentMuster = updated
        print("Muster updated successfully")
    }

    // MARK: - Invitation Handling

    /// Fetches user invitations based on the provided profile ID.
    internal open suspend fun fetchUserInvitations(profileId: String): Unit = MainActor.run {
        var deferaction_3: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_3 = {
                isWorking = false
            }

            invites = musterRepository.collectUserMusterInvites(userId = profileId)
        } finally {
            deferaction_3?.invoke()
        }
    }

    /// Responds to a user's muster invite.
    internal open suspend fun respondToUserInvite(profile: Profile, invite: MusterInvite, accepted: Boolean, profileViewModel: ProfileViewModel): Unit = MainActor.run {
        var deferaction_4: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_4 = {
                isWorking = false
            }

            if (accepted) {
                acceptInvite(profile = profile, invite = invite, profileViewModel = profileViewModel)
            } else {
                declineInvite(invite = invite)
            }
        } finally {
            deferaction_4?.invoke()
        }
    }

    /// Accepts a muster invite.
    private suspend fun acceptInvite(profile: Profile, invite: MusterInvite, profileViewModel: ProfileViewModel): Unit = MainActor.run {
        resetMusterInviteState()

        currentMuster = musterRepository.getMuster(byId = invite.musterId)
        var muster = requireMuster()

        // Add this profile to muster membership
        muster.profileIds.append(profile.id)

        updateMuster(muster = muster)

        // Cancel the invite
        musterRepository.cancelMusterInvite(invitationId = invite.id)
        invites.removeAll { it -> it.id == invite.id }

        // Update local profile musterId
        profileViewModel.profile.musterId = muster.id
    }

    /// Declines a muster invite.
    private suspend fun declineInvite(invite: MusterInvite): Unit = MainActor.run {
        musterRepository.cancelMusterInvite(invitationId = invite.id)
        invites.removeAll { it -> it.id == invite.id }
    }

    // MARK: - Admin Functions

    /// Invites a user to the current muster.
    internal open suspend fun inviteUserToMuster(profile: Profile, currentUser: Profile): Unit = MainActor.run {
        var deferaction_5: (() -> Unit)? = null
        try {
            val muster = requireMuster()
            if (!muster.administratorProfileIds.contains(currentUser.id)) {
                throw MusterError.invitationFailed("Only muster admins can invite.")
            }

            resetMusterInviteState()
            configureInvite(for_ = profile, currentUser = currentUser, muster = muster)
            val invitation_0 = invite.sref()
            if (invitation_0 == null) {
                throw MusterError.invitationFailed("Invitation is invalid. Please try again.")
            }

            isWorking = true
            deferaction_5 = {
                isWorking = false
            }

            musterRepository.sendMusterInvite(invite = invitation_0, userId = profile.id)
            print("Invitation sent to ${profile.firstName} ${profile.lastName}")
            invites.append(invitation_0)

            resetMusterInviteState()
        } finally {
            deferaction_5?.invoke()
        }
    }

    /// Checks if the user is an admin within the muster.
    internal open fun isUserAdmin(profile: Profile): Boolean {
        val muster_1 = currentMuster.sref()
        if (muster_1 == null) {
            return false
        }
        return muster_1.administratorProfileIds.contains(profile.id)
    }

    /// Retrieves muster invitations for the specified muster.
    internal open suspend fun getMusterInvitations(muster: Muster): Unit = MainActor.run {
        var deferaction_6: (() -> Unit)? = null
        try {
            isWorking = true
            deferaction_6 = {
                isWorking = false
            }

            invites = musterRepository.collectInvitesForMuster(musterId = muster.id)
        } finally {
            deferaction_6?.invoke()
        }
    }

    /// Assigns admin privileges to a user within the muster.
    internal open suspend fun assignAdmin(userId: String): Unit = MainActor.run {
        var deferaction_7: (() -> Unit)? = null
        try {
            var muster = requireMuster()
            if (muster.administratorProfileIds.contains(userId)) {
                throw MusterError.invitationFailed("User is already an admin.")
            }

            isWorking = true
            deferaction_7 = {
                isWorking = false
            }

            muster.administratorProfileIds.append(userId)
            updateMuster(muster = muster)
            print("Admin assigned to user ID: ${userId}")
        } finally {
            deferaction_7?.invoke()
        }
    }

    // MARK: - Helper Methods

    /// Configures the muster invite with necessary details.
    private fun configureInvite(for_: Profile, currentUser: Profile, muster: Muster) {
        val profile = for_
        invite?.musterId = muster.id
        invite?.recipientId = profile.id
        invite?.musterName = muster.name
        invite?.senderName = currentUser.firstName
        invite?.recipientName = profile.firstName
    }

    /// Prepares a new muster invite object in `invite`.
    private fun resetMusterInviteState() {
        invite = MusterInvite(id = UUID().uuidString, recipientId = "", recipientName = "", senderName = "", musterName = "", musterId = "")
    }

    /// Ensures `currentMuster` is non-nil, or throws an error.
    private fun requireMuster(): Muster {
        val muster_2 = currentMuster.sref()
        if (muster_2 == null) {
            throw MusterError.updateFailed("No muster loaded.")
        }
        return muster_2.sref()
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
