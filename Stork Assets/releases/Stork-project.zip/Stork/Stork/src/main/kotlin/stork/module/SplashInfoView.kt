//
//  SplashInfoView.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.foundation.*
import skip.ui.*
import skip.model.*

internal class SplashInfoView: View {
    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Text(LocalizedStringKey(stringLiteral = "About Stork"))
                        .font(Font.title2)
                        .fontWeight(Font.Weight.bold).Compose(composectx)

                    Text(LocalizedStringKey(stringLiteral = "Stork is a labor and delivery app designed to assist healthcare providers in managing weekly delivery statistics."))
                        .font(Font.body)
                        .multilineTextAlignment(TextAlignment.center)
                        .padding().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding()
            .frame(width = 300.0)
            .cornerRadius(20.0).Compose(composectx)
        }
    }
}

// #Preview omitted
