//
//  MusterCarouselView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 12/31/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class MusterCarouselView: View {
    internal lateinit var colorScheme: ColorScheme
    internal var deliveryViewModel: DeliveryViewModel
        get() = _deliveryViewModel.wrappedValue
        set(newValue) {
            _deliveryViewModel.wrappedValue = newValue
        }
    internal var _deliveryViewModel = skip.ui.Environment<DeliveryViewModel>()

    private var currentIndex: Int
        get() = _currentIndex.wrappedValue
        set(newValue) {
            _currentIndex.wrappedValue = newValue
        }
    private var _currentIndex: skip.ui.State<Int>
    private var dragOffset: Double
        get() = _dragOffset.wrappedValue
        set(newValue) {
            _dragOffset.wrappedValue = newValue
        }
    private var _dragOffset: skip.ui.State<Double>
    private val threshold: Double = 100.0
    private val numberOfCards = 4 // Update this if you add or remove graphs

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            GeometryReader { geometry ->
                ComposeBuilder { composectx: ComposeContext ->
                    val cardWidth = geometry.size.width * 0.95 // Consistent card width
                    val spacing: Double = 10.0
                    val totalCardWidth = cardWidth + spacing

                    VStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ZStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ForEach(0..<numberOfCards, id = { it }) { index ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            carouselCard(for_ = index)
                                                .frame(width = cardWidth)
                                                .offset(x = calculateCardOffset(for_ = index, totalCardWidth = totalCardWidth))
                                                .animation(Animation.easeInOut, value = currentIndex).Compose(composectx) // Smooth animation when changing index
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .gesture(DragGesture()
                                .onChanged { value -> dragOffset = value.translation.width }
                                .onEnded { value ->
                                    withAnimation(Animation.easeInOut) { ->
                                        if (value.translation.width < -threshold && currentIndex < numberOfCards - 1) {
                                            currentIndex += 1
                                        } else if (value.translation.width > threshold && currentIndex > 0) {
                                            currentIndex -= 1
                                        }
                                        dragOffset = 0.0
                                    }
                                })
                            .frame(width = geometry.size.width)
                            .clipped().Compose(composectx)

                            // Dot Indicators
                            HStack(spacing = 8.0) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    ForEach(0..<numberOfCards, id = { it }) { index ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Circle()
                                                .fill(if (currentIndex == index) Color.primary else Color.secondary.opacity(0.5))
                                                .frame(width = 10.0, height = 10.0).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .padding(Edge.Set.top, 8.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }
            .frame(height = 220.0)
            .onAppear { ->
                currentIndex = 0
                dragOffset = 0.0
            }.Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedcurrentIndex by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Int>, Any>) { mutableStateOf(_currentIndex) }
        _currentIndex = rememberedcurrentIndex

        val remembereddragOffset by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<Double>, Any>) { mutableStateOf(_dragOffset) }
        _dragOffset = remembereddragOffset

        colorScheme = EnvironmentValues.shared.colorScheme
        _deliveryViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = DeliveryViewModel::class)!!

        super.ComposeContent(composectx)
    }

    // MARK: - Helper Methods
    private fun calculateCardOffset(for_: Int, totalCardWidth: Double): Double {
        val index = for_
        // Offset each card based on its position and the current index
        val centeredIndexOffset = Double(index - currentIndex) * totalCardWidth
        return centeredIndexOffset + dragOffset
    }

    private fun carouselCard(for_: Int): View {
        val index = for_
        return ZStack { ->
            ComposeBuilder { composectx: ComposeContext ->
                Group { ->
                    ComposeBuilder { composectx: ComposeContext ->
                        if (index == 0) {
                        } else if (index == 1) {
                        } else if (index == 2) {
                            BabySexDistributionView(groupedDeliveries = Binding({ _deliveryViewModel.wrappedValue.groupedMusterDeliveries }, { it -> _deliveryViewModel.wrappedValue.groupedMusterDeliveries = it })).Compose(composectx)
                        } else if (index == 3) {
                            TotalWeightAndLengthStatsView(groupedDeliveries = Binding({ _deliveryViewModel.wrappedValue.groupedMusterDeliveries }, { it -> _deliveryViewModel.wrappedValue.groupedMusterDeliveries = it })).Compose(composectx)
                        }
                        ComposeResult.ok
                    }
                }
                .frame(maxWidth = Double.infinity, maxHeight = Double.infinity)
                .backgroundCard(colorScheme = colorScheme)
                .padding(Edge.Set.vertical, 5.0).Compose(composectx)
                ComposeResult.ok
            }
        }
    }

    private constructor(currentIndex: Int = 0, dragOffset: Double = 0.0, privatep: Nothing? = null) {
        this._currentIndex = skip.ui.State(currentIndex)
        this._dragOffset = skip.ui.State(dragOffset)
    }

    constructor(): this(privatep = null) {
    }
}

// #Preview omitted
