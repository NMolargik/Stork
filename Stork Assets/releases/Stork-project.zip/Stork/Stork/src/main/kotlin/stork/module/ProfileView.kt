package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class ProfileView: View {
    internal var errorMessage: String
        get() = _errorMessage.wrappedValue
        set(newValue) {
            _errorMessage.wrappedValue = newValue
        }
    internal var _errorMessage: skip.ui.AppStorage<String>

    // MARK: - Environment Objects
    internal var profileViewModel: ProfileViewModel
        get() = _profileViewModel.wrappedValue
        set(newValue) {
            _profileViewModel.wrappedValue = newValue
        }
    internal var _profileViewModel = skip.ui.Environment<ProfileViewModel>()
    internal lateinit var dismiss: DismissAction
    internal lateinit var colorScheme: ColorScheme

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            NavigationStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    VStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            if ((profileViewModel.editingProfile)) {
                                CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.tempProfile.firstName }, { it -> _profileViewModel.wrappedValue.tempProfile.firstName = it }), hintText = "First Name", icon = Image(systemName = "1.square"), isSecure = false, iconColor = Color.green).Compose(composectx)

                                profileViewModel.firstNameError?.let { firstNameError ->
                                    Text(firstNameError)
                                        .font(Font.caption)
                                        .foregroundColor(Color.gray)
                                        .bold()
                                        .padding(Edge.Set.top, -5.0).Compose(composectx)
                                }

                                CustomTextfieldView(text = Binding({ _profileViewModel.wrappedValue.tempProfile.lastName }, { it -> _profileViewModel.wrappedValue.tempProfile.lastName = it }), hintText = "Last Name", icon = Image(systemName = "2.square"), isSecure = false, iconColor = Color.green).Compose(composectx)

                                profileViewModel.lastNameError?.let { lastNameError ->
                                    Text(lastNameError)
                                        .font(Font.caption)
                                        .foregroundColor(Color.gray)
                                        .padding(Edge.Set.top, -5.0).Compose(composectx)
                                }

                                Divider().Compose(composectx)

                                Text(LocalizedStringKey(stringLiteral = "Select Your Birthday")).Compose(composectx)

                                DatePicker(LocalizedStringKey(stringLiteral = "Select Birthday"), selection = Binding({ _profileViewModel.wrappedValue.tempProfile.birthday }, { it -> _profileViewModel.wrappedValue.tempProfile.birthday = it }), displayedComponents = DatePickerComponents.of(DatePickerComponents.date))
                                    .tint(Color.indigo)
                                    .labelsHidden()
                                    .environment({ it -> EnvironmentValues.shared.setlocale(it) }, Locale(identifier = "en_US"))
                                    .padding(Edge.Set.top, -15.0).Compose(composectx)

                                profileViewModel.birthdayError?.let { birthdayError ->
                                    Text(birthdayError)
                                        .font(Font.caption)
                                        .foregroundColor(Color.gray)
                                        .padding(Edge.Set.top, -5.0).Compose(composectx)
                                }

                                Divider().Compose(composectx)

                                Text(LocalizedStringKey(stringLiteral = "Select Your Role")).Compose(composectx)

                                Picker(LocalizedStringKey(stringLiteral = "Role"), selection = Binding({ _profileViewModel.wrappedValue.tempProfile.role }, { it -> _profileViewModel.wrappedValue.tempProfile.role = it })) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        ForEach(ProfileRole.allCases, id = { it }) { role ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Text(role.rawValue.capitalized).tag(role).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }.Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }
                                .pickerStyle(PickerStyle.segmented)
                                .onChange(of = profileViewModel.tempProfile.firstName) { _ -> profileViewModel.validateProfileForm(profileViewModel.tempProfile) }
                                .onChange(of = profileViewModel.tempProfile.lastName) { _ -> profileViewModel.validateProfileForm(profileViewModel.tempProfile) }
                                .onChange(of = profileViewModel.tempProfile.birthday) { _ -> profileViewModel.validateProfileForm(profileViewModel.tempProfile) }
                                .onChange(of = profileViewModel.tempProfile.role) { _ -> profileViewModel.validateProfileForm(profileViewModel.tempProfile) }
                                .onAppear { -> profileViewModel.validateProfileForm(profileViewModel.tempProfile) }.Compose(composectx)
                            } else {
                                HStack(alignment = VerticalAlignment.center) { ->
                                    ComposeBuilder { composectx: ComposeContext ->
                                        VStack(alignment = HorizontalAlignment.leading, spacing = 8.0) { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Text({
                                                    val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                    str.appendInterpolation(profileViewModel.profile.role.description)
                                                    str.appendLiteral(" ")
                                                    str.appendInterpolation(profileViewModel.profile.firstName)
                                                    str.appendLiteral(" ")
                                                    str.appendInterpolation(profileViewModel.profile.lastName)
                                                    LocalizedStringKey(stringInterpolation = str)
                                                }())
                                                    .font(Font.title2)
                                                    .fontWeight(Font.Weight.bold)
                                                    .multilineTextAlignment(TextAlignment.leading).Compose(composectx)

                                                HStack { ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        Image(systemName = "birthday.cake.fill").Compose(composectx)
                                                        Text(Profile.dateFormatter.string(from = profileViewModel.profile.birthday))
                                                            .font(Font.subheadline)
                                                            .foregroundColor(Color.secondary).Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }.Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }
                                        .padding(Edge.Set.horizontal).Compose(composectx)

                                        Spacer().Compose(composectx)

                                        VStack { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                InitialsAvatarView(firstName = profileViewModel.profile.firstName, lastName = profileViewModel.profile.lastName, size = 80.0, font = Font.largeTitle.bold()).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }
                                        .padding(Edge.Set.trailing).Compose(composectx)
                                        ComposeResult.ok
                                    }
                                }.Compose(composectx)
                            }
                            ComposeResult.ok
                        }
                    }
                    .padding()
                    .toolbar { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            ToolbarItem(placement = ToolbarItemPlacement.topBarLeading) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    if ((!profileViewModel.editingProfile)) {
                                        Button(action = { ->
                                            triggerHaptic()
                                            dismiss()
                                        }, label = { ->
                                            ComposeBuilder { composectx: ComposeContext ->
                                                Text(LocalizedStringKey(stringLiteral = "Close"))
                                                    .font(Font.body)
                                                    .fontWeight(Font.Weight.bold)
                                                    .foregroundStyle(Color.red).Compose(composectx)
                                                ComposeResult.ok
                                            }
                                        }).Compose(composectx)
                                    } else {
                                        Text(LocalizedStringKey(stringLiteral = "Editing Profile"))
                                            .font(Font.body)
                                            .fontWeight(Font.Weight.bold).Compose(composectx)
                                    }
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)

                            ToolbarItem(placement = ToolbarItemPlacement.topBarTrailing) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    Button(action = { ->
                                        triggerHaptic()
                                        withAnimation { ->
                                            if (profileViewModel.editingProfile) {
                                                stopEditingProfile()
                                            } else {
                                                startEditingProfile()
                                            }
                                        }
                                    }, label = { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Text(if (profileViewModel.editingProfile) "Save Changes" else "Edit Profile")
                                                .font(Font.body)
                                                .fontWeight(Font.Weight.bold)
                                                .foregroundStyle(Color.orange).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    })
                                    .disabled(profileViewModel.isWorking || (profileViewModel.editingProfile && !profileViewModel.isFormValid)).Compose(composectx)
                                    ComposeResult.ok
                                }
                            }.Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        _profileViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = ProfileViewModel::class)!!
        dismiss = EnvironmentValues.shared.dismiss
        colorScheme = EnvironmentValues.shared.colorScheme

        val rememberederrorMessage by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<String>, Any>) { mutableStateOf(_errorMessage) }
        _errorMessage = rememberederrorMessage

        super.ComposeContent(composectx)
    }

    private fun triggerHaptic() = Unit

    private fun startEditingProfile() {
        profileViewModel.editingProfile = true
        profileViewModel.tempProfile = profileViewModel.profile

    }

    private fun stopEditingProfile() {
        profileViewModel.editingProfile = false
        profileViewModel.isWorking = true

        Task { ->
            try {
                profileViewModel.updateProfile()
                profileViewModel.editingProfile = false
                profileViewModel.isWorking = false

            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                profileViewModel.isWorking = false
                errorMessage = error.localizedDescription
            }
        }
    }

    constructor(errorMessage: String = "") {
        this._errorMessage = skip.ui.AppStorage(wrappedValue = errorMessage, "errorMessage")
    }
}
