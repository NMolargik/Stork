//
//  File.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 1/7/25.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.foundation.*
import skip.ui.*
import skip.model.*

internal class StoreConstants {



    companion object {
        internal val apiKey = "GOOGLE_KEY"

        internal val entitlementID = "Premium"
    }
}
