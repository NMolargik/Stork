//
//  DeliveryDetailView.swift
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class DeliveryDetailView: View {
    // MARK: - AppStorage
    private var useMetric: Boolean
        get() = _useMetric.wrappedValue
        set(newValue) {
            _useMetric.wrappedValue = newValue
        }
    private var _useMetric: skip.ui.AppStorage<Boolean>

    // MARK: - Environment Objects
    internal var musterViewModel: MusterViewModel
        get() = _musterViewModel.wrappedValue
        set(newValue) {
            _musterViewModel.wrappedValue = newValue
        }
    internal var _musterViewModel = skip.ui.Environment<MusterViewModel>()

    // MARK: - Binding
    internal var delivery: Delivery
        get() = _delivery.wrappedValue.sref({ this.delivery = it })
        set(newValue) {
            _delivery.wrappedValue = newValue.sref()
        }
    internal var _delivery: Binding<Delivery>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    ScrollView { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            VStack(alignment = HorizontalAlignment.leading, spacing = 15.0) { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    // MARK: - Delivery Date
                                    Text(delivery.date.formatted(date = Date.FormatStyle.DateStyle.omitted, time = Date.FormatStyle.TimeStyle.shortened))
                                        .font(Font.title2)
                                        .fontWeight(Font.Weight.bold)
                                        .padding(Edge.Set.leading)
                                        .accessibilityLabel({
                                            val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                            str.appendLiteral("Delivery Date: ")
                                            str.appendInterpolation(delivery.date.formatted(date = Date.FormatStyle.DateStyle.omitted, time = Date.FormatStyle.TimeStyle.shortened))
                                            LocalizedStringKey(stringInterpolation = str)
                                        }()).Compose(composectx)

                                    // MARK: - Hospital Information
                                    HStack { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            Image(systemName = "building.fill")
                                                .foregroundStyle(Color.orange)
                                                .font(Font.title)
                                                .frame(width = 30.0)
                                                .shadow(radius = 1.0)
                                                .accessibilityHidden(true).Compose(composectx)

                                            Text(delivery.hospitalName)
                                                .font(Font.subheadline)
                                                .fontWeight(Font.Weight.semibold)
                                                .foregroundColor(Color.black)
                                                .lineLimit(2)
                                                .multilineTextAlignment(TextAlignment.leading)
                                                .accessibilityLabel({
                                                    val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                    str.appendLiteral("Hospital Name: ")
                                                    str.appendInterpolation(delivery.hospitalName)
                                                    LocalizedStringKey(stringInterpolation = str)
                                                }()).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius = 20.0)
                                        .fill(Color.white)
                                        .shadow(radius = 2.0)
                                        .opacity(0.9))
                                    .padding(Edge.Set.horizontal).Compose(composectx)

                                    // MARK: - Delivery Details
                                    VStack(alignment = HorizontalAlignment.leading, spacing = 10.0) { ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            if (delivery.epiduralUsed) {
                                                HStack { ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        Image(systemName = "syringe.fill")
                                                            .foregroundStyle(Color.red)
                                                            .font(Font.title2)
                                                            .frame(width = 30.0)
                                                            .accessibilityHidden(true).Compose(composectx)

                                                        Text(LocalizedStringKey(stringLiteral = "Epidural Used"))
                                                            .font(Font.subheadline)
                                                            .fontWeight(Font.Weight.semibold)
                                                            .foregroundColor(Color.black)
                                                            .lineLimit(1)
                                                            .accessibilityLabel(LocalizedStringKey(stringLiteral = "Epidural Used")).Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }.Compose(composectx)
                                            }

                                            HStack { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Image(systemName = "shippingbox.fill")
                                                        .foregroundStyle(Color.indigo)
                                                        .font(Font.title2)
                                                        .frame(width = 30.0)
                                                        .accessibilityHidden(true).Compose(composectx)

                                                    Text({
                                                        val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                        str.appendInterpolation(delivery.deliveryMethod.description)
                                                        str.appendLiteral(" Delivery")
                                                        LocalizedStringKey(stringInterpolation = str)
                                                    }())
                                                        .font(Font.subheadline)
                                                        .fontWeight(Font.Weight.semibold)
                                                        .foregroundColor(Color.black)
                                                        .lineLimit(1)
                                                        .accessibilityLabel({
                                                            val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                            str.appendLiteral("Delivery Method: ")
                                                            str.appendInterpolation(delivery.deliveryMethod.description)
                                                            LocalizedStringKey(stringInterpolation = str)
                                                        }()).Compose(composectx)
                                                    ComposeResult.ok
                                                }
                                            }.Compose(composectx)

                                            if (!delivery.musterId.isEmpty) {
                                                HStack { ->
                                                    ComposeBuilder { composectx: ComposeContext ->
                                                        Image(systemName = "person.3.fill")
                                                            .foregroundStyle(Color.red)
                                                            .font(Font.body)
                                                            .frame(width = 30.0)
                                                            .accessibilityHidden(true).Compose(composectx)

                                                        Text(LocalizedStringKey(stringLiteral = "Added to your muster"))
                                                            .font(Font.subheadline)
                                                            .fontWeight(Font.Weight.semibold)
                                                            .foregroundColor(Color.black)
                                                            .lineLimit(1)
                                                            .accessibilityLabel(LocalizedStringKey(stringLiteral = "Added to your muster")).Compose(composectx)
                                                        ComposeResult.ok
                                                    }
                                                }.Compose(composectx)
                                            }
                                            ComposeResult.ok
                                        }
                                    }
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius = 20.0)
                                        .fill(Color.white)
                                        .shadow(radius = 2.0)
                                        .opacity(0.9))
                                    .padding(Edge.Set.horizontal).Compose(composectx)

                                    // MARK: - Babies Information
                                    ForEach(delivery.babies, id = { it.id }) { baby ->
                                        ComposeBuilder { composectx: ComposeContext ->
                                            HStack { ->
                                                ComposeBuilder { composectx: ComposeContext ->
                                                    Image(systemName = "figure.child")
                                                        .foregroundStyle(baby.sex.color)
                                                        .font(Font.title)
                                                        .frame(width = 30.0)
                                                        .shadow(radius = 1.0)
                                                        .accessibilityHidden(true).Compose(composectx)

                                                    VStack(alignment = HorizontalAlignment.leading, spacing = 8.0) { ->
                                                        ComposeBuilder { composectx: ComposeContext ->
                                                            HStack { ->
                                                                ComposeBuilder { composectx: ComposeContext ->
                                                                    Image(systemName = "scalemass.fill")
                                                                        .foregroundStyle(Color.orange)
                                                                        .frame(width = 30.0)
                                                                        .accessibilityHidden(true).Compose(composectx)

                                                                    Text(weightText(for_ = baby.weight))
                                                                        .font(Font.subheadline)
                                                                        .fontWeight(Font.Weight.semibold)
                                                                        .foregroundColor(Color.black)
                                                                        .lineLimit(1)
                                                                        .accessibilityLabel({
                                                                            val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                            str.appendLiteral("Weight: ")
                                                                            str.appendInterpolation(weightText(for_ = baby.weight))
                                                                            LocalizedStringKey(stringInterpolation = str)
                                                                        }()).Compose(composectx)
                                                                    ComposeResult.ok
                                                                }
                                                            }.Compose(composectx)

                                                            HStack { ->
                                                                ComposeBuilder { composectx: ComposeContext ->
                                                                    Image(systemName = "ruler.fill")
                                                                        .foregroundStyle(Color.green)
                                                                        .frame(width = 30.0)
                                                                        .accessibilityHidden(true).Compose(composectx)

                                                                    Text(heightText(for_ = baby.height))
                                                                        .font(Font.subheadline)
                                                                        .fontWeight(Font.Weight.semibold)
                                                                        .foregroundColor(Color.black)
                                                                        .lineLimit(1)
                                                                        .accessibilityLabel({
                                                                            val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                                                            str.appendLiteral("Height: ")
                                                                            str.appendInterpolation(heightText(for_ = baby.height))
                                                                            LocalizedStringKey(stringInterpolation = str)
                                                                        }()).Compose(composectx)
                                                                    ComposeResult.ok
                                                                }
                                                            }.Compose(composectx)
                                                            ComposeResult.ok
                                                        }
                                                    }
                                                    .frame(maxWidth = Double.infinity, alignment = Alignment.leading).Compose(composectx)

                                                    if (baby.nurseCatch) {
                                                        Text(LocalizedStringKey(stringLiteral = "Nurse Catch"))
                                                            .font(Font.subheadline)
                                                            .fontWeight(Font.Weight.semibold)
                                                            .foregroundColor(Color.black)
                                                            .lineLimit(1)
                                                            .accessibilityLabel(LocalizedStringKey(stringLiteral = "Nurse Catch")).Compose(composectx)
                                                    }
                                                    ComposeResult.ok
                                                }
                                            }
                                            .padding()
                                            .background(RoundedRectangle(cornerRadius = 20.0)
                                                .fill(Color.white)
                                                .shadow(radius = 2.0)
                                                .opacity(0.9))
                                            .padding(Edge.Set.horizontal)
                                            .transition(AnyTransition.scale.combined(with = AnyTransition.opacity))
                                            .animation(Animation.easeInOut, value = delivery.babies).Compose(composectx)
                                            ComposeResult.ok
                                        }
                                    }.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .padding(Edge.Set.of(Edge.Set.horizontal, Edge.Set.bottom)).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)

                    Spacer().Compose(composectx)

                    // MARK: - Delivery ID
                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Spacer().Compose(composectx)

                            Text({
                                val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                str.appendLiteral("ID: ")
                                str.appendInterpolation(delivery.id)
                                LocalizedStringKey(stringInterpolation = str)
                            }())
                                .foregroundStyle(Color.gray)
                                .font(Font.footnote)
                                .accessibilityLabel({
                                    val str = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
                                    str.appendLiteral("Delivery ID: ")
                                    str.appendInterpolation(delivery.id)
                                    LocalizedStringKey(stringInterpolation = str)
                                }()).Compose(composectx)
                            ComposeResult.ok
                        }
                    }
                    .padding(Edge.Set.of(Edge.Set.trailing, Edge.Set.bottom)).Compose(composectx)
                    ComposeResult.ok
                }
            }
            .navigationTitle(delivery.date.formatted(date = Date.FormatStyle.DateStyle.long, time = Date.FormatStyle.TimeStyle.omitted))
            .onAppear { -> triggerHaptic() }
            .onDisappear { -> triggerHaptic() }.Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        _musterViewModel.wrappedValue = EnvironmentValues.shared.environmentObject(type = MusterViewModel::class)!!

        val remembereduseMetric by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_useMetric) }
        _useMetric = remembereduseMetric

        super.ComposeContent(composectx)
    }

    // MARK: - Haptic Feedback
    private fun triggerHaptic() = Unit

    // MARK: - Weight Formatting
    private fun weightText(for_: Double): String {
        val weightInOunces = for_
        if (useMetric) {
            val weightInKilograms = weightInOunces * 0.0283495 // 1 ounce = 0.0283495 kg
            return "${String(format = "%.2f", weightInKilograms)} kg"
        } else {
            val pounds = Int(weightInOunces) / 16
            val ounces = Int(weightInOunces) % 16
            return "${pounds} lbs ${ounces} oz"
        }
    }

    // MARK: - Height Formatting
    private fun heightText(for_: Double): String {
        val heightInInches = for_
        if (useMetric) {
            val heightInCentimeters = heightInInches * 2.54 // 1 inch = 2.54 cm
            return "${String(format = "%.1f", heightInCentimeters)} cm"
        } else {
            return "${String(format = "%.1f", heightInInches)} inches"
        }
    }

    private constructor(useMetric: Boolean = false, delivery: Binding<Delivery>, privatep: Nothing? = null) {
        this._useMetric = skip.ui.AppStorage(wrappedValue = useMetric, "useMetric")
        this._delivery = delivery
    }

    constructor(delivery: Binding<Delivery>): this(delivery = delivery, privatep = null) {
    }
}
