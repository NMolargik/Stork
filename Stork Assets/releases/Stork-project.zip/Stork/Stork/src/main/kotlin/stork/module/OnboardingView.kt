//
//  OnboardingView.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 12/30/24.
//

package stork.module

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import stork.model.*
import skip.foundation.*
import skip.model.*

internal class OnboardingView: View {
    private var appState: AppState
        get() = _appState.wrappedValue
        set(newValue) {
            _appState.wrappedValue = newValue
        }
    private var _appState: skip.ui.AppStorage<AppState>
    internal var selectedTab: Tab
        get() = _selectedTab.wrappedValue
        set(newValue) {
            _selectedTab.wrappedValue = newValue
        }
    internal var _selectedTab: skip.ui.AppStorage<Tab>
    private var isOnboardingComplete: Boolean
        get() = _isOnboardingComplete.wrappedValue
        set(newValue) {
            _isOnboardingComplete.wrappedValue = newValue
        }
    private var _isOnboardingComplete: skip.ui.AppStorage<Boolean>
    private var loggedIn: Boolean
        get() = _loggedIn.wrappedValue
        set(newValue) {
            _loggedIn.wrappedValue = newValue
        }
    private var _loggedIn: skip.ui.AppStorage<Boolean>

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            VStack { ->
                ComposeBuilder { composectx: ComposeContext ->
                    Button(action = { ->
                        withAnimation { ->
                            isOnboardingComplete = true
                            selectedTab = Tab.home
                            appState = AppState.main
                        }
                    }, label = { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            Text(LocalizedStringKey(stringLiteral = "Skip Onboarding"))
                                .foregroundStyle(Color.blue).Compose(composectx)
                            ComposeResult.ok
                        }
                    }).Compose(composectx)

                    Spacer().Compose(composectx)
                    ComposeResult.ok
                }
            }
            .padding().Compose(composectx)
        }
    }

    @Composable
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedappState by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<AppState>, Any>) { mutableStateOf(_appState) }
        _appState = rememberedappState

        val rememberedselectedTab by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Tab>, Any>) { mutableStateOf(_selectedTab) }
        _selectedTab = rememberedselectedTab

        val rememberedisOnboardingComplete by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_isOnboardingComplete) }
        _isOnboardingComplete = rememberedisOnboardingComplete

        val rememberedloggedIn by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.AppStorage<Boolean>, Any>) { mutableStateOf(_loggedIn) }
        _loggedIn = rememberedloggedIn

        super.ComposeContent(composectx)
    }

    private constructor(appState: AppState = AppState.splash, selectedTab: Tab = Tab.hospitals, isOnboardingComplete: Boolean = false, loggedIn: Boolean = false, privatep: Nothing? = null) {
        this._appState = skip.ui.AppStorage(wrappedValue = appState, "appState", serializer = { it.rawValue }, deserializer = { if (it is String) AppState(rawValue = it) else null })
        this._selectedTab = skip.ui.AppStorage(wrappedValue = selectedTab, "selectedTab", serializer = { it.rawValue }, deserializer = { if (it is String) Tab(rawValue = it) else null })
        this._isOnboardingComplete = skip.ui.AppStorage(wrappedValue = isOnboardingComplete, "isOnboardingComplete")
        this._loggedIn = skip.ui.AppStorage(wrappedValue = loggedIn, "loggedIn")
    }

    constructor(selectedTab: Tab = Tab.hospitals): this(selectedTab = selectedTab, privatep = null) {
    }
}

// #Preview omitted
