//
//  Double+toRadians.swift
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.model

import skip.lib.*

import skip.foundation.*

// MARK: - Computed Properties

/// Converts an angle from degrees to radians.
///
/// - Returns: The angle in radians.
///
/// This computed property allows for easy conversion of angles from degrees to radians,
/// which is often required in trigonometric calculations and graphical representations.
///
/// ## Usage Example
/// ```
/// let angleDegrees: Double = 180.0
/// let angleRadians = angleDegrees.toRadians
/// print(angleRadians) // Output: 3.141592653589793
/// ```
internal val Double.toRadians: Double
    get() = this * Double.pi / 180.0
