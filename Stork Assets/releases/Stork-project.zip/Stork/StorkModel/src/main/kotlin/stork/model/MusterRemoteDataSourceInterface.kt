//
//  MusterRemoteDataSourceInterface.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// A protocol defining the interface for remote data source interactions related to musters.
interface MusterRemoteDataSourceInterface {
    /// Creates a new muster record and returns the newly created `Muster`.
    ///
    /// - Parameter muster: The `Muster` object to create.
    /// - Returns: The newly created `Muster`.
    /// - Throws:
    ///   - `MusterError.creationFailed`: If the creation fails.
    ///   - `MusterError.firebaseError`: If the Firestore operation fails.
    suspend fun createMuster(muster: Muster): Muster

    /// Updates an existing muster record and returns the updated `Muster`.
    ///
    /// - Parameter muster: The `Muster` object containing the updated data.
    /// - Returns: The updated `Muster`.
    /// - Throws:
    ///   - `MusterError.notFound`: If the muster does not exist.
    ///   - `MusterError.updateFailed`: If the update operation fails.
    ///   - `MusterError.firebaseError`: If the Firestore operation fails.
    suspend fun updateMuster(muster: Muster): Muster

    /// Retrieves a single muster by its unique ID.
    ///
    /// - Parameter id: The unique ID of the muster to fetch.
    /// - Returns: A `Muster` object representing the muster with the specified ID.
    /// - Throws:
    ///   - `MusterError.notFound`: If the muster cannot be found.
    ///   - `MusterError.firebaseError`: If the Firestore operation fails.
    suspend fun getMuster(byId: String): Muster

    /// Lists musters based on optional filters.
    ///
    /// - Parameters:
    ///   - profileIds: An optional filter for profile IDs associated with the muster. If `nil`, this filter is ignored.
    ///   - primaryHospitalId: An optional filter for the primary hospital ID associated with the muster. If `nil`, this filter is ignored.
    ///   - administratorProfileIds: An optional filter for administrator profile IDs. If `nil`, this filter is ignored.
    ///   - name: An optional filter for the muster name. If `nil`, this filter is ignored.
    /// - Returns: An array of `Muster` objects matching the specified filters.
    /// - Throws: `MusterError` if the operation fails or no musters are found.
    suspend fun listMusters(profileIds: Array<String>?, primaryHospitalId: String?, administratorProfileIds: Array<String>?, name: String?): Array<Muster>

    /// Sends a profile an invite to join a muster.
    ///
    /// - Parameters:
    ///   - invite: The `MusterInvite` object defining the invitation.
    ///   - userId: The ID of the user being invited.
    /// - Throws: `MusterError` if sending fails or the Firestore operation fails.
    suspend fun sendMusterInvite(invite: MusterInvite, userId: String): Unit

    /// Collects all muster invitations for a user.
    ///
    /// - Parameter userId: The user ID associated with potential muster invites.
    /// - Returns: An array of `MusterInvite` objects for the specified user.
    /// - Throws: `MusterError` if the operation fails or the Firestore operation fails.
    suspend fun collectUserMusterInvites(userId: String): Array<MusterInvite>

    /// Collects all muster invitations for a specific muster.
    ///
    /// - Parameter musterId: The muster ID associated with potential invites.
    /// - Returns: An array of `MusterInvite` objects for the specified muster.
    /// - Throws: `MusterError` if the operation fails or the Firestore operation fails.
    suspend fun collectInvitesForMuster(musterId: String): Array<MusterInvite>

    /// Cancels a previously sent muster invitation.
    ///
    /// - Parameter invitationId: The ID from the invitation to cancel.
    /// - Throws: `MusterError` if cancellation fails or the Firestore operation fails.
    suspend fun cancelMusterInvite(invitationId: String): Unit

    /// Deletes all muster invitations associated with a given muster.
    ///
    /// - Parameter musterId: The ID of the muster whose invitations should be deleted.
    /// - Throws: `MusterError` if deletion fails or the Firestore operation fails.
    suspend fun deleteMusterInvites(musterId: String): Unit

    /// Deletes an existing muster record.
    ///
    /// - Parameter muster: The `Muster` object to delete.
    /// - Throws:
    ///   - `MusterError.notFound`: If the muster does not exist.
    ///   - `MusterError.deletionFailed`: If the deletion operation fails.
    ///   - `MusterError.firebaseError`: If the Firestore operation fails.
    suspend fun deleteMuster(muster: Muster): Unit
}
