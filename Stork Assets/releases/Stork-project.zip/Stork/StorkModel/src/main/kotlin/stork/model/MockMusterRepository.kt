//
//  MockMusterRepository.swift
//
//
//  Created by Nick Molargik on 11/20/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// A mock implementation of the `MusterRepositoryInterface` protocol for testing purposes.
open class MockMusterRepository: MusterRepositoryInterface {
    // MARK: - Properties

    /// A list of mock Musters used for in-memory storage.
    private var musters: Array<Muster> = arrayOf()
        get() = field.sref({ this.musters = it })
        set(newValue) {
            field = newValue.sref()
        }

    /// A list of mock invitations used for in-memory storage.
    private var invites: Array<MusterInvite> = arrayOf()
        get() = field.sref({ this.invites = it })
        set(newValue) {
            field = newValue.sref()
        }

    // MARK: - Initializer

    /// Initializes the mock repository with optional sample data.
    ///
    /// - Parameters:
    ///   - musters: An array of `Muster` objects to initialize the repository with. Defaults to an empty array.
    ///   - invites: An array of `MusterInvite` objects to initialize the repository with. Defaults to an empty array.
    constructor(musters: Array<Muster> = arrayOf(), invites: Array<MusterInvite> = arrayOf()) {
        this.musters = musters

        // For demonstration, add a couple sample invites
        this.invites.append(MusterInvite(id = UUID().description, recipientId = "", recipientName = "Nick", senderName = "Jessica", musterName = "Admin Muster", musterId = ""))

        this.invites.append(MusterInvite(id = UUID().description, recipientId = "", recipientName = "Nick", senderName = "Jeanne", musterName = "Parkview Muster", musterId = ""))
    }

    // MARK: - Create

    /// Creates a new muster record and returns the newly created `Muster`.
    ///
    /// - Parameter muster: The `Muster` object to create.
    /// - Returns: The newly created `Muster`.
    /// - Throws: `MusterError.creationFailed` if a muster with the same ID already exists.
    override suspend fun createMuster(muster: Muster): Muster = Async.run l@{
        if (musters.contains(where = { it -> it.id == muster.id })) {
            throw MusterError.creationFailed("Muster with ID ${muster.id} already exists.")
        }
        musters.append(muster)
        return@l muster.sref()
    }

    // MARK: - Update

    /// Updates an existing muster record and returns the updated `Muster`.
    ///
    /// - Parameter muster: The `Muster` object containing updated data.
    /// - Returns: The updated `Muster`.
    /// - Throws: `MusterError.notFound` if the muster does not exist.
    override suspend fun updateMuster(muster: Muster): Muster = Async.run l@{
        val index_0 = musters.firstIndex(where = { it -> it.id == muster.id })
        if (index_0 == null) {
            throw MusterError.notFound("Muster with ID ${muster.id} not found.")
        }
        musters[index_0] = muster.sref()
        return@l muster.sref()
    }

    // MARK: - Read

    /// Fetches a single muster by its unique ID.
    ///
    /// - Parameter id: The unique ID of the muster.
    /// - Returns: A `Muster` object matching the ID.
    /// - Throws: `MusterError.notFound` if no muster with the specified ID exists.
    override suspend fun getMuster(byId: String): Muster = Async.run l@{
        val id = byId
        val muster_0 = musters.first(where = { it -> it.id == id })
        if (muster_0 == null) {
            throw MusterError.notFound("Muster with ID ${id} not found.")
        }
        return@l muster_0.sref()
    }

    /// Lists musters based on optional filters.
    ///
    /// - Parameters:
    ///   - profileIds: An optional filter for profile IDs associated with the muster.
    ///   - primaryHospitalId: An optional filter for the muster’s primary hospital ID.
    ///   - administratorProfileIds: An optional filter for administrator profile IDs.
    ///   - name: An optional filter for the muster name (case-insensitive substring).
    /// - Returns: An array of `Muster` objects matching the specified filters.
    override suspend fun listMusters(profileIds: Array<String>?, primaryHospitalId: String?, administratorProfileIds: Array<String>?, name: String?): Array<Muster> = Async.run l@{
        return@l musters.filter l@{ muster ->
            val nameFilter = name?.lowercased()

            val profileMatch = profileIds == null || profileIds!!.allSatisfy { it -> muster.profileIds.contains(it) }

            // Fix the logic for primaryHospitalId to compare with muster’s property
            val hospitalMatch = primaryHospitalId == null || muster.primaryHospitalId == primaryHospitalId

            val adminMatch = administratorProfileIds == null || administratorProfileIds!!.allSatisfy { it -> muster.administratorProfileIds.contains(it) }

            val nameMatch = nameFilter == null || muster.name.lowercased().contains(nameFilter!!)

            return@l profileMatch && hospitalMatch && adminMatch && nameMatch
        }
    }

    // MARK: - Invitation Methods

    /// Sends a profile an invite to join a muster.
    ///
    /// - Parameter invite: The `MusterInvite` object defining the invitation.
    /// - Parameter userId: The ID of the user that is being invited.
    /// - Throws: `MusterError.invitationFailed` if an invite with the same ID already exists.
    override suspend fun sendMusterInvite(invite: MusterInvite, userId: String): Unit = Async.run {
        // Ensure no duplicate invite with the same ID
        if (invites.contains(where = { it -> it.id == invite.id })) {
            throw MusterError.invitationFailed("An invite with ID ${invite.id} already exists.")
        }
        invites.append(invite)
    }

    /// Collects all muster invitations for a user.
    ///
    /// - Parameter userId: The user ID associated with potential muster invites.
    /// - Returns: An array of `MusterInvite` objects for the specified user.
    override suspend fun collectUserMusterInvites(userId: String): Array<MusterInvite> = Async.run l@{
        return@l invites.filter { it -> it.recipientId == userId }
    }

    /// Collects all muster invitations for a specific muster.
    ///
    /// - Parameter musterId: The muster ID associated with the invitations.
    /// - Returns: An array of `MusterInvite` objects for the specified muster.
    override suspend fun collectInvitesForMuster(musterId: String): Array<MusterInvite> = Async.run l@{
        return@l invites.filter { it -> it.musterId == musterId }
    }

    /// Cancels a sent muster invitation.
    ///
    /// - Parameter invitationId: The ID of the invitation to cancel.
    /// - Throws: `MusterError.failedToCancelInvite` if the invitation is not found.
    override suspend fun cancelMusterInvite(invitationId: String): Unit = Async.run {
        val index_1 = invites.firstIndex(where = { it -> it.id == invitationId })
        if (index_1 == null) {
            throw MusterError.failedToCancelInvite("Invite with ID ${invitationId} not found.")
        }
        invites.remove(at = index_1)
    }

    /// Deletes all muster invitations associated with a given muster.
    ///
    /// - Parameter musterId: The muster ID whose invitations should be deleted.
    override suspend fun deleteMusterInvites(musterId: String): Unit = Async.run {
        invites.removeAll(where = { it -> it.musterId == musterId })
    }

    /// Deletes an existing muster record.
    ///
    /// - Parameter muster: The `Muster` object to delete.
    /// - Throws: `MusterError.deletionFailed` if the muster is not found.
    override suspend fun deleteMuster(muster: Muster): Unit = Async.run {
        val index_2 = musters.firstIndex(where = { it -> it.id == muster.id })
        if (index_2 == null) {
            throw MusterError.deletionFailed("Failed to delete muster with ID ${muster.id}.")
        }
        musters.remove(at = index_2)
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
