//
//  Location.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.model

import skip.lib.*

import skip.foundation.*

/// A lat/lon location (in degrees).
@Suppress("MUST_BE_INITIALIZED")
class Location: Codable, MutableStruct {
    var latitude: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var longitude: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    constructor(latitude: Double, longitude: Double) {
        this.latitude = latitude
        this.longitude = longitude
    }

    fun coordinates(fractionalDigits: Int? = null): Tuple2<Double, Double> {
        if (fractionalDigits == null) {
            return Tuple2(latitude, longitude)
        }
        val factor = pow(10.0, Double(fractionalDigits))
        return Tuple2(Double(round(latitude * factor)) / factor, Double(round(longitude * factor)) / factor)
    }

    /// Calculate the distance from another Location using the Haversine formula and returns the distance in kilometers
    fun distance(from: Location): Double {
        val location = from
        val lat1 = this.latitude
        val lon1 = this.longitude
        val lat2 = location.latitude
        val lon2 = location.longitude

        val dLat = (lat2 - lat1).toRadians
        val dLon = (lon2 - lon1).toRadians

        val slat: Double = sin(dLat / 2.0)
        val slon: Double = sin(dLon / 2.0)
        val a: Double = slat * slat + cos(lat1.toRadians) * cos(lat2.toRadians) * slon * slon
        val c: Double = 2.0 * atan2(sqrt(a), sqrt(1.0 - a))

        return c * 6371.0 // earthRadiusKilometers
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as Location
        this.latitude = copy.latitude
        this.longitude = copy.longitude
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Location(this as MutableStruct)

    override fun equals(other: Any?): Boolean {
        if (other !is Location) return false
        return latitude == other.latitude && longitude == other.longitude
    }

    override fun hashCode(): Int {
        var result = 1
        result = Hasher.combine(result, latitude)
        result = Hasher.combine(result, longitude)
        return result
    }

    private enum class CodingKeys(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CodingKey, RawRepresentable<String> {
        latitude("latitude"),
        longitude("longitude");

        companion object {
            fun init(rawValue: String): CodingKeys? {
                return when (rawValue) {
                    "latitude" -> CodingKeys.latitude
                    "longitude" -> CodingKeys.longitude
                    else -> null
                }
            }
        }
    }

    override fun encode(to: Encoder) {
        val container = to.container(keyedBy = CodingKeys::class)
        container.encode(latitude, forKey = CodingKeys.latitude)
        container.encode(longitude, forKey = CodingKeys.longitude)
    }

    constructor(from: Decoder) {
        val container = from.container(keyedBy = CodingKeys::class)
        this.latitude = container.decode(Double::class, forKey = CodingKeys.latitude)
        this.longitude = container.decode(Double::class, forKey = CodingKeys.longitude)
    }

    companion object: DecodableCompanion<Location> {
        override fun init(from: Decoder): Location = Location(from = from)

        private fun CodingKeys(rawValue: String): CodingKeys? = CodingKeys.init(rawValue = rawValue)
    }
}
