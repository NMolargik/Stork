package stork.model

import skip.lib.*

import skip.foundation.*

sealed class DeliveryError: Exception(), Error, LocalizedError {
    class NotFoundCase(val associated0: String): DeliveryError() {
    }
    class CreationFailedCase(val associated0: String): DeliveryError() {
    }
    class UpdateFailedCase(val associated0: String): DeliveryError() {
    }
    class DeletionFailedCase(val associated0: String): DeliveryError() {
    }
    class FirebaseErrorCase(val associated0: String): DeliveryError() {
    }
    class UnknownCase(val associated0: String): DeliveryError() {
    }

    override val errorDescription: String?
        get() {
            when (this) {
                is DeliveryError.NotFoundCase -> {
                    val message = this.associated0
                    return "Delivery Not Found: ${message}"
                }
                is DeliveryError.CreationFailedCase -> {
                    val message = this.associated0
                    return "Delivery Creation Failed: ${message}"
                }
                is DeliveryError.UpdateFailedCase -> {
                    val message = this.associated0
                    return "Delivery Update Failed: ${message}"
                }
                is DeliveryError.DeletionFailedCase -> {
                    val message = this.associated0
                    return "Delivery Deletion Failed: ${message}"
                }
                is DeliveryError.FirebaseErrorCase -> {
                    val message = this.associated0
                    return "Firebase Error: ${message}"
                }
                is DeliveryError.UnknownCase -> {
                    val message = this.associated0
                    return "Unknown Delivery Error: ${message}"
                }
            }
        }

    companion object {
        fun notFound(associated0: String): DeliveryError = NotFoundCase(associated0)
        fun creationFailed(associated0: String): DeliveryError = CreationFailedCase(associated0)
        fun updateFailed(associated0: String): DeliveryError = UpdateFailedCase(associated0)
        fun deletionFailed(associated0: String): DeliveryError = DeletionFailedCase(associated0)
        fun firebaseError(associated0: String): DeliveryError = FirebaseErrorCase(associated0)
        fun unknown(associated0: String): DeliveryError = UnknownCase(associated0)
    }
}
