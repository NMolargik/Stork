//
//  Sex.swift
//
//  Created by Nick Molargik on 11/26/24.
//

package stork.model

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.ui.*
import skip.model.*

/// Represents the sex of a baby within the Stork application.
enum class Sex(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): Codable, CaseIterable, Identifiable<Sex>, RawRepresentable<String> {

    // MARK: - Cases

    /// Represents a male baby.
    male("male"),

    /// Represents a female baby.
    female("female"),

    /// Represents an undetermined or unspecified sex.
    loss("loss");

    // MARK: - Identifiable Conformance

    /// Provides a unique identifier for each `Sex` instance.
    override val id: Sex
        get() = this

    // MARK: - CustomStringConvertible Conformance

    /// A human-readable description of the `Sex` instance.
    val description: String
        get() {
            when (this) {
                Sex.male -> return "Male"
                Sex.female -> return "Female"
                Sex.loss -> return "Loss"
            }
        }

    // MARK: - Computed Properties

    /// Returns the SwiftUI `Color` associated with each sex.
    ///
    /// - Returns: A `Color` representing the sex.
    val color: Color
        get() {
            when (this) {
                Sex.male -> return Color.blue
                Sex.female -> return Color.pink
                Sex.loss -> return Color.purple
            }
        }

    override fun toString(): String = description

    override fun encode(to: Encoder) {
        val container = to.singleValueContainer()
        container.encode(rawValue)
    }

    companion object: CaseIterableCompanion<Sex>, DecodableCompanion<Sex> {
        override fun init(from: Decoder): Sex = Sex(from = from)

        fun init(rawValue: String): Sex? {
            return when (rawValue) {
                "male" -> Sex.male
                "female" -> Sex.female
                "loss" -> Sex.loss
                else -> null
            }
        }

        override val allCases: Array<Sex>
            get() = arrayOf(male, female, loss)
    }
}

fun Sex(rawValue: String): Sex? = Sex.init(rawValue = rawValue)

fun Sex(from: Decoder): Sex {
    val container = from.singleValueContainer()
    val rawValue = container.decode(String::class)
    return Sex(rawValue = rawValue) ?: throw ErrorException(cause = NullPointerException())
}
