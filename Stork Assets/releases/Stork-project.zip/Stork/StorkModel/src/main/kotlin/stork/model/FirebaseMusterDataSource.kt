//
//  FirebaseMusterDataSource.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.firebase.firestore.*

/// A data source responsible for interacting with the Firebase Firestore database to manage muster records.
open class FirebaseMusterDataSource: MusterRemoteDataSourceInterface {
    /// The Firestore database instance.
    private val db: Firestore

    /// Initializes the FirebaseMusterDataSource with a Firestore instance.
    constructor() {
        this.db = Firestore.firestore()
    }

    // MARK: - Create a New Muster Record

    /// Creates a new muster record in Firestore and returns the newly created `Muster`.
    ///
    /// - Parameter muster: The `Muster` object to create.
    /// - Returns: The newly created `Muster` (optionally re-fetched if you need server-updated fields).
    /// - Throws:
    ///   - `MusterError.creationFailed`: If an error occurs while creating the muster.
    override suspend fun createMuster(muster: Muster): Muster = Async.run l@{
        try {
            // Convert muster to dictionary and write to Firestore
            val data = muster.dictionary.sref()
            db.collection("Muster").document(muster.id).setData(data)

            return@l muster.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.creationFailed("Failed to create muster: ${error.localizedDescription}")
        }
    }

    // MARK: - Update an Existing Muster Record

    /// Updates an existing muster record in Firestore and returns the updated `Muster`.
    ///
    /// - Parameter muster: The `Muster` object containing updated data.
    /// - Returns: The updated `Muster` (optionally re-fetched if you need server-updated fields).
    /// - Throws:
    ///   - `MusterError.updateFailed`: If an error occurs while updating the muster.
    override suspend fun updateMuster(muster: Muster): Muster = Async.run l@{
        try {
            val data = muster.dictionary.sref()
            db.collection("Muster").document(muster.id).updateData(data)

            return@l muster.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.updateFailed("Failed to update muster: ${error.localizedDescription}")
        }
    }

    /// Fetches a single muster by its unique ID.
    ///
    /// - Parameter id: The unique ID of the muster to fetch.
    /// - Returns: A `Muster` object representing the muster with the specified ID.
    /// - Throws:
    ///   - `MusterError.notFound`: If no muster with the specified ID is found.
    ///   - `MusterError.firebaseError`: If an error occurs while fetching the muster.
    override suspend fun getMuster(byId: String): Muster = Async.run l@{
        val id = byId
        try {
            val document = db.collection("Muster").document(id).getDocument()
            val data_0 = document.data()
            if (data_0 == null) {
                throw MusterError.notFound("Muster with ID ${id} not found.")
            }
            val muster_0 = (try { Muster(from = data_0, id = document.documentID) } catch (_: NullReturnException) { null })
            if (muster_0 == null) {
                throw MusterError.notFound("Invalid data for muster with ID ${id}.")
            }

            return@l muster_0.sref()
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.notFound("Failed to fetch muster with ID ${id}: ${error.localizedDescription}")
        }
    }

    // MARK: - List Musters with Filters

    /// Lists musters based on optional filters.
    ///
    /// - Parameters:
    ///   - profileIds: An optional filter for profile IDs associated with the muster.
    ///   - primaryHospitalId: An optional filter for the primary hospital ID associated with the muster.
    ///   - administratorProfileIds: An optional filter for the administrator profile IDs.
    ///   - name: An optional filter for the muster name.
    /// - Returns: An array of `Muster` objects matching the specified filters.
    /// - Throws:
    ///   - `MusterError.notFound`: If none are found or Firestore errors occur.
    override suspend fun listMusters(profileIds: Array<String>?, primaryHospitalId: String?, administratorProfileIds: Array<String>?, name: String?): Array<Muster> = Async.run l@{
        try {
            var query: Query = db.collection("Muster")

            if (profileIds != null) {
                query = query.whereField("profileIds", isEqualTo = profileIds)
            }
            if (primaryHospitalId != null) {
                query = query.whereField("primaryHospitalId", isEqualTo = primaryHospitalId)
            }
            if (administratorProfileIds != null) {
                query = query.whereField("administratorProfileIds", isEqualTo = administratorProfileIds)
            }
            if (name != null) {
                query = query.whereField("name", isEqualTo = name)
            }

            // Fetch documents that match the query
            val snapshot = query.getDocuments()
            var musters = snapshot.documents.compactMap { it -> (try { Muster(from = it.data(), id = it.documentID) } catch (_: NullReturnException) { null }) }

            // Manually filter by `profileIds` if provided (if your query logic requires it)
            if (profileIds != null) {
                musters = musters.filter { muster ->
                    // Ensure that for each ID in `profileIds`, `muster.profileIds` contains that ID
                    profileIds.allSatisfy { it -> muster.profileIds.contains(it) }
                }
            }

            return@l musters.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.notFound("Failed to fetch musters: ${error.localizedDescription}")
        }
    }

    // MARK: - Delete an Existing Muster Record

    /// Deletes an existing muster record from Firestore.
    ///
    /// - Parameter muster: The `Muster` object to delete.
    /// - Throws:
    ///   - `MusterError.deletionFailed`: If an error occurs while deleting the muster.
    override suspend fun deleteMuster(muster: Muster): Unit = Async.run {
        try {
            db.collection("Muster").document(muster.id).delete()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.deletionFailed("Failed to delete muster: ${error.localizedDescription}")
        }
    }

    // MARK: - Invite a User to a Muster

    /// Sends a profile an invite to join a muster.
    ///
    /// - Parameter invite: The `MusterInvite` object defining the invitation.
    /// - Parameter userId: The ID of the user being invited.
    /// - Throws: `MusterError.invitationFailed` if sending fails.
    override suspend fun sendMusterInvite(invite: MusterInvite, userId: String): Unit = Async.run {
        try {
            val data = invite.dictionary.sref()
            db.collection("MusterInvite").document(invite.id).setData(data)
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.invitationFailed(error.localizedDescription)
        }
    }

    /// Collects all muster invitations for a user.
    ///
    /// - Parameter userId: The user ID associated with potential muster invites.
    /// - Returns: An array of `MusterInvite` objects for the specified user.
    /// - Throws: `MusterError.failedToCollectInvitations` if fetching fails.
    override suspend fun collectUserMusterInvites(userId: String): Array<MusterInvite> = Async.run l@{
        try {
            val query = db.collection("MusterInvite").whereField("recipientId", isEqualTo = userId)
            val snapshot = query.getDocuments()
            val invitations = snapshot.documents.compactMap { it -> (try { MusterInvite(from = it.data(), id = it.documentID) } catch (_: NullReturnException) { null }) }
            return@l invitations.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.failedToCollectInvitations(error.localizedDescription)
        }
    }

    /// Collects all muster invitations for a specific muster.
    ///
    /// - Parameter musterId: The ID of the muster whose invitations should be fetched.
    /// - Returns: An array of `MusterInvite` objects for the specified muster.
    /// - Throws: `MusterError.failedToCollectInvitations` if fetching fails.
    override suspend fun collectInvitesForMuster(musterId: String): Array<MusterInvite> = Async.run l@{
        try {
            val query = db.collection("MusterInvite").whereField("musterId", isEqualTo = musterId)
            val snapshot = query.getDocuments()
            val invitations = snapshot.documents.compactMap { it -> (try { MusterInvite(from = it.data(), id = it.documentID) } catch (_: NullReturnException) { null }) }
            return@l invitations.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.failedToCollectInvitations(error.localizedDescription)
        }
    }

    /// Deletes all muster invitations associated with a given muster.
    ///
    /// - Parameter musterId: The ID of the muster whose invitations should be deleted.
    /// - Throws: `MusterError.failedToCollectInvitations` if fetching fails, or other errors during deletion.
    override suspend fun deleteMusterInvites(musterId: String): Unit = Async.run {
        val query = db.collection("MusterInvite").whereField("musterId", isEqualTo = musterId)
        val snapshot = query.getDocuments()
        val invitations = snapshot.documents.compactMap { it -> (try { MusterInvite(from = it.data(), id = it.documentID) } catch (_: NullReturnException) { null }) }

        for (musterInvite in invitations.sref()) {
            db.collection("MusterInvite").document(musterInvite.id).delete()
        }
    }

    /// Cancels a previously sent muster invitation by deleting its Firestore document.
    ///
    /// - Parameter invitationId: The ID of the invitation to cancel.
    /// - Throws: `MusterError.failedToCancelInvite` if deletion fails.
    override suspend fun cancelMusterInvite(invitationId: String): Unit = Async.run {
        try {
            db.collection("MusterInvite").document(invitationId).delete()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.failedToCancelInvite(error.localizedDescription)
        }
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
