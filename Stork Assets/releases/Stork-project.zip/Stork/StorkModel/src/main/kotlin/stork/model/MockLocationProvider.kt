//
//  MockLocationProvider.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.model

import skip.lib.*

import skip.foundation.*

open class MockLocationProvider: LocationProviderInterface {
    private val mockLatitude: Double
    private val mockLongitude: Double
    private val mockCity: String?
    private val mockState: String?

    constructor(mockLatitude: Double = 40.7128, mockLongitude: Double = -74.0060, mockCity: String? = "Fort Wayne", mockState: String? = "IN") {
        this.mockLatitude = mockLatitude
        this.mockLongitude = mockLongitude
        this.mockCity = mockCity
        this.mockState = mockState
    }

    override suspend fun fetchCurrentLocation(): Tuple2<Double, Double> = Async.run l@{
        // Simulate a delay for realism, if necessary
        Task.sleep(nanoseconds = 500_000_000) // 500 ms
        return@l Tuple2(mockLatitude, mockLongitude)
    }

    override suspend fun fetchCityAndState(from: Location): Tuple2<String?, String?> = Async.run l@{
        val location = from
        // Simulate a delay for realism, if necessary
        Task.sleep(nanoseconds = 500_000_000) // 500 ms
        return@l Tuple2(mockCity, mockState)
    }

    override suspend fun geocodeAddress(address: String): Tuple2<Double, Double> = Async.run l@{
        // Simulate geocoding by returning mock coordinates
        Task.sleep(nanoseconds = 500_000_000) // Simulate delay for realism

        // Return predefined coordinates for the mock address
        when (address.lowercased()) {
            "1600 amphitheatre parkway, mountain view, ca" -> return@l Tuple2(37.4220, -122.0841) // Googleplex
            "one apple park way, cupertino, ca" -> return@l Tuple2(37.3349, -122.0090) // Apple HQ
            "fort wayne, in" -> return@l Tuple2(41.0793, -85.1394) // Fort Wayne, Indiana
            else -> return@l Tuple2(mockLatitude, mockLongitude) // Default to mock location
        }
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
