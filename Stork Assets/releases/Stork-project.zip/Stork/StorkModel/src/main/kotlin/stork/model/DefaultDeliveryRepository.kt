//
//  DefaultDeliveryRepository.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// A concrete implementation of the `DeliveryRepositoryInterface` protocol.
/// This class is responsible for handling delivery-related operations by interacting with a remote data source.
open class DefaultDeliveryRepository: DeliveryRepositoryInterface {
    // MARK: - Properties

    /// The remote data source used to perform delivery operations.
    private val remoteDataSource: DeliveryRemoteDataSourceInterface

    // MARK: - Initializer

    /// Initializes the repository with a remote data source.
    ///
    /// - Parameter remoteDataSource: An instance of `DeliveryRemoteDataSourceInterface`.
    constructor(remoteDataSource: DeliveryRemoteDataSourceInterface) {
        this.remoteDataSource = remoteDataSource.sref()
    }

    // MARK: - Create

    /// Creates a new delivery record and returns the newly created `Delivery`.
    ///
    /// - Parameter delivery: The `Delivery` object to be created.
    /// - Returns: The newly created `Delivery`, including its Firestore-generated `id`.
    /// - Throws:
    ///   - `DeliveryError.creationFailed`: If the operation fails to create the delivery.
    override suspend fun createDelivery(delivery: Delivery): Delivery = Async.run l@{
        try {
            val createdDelivery = remoteDataSource.createDelivery(delivery = delivery)
            return@l createdDelivery.sref()
        } catch (error: DeliveryError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.creationFailed("Failed to create delivery: ${error.localizedDescription}")
        }
    }

    // MARK: - Update

    /// Updates an existing delivery record and returns the updated `Delivery`.
    ///
    /// - Parameter delivery: The `Delivery` object containing the updated data.
    /// - Returns: The updated `Delivery`.
    /// - Throws:
    ///   - `DeliveryError.updateFailed`: If the operation fails to update the delivery.
    override suspend fun updateDelivery(delivery: Delivery): Delivery = Async.run l@{
        try {
            val updatedDelivery = remoteDataSource.updateDelivery(delivery = delivery)
            return@l updatedDelivery.sref()
        } catch (error: DeliveryError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.updateFailed("Failed to update delivery: ${error.localizedDescription}")
        }
    }

    // MARK: - Read

    /// Fetches a single delivery by its unique ID.
    ///
    /// - Parameter id: The unique ID of the delivery to fetch.
    /// - Returns: A `Delivery` object representing the fetched delivery.
    /// - Throws:
    ///   - `DeliveryError.notFound`: If the delivery with the specified ID is not found.
    ///   - `DeliveryError.firebaseError`: If the operation fails due to a Firestore-related issue.
    override suspend fun getDelivery(byId: String): Delivery = Async.run l@{
        val id = byId
        try {
            return@l remoteDataSource.getDelivery(byId = id)
        } catch (error: DeliveryError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.notFound("Failed to fetch delivery with ID ${id}: ${error.localizedDescription}")
        }
    }

    /// Lists deliveries based on optional filter criteria.
    ///
    /// - Parameters:
    ///   - userId: An optional filter for the ID of the user associated with the delivery.
    ///   - userFirstName: An optional filter for the first name of the user.
    ///   - hospitalId: An optional filter for the hospital ID associated with the delivery.
    ///   - hospitalName: An optional filter for the hospital name.
    ///   - musterId: An optional filter for the muster ID associated with the delivery.
    ///   - date: An optional filter for the delivery date.
    ///   - babyCount: An optional filter for the number of babies in the delivery.
    ///   - deliveryMethod: An optional filter for the delivery method (e.g., vaginal, c-section).
    ///   - epiduralUsed: An optional filter for whether an epidural was used.
    /// - Returns: An array of `Delivery` objects matching the specified filters.
    /// - Throws:
    ///   - `DeliveryError.firebaseError`: If the operation fails due to a Firestore-related issue.
    override suspend fun listDeliveries(userId: String?, userFirstName: String?, hospitalId: String?, hospitalName: String?, musterId: String?, date: Date?, babyCount: Int?, deliveryMethod: DeliveryMethod?, epiduralUsed: Boolean?): Array<Delivery> = Async.run l@{
        try {
            return@l remoteDataSource.listDeliveries(userId = userId, userFirstName = userFirstName, hospitalId = hospitalId, hospitalName = hospitalName, musterId = musterId, date = date, babyCount = babyCount, deliveryMethod = deliveryMethod, epiduralUsed = epiduralUsed)
        } catch (error: DeliveryError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.firebaseError("Failed to list deliveries: ${error.localizedDescription}")
        }
    }

    // MARK: - Delete

    /// Deletes an existing delivery record.
    ///
    /// - Parameter delivery: The `Delivery` object to be deleted.
    /// - Throws:
    ///   - `DeliveryError.deletionFailed`: If the operation fails to delete the delivery.
    override suspend fun deleteDelivery(delivery: Delivery): Unit = Async.run {
        try {
            remoteDataSource.deleteDelivery(delivery = delivery)
        } catch (error: DeliveryError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.deletionFailed("Failed to delete delivery: ${error.localizedDescription}")
        }
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
