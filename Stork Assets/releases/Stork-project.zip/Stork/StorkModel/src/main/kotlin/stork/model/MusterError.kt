package stork.model

import skip.lib.*

import skip.foundation.*

sealed class MusterError: Exception(), Error, LocalizedError {
    class NotFoundCase(val associated0: String): MusterError() {
    }
    class CreationFailedCase(val associated0: String): MusterError() {
    }
    class UpdateFailedCase(val associated0: String): MusterError() {
    }
    class DeletionFailedCase(val associated0: String): MusterError() {
    }
    class InvitationFailedCase(val associated0: String): MusterError() {
    }
    class InvitationResponseFailedCase(val associated0: String): MusterError() {
    }
    class FailedToCollectInvitationsCase(val associated0: String): MusterError() {
    }
    class FailedToCancelInviteCase(val associated0: String): MusterError() {
    }
    class UnknownCase(val associated0: String): MusterError() {
    }

    override val errorDescription: String?
        get() {
            when (this) {
                is MusterError.NotFoundCase -> {
                    val message = this.associated0
                    return "Muster Not Found: ${message}"
                }
                is MusterError.CreationFailedCase -> {
                    val message = this.associated0
                    return "Muster Creation Failed: ${message}"
                }
                is MusterError.UpdateFailedCase -> {
                    val message = this.associated0
                    return "Muster Update Failed: ${message}"
                }
                is MusterError.DeletionFailedCase -> {
                    val message = this.associated0
                    return "Muster Deletion Failed: ${message}"
                }
                is MusterError.UnknownCase -> {
                    val message = this.associated0
                    return "Unknown Muster Error: ${message}"
                }
                is MusterError.InvitationFailedCase -> {
                    val message = this.associated0
                    return "Invitation Failed To Send: ${message}"
                }
                is MusterError.InvitationResponseFailedCase -> {
                    val message = this.associated0
                    return "Failed to respond to invitation: ${message}"
                }
                is MusterError.FailedToCollectInvitationsCase -> {
                    val message = this.associated0
                    return "Failed to collect invitations: ${message}"
                }
                is MusterError.FailedToCancelInviteCase -> {
                    val message = this.associated0
                    return "Failed to cancel invitation: ${message}"
                }
            }
        }

    companion object {
        fun notFound(associated0: String): MusterError = NotFoundCase(associated0)
        fun creationFailed(associated0: String): MusterError = CreationFailedCase(associated0)
        fun updateFailed(associated0: String): MusterError = UpdateFailedCase(associated0)
        fun deletionFailed(associated0: String): MusterError = DeletionFailedCase(associated0)
        fun invitationFailed(associated0: String): MusterError = InvitationFailedCase(associated0)
        fun invitationResponseFailed(associated0: String): MusterError = InvitationResponseFailedCase(associated0)
        fun failedToCollectInvitations(associated0: String): MusterError = FailedToCollectInvitationsCase(associated0)
        fun failedToCancelInvite(associated0: String): MusterError = FailedToCancelInviteCase(associated0)
        fun unknown(associated0: String): MusterError = UnknownCase(associated0)
    }
}
