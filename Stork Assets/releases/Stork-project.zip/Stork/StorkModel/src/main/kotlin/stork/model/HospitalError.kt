package stork.model

import skip.lib.*

import skip.foundation.*

sealed class HospitalError: Exception(), Error, LocalizedError {
    class NotFoundCase(val associated0: String): HospitalError() {
    }
    class CreationFailedCase(val associated0: String): HospitalError() {
    }
    class UpdateFailedCase(val associated0: String): HospitalError() {
    }
    class DeletionFailedCase(val associated0: String): HospitalError() {
    }
    class UnknownCase(val associated0: String): HospitalError() {
    }

    override val errorDescription: String?
        get() {
            when (this) {
                is HospitalError.NotFoundCase -> {
                    val message = this.associated0
                    return "Hospital Not Found: ${message}"
                }
                is HospitalError.CreationFailedCase -> {
                    val message = this.associated0
                    return "Hospital Creation Failed: ${message}"
                }
                is HospitalError.UpdateFailedCase -> {
                    val message = this.associated0
                    return "Hospital Update Failed: ${message}"
                }
                is HospitalError.DeletionFailedCase -> {
                    val message = this.associated0
                    return "Hospital Deletion Failed: ${message}"
                }
                is HospitalError.UnknownCase -> {
                    val message = this.associated0
                    return "Unknown Hospital Error: ${message}"
                }
            }
        }

    companion object {
        fun notFound(associated0: String): HospitalError = NotFoundCase(associated0)
        fun creationFailed(associated0: String): HospitalError = CreationFailedCase(associated0)
        fun updateFailed(associated0: String): HospitalError = UpdateFailedCase(associated0)
        fun deletionFailed(associated0: String): HospitalError = DeletionFailedCase(associated0)
        fun unknown(associated0: String): HospitalError = UnknownCase(associated0)
    }
}
