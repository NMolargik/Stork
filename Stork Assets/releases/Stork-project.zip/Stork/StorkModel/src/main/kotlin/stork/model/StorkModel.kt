package stork.model

import skip.lib.*

open class StorkModelModule {

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
