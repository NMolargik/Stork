//
//  DefaultMusterRepository.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// A repository implementation for managing muster-related operations.
/// Handles interactions with the remote data source for musters.
open class DefaultMusterRepository: MusterRepositoryInterface {
    // MARK: - Properties

    /// The remote data source for muster operations.
    private val remoteDataSource: MusterRemoteDataSourceInterface

    // MARK: - Initializer

    /// Initializes the repository with a remote data source.
    ///
    /// - Parameter remoteDataSource: An instance of `MusterRemoteDataSourceInterface`.
    constructor(remoteDataSource: MusterRemoteDataSourceInterface) {
        this.remoteDataSource = remoteDataSource.sref()
    }

    // MARK: - Create

    /// Creates a new muster record and returns the newly created `Muster`.
    ///
    /// - Parameter muster: The `Muster` object to create.
    /// - Returns: The newly created `Muster`, including any auto-generated fields (e.g., ID).
    /// - Throws:
    ///   - `MusterError.creationFailed`: If the creation operation fails.
    ///   - Other `MusterError` variants for different failure scenarios.
    override suspend fun createMuster(muster: Muster): Muster = Async.run l@{
        try {
            // The data source now returns a `Muster` instead of `Void`.
            val createdMuster = remoteDataSource.createMuster(muster = muster)
            return@l createdMuster.sref()
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.creationFailed("Failed to create muster: ${error.localizedDescription}")
        }
    }

    // MARK: - Update

    /// Updates an existing muster record and returns the updated `Muster`.
    ///
    /// - Parameter muster: The `Muster` object containing updated data.
    /// - Returns: The updated `Muster`, reflecting any changes from the server.
    /// - Throws:
    ///   - `MusterError.notFound`: If the muster does not exist.
    ///   - `MusterError.updateFailed`: If the update operation fails.
    ///   - Other `MusterError` variants for additional failure scenarios.
    override suspend fun updateMuster(muster: Muster): Muster = Async.run l@{
        try {
            val updatedMuster = remoteDataSource.updateMuster(muster = muster)
            return@l updatedMuster.sref()
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.updateFailed("Failed to update muster: ${error.localizedDescription}")
        }
    }

    // MARK: - Read

    /// Fetches a single muster by its unique ID.
    ///
    /// - Parameter id: The unique ID of the muster to fetch.
    /// - Returns: A `Muster` object representing the fetched muster.
    /// - Throws:
    ///   - `MusterError.notFound`: If the muster with the specified ID does not exist.
    ///   - Other `MusterError` variants for failures during the fetch operation.
    override suspend fun getMuster(byId: String): Muster = Async.run l@{
        val id = byId
        try {
            return@l remoteDataSource.getMuster(byId = id)
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.unknown("Failed to fetch muster with ID ${id}: ${error.localizedDescription}")
        }
    }

    /// Lists musters based on optional filter criteria.
    ///
    /// - Parameters:
    ///   - profileIds: An optional filter for profile IDs associated with the muster.
    ///   - primaryHospitalId: An optional filter for the hospital ID associated with the muster.
    ///   - administratorProfileIds: An optional filter for the administrators' profile IDs.
    ///   - name: An optional filter for the muster name.
    /// - Returns: An array of `Muster` objects matching the specified filters.
    /// - Throws:
    ///   - `MusterError` variants if the operation fails.
    override suspend fun listMusters(profileIds: Array<String>?, primaryHospitalId: String?, administratorProfileIds: Array<String>?, name: String?): Array<Muster> = Async.run l@{
        try {
            return@l remoteDataSource.listMusters(profileIds = profileIds, primaryHospitalId = primaryHospitalId, administratorProfileIds = administratorProfileIds, name = name)
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.unknown("Failed to list musters: ${error.localizedDescription}")
        }
    }

    // MARK: - Invites

    /// Sends a profile an invite to join a muster.
    ///
    /// - Parameters:
    ///   - invite: The `MusterInvite` object defining the invitation.
    ///   - userId: The ID of the user that is being invited.
    /// - Throws:
    ///   - `MusterError.invitationFailed`: If the invitation fails.
    ///   - Other `MusterError` variants for different failure scenarios.
    override suspend fun sendMusterInvite(invite: MusterInvite, userId: String): Unit = Async.run {
        try {
            remoteDataSource.sendMusterInvite(invite = invite, userId = userId)
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.invitationFailed("Failed to create muster invitation: ${error.localizedDescription}")
        }
    }

    /// Collects all muster invitations for a user.
    ///
    /// - Parameter userId: The user ID associated with potential muster invites.
    /// - Returns: An array of `MusterInvite` objects.
    /// - Throws:
    ///   - `MusterError.failedToCollectInvitations`: If collection fails.
    ///   - Other `MusterError` variants for different failure scenarios.
    override suspend fun collectUserMusterInvites(userId: String): Array<MusterInvite> = Async.run l@{
        try {
            return@l remoteDataSource.collectUserMusterInvites(userId = userId)
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.failedToCollectInvitations("Failed to collect your invites: ${error.localizedDescription}")
        }
    }

    /// Collects all muster invitations for a specific muster.
    ///
    /// - Parameter musterId: The muster ID associated with the invitations.
    /// - Returns: An array of `MusterInvite` objects.
    /// - Throws:
    ///   - `MusterError.failedToCollectInvitations`: If the collection fails.
    ///   - Other `MusterError` variants for additional failure modes.
    override suspend fun collectInvitesForMuster(musterId: String): Array<MusterInvite> = Async.run l@{
        try {
            return@l remoteDataSource.collectInvitesForMuster(musterId = musterId)
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.failedToCollectInvitations("Failed to collect muster invites: ${error.localizedDescription}")
        }
    }

    /// Cancels a previously sent muster invitation.
    ///
    /// - Parameter invitationId: The ID of the invitation to cancel.
    /// - Throws:
    ///   - `MusterError.failedToCancelInvite`: If the cancellation fails.
    ///   - Other `MusterError` variants for different failure scenarios.
    override suspend fun cancelMusterInvite(invitationId: String): Unit = Async.run {
        try {
            remoteDataSource.cancelMusterInvite(invitationId = invitationId)
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.failedToCancelInvite("Failed to cancel invite: ${error.localizedDescription}")
        }
    }

    /// Deletes all muster invitations associated with a given muster.
    ///
    /// - Parameter musterId: The ID of the muster whose invitations should be deleted.
    /// - Throws:
    ///   - `MusterError.failedToCollectInvitations`, `MusterError.deletionFailed`, or other relevant errors.
    override suspend fun deleteMusterInvites(musterId: String): Unit = Async.run {
        try {
            remoteDataSource.deleteMusterInvites(musterId = musterId)
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            // Re-throwing the original error might be simpler if your domain logic doesn't require further wrapping
            throw error as Throwable
        }
    }

    // MARK: - Delete

    /// Deletes an existing muster record.
    ///
    /// - Parameter muster: The `Muster` object to delete.
    /// - Throws:
    ///   - `MusterError.notFound`: If the muster does not exist.
    ///   - `MusterError.deletionFailed`: If the deletion operation fails.
    ///   - Other `MusterError` variants for additional failure scenarios.
    override suspend fun deleteMuster(muster: Muster): Unit = Async.run {
        try {
            remoteDataSource.deleteMuster(muster = muster)
        } catch (error: MusterError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw MusterError.deletionFailed("Failed to close your muster: ${error.localizedDescription}")
        }
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
