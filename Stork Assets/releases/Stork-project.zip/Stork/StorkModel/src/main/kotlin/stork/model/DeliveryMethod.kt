//
//  DeliveryMethod.swift
//
//  Created by Nick Molargik on 11/26/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// Represents the various methods of delivery available within the Stork application.
enum class DeliveryMethod(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CaseIterable, Codable, RawRepresentable<String> {

    // MARK: - Cases

    /// Represents a vaginal delivery.
    vaginal("vaginal"),

    /// Represents a cesarean section delivery.
    cSection("cSection"),

    /// Represents a vaginal birth after cesarean (VBAC).
    vBac("vBac");

    // MARK: - Computed Properties

    /// Provides a human-readable description of the delivery method.
    val description: String
        get() {
            when (this) {
                DeliveryMethod.vaginal -> return "Vaginal"
                DeliveryMethod.cSection -> return "C-Section"
                DeliveryMethod.vBac -> return "VBAC"
            }
        }

    /// Returns the string value of the delivery method's description.
    val stringValue: String
        get() = this.description

    override fun encode(to: Encoder) {
        val container = to.singleValueContainer()
        container.encode(rawValue)
    }

    companion object: CaseIterableCompanion<DeliveryMethod>, DecodableCompanion<DeliveryMethod> {
        override fun init(from: Decoder): DeliveryMethod = DeliveryMethod(from = from)

        fun init(rawValue: String): DeliveryMethod? {
            return when (rawValue) {
                "vaginal" -> DeliveryMethod.vaginal
                "cSection" -> DeliveryMethod.cSection
                "vBac" -> DeliveryMethod.vBac
                else -> null
            }
        }

        override val allCases: Array<DeliveryMethod>
            get() = arrayOf(vaginal, cSection, vBac)
    }
}

fun DeliveryMethod(rawValue: String): DeliveryMethod? = DeliveryMethod.init(rawValue = rawValue)

fun DeliveryMethod(from: Decoder): DeliveryMethod {
    val container = from.singleValueContainer()
    val rawValue = container.decode(String::class)
    return DeliveryMethod(rawValue = rawValue) ?: throw ErrorException(cause = NullPointerException())
}
