package stork.model

import skip.lib.*


internal val <E0, E1> Tuple2<E0, E1>.city: E0
    get() = element0

internal val <E0, E1> Tuple2<E0, E1>.latitude: E0
    get() = element0

internal val <E0, E1> Tuple2<E0, E1>.longitude: E1
    get() = element1

internal val <E0, E1> Tuple2<E0, E1>.state: E1
    get() = element1
