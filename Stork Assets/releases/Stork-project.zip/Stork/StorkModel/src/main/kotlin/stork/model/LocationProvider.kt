//
//  LocationProvider.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.model

import androidx.compose.runtime.Stable
import androidx.compose.runtime.mutableStateOf
import skip.lib.*


import skip.foundation.*
import skip.model.*


open class LocationProvider: java.lang.Object, LocationProviderInterface {
    var location: Location? = null
        get() = field.sref({ this.location = it })
        private set(newValue) {
            field = newValue.sref()
        }
    private var completion: ((Result<Tuple2<Double, Double>, Error>) -> Unit)? = null
    var city: String? = null
        private set
    var state: String? = null
        private set


    constructor(): super() {
    }

    open suspend fun fetch(): Unit = Async.run {
        val (latitude, longitude) = fetchCurrentLocation()
        location = Location(latitude = latitude, longitude = longitude)

        val (city, state) = fetchCityAndState(from = location!!)
        this.city = city
        this.state = state
    }

    override suspend fun fetchCurrentLocation(): Tuple2<Double, Double> = Async.run l@{
        val context = ProcessInfo.processInfo.androidContext.sref()
        val matchtarget_0 = fetchCurrentLocation(context)
        if (matchtarget_0 == null) {
            throw NSError(domain = "LocationError", code = 1, userInfo = dictionaryOf(Tuple2(NSLocalizedDescriptionKey, "Failed to fetch location in SKIP context.")))
        }
        val (latitude_0, longitude_0) = matchtarget_0
        return@l Tuple2(latitude_0, longitude_0)
    }

    override suspend fun geocodeAddress(address: String): Tuple2<Double, Double> = Async.run l@{
        val context = ProcessInfo.processInfo.androidContext.sref()
        val matchtarget_1 = geocodeAddress(context, address)
        if (matchtarget_1 == null) {
            throw NSError(domain = "GeocodingError", code = 2, userInfo = dictionaryOf(Tuple2(NSLocalizedDescriptionKey, "Could not geocode address in SKIP context.")))
        }
        val (latitude_1, longitude_1) = matchtarget_1
        return@l Tuple2(latitude_1, longitude_1)
    }


    override suspend fun fetchCityAndState(from: Location): Tuple2<String?, String?> = Async.run l@{
        val location = from
        val context = ProcessInfo.processInfo.androidContext.sref()
        val matchtarget_2 = fetchCityAndState(context, location.latitude, location.longitude)
        if (matchtarget_2 == null) {
            throw NSError(domain = "ReverseGeocodingError", code = 2, userInfo = dictionaryOf(Tuple2(NSLocalizedDescriptionKey, "Could not fetch city and state in SKIP context.")))
        }
        val (city_0, state_0) = matchtarget_2
        return@l Tuple2(city_0, state_0)

    }

    internal val stateAbbreviations: Dictionary<String, String> = dictionaryOf(
        Tuple2("Alabama", "AL"),
        Tuple2("Alaska", "AK"),
        Tuple2("Arizona", "AZ"),
        Tuple2("Arkansas", "AR"),
        Tuple2("California", "CA"),
        Tuple2("Colorado", "CO"),
        Tuple2("Connecticut", "CT"),
        Tuple2("Delaware", "DE"),
        Tuple2("Florida", "FL"),
        Tuple2("Georgia", "GA"),
        Tuple2("Hawaii", "HI"),
        Tuple2("Idaho", "ID"),
        Tuple2("Illinois", "IL"),
        Tuple2("Indiana", "IN"),
        Tuple2("Iowa", "IA"),
        Tuple2("Kansas", "KS"),
        Tuple2("Kentucky", "KY"),
        Tuple2("Louisiana", "LA"),
        Tuple2("Maine", "ME"),
        Tuple2("Maryland", "MD"),
        Tuple2("Massachusetts", "MA"),
        Tuple2("Michigan", "MI"),
        Tuple2("Minnesota", "MN"),
        Tuple2("Mississippi", "MS"),
        Tuple2("Missouri", "MO"),
        Tuple2("Montana", "MT"),
        Tuple2("Nebraska", "NE"),
        Tuple2("Nevada", "NV"),
        Tuple2("New Hampshire", "NH"),
        Tuple2("New Jersey", "NJ"),
        Tuple2("New Mexico", "NM"),
        Tuple2("New York", "NY"),
        Tuple2("North Carolina", "NC"),
        Tuple2("North Dakota", "ND"),
        Tuple2("Ohio", "OH"),
        Tuple2("Oklahoma", "OK"),
        Tuple2("Oregon", "OR"),
        Tuple2("Pennsylvania", "PA"),
        Tuple2("Rhode Island", "RI"),
        Tuple2("South Carolina", "SC"),
        Tuple2("South Dakota", "SD"),
        Tuple2("Tennessee", "TN"),
        Tuple2("Texas", "TX"),
        Tuple2("Utah", "UT"),
        Tuple2("Vermont", "VT"),
        Tuple2("Virginia", "VA"),
        Tuple2("Washington", "WA"),
        Tuple2("West Virginia", "WV"),
        Tuple2("Wisconsin", "WI"),
        Tuple2("Wyoming", "WY")
    )

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}


