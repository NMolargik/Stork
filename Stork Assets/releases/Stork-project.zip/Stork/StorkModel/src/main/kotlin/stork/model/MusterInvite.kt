//
//  MusterInvite.swift
//
//  Created by Nick Molargik on 12/10/24.
//

package stork.model

import skip.lib.*

import skip.foundation.*

/// Represents an invitation sent to a user to join a muster within the Stork application.
@Suppress("MUST_BE_INITIALIZED")
class MusterInvite: Identifiable<String>, Codable, MutableStruct {

    // MARK: - Properties

    /// Unique identifier for the muster invite.
    override var id: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier of the recipient's profile.
    var recipientId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Name of the recipient.
    var recipientName: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Name of the sender who is inviting the recipient.
    var senderName: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Name of the muster to which the recipient is being invited.
    var musterName: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier of the muster.
    var musterId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    // MARK: - Computed Properties

    /// Converts the muster invite data into a dictionary format, suitable for Firestore or similar databases.
    val dictionary: Dictionary<String, Any>
        get() = dictionaryOf(
            Tuple2("recipientId", recipientId),
            Tuple2("recipientName", recipientName),
            Tuple2("senderName", senderName),
            Tuple2("musterName", musterName),
            Tuple2("musterId", musterId)
        )

    // MARK: - Initializers

    /// Initializes a `MusterInvite` instance from a dictionary and an optional ID.
    ///
    /// - Parameters:
    ///   - dictionary: A dictionary containing muster invite data.
    ///   - id: Optional ID for the muster invite. If `nil`, initialization fails.
    constructor(from: Dictionary<String, Any>, id: String?) {
        val dictionary = from
        if (id == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val recipientId_0 = dictionary["recipientId"] as? String
        if (recipientId_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val recipientName_0 = dictionary["recipientName"] as? String
        if (recipientName_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val senderName_0 = dictionary["senderName"] as? String
        if (senderName_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val musterName_0 = dictionary["musterName"] as? String
        if (musterName_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val musterId_0 = dictionary["musterId"] as? String
        if (musterId_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }

        this.id = id
        this.recipientId = recipientId_0
        this.recipientName = recipientName_0
        this.senderName = senderName_0
        this.musterName = musterName_0
        this.musterId = musterId_0
    }

    /// Initializes a `MusterInvite` instance with explicit parameters.
    ///
    /// - Parameters:
    ///   - id: Unique identifier for the muster invite.
    ///   - recipientId: Identifier of the recipient's profile.
    ///   - recipientName: Name of the recipient.
    ///   - senderName: Name of the sender.
    ///   - musterName: Name of the muster.
    ///   - musterId: Identifier of the muster.
    constructor(id: String, recipientId: String, recipientName: String, senderName: String, musterName: String, musterId: String) {
        this.id = id
        this.recipientId = recipientId
        this.recipientName = recipientName
        this.senderName = senderName
        this.musterName = musterName
        this.musterId = musterId
    }

    // MARK: - Default Initializer

    /// Initializes a `MusterInvite` instance with default values.
    /// This initializer can be useful for creating placeholder or testing instances.
    constructor() {
        this.id = UUID().uuidString
        this.recipientId = ""
        this.recipientName = ""
        this.senderName = ""
        this.musterName = "New Muster"
        this.musterId = ""
    }

    // MARK: - Codable Conformance

    /// Specifies the coding keys for encoding and decoding.
    private enum class CodingKeys(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CodingKey, RawRepresentable<String> {
        id("id"),
        recipientId("recipientId"),
        recipientName("recipientName"),
        senderName("senderName"),
        musterName("musterName"),
        musterId("musterId");

        companion object {
            fun init(rawValue: String): MusterInvite.CodingKeys? {
                return when (rawValue) {
                    "id" -> CodingKeys.id
                    "recipientId" -> CodingKeys.recipientId
                    "recipientName" -> CodingKeys.recipientName
                    "senderName" -> CodingKeys.senderName
                    "musterName" -> CodingKeys.musterName
                    "musterId" -> CodingKeys.musterId
                    else -> null
                }
            }
        }
    }

    // MARK: - Hashable Conformance

    /// Determines equality between two `MusterInvite` instances based on their properties.
    ///
    /// - Parameters:
    ///   - lhs: The left-hand side `MusterInvite` instance.
    ///   - rhs: The right-hand side `MusterInvite` instance.
    /// - Returns: `true` if all properties are equal; otherwise, `false`.
    override fun equals(other: Any?): Boolean {
        if (other !is MusterInvite) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.id == rhs.id && lhs.recipientId == rhs.recipientId && lhs.recipientName == rhs.recipientName && lhs.senderName == rhs.senderName && lhs.musterName == rhs.musterName && lhs.musterId == rhs.musterId
    }

    /// Generates a hash value for the `MusterInvite` instance by combining its properties.
    ///
    /// - Parameter hasher: The hasher to use when combining the components of this instance.
    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(id)
        hasher.value.combine(recipientId)
        hasher.value.combine(recipientName)
        hasher.value.combine(senderName)
        hasher.value.combine(musterName)
        hasher.value.combine(musterId)
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as MusterInvite
        this.id = copy.id
        this.recipientId = copy.recipientId
        this.recipientName = copy.recipientName
        this.senderName = copy.senderName
        this.musterName = copy.musterName
        this.musterId = copy.musterId
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = MusterInvite(this as MutableStruct)

    override fun encode(to: Encoder) {
        val container = to.container(keyedBy = CodingKeys::class)
        container.encode(id, forKey = CodingKeys.id)
        container.encode(recipientId, forKey = CodingKeys.recipientId)
        container.encode(recipientName, forKey = CodingKeys.recipientName)
        container.encode(senderName, forKey = CodingKeys.senderName)
        container.encode(musterName, forKey = CodingKeys.musterName)
        container.encode(musterId, forKey = CodingKeys.musterId)
    }

    constructor(from: Decoder) {
        val container = from.container(keyedBy = CodingKeys::class)
        this.id = container.decode(String::class, forKey = CodingKeys.id)
        this.recipientId = container.decode(String::class, forKey = CodingKeys.recipientId)
        this.recipientName = container.decode(String::class, forKey = CodingKeys.recipientName)
        this.senderName = container.decode(String::class, forKey = CodingKeys.senderName)
        this.musterName = container.decode(String::class, forKey = CodingKeys.musterName)
        this.musterId = container.decode(String::class, forKey = CodingKeys.musterId)
    }

    companion object: DecodableCompanion<MusterInvite> {
        override fun init(from: Decoder): MusterInvite = MusterInvite(from = from)

        private fun CodingKeys(rawValue: String): MusterInvite.CodingKeys? = CodingKeys.init(rawValue = rawValue)
    }
}
