package stork.model

import skip.lib.*

import skip.foundation.*

sealed class ProfileError: Exception(), Error, LocalizedError {
    class NotFoundCase(val associated0: String): ProfileError() {
    }
    class CreationFailedCase(val associated0: String): ProfileError() {
    }
    class UpdateFailedCase(val associated0: String): ProfileError() {
    }
    class DeletionFailedCase(val associated0: String): ProfileError() {
    }
    class AuthenticationFailedCase(val associated0: String): ProfileError() {
    }
    class PasswordResetFailedCase(val associated0: String): ProfileError() {
    }
    class FetchFailedCase(val associated0: String): ProfileError() {
    }
    class SignOutFailedCase(val associated0: String): ProfileError() {
    }
    class UnknownCase(val associated0: String): ProfileError() {
    }

    override val errorDescription: String?
        get() {
            when (this) {
                is ProfileError.NotFoundCase -> {
                    val message = this.associated0
                    return "Profile Not Found: ${message}"
                }
                is ProfileError.CreationFailedCase -> {
                    val message = this.associated0
                    return "Profile Creation Failed: ${message}"
                }
                is ProfileError.UpdateFailedCase -> {
                    val message = this.associated0
                    return "Profile Update Failed: ${message}"
                }
                is ProfileError.DeletionFailedCase -> {
                    val message = this.associated0
                    return "Profile Deletion Failed: ${message}"
                }
                is ProfileError.AuthenticationFailedCase -> {
                    val message = this.associated0
                    return "Authentication Failed: ${message}"
                }
                is ProfileError.PasswordResetFailedCase -> {
                    val message = this.associated0
                    return "Password Reset Failed: ${message}"
                }
                is ProfileError.FetchFailedCase -> {
                    val message = this.associated0
                    return "Profile fetch failed: ${message}"
                }
                is ProfileError.SignOutFailedCase -> {
                    val message = this.associated0
                    return "Profile sign out failed: ${message}"
                }
                is ProfileError.UnknownCase -> {
                    val message = this.associated0
                    return "Unknown Error: ${message}"
                }
            }
        }

    companion object {
        fun notFound(associated0: String): ProfileError = NotFoundCase(associated0)
        fun creationFailed(associated0: String): ProfileError = CreationFailedCase(associated0)
        fun updateFailed(associated0: String): ProfileError = UpdateFailedCase(associated0)
        fun deletionFailed(associated0: String): ProfileError = DeletionFailedCase(associated0)
        fun authenticationFailed(associated0: String): ProfileError = AuthenticationFailedCase(associated0)
        fun passwordResetFailed(associated0: String): ProfileError = PasswordResetFailedCase(associated0)
        fun fetchFailed(associated0: String): ProfileError = FetchFailedCase(associated0)
        fun signOutFailed(associated0: String): ProfileError = SignOutFailedCase(associated0)
        fun unknown(associated0: String): ProfileError = UnknownCase(associated0)
    }
}
