//
//  FirebaseHospitalDatasource.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.firebase.firestore.*

/// A concrete implementation of the `HospitalRemoteDataSourceInterface` protocol.
/// Handles interactions with Firebase Firestore for hospital data.
open class FirebaseHospitalDatasource: HospitalRemoteDataSourceInterface {

    // MARK: - Properties

    /// Firestore database instance for interacting with Firebase.
    private val db: Firestore

    // MARK: - Initializer

    /// Initializes the data source with a Firestore instance.
    constructor() {
        this.db = Firestore.firestore()
    }

    // MARK: - Public Methods

    /// Creates a new hospital record in Firestore and returns the newly created `Hospital`.
    ///
    /// - Parameter hospital: The `Hospital` object to create.
    /// - Returns: The newly created `Hospital`, updated with the newly generated Firestore `id`.
    /// - Throws: `HospitalError.creationFailed` if creation fails.
    override suspend fun createHospital(hospital: Hospital): Hospital = Async.run l@{
        try {
            val data: Dictionary<String, Any> = dictionaryOf(
                Tuple2("facility_name", hospital.facility_name),
                Tuple2("address", hospital.address),
                Tuple2("citytown", hospital.citytown),
                Tuple2("state", hospital.state),
                Tuple2("zip_code", hospital.zip_code),
                Tuple2("countyparish", hospital.countyparish),
                Tuple2("telephone_number", hospital.telephone_number),
                Tuple2("hospital_type", hospital.hospital_type),
                Tuple2("hospital_ownership", hospital.hospital_ownership),
                Tuple2("emergency_services", hospital.emergency_services),
                Tuple2("meets_criteria_for_birthing_friendly_designation", hospital.meets_criteria_for_birthing_friendly_designation),
                Tuple2("deliveryCount", hospital.deliveryCount),
                Tuple2("babyCount", hospital.babyCount)
            )
            val docRef = db.collection("Hospital").addDocument(data = data)

            // Create a new Hospital that includes the Firestore-generated document ID.
            var newHospital = hospital.sref()
            newHospital.id = docRef.documentID
            return@l newHospital.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw HospitalError.creationFailed("Failed to create hospital: ${error.localizedDescription}")
        }
    }

    /// Updates the hospital stats in Firestore by incrementing `deliveryCount` and `babyCount`.
    ///
    /// - Parameters:
    ///   - hospital: The `Hospital` object whose stats should be updated. Must include a valid Firestore `id`.
    ///   - additionalDeliveryCount: The number by which to increment `deliveryCount`.
    ///   - additionalBabyCount: The number by which to increment `babyCount`.
    /// - Returns: The updated `Hospital` object with local counts incremented.
    /// - Throws: `HospitalError.updateFailed` if the Firestore update operation fails.
    override suspend fun updateHospitalStats(hospital: Hospital, additionalDeliveryCount: Int, additionalBabyCount: Int): Hospital = Async.run l@{
        try {
            // Atomically increment the fields in Firestore
            val docRef = db.collection("Hospital").document(hospital.id)
            docRef.updateData(dictionaryOf(
                Tuple2("deliveryCount", FieldValue.increment(Long(additionalDeliveryCount))),
                Tuple2("babyCount", FieldValue.increment(Long(additionalBabyCount)))
            ))

            // If Firestore didn't throw an error, safely increment local stats
            var updatedHospital = hospital.sref()
            updatedHospital.deliveryCount += additionalDeliveryCount
            updatedHospital.babyCount += additionalBabyCount

            // Return the updated hospital
            return@l updatedHospital.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw HospitalError.updateFailed("Failed to update hospital stats: ${error.localizedDescription}")
        }
    }

    /// Fetches a hospital by its unique ID from Firestore.
    ///
    /// - Parameter id: The Firestore document ID for the hospital.
    /// - Returns: A `Hospital` object if found.
    /// - Throws: `HospitalError.notFound` if the hospital document doesn't exist.
    override suspend fun getHospital(byId: String): Hospital = Async.run l@{
        val id = byId
        try {
            val document = db.collection("Hospital").document(id).getDocument()
            val data_0 = document.data()
            if (data_0 == null) {
                throw HospitalError.notFound("Hospital with ID ${id} not found.")
            }

            // Insert the doc ID into the data so `mapDocumentToHospital` can pick it up
            var docData = data_0.sref()
            docData["id"] = document.documentID

            return@l mapDocumentToHospital(data = docData)
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw HospitalError.notFound("Failed to fetch hospital with ID ${id}: ${error.localizedDescription}")
        }
    }

    /// Fetches hospitals located in a specific city and state.
    ///
    /// - Parameters:
    ///   - city: The city to filter hospitals by.
    ///   - state: The state to filter hospitals by.
    /// - Returns: A list of matching `Hospital` objects.
    /// - Throws: `HospitalError.notFound` if no hospitals are found or Firestore errors.
    override suspend fun listHospitals(city: String, state: String): Array<Hospital> = Async.run l@{
        try {
            // Automatically uppercase both city and state (if your data is stored in uppercase).
            val uppercasedCity = city.uppercased()
            val uppercasedState = state.uppercased()

            val query = db.collection("Hospital")
                .whereField("citytown", isEqualTo = uppercasedCity)
                .whereField("state", isEqualTo = uppercasedState)

            val snapshot = query.getDocuments()

            return@l snapshot.documents.map l@{ document ->
                var data = document.data()
                data["id"] = document.documentID // Ensure 'id' field is set
                return@l mapDocumentToHospital(data = data)
            }
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw HospitalError.notFound("Failed to fetch hospitals in ${city}, ${state}: ${error.localizedDescription}")
        }
    }

    override suspend fun listHospitalsByPartialName(partialName: String?): Array<Hospital> = MainActor.run l@{
        if ((partialName == null) || partialName.isEmpty) {
            throw HospitalError.notFound("Invalid search text.")
        }

        // Normalize user input to uppercase to match Firestore data (assuming your data is stored uppercase).
        val normalizedPartialName = partialName.uppercased()

        try {
            val query = db.collection("Hospital")
                .whereField("facility_name", isGreaterThanOrEqualTo = normalizedPartialName)
                .whereField("facility_name", isLessThan = normalizedPartialName + "\uF8FF")
                .order(by = "facility_name")

            val snapshot = query.getDocuments()

            val hospitals = snapshot.documents.map l@{ document ->
                var data = document.data()
                data["id"] = document.documentID // Ensure 'id' field is set
                return@l mapDocumentToHospital(data = data)
            }

            if (hospitals.isEmpty) {
                throw HospitalError.notFound("No hospitals matching '${partialName}' found.")
            }

            return@l hospitals.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw HospitalError.notFound("Failed to search hospitals by name '${partialName}': ${error.localizedDescription}")
        }
    }

    /// Increments the delivery count for a specific hospital and returns the updated `Hospital`.
    ///
    /// - Parameter id: The hospital's Firestore document ID.
    /// - Returns: The updated `Hospital`.
    /// - Throws: `HospitalError.updateFailed` if increment operation or re-fetch fails.
    open suspend fun incrementDeliveryCount(forHospitalId: String): Hospital = Async.run l@{
        val id = forHospitalId
        try {
            // Atomically increment "deliveryCount" by 1
            db.collection("Hospital").document(id).updateData(dictionaryOf(
                Tuple2("deliveryCount", FieldValue.increment(1L))
            ))

            // Fetch updated hospital
            val doc = db.collection("Hospital").document(id).getDocument()
            val data_1 = doc.data()
            if (data_1 == null) {
                throw HospitalError.notFound("Hospital with ID ${id} not found after increment.")
            }

            var docData = data_1.sref()
            docData["id"] = doc.documentID
            return@l mapDocumentToHospital(data = docData)
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw HospitalError.updateFailed("Failed to increment delivery count for hospital with ID ${id}: ${error.localizedDescription}")
        }
    }

    /// Increments the baby count for a specific hospital and returns the updated `Hospital`.
    ///
    /// - Parameters:
    ///   - babyCount: The number of babies to add.
    ///   - id: The hospital's Firestore document ID.
    /// - Returns: The updated `Hospital`.
    /// - Throws: `HospitalError.updateFailed` if increment operation or re-fetch fails.
    open suspend fun incrementBabyCount(babyCount: Int, forHospitalId: String): Hospital = Async.run l@{
        val id = forHospitalId
        try {
            // Atomically increment "babyCount" by the given value
            db.collection("Hospital").document(id).updateData(dictionaryOf(
                Tuple2("babyCount", FieldValue.increment(Long(babyCount)))
            ))

            // Fetch updated hospital
            val doc = db.collection("Hospital").document(id).getDocument()
            val data_2 = doc.data()
            if (data_2 == null) {
                throw HospitalError.notFound("Hospital with ID ${id} not found after baby count increment.")
            }

            var docData = data_2.sref()
            docData["id"] = doc.documentID
            return@l mapDocumentToHospital(data = docData)
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw HospitalError.updateFailed("Failed to increment baby count for hospital with ID ${id}: ${error.localizedDescription}")
        }
    }

    /// Deletes a hospital from Firestore.
    ///
    /// - Parameter id: The Firestore document ID of the hospital to delete.
    /// - Throws: `HospitalError.deletionFailed` if the delete operation fails.
    override suspend fun deleteHospital(byId: String): Unit = Async.run {
        val id = byId
        try {
            db.collection("Hospital").document(id).delete()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw HospitalError.deletionFailed("Failed to delete hospital with ID ${id}: ${error.localizedDescription}")
        }
    }

    // MARK: - Private Methods

    /// Maps Firestore document data to a `Hospital` object.
    ///
    /// **Important**: Ensure `data["id"]` is set before calling this method, or it will throw an error.
    private fun mapDocumentToHospital(data: Dictionary<String, Any>): Hospital {
        val id_0 = data["id"] as? String
        if (id_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val facility_name_0 = data["facility_name"] as? String
        if (facility_name_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val address_0 = data["address"] as? String
        if (address_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val citytown_0 = data["citytown"] as? String
        if (citytown_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val state_0 = data["state"] as? String
        if (state_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val zip_code_0 = data["zip_code"] as? String
        if (zip_code_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val countyparish_0 = data["countyparish"] as? String
        if (countyparish_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val telephone_number_0 = data["telephone_number"] as? String
        if (telephone_number_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val hospital_type_0 = data["hospital_type"] as? String
        if (hospital_type_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val hospital_ownership_0 = data["hospital_ownership"] as? String
        if (hospital_ownership_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val emergency_services_0 = data["emergency_services"] as? Boolean
        if (emergency_services_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val meets_criteria_for_birthing_friendly_designation_0 = data["meets_criteria_for_birthing_friendly_designation"] as? Boolean
        if (meets_criteria_for_birthing_friendly_designation_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val deliveryCount_0 = data["deliveryCount"] as? Int
        if (deliveryCount_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }
        val babyCount_0 = data["babyCount"] as? Int
        if (babyCount_0 == null) {
            print("mapping failed")
            throw HospitalError.unknown("Failed to map hospital data.")
        }

        return Hospital(id = id_0, facility_name = facility_name_0, address = address_0, citytown = citytown_0, state = state_0, zip_code = zip_code_0, countyparish = countyparish_0, telephone_number = telephone_number_0, hospital_type = hospital_type_0, hospital_ownership = hospital_ownership_0, emergency_services = emergency_services_0, meets_criteria_for_birthing_friendly_designation = meets_criteria_for_birthing_friendly_designation_0, deliveryCount = deliveryCount_0, babyCount = babyCount_0)
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
