//
//  MockHospitalRepository.swift
//
//
//  Created by Nick Molargik on 11/20/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// A mock implementation of the `HospitalRepositoryInterface` protocol for testing purposes.
@Suppress("MUST_BE_INITIALIZED")
open class MockHospitalRepository: HospitalRepositoryInterface {
    // MARK: - Properties

    /// A list of mock hospitals used for in-memory storage.
    private var hospitals: Array<Hospital>
        get() = field.sref({ this.hospitals = it })
        set(newValue) {
            field = newValue.sref()
        }

    // MARK: - Initializer

    /// Initializes the mock repository with optional sample data.
    ///
    /// - Parameter hospitals: An array of `Hospital` objects to initialize the repository with.
    ///   Defaults to a predefined set of mock hospitals.
    constructor(hospitals: Array<Hospital> = arrayOf()) {
        this.hospitals = if (hospitals.isEmpty) Companion.generateMockHospitals() else hospitals
    }

    // MARK: - Create

    /// Creates a new hospital record.
    ///
    /// - Parameter name: The name of the new `Hospital`.
    /// - Returns: The newly created `Hospital`, including its generated ID.
    /// - Throws: `HospitalError.creationFailed` if a hospital with the same ID already exists.
    override suspend fun createHospital(name: String): Hospital = Async.run l@{
        val hospital = Hospital(id = UUID().uuidString, facility_name = name, address = "", citytown = "", state = "", zip_code = "", countyparish = "", telephone_number = "", hospital_type = "", hospital_ownership = "", emergency_services = false, meets_criteria_for_birthing_friendly_designation = false, deliveryCount = 0, babyCount = 0)
        if (hospitals.contains(where = { it -> it.id == hospital.id })) {
            throw HospitalError.creationFailed("Hospital with ID ${hospital.id} already exists.")
        }
        hospitals.append(hospital)
        return@l hospital.sref()
    }

    // MARK: - Update Stats

    /// Updates hospital statistics by incrementing its delivery and baby counts.
    ///
    /// - Parameters:
    ///   - hospital: The existing `Hospital` to update.
    ///   - additionalDeliveryCount: The number by which to increment the delivery count.
    ///   - additionalBabyCount: The number by which to increment the baby count.
    /// - Returns: The updated `Hospital` after incrementing counts.
    /// - Throws: `HospitalError.notFound` if the hospital does not exist.
    override suspend fun updateHospitalStats(hospital: Hospital, additionalDeliveryCount: Int, additionalBabyCount: Int): Hospital = Async.run l@{
        val index_0 = hospitals.firstIndex(where = { it -> it.id == hospital.id })
        if (index_0 == null) {
            throw HospitalError.notFound("Hospital with ID ${hospital.id} not found.")
        }
        var updatedHospital = hospitals[index_0].sref()
        updatedHospital.deliveryCount += additionalDeliveryCount
        updatedHospital.babyCount += additionalBabyCount
        hospitals[index_0] = updatedHospital.sref()

        return@l updatedHospital.sref()
    }

    // MARK: - Fetch

    /// Fetches a single hospital by its unique ID.
    ///
    /// - Parameter id: The unique ID of the hospital.
    /// - Returns: A `Hospital` object matching the ID.
    /// - Throws: `HospitalError.notFound` if no hospital with the specified ID exists.
    override suspend fun getHospital(byId: String): Hospital = Async.run l@{
        val id = byId
        val hospital_0 = hospitals.first(where = { it -> it.id == id })
        if (hospital_0 == null) {
            throw HospitalError.notFound("Hospital with ID ${id} not found.")
        }
        return@l hospital_0.sref()
    }

    // MARK: - List / Search

    /// Lists hospitals based on an optional filter for hospital name.
    ///
    /// - Parameter partialName: An optional substring to match against hospital names.
    /// - Returns: An array of `Hospital` objects matching the name filter.
    ///            If `partialName` is `nil`, returns all hospitals.
    override suspend fun listHospitalsByPartialName(partialName: String?): Array<Hospital> = Async.run l@{
        val name_0 = partialName?.lowercased()
        if ((name_0 == null) || name_0.isEmpty) {
            return@l hospitals.sref()
        }
        return@l hospitals.filter { it -> it.facility_name.lowercased().contains(name_0) }
    }

    /// Lists hospitals filtered by city and state.
    ///
    /// - Parameters:
    ///   - city: The city to filter hospitals by.
    ///   - state: The state to filter hospitals by.
    /// - Returns: An array of `Hospital` objects matching the specified city and state.
    /// - Throws: `HospitalError.notFound` if no hospitals are found in the specified city and state.
    override suspend fun getHospitals(byCity: String, andState: String): Array<Hospital> = Async.run l@{
        val city = byCity
        val state = andState
        val filteredHospitals = hospitals.filter { it -> it.citytown.equals(city, ignoreCase = true) && it.state.equals(state, ignoreCase = true) }
        if (filteredHospitals.isEmpty) {
            throw HospitalError.notFound("No hospitals found in ${city}, ${state}.")
        }
        return@l filteredHospitals.sref()
    }

    /// Searches for hospitals by a partial name match.
    ///
    /// - Parameter partialName: The partial string to match against hospital names.
    /// - Returns: A list of `Hospital` objects with names matching the partial string.
    /// - Throws: `HospitalError.notFound` if no hospitals are found.
    override suspend fun searchHospitals(byPartialName: String): Array<Hospital> = Async.run l@{
        val partialName = byPartialName
        val filteredHospitals = hospitals.filter { it -> it.facility_name.contains(partialName, ignoreCase = true) }
        if (filteredHospitals.isEmpty) {
            throw HospitalError.notFound("No hospitals found matching the name ${partialName}.")
        }
        return@l filteredHospitals.sref()
    }

    // MARK: - Delete

    /// Deletes an existing hospital record.
    ///
    /// - Parameter hospital: The `Hospital` object to delete.
    /// - Throws: `HospitalError.deletionFailed` if the hospital does not exist.
    override suspend fun deleteHospital(hospital: Hospital): Unit = Async.run {
        val index_1 = hospitals.firstIndex(where = { it -> it.id == hospital.id })
        if (index_1 == null) {
            throw HospitalError.deletionFailed("Failed to delete hospital with ID ${hospital.id}.")
        }
        hospitals.remove(at = index_1)
    }

    companion object: CompanionClass() {

        // MARK: - Mock Data Generator

        /// Generates a set of predefined mock hospitals.
        ///
        /// - Returns: An array of `Hospital` objects representing mock data.
        private fun generateMockHospitals(): Array<Hospital> = arrayOf(
            Hospital(id = UUID().uuidString, facility_name = "Parkview Medical Center", address = "123 Health Ave", citytown = "Fort Wayne", state = "IN", zip_code = "46805", countyparish = "Allen", telephone_number = "123-456-7890", hospital_type = "Acute Care", hospital_ownership = "Private", emergency_services = true, meets_criteria_for_birthing_friendly_designation = true, deliveryCount = 50, babyCount = 100),
            Hospital(id = UUID().uuidString, facility_name = "Parkway Hospital", address = "456 Wellness St", citytown = "Indianapolis", state = "IN", zip_code = "46220", countyparish = "Marion", telephone_number = "987-654-3210", hospital_type = "Acute Care", hospital_ownership = "Government", emergency_services = true, meets_criteria_for_birthing_friendly_designation = false, deliveryCount = 30, babyCount = 60),
            Hospital(id = UUID().uuidString, facility_name = "Sunnyvale General", address = "789 Sunshine Blvd", citytown = "Fort Wayne", state = "IN", zip_code = "47408", countyparish = "Monroe", telephone_number = "555-123-4567", hospital_type = "General", hospital_ownership = "Private", emergency_services = false, meets_criteria_for_birthing_friendly_designation = true, deliveryCount = 20, babyCount = 40),
            Hospital(id = UUID().uuidString, facility_name = "Community Health Center", address = "321 Care Rd", citytown = "Muncie", state = "IN", zip_code = "47303", countyparish = "Delaware", telephone_number = "444-555-6666", hospital_type = "Community", hospital_ownership = "Non-Profit", emergency_services = true, meets_criteria_for_birthing_friendly_designation = false, deliveryCount = 10, babyCount = 20),
            Hospital(id = UUID().uuidString, facility_name = "Greenfield Regional Hospital", address = "654 Regional Dr", citytown = "Greenfield", state = "IN", zip_code = "46140", countyparish = "Hancock", telephone_number = "333-222-1111", hospital_type = "Regional", hospital_ownership = "Private", emergency_services = true, meets_criteria_for_birthing_friendly_designation = true, deliveryCount = 40, babyCount = 80),
            Hospital(id = UUID().uuidString, facility_name = "Springfield Medical", address = "987 Specialty Ln", citytown = "Evansville", state = "IN", zip_code = "47715", countyparish = "Vanderburgh", telephone_number = "999-888-7777", hospital_type = "Specialty", hospital_ownership = "Private", emergency_services = false, meets_criteria_for_birthing_friendly_designation = true, deliveryCount = 15, babyCount = 30)
        )
    }
    open class CompanionClass {
    }
}
