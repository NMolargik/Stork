//
//  HospitalModel.swift
//
//
//  Created by Nick Molargik on 11/26/24.
//

package stork.model

import skip.lib.*

import skip.foundation.*

@Suppress("MUST_BE_INITIALIZED")
class Hospital: Identifiable<String>, Codable, MutableStruct {
    override var id: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Unique identifier for the hospital
    var facility_name: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Name of the hospital
    var address: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Hospital's street address
    var citytown: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // City where the hospital is located
    var state: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // State abbreviation (e.g., IN)
    var zip_code: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // ZIP code of the hospital
    var countyparish: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // County where the hospital is located
    var telephone_number: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var hospital_type: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Type of hospital (e.g., Acute Care)
    var hospital_ownership: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Ownership type of the hospital
    var emergency_services: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Whether the hospital provides emergency services
    var meets_criteria_for_birthing_friendly_designation: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Whether it meets the birthing-friendly criteria
    var deliveryCount: Int
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Total deliveries recorded at the hospital
    var babyCount: Int
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        } // Total babies born at the hospital

    // Init from dictionary
    internal val dictionary: Dictionary<String, Any>
        get() = dictionaryOf(
            Tuple2("facility_name", facility_name),
            Tuple2("address", address),
            Tuple2("citytown", citytown),
            Tuple2("state", state),
            Tuple2("zip_code", zip_code),
            Tuple2("countyparish", countyparish),
            Tuple2("telephone_number", telephone_number),
            Tuple2("hospital_type", hospital_type),
            Tuple2("hospital_ownership", hospital_ownership),
            Tuple2("emergency_services", emergency_services),
            Tuple2("meets_criteria_for_birthing_friendly_designation", meets_criteria_for_birthing_friendly_designation),
            Tuple2("deliveryCount", deliveryCount),
            Tuple2("babyCount", babyCount)
        )

    internal constructor(from: Dictionary<String, Any>, id: String?) {
        val dictionary = from
        if (id == null) {
            throw NullReturnException()
        }
        val facility_name_0 = dictionary["facility_name"] as? String
        if (facility_name_0 == null) {
            throw NullReturnException()
        }
        val address_0 = dictionary["address"] as? String
        if (address_0 == null) {
            throw NullReturnException()
        }
        val citytown_0 = dictionary["citytown"] as? String
        if (citytown_0 == null) {
            throw NullReturnException()
        }
        val state_0 = dictionary["state"] as? String
        if (state_0 == null) {
            throw NullReturnException()
        }
        val zip_code_0 = dictionary["zip_code"] as? String
        if (zip_code_0 == null) {
            throw NullReturnException()
        }
        val countyparish_0 = dictionary["countyparish"] as? String
        if (countyparish_0 == null) {
            throw NullReturnException()
        }
        val telephone_number_0 = dictionary["telephone_number"] as? String
        if (telephone_number_0 == null) {
            throw NullReturnException()
        }
        val hospital_type_0 = dictionary["hospital_type"] as? String
        if (hospital_type_0 == null) {
            throw NullReturnException()
        }
        val hospital_ownership_0 = dictionary["hospital_ownership"] as? String
        if (hospital_ownership_0 == null) {
            throw NullReturnException()
        }
        val emergency_services_0 = dictionary["emergency_services"] as? Boolean
        if (emergency_services_0 == null) {
            throw NullReturnException()
        }
        val meets_criteria_for_birthing_friendly_designation_0 = dictionary["meets_criteria_for_birthing_friendly_designation"] as? Boolean
        if (meets_criteria_for_birthing_friendly_designation_0 == null) {
            throw NullReturnException()
        }
        val deliveryCount_0 = dictionary["deliveryCount"] as? Int
        if (deliveryCount_0 == null) {
            throw NullReturnException()
        }
        val babyCount_0 = dictionary["babyCount"] as? Int
        if (babyCount_0 == null) {
            throw NullReturnException()
        }

        this.id = id
        this.facility_name = facility_name_0
        this.address = address_0
        this.citytown = citytown_0
        this.state = state_0
        this.zip_code = zip_code_0
        this.countyparish = countyparish_0
        this.telephone_number = telephone_number_0
        this.hospital_type = hospital_type_0
        this.hospital_ownership = hospital_ownership_0
        this.emergency_services = emergency_services_0
        this.meets_criteria_for_birthing_friendly_designation = meets_criteria_for_birthing_friendly_designation_0
        this.deliveryCount = deliveryCount_0
        this.babyCount = babyCount_0
    }

    constructor(id: String, facility_name: String, address: String, citytown: String, state: String, zip_code: String, countyparish: String, telephone_number: String, hospital_type: String, hospital_ownership: String, emergency_services: Boolean, meets_criteria_for_birthing_friendly_designation: Boolean, deliveryCount: Int = 0, babyCount: Int = 0) {
        this.id = id
        this.facility_name = facility_name
        this.address = address
        this.citytown = citytown
        this.state = state
        this.zip_code = zip_code
        this.countyparish = countyparish
        this.telephone_number = telephone_number
        this.hospital_type = hospital_type
        this.hospital_ownership = hospital_ownership
        this.emergency_services = emergency_services
        this.meets_criteria_for_birthing_friendly_designation = meets_criteria_for_birthing_friendly_designation
        this.deliveryCount = deliveryCount
        this.babyCount = babyCount
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as Hospital
        this.id = copy.id
        this.facility_name = copy.facility_name
        this.address = copy.address
        this.citytown = copy.citytown
        this.state = copy.state
        this.zip_code = copy.zip_code
        this.countyparish = copy.countyparish
        this.telephone_number = copy.telephone_number
        this.hospital_type = copy.hospital_type
        this.hospital_ownership = copy.hospital_ownership
        this.emergency_services = copy.emergency_services
        this.meets_criteria_for_birthing_friendly_designation = copy.meets_criteria_for_birthing_friendly_designation
        this.deliveryCount = copy.deliveryCount
        this.babyCount = copy.babyCount
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Hospital(this as MutableStruct)

    override fun equals(other: Any?): Boolean {
        if (other !is Hospital) return false
        return id == other.id && facility_name == other.facility_name && address == other.address && citytown == other.citytown && state == other.state && zip_code == other.zip_code && countyparish == other.countyparish && telephone_number == other.telephone_number && hospital_type == other.hospital_type && hospital_ownership == other.hospital_ownership && emergency_services == other.emergency_services && meets_criteria_for_birthing_friendly_designation == other.meets_criteria_for_birthing_friendly_designation && deliveryCount == other.deliveryCount && babyCount == other.babyCount
    }

    override fun hashCode(): Int {
        var result = 1
        result = Hasher.combine(result, id)
        result = Hasher.combine(result, facility_name)
        result = Hasher.combine(result, address)
        result = Hasher.combine(result, citytown)
        result = Hasher.combine(result, state)
        result = Hasher.combine(result, zip_code)
        result = Hasher.combine(result, countyparish)
        result = Hasher.combine(result, telephone_number)
        result = Hasher.combine(result, hospital_type)
        result = Hasher.combine(result, hospital_ownership)
        result = Hasher.combine(result, emergency_services)
        result = Hasher.combine(result, meets_criteria_for_birthing_friendly_designation)
        result = Hasher.combine(result, deliveryCount)
        result = Hasher.combine(result, babyCount)
        return result
    }

    private enum class CodingKeys(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CodingKey, RawRepresentable<String> {
        id("id"),
        facility_name("facility_name"),
        address("address"),
        citytown("citytown"),
        state("state"),
        zip_code("zip_code"),
        countyparish("countyparish"),
        telephone_number("telephone_number"),
        hospital_type("hospital_type"),
        hospital_ownership("hospital_ownership"),
        emergency_services("emergency_services"),
        meets_criteria_for_birthing_friendly_designation("meets_criteria_for_birthing_friendly_designation"),
        deliveryCount("deliveryCount"),
        babyCount("babyCount");

        companion object {
            fun init(rawValue: String): CodingKeys? {
                return when (rawValue) {
                    "id" -> CodingKeys.id
                    "facility_name" -> CodingKeys.facility_name
                    "address" -> CodingKeys.address
                    "citytown" -> CodingKeys.citytown
                    "state" -> CodingKeys.state
                    "zip_code" -> CodingKeys.zip_code
                    "countyparish" -> CodingKeys.countyparish
                    "telephone_number" -> CodingKeys.telephone_number
                    "hospital_type" -> CodingKeys.hospital_type
                    "hospital_ownership" -> CodingKeys.hospital_ownership
                    "emergency_services" -> CodingKeys.emergency_services
                    "meets_criteria_for_birthing_friendly_designation" -> CodingKeys.meets_criteria_for_birthing_friendly_designation
                    "deliveryCount" -> CodingKeys.deliveryCount
                    "babyCount" -> CodingKeys.babyCount
                    else -> null
                }
            }
        }
    }

    override fun encode(to: Encoder) {
        val container = to.container(keyedBy = CodingKeys::class)
        container.encode(id, forKey = CodingKeys.id)
        container.encode(facility_name, forKey = CodingKeys.facility_name)
        container.encode(address, forKey = CodingKeys.address)
        container.encode(citytown, forKey = CodingKeys.citytown)
        container.encode(state, forKey = CodingKeys.state)
        container.encode(zip_code, forKey = CodingKeys.zip_code)
        container.encode(countyparish, forKey = CodingKeys.countyparish)
        container.encode(telephone_number, forKey = CodingKeys.telephone_number)
        container.encode(hospital_type, forKey = CodingKeys.hospital_type)
        container.encode(hospital_ownership, forKey = CodingKeys.hospital_ownership)
        container.encode(emergency_services, forKey = CodingKeys.emergency_services)
        container.encode(meets_criteria_for_birthing_friendly_designation, forKey = CodingKeys.meets_criteria_for_birthing_friendly_designation)
        container.encode(deliveryCount, forKey = CodingKeys.deliveryCount)
        container.encode(babyCount, forKey = CodingKeys.babyCount)
    }

    constructor(from: Decoder) {
        val container = from.container(keyedBy = CodingKeys::class)
        this.id = container.decode(String::class, forKey = CodingKeys.id)
        this.facility_name = container.decode(String::class, forKey = CodingKeys.facility_name)
        this.address = container.decode(String::class, forKey = CodingKeys.address)
        this.citytown = container.decode(String::class, forKey = CodingKeys.citytown)
        this.state = container.decode(String::class, forKey = CodingKeys.state)
        this.zip_code = container.decode(String::class, forKey = CodingKeys.zip_code)
        this.countyparish = container.decode(String::class, forKey = CodingKeys.countyparish)
        this.telephone_number = container.decode(String::class, forKey = CodingKeys.telephone_number)
        this.hospital_type = container.decode(String::class, forKey = CodingKeys.hospital_type)
        this.hospital_ownership = container.decode(String::class, forKey = CodingKeys.hospital_ownership)
        this.emergency_services = container.decode(Boolean::class, forKey = CodingKeys.emergency_services)
        this.meets_criteria_for_birthing_friendly_designation = container.decode(Boolean::class, forKey = CodingKeys.meets_criteria_for_birthing_friendly_designation)
        this.deliveryCount = container.decode(Int::class, forKey = CodingKeys.deliveryCount)
        this.babyCount = container.decode(Int::class, forKey = CodingKeys.babyCount)
    }

    companion object: DecodableCompanion<Hospital> {
        override fun init(from: Decoder): Hospital = Hospital(from = from)

        private fun CodingKeys(rawValue: String): CodingKeys? = CodingKeys.init(rawValue = rawValue)
    }
}
