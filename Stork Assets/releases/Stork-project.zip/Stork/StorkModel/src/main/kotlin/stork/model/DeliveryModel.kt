//
//  DeliveryModel.swift
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// Represents a delivery event within the Stork application.
@Suppress("MUST_BE_INITIALIZED")
class Delivery: Identifiable<String>, Codable, MutableStruct {

    // MARK: - Properties

    /// Unique identifier for the delivery.
    override var id: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier of the user associated with the delivery.
    var userId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// First name of the user associated with the delivery.
    var userFirstName: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier of the hospital where the delivery took place.
    var hospitalId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Name of the hospital where the delivery took place.
    var hospitalName: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier of the muster associated with the delivery.
    var musterId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Date of the delivery.
    var date: Date
        get() = field.sref({ this.date = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    /// List of babies born during the delivery.
    var babies: Array<Baby>
        get() = field.sref({ this.babies = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    /// Total number of babies born during the delivery.
    var babyCount: Int
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Method of delivery (e.g., vaginal, cesarean).
    var deliveryMethod: DeliveryMethod
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Indicates whether an epidural was used during the delivery.
    var epiduralUsed: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    // MARK: - Computed Properties

    /// Converts the `Delivery` instance into a dictionary format suitable for Firestore storage.
    ///
    /// - Returns: A dictionary representation of the delivery.
    internal val dictionary: Dictionary<String, Any>
        get() {
            return dictionaryOf(
                Tuple2("userId", userId),
                Tuple2("userFirstName", userFirstName),
                Tuple2("hospitalId", hospitalId),
                Tuple2("hospitalName", hospitalName),
                Tuple2("musterId", musterId),
                Tuple2("date", date.timeIntervalSince1970),
                Tuple2("babies", babies.map { it -> it.dictionary }),
                Tuple2("babyCount", babyCount),
                Tuple2("deliveryMethod", deliveryMethod.rawValue),
                Tuple2("epiduralUsed", epiduralUsed)
            )
        }

    // MARK: - Initializers

    /// Initializes a `Delivery` instance from a Firestore data dictionary and an optional ID.
    ///
    /// - Parameters:
    ///   - dictionary: A dictionary containing delivery data fetched from Firestore.
    ///   - id: Optional ID for the delivery. If `nil`, initialization fails.
    constructor(from: Dictionary<String, Any>, id: String?) {
        val dictionary = from
        if (id == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val userId_0 = dictionary["userId"] as? String
        if (userId_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val userFirstName_0 = dictionary["userFirstName"] as? String
        if (userFirstName_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val hospitalId_0 = dictionary["hospitalId"] as? String
        if (hospitalId_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val hospitalName_0 = dictionary["hospitalName"] as? String
        if (hospitalName_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val musterId_0 = dictionary["musterId"] as? String
        if (musterId_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val dateTimestamp_0 = dictionary["date"] as? Double
        if (dateTimestamp_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val babiesData_0 = (dictionary["babies"] as? Array<Dictionary<String, Any>>).sref()
        if (babiesData_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val babyCount_0 = dictionary["babyCount"] as? Int
        if (babyCount_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val deliveryMethodRawValue_0 = dictionary["deliveryMethod"] as? String
        if (deliveryMethodRawValue_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val deliveryMethod_0 = DeliveryMethod(rawValue = deliveryMethodRawValue_0)
        if (deliveryMethod_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val epiduralUsed_0 = dictionary["epiduralUsed"] as? Boolean
        if (epiduralUsed_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }

        this.id = id
        this.userId = userId_0
        this.userFirstName = userFirstName_0
        this.hospitalId = hospitalId_0
        this.hospitalName = hospitalName_0
        this.musterId = musterId_0
        this.date = Date(timeIntervalSince1970 = dateTimestamp_0)
        this.babies = babiesData_0.compactMap { it -> (try { Baby(from = it) } catch (_: NullReturnException) { null }) }
        this.babyCount = babyCount_0
        this.deliveryMethod = deliveryMethod_0
        this.epiduralUsed = epiduralUsed_0
    }

    /// Initializes a `Delivery` instance with explicit parameters.
    ///
    /// - Parameters:
    ///   - id: Unique identifier for the delivery.
    ///   - userId: Identifier of the user associated with the delivery.
    ///   - userFirstName: First name of the user.
    ///   - hospitalId: Identifier of the hospital.
    ///   - hospitalName: Name of the hospital.
    ///   - musterId: Identifier of the muster.
    ///   - date: Date of the delivery.
    ///   - babies: List of babies born during the delivery.
    ///   - babyCount: Total number of babies.
    ///   - deliveryMethod: Method of delivery.
    ///   - epiduralUsed: Indicates if an epidural was used.
    constructor(id: String, userId: String, userFirstName: String, hospitalId: String, hospitalName: String, musterId: String, date: Date, babies: Array<Baby>, babyCount: Int, deliveryMethod: DeliveryMethod, epiduralUsed: Boolean) {
        this.id = id
        this.userId = userId
        this.userFirstName = userFirstName
        this.hospitalId = hospitalId
        this.hospitalName = hospitalName
        this.musterId = musterId
        this.date = date
        this.babies = babies
        this.babyCount = babyCount
        this.deliveryMethod = deliveryMethod
        this.epiduralUsed = epiduralUsed
    }

    /// Initializes a `Delivery` instance with sample data.
    /// This initializer is useful for testing and preview purposes.
    ///
    /// - Parameter sample: A boolean indicating whether to initialize with sample data.
    constructor(sample: Boolean) {
        this.id = UUID().uuidString
        this.userId = UUID().uuidString
        this.userFirstName = "FirstName"
        this.hospitalId = "1234"
        this.hospitalName = "Parkview Regional Medical Center"
        this.musterId = "5678"
        this.date = Date()
        this.babies = arrayOf(
            Baby(deliveryId = "12345", nurseCatch = true, sex = Sex.male),
            Baby(deliveryId = "12345", nurseCatch = false, sex = Sex.female),
            Baby(deliveryId = "12345", nurseCatch = false, sex = Sex.loss)
        )
        this.babyCount = 3
        this.deliveryMethod = DeliveryMethod.vaginal
        this.epiduralUsed = true
    }

    // MARK: - Codable Conformance

    /// Specifies the coding keys for encoding and decoding.
    private enum class CodingKeys(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CodingKey, RawRepresentable<String> {
        id("id"),
        userId("userId"),
        userFirstName("userFirstName"),
        hospitalId("hospitalId"),
        hospitalName("hospitalName"),
        musterId("musterId"),
        date("date"),
        babies("babies"),
        babyCount("babyCount"),
        deliveryMethod("deliveryMethod"),
        epiduralUsed("epiduralUsed");

        companion object {
            fun init(rawValue: String): Delivery.CodingKeys? {
                return when (rawValue) {
                    "id" -> CodingKeys.id
                    "userId" -> CodingKeys.userId
                    "userFirstName" -> CodingKeys.userFirstName
                    "hospitalId" -> CodingKeys.hospitalId
                    "hospitalName" -> CodingKeys.hospitalName
                    "musterId" -> CodingKeys.musterId
                    "date" -> CodingKeys.date
                    "babies" -> CodingKeys.babies
                    "babyCount" -> CodingKeys.babyCount
                    "deliveryMethod" -> CodingKeys.deliveryMethod
                    "epiduralUsed" -> CodingKeys.epiduralUsed
                    else -> null
                }
            }
        }
    }

    // MARK: - Hashable Conformance

    /// Determines equality between two `Delivery` instances based on their properties.
    ///
    /// - Parameters:
    ///   - lhs: The left-hand side `Delivery` instance.
    ///   - rhs: The right-hand side `Delivery` instance.
    /// - Returns: `true` if all properties are equal; otherwise, `false`.
    override fun equals(other: Any?): Boolean {
        if (other !is Delivery) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.id == rhs.id && lhs.userId == rhs.userId && lhs.userFirstName == rhs.userFirstName && lhs.hospitalId == rhs.hospitalId && lhs.hospitalName == rhs.hospitalName && lhs.musterId == rhs.musterId && lhs.date == rhs.date && lhs.babies == rhs.babies && lhs.babyCount == rhs.babyCount && lhs.deliveryMethod == rhs.deliveryMethod && lhs.epiduralUsed == rhs.epiduralUsed
    }

    /// Generates a hash value for the `Delivery` instance by combining its properties.
    ///
    /// - Parameter hasher: The hasher to use when combining the components of this instance.
    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(id)
        hasher.value.combine(userId)
        hasher.value.combine(userFirstName)
        hasher.value.combine(hospitalId)
        hasher.value.combine(hospitalName)
        hasher.value.combine(musterId)
        hasher.value.combine(date)
        hasher.value.combine(babies)
        hasher.value.combine(babyCount)
        hasher.value.combine(deliveryMethod)
        hasher.value.combine(epiduralUsed)
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as Delivery
        this.id = copy.id
        this.userId = copy.userId
        this.userFirstName = copy.userFirstName
        this.hospitalId = copy.hospitalId
        this.hospitalName = copy.hospitalName
        this.musterId = copy.musterId
        this.date = copy.date
        this.babies = copy.babies
        this.babyCount = copy.babyCount
        this.deliveryMethod = copy.deliveryMethod
        this.epiduralUsed = copy.epiduralUsed
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Delivery(this as MutableStruct)

    override fun encode(to: Encoder) {
        val container = to.container(keyedBy = CodingKeys::class)
        container.encode(id, forKey = CodingKeys.id)
        container.encode(userId, forKey = CodingKeys.userId)
        container.encode(userFirstName, forKey = CodingKeys.userFirstName)
        container.encode(hospitalId, forKey = CodingKeys.hospitalId)
        container.encode(hospitalName, forKey = CodingKeys.hospitalName)
        container.encode(musterId, forKey = CodingKeys.musterId)
        container.encode(date, forKey = CodingKeys.date)
        container.encode(babies, forKey = CodingKeys.babies)
        container.encode(babyCount, forKey = CodingKeys.babyCount)
        container.encode(deliveryMethod, forKey = CodingKeys.deliveryMethod)
        container.encode(epiduralUsed, forKey = CodingKeys.epiduralUsed)
    }

    constructor(from: Decoder) {
        val container = from.container(keyedBy = CodingKeys::class)
        this.id = container.decode(String::class, forKey = CodingKeys.id)
        this.userId = container.decode(String::class, forKey = CodingKeys.userId)
        this.userFirstName = container.decode(String::class, forKey = CodingKeys.userFirstName)
        this.hospitalId = container.decode(String::class, forKey = CodingKeys.hospitalId)
        this.hospitalName = container.decode(String::class, forKey = CodingKeys.hospitalName)
        this.musterId = container.decode(String::class, forKey = CodingKeys.musterId)
        this.date = container.decode(Date::class, forKey = CodingKeys.date)
        this.babies = container.decode(Array::class, elementType = Baby::class, forKey = CodingKeys.babies)
        this.babyCount = container.decode(Int::class, forKey = CodingKeys.babyCount)
        this.deliveryMethod = container.decode(DeliveryMethod::class, forKey = CodingKeys.deliveryMethod)
        this.epiduralUsed = container.decode(Boolean::class, forKey = CodingKeys.epiduralUsed)
    }

    companion object: DecodableCompanion<Delivery> {
        override fun init(from: Decoder): Delivery = Delivery(from = from)

        private fun CodingKeys(rawValue: String): Delivery.CodingKeys? = CodingKeys.init(rawValue = rawValue)
    }
}
