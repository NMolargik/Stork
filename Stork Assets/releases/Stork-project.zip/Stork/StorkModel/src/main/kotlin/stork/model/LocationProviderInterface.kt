//
//  LocationProviderInterface.swift
//
//
//  Created by Nick Molargik on 11/30/24.
//

package stork.model

import skip.lib.*

import skip.foundation.*

interface LocationProviderInterface {
    /// Fetches the current latitude and longitude.
    suspend fun fetchCurrentLocation(): Tuple2<Double, Double>

    /// Fetches the city and state for a given location.
    suspend fun fetchCityAndState(from: Location): Tuple2<String?, String?>

    suspend fun geocodeAddress(address: String): Tuple2<Double, Double>
}
