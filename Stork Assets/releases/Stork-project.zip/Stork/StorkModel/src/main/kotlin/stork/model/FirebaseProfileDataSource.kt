//
//  FirebaseProfileDataSource.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.ui.*

import skip.firebase.storage.*
import skip.firebase.core.*
import skip.firebase.firestore.*
import skip.firebase.auth.*
import skip.model.*

/// A data source responsible for interacting with the Firebase Firestore database to manage profile records.
open class FirebaseProfileDataSource: ProfileRemoteDataSourceInterface {

    // MARK: - Dependencies

    /// The Firestore database instance.
    private val db: Firestore

    /// The Firebase Auth instance
    private val auth: Auth

    /// The Firebase Storage instance
    private val storage: Storage

    // MARK: - Initialization

    /// Initializes the FirebaseProfileDataSource with Firestore, Auth, and Storage instances.
    constructor() {
        this.db = Firestore.firestore()
        this.auth = Auth.auth()
        this.storage = Storage.storage()
    }

    // MARK: - Create a New Profile

    /// Creates a new profile record in Firestore and returns the newly created `Profile`.
    ///
    /// - Parameter profile: The `Profile` object to create.
    /// - Returns: The newly created `Profile` (including the `id` if needed).
    /// - Throws:
    ///   - `ProfileError.firebaseError`: If an error occurs while creating the profile.
    override suspend fun createProfile(profile: Profile): Profile = Async.run l@{
        try {
            // Convert to dictionary
            val data = profile.dictionary.sref()
            // Write to Firestore at document ID = profile.id (if you're setting that manually).
            db.collection("Profile").document(profile.id).setData(data)

            // Return the same profile (or optionally re-fetch if needed).
            return@l profile.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.creationFailed("Failed to create profile: ${error.localizedDescription}")
        }
    }

    // MARK: - Update an Existing Profile

    /// Updates an existing profile record in Firestore and returns the updated `Profile`.
    ///
    /// - Parameter profile: The `Profile` object containing updated data.
    /// - Returns: The updated `Profile`.
    /// - Throws:
    ///   - `ProfileError.firebaseError`: If an error occurs while updating the profile.
    ///   - `ProfileError.notFound`: If the profile does not exist.
    override suspend fun updateProfile(profile: Profile): Profile = Async.run l@{
        try {
            val data = profile.dictionary.sref()
            db.collection("Profile").document(profile.id).updateData(data)

            return@l profile.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.updateFailed("Failed to update profile: ${error.localizedDescription}")
        }
    }

    // MARK: - Retrieve a Single Profile by ID

    /// Fetches a single profile by its unique ID, returning a non-optional `Profile` or throwing if not found.
    ///
    /// - Parameter id: The unique ID of the profile to fetch.
    /// - Returns: A `Profile` object representing the profile with the specified ID.
    /// - Throws:
    ///   - `ProfileError.notFound`: If no profile with the specified ID is found.
    ///   - `ProfileError.firebaseError`: If an error occurs while fetching the profile.
    override suspend fun getProfile(byId: String): Profile = Async.run l@{
        val id = byId
        try {
            val document = db.collection("Profile").document(id).getDocument()
            val data_0 = document.data()
            if (data_0 == null) {
                throw ProfileError.notFound("Profile with ID ${id} not found.")
            }
            val profile_0 = (try { Profile(from = data_0) } catch (_: NullReturnException) { null })
            if (profile_0 == null) {
                throw ProfileError.notFound("Invalid data for profile with ID ${id}.")
            }
            return@l profile_0.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.fetchFailed("Failed to fetch profile with ID ${id}: ${error.localizedDescription}")
        }
    }

    /// Retrieves the currently authenticated profile, returning a non-optional `Profile` or throwing if not found.
    ///
    /// - Returns: A `Profile` object representing the current authenticated user's profile.
    /// - Throws:
    ///   - `ProfileError.notFound`: If there is no currently logged-in user or their profile doesn't exist.
    ///   - `ProfileError.firebaseError`: If any error occurs while fetching the profile.
    override suspend fun getCurrentProfile(): Profile = Async.run l@{
        try {
            val userId_0 = auth.currentUser?.uid
            if (userId_0 == null) {
                // Optionally sign out if no valid user
                try { auth.signOut() } catch (_: Throwable) { null }
                throw ProfileError.notFound("No profile currently logged in.")
            }

            val document = db.collection("Profile").document(userId_0).getDocument()
            val data_1 = document.data()
            if (data_1 == null) {
                throw ProfileError.notFound("Profile with ID ${userId_0} not found.")
            }
            val profile_1 = (try { Profile(from = data_1) } catch (_: NullReturnException) { null })
            if (profile_1 == null) {
                throw ProfileError.notFound("Invalid data for profile with ID ${userId_0}.")
            }
            return@l profile_1.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.fetchFailed("Failed to retrieve the current profile: ${error.localizedDescription}")
        }
    }

    // MARK: - List Profiles with Filters

    /// Lists profiles based on optional filters.
    ///
    /// - Parameters:
    ///   - id: An optional filter for the profile's `id`.
    ///   - firstName: An optional filter for the profile's first name.
    ///   - lastName: An optional filter for the profile's last name.
    ///   - email: An optional filter for the profile's email address.
    ///   - birthday: An optional filter for the profile's birthday.
    ///   - role: An optional filter for the profile's role.
    ///   - primaryHospital: An optional filter for the profile's primary hospital ID.
    ///   - joinDate: An optional filter for the profile's join date.
    ///   - musterId: An optional filter for the muster ID associated with the profile.
    /// - Returns: An array of `Profile` objects matching the specified filters.
    /// - Throws:
    ///   - `ProfileError.firebaseError`: If an error occurs while fetching profiles.
    override suspend fun listProfiles(id: String?, firstName: String?, lastName: String?, email: String?, birthday: Date?, role: ProfileRole?, primaryHospital: String?, joinDate: Date?, musterId: String?): Array<Profile> = Async.run l@{
        try {
            var query: Query = db.collection("Profile")

            // Apply optional filters
            if (id != null) {
                query = query.whereField("id", isEqualTo = id)
            }
            if (firstName != null) {
                query = query.whereField("firstName", isEqualTo = firstName)
            }
            if (lastName != null) {
                query = query.whereField("lastName", isEqualTo = lastName)
            }
            if (email != null) {
                query = query.whereField("email", isEqualTo = email)
            }
            if (birthday != null) {
                query = query.whereField("birthday", isEqualTo = birthday.timeIntervalSince1970)
            }
            if (role != null) {
                query = query.whereField("role", isEqualTo = role.rawValue)
            }
            if (primaryHospital != null) {
                query = query.whereField("primaryHospital", isEqualTo = primaryHospital)
            }
            if (musterId != null) {
                query = query.whereField("musterId", isEqualTo = musterId)
            }
            if (joinDate != null) {
                query = query.whereField("joinDate", isEqualTo = joinDate.timeIntervalSince1970)
            }

            // Fetch documents
            val snapshot = query.getDocuments()
            return@l snapshot.documents.compactMap { doc -> (try { Profile(from = doc.data()) } catch (_: NullReturnException) { null }) }
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.fetchFailed("Failed to list profiles: ${error.localizedDescription}")
        }
    }

    // MARK: - Delete an Existing Profile

    /// Deletes an existing profile record from Firestore.
    ///
    /// - Parameter profile: The `Profile` object to delete.
    /// - Throws:
    ///   - `ProfileError.firebaseError`: If an error occurs while deleting the profile.
    ///   - `ProfileError.notFound`: If the profile does not exist.
    override suspend fun deleteProfile(profile: Profile): Unit = Async.run {
        try {
            db.collection("Profile").document(profile.id).delete()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.deletionFailed("Failed to delete profile with ID ${profile.id}: ${error.localizedDescription}")
        }
    }

    // MARK: - AUTHENTICATION

    /// Registers a new user account with an email and password, returning the newly registered profile's UID or entire Profile.
    ///
    /// - Parameters:
    ///   - profile: The `Profile` object containing user information, including email.
    ///   - password: The password for the user's account.
    /// - Returns: The newly registered user’s UID (or a `Profile`, if you prefer).
    /// - Throws:
    ///   - `ProfileError.firebaseError`: If the registration process fails in Firebase.
    override suspend fun registerWithEmail(profile: Profile, password: String): Profile = Async.run l@{
        try {
            val result = auth.createUser(withEmail = profile.email, password = password)
            var updatedProfile = profile.sref()
            updatedProfile.id = result.user.uid
            return@l updatedProfile.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.creationFailed("Failed to register with email: ${error.localizedDescription}")
        }
    }

    /// Signs in an existing user with an email and password, returning the associated `Profile`.
    ///
    /// - Parameters:
    ///   - profile: A partial `Profile` object containing the user's email.
    ///   - password: The password for the user's account.
    /// - Returns: A `Profile` object representing the authenticated user.
    /// - Throws:
    ///   - `ProfileError.authenticationFailed`: If authentication or profile retrieval fails.
    override suspend fun signInWithEmail(profile: Profile, password: String): Profile = Async.run l@{
        try {
            val result = auth.signIn(withEmail = profile.email, password = password)
            val firebaseUser = result.user

            val document = db.collection("Profile").document(firebaseUser.uid).getDocument()
            val data_2 = document.data()
            if (data_2 == null) {
                throw ProfileError.notFound("No profile found for user with ID ${firebaseUser.uid}.")
            }
            val fullProfile_0 = (try { Profile(from = data_2) } catch (_: NullReturnException) { null })
            if (fullProfile_0 == null) {
                throw ProfileError.authenticationFailed("Invalid data for profile with ID ${firebaseUser.uid}.")
            }

            return@l fullProfile_0.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.authenticationFailed("Failed to sign in with email: ${error.localizedDescription}")
        }
    }

    //    /// Re-authenticates the currently logged-in user with the given password.
    //    /// - Throws:
    //    ///   - `ProfileError.authenticationFailed` if re-auth fails.
    //    public func reauthenticateUser(password: String) async throws {
    //        guard let user = auth.currentUser else {
    //            throw ProfileError.notFound("No current user found. Cannot re-authenticate.")
    //        }
    //        guard let email = user.email else {
    //            throw ProfileError.notFound("Current user has no email; cannot re-authenticate.")
    //        }
    //        //TODO: Future Skip contribution
    //
    ////        let credential: AuthCredential = EmailAuthProvider.credential(withEmail: email, password: password)
    ////
    ////        do {
    ////            try await user.reauthenticate(with: credential)
    ////        } catch {
    ////            throw ProfileError.authenticationFailed("Failed to re-authenticate user: \(error.localizedDescription)")
    ////        }
    //    }

    /// Signs out the currently authenticated user.
    ///
    /// - Throws:
    ///   - `ProfileError.signOutFailed`: If the sign-out operation fails.
    override suspend fun signOut(): Unit = Async.run {
        try {
            auth.signOut()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.signOutFailed("Error signing out: ${error.localizedDescription}")
        }
    }

    /// Checks whether a user is currently authenticated.
    ///
    /// - Returns: `true` if a user is logged in, `false` otherwise.
    open fun isAuthenticated(): Boolean = auth.currentUser != null

    /// Sends a password reset email to the specified address.
    ///
    /// - Parameter email: The email address to send a password reset link to.
    /// - Throws: `ProfileError.firebaseError` if the reset fails.
    override suspend fun sendPasswordReset(email: String): Unit = Async.run {
        try {
            auth.sendPasswordReset(withEmail = email)
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.passwordResetFailed("Failed to send password reset: ${error.localizedDescription}")
        }
    }

    //    // MARK: - Terminate User (Requires Recent Re-Authentication)
    //
    //    /// Terminates the currently authenticated user's account by re-authenticating with the provided password
    //    /// and then deleting the user from Firebase Auth and Firestore.
    //    ///
    //    /// - Parameter password: The password used to re-authenticate before account termination.
    //    /// - Throws:
    //    ///   - `ProfileError.authenticationFailed`: If re-authentication fails.
    //    ///   - `ProfileError.deletionFailed`: If the account deletion fails.
    //    ///   - `ProfileError.notFound`: If there's no current user.
    //    public func terminateUser(password: String) async throws {
    //        // Make sure we have a current user
    //        guard let user = auth.currentUser else {
    //            throw ProfileError.notFound("No current user found. Cannot terminate.")
    //        }
    //        // Make sure user has a valid email
    //        guard let email = user.email else {
    //            throw ProfileError.notFound("Current user has no email. Cannot re-authenticate.")
    //        }
    //
    //
    //        // 1) Re-authenticate with the provided password
    //
    //        //TODO: Future Skip contribution
    ////        let credential: AuthCredential = EmailAuthProvider.credential(withEmail: email, password: password)
    ////        do {
    ////            // Must succeed to allow deletion
    ////            try await user.reauthenticate(with: credential)
    ////        } catch {
    ////            throw ProfileError.authenticationFailed("Re-authentication failed: \(error.localizedDescription)")
    ////        }
    //
    //
    //        try await user.delete()
    //
    //
    //
    //        // 2) Delete Firebase Auth user
    //        //TODO: awaiting Skip support
    //
    ////        do {
    ////            try await user.delete()
    ////        } catch {
    ////            throw ProfileError.deletionFailed("Failed to delete user from Auth: \(error.localizedDescription)")
    ////        }
    //
    //        // 3) Also delete the user’s profile document in Firestore
    //        do {
    //            try await db.collection("Profile").document(user.uid).delete()
    //        } catch {
    //            throw ProfileError.deletionFailed("Failed to delete user’s profile document: \(error.localizedDescription)")
    //        }
    //    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
