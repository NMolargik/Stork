//
//  MusterModel.swift
//
//  Created by Nick Molargik on 11/26/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// Represents a muster within the Stork application.
/// A muster is a group that organizes profiles (users) associated with a primary hospital.
@Suppress("MUST_BE_INITIALIZED")
class Muster: Identifiable<String>, Codable, MutableStruct {

    // MARK: - Properties

    /// Unique identifier for the muster.
    override var id: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// List of profile IDs associated with the muster.
    var profileIds: Array<String>
        get() = field.sref({ this.profileIds = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier for the primary hospital associated with the muster.
    var primaryHospitalId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// List of administrator profile IDs within the muster.
    var administratorProfileIds: Array<String>
        get() = field.sref({ this.administratorProfileIds = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    /// Name of the muster.
    var name: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Converts the muster data into a dictionary format, suitable for Firestore or similar databases.
    internal val dictionary: Dictionary<String, Any>
        get() = dictionaryOf(
            Tuple2("profileIds", profileIds),
            Tuple2("primaryHospitalId", primaryHospitalId),
            Tuple2("administratorProfileIds", administratorProfileIds),
            Tuple2("name", name)
        )

    // MARK: - Initializers

    /// Initializes a `Muster` instance from a dictionary and an optional ID.
    ///
    /// - Parameters:
    ///   - dictionary: A dictionary containing muster data.
    ///   - id: Optional ID for the muster. If `nil`, initialization fails.
    constructor(from: Dictionary<String, Any>, id: String?) {
        val dictionary = from
        if (id == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val profileIds_0 = (dictionary["profileIds"] as? Array<String>).sref()
        if (profileIds_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val primaryHospitalId_0 = dictionary["primaryHospitalId"] as? String
        if (primaryHospitalId_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val administratorProfileIds_0 = (dictionary["administratorProfileIds"] as? Array<String>).sref()
        if (administratorProfileIds_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }
        val name_0 = dictionary["name"] as? String
        if (name_0 == null) {
            print("Initialization failed: Missing or invalid required fields.")
            throw NullReturnException()
        }

        this.id = id
        this.profileIds = profileIds_0
        this.primaryHospitalId = primaryHospitalId_0
        this.administratorProfileIds = administratorProfileIds_0
        this.name = name_0
    }

    /// Initializes a `Muster` instance with explicit parameters.
    ///
    /// - Parameters:
    ///   - id: Unique identifier for the muster.
    ///   - profileIds: List of profile IDs associated with the muster.
    ///   - primaryHospitalId: Identifier for the primary hospital.
    ///   - administratorProfileIds: List of administrator profile IDs.
    ///   - name: Name of the muster.
    constructor(id: String, profileIds: Array<String>, primaryHospitalId: String, administratorProfileIds: Array<String>, name: String) {
        this.id = id
        this.profileIds = profileIds
        this.primaryHospitalId = primaryHospitalId
        this.administratorProfileIds = administratorProfileIds
        this.name = name
    }

    // MARK: - Default Initializer

    /// Initializes a `Muster` instance with default values.
    /// This initializer can be useful for creating placeholder or testing instances.
    constructor() {
        this.id = UUID().uuidString
        this.profileIds = arrayOf()
        this.primaryHospitalId = ""
        this.administratorProfileIds = arrayOf()
        this.name = "New Muster"
    }

    // MARK: - Codable Conformance

    /// Specifies the coding keys for encoding and decoding.
    private enum class CodingKeys(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CodingKey, RawRepresentable<String> {
        id("id"),
        profileIds("profileIds"),
        primaryHospitalId("primaryHospitalId"),
        administratorProfileIds("administratorProfileIds"),
        name_("name");

        companion object {
            fun init(rawValue: String): Muster.CodingKeys? {
                return when (rawValue) {
                    "id" -> CodingKeys.id
                    "profileIds" -> CodingKeys.profileIds
                    "primaryHospitalId" -> CodingKeys.primaryHospitalId
                    "administratorProfileIds" -> CodingKeys.administratorProfileIds
                    "name" -> CodingKeys.name_
                    else -> null
                }
            }
        }
    }

    // MARK: - Hashable Conformance

    /// Determines equality between two `Muster` instances based on their properties.
    ///
    /// - Parameters:
    ///   - lhs: The left-hand side `Muster` instance.
    ///   - rhs: The right-hand side `Muster` instance.
    /// - Returns: `true` if all properties are equal; otherwise, `false`.
    override fun equals(other: Any?): Boolean {
        if (other !is Muster) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.id == rhs.id && lhs.profileIds == rhs.profileIds && lhs.primaryHospitalId == rhs.primaryHospitalId && lhs.administratorProfileIds == rhs.administratorProfileIds && lhs.name == rhs.name
    }

    /// Generates a hash value for the `Muster` instance by combining its properties.
    ///
    /// - Parameter hasher: The hasher to use when combining the components of this instance.
    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(id)
        hasher.value.combine(profileIds)
        hasher.value.combine(primaryHospitalId)
        hasher.value.combine(administratorProfileIds)
        hasher.value.combine(name)
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as Muster
        this.id = copy.id
        this.profileIds = copy.profileIds
        this.primaryHospitalId = copy.primaryHospitalId
        this.administratorProfileIds = copy.administratorProfileIds
        this.name = copy.name
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Muster(this as MutableStruct)

    override fun encode(to: Encoder) {
        val container = to.container(keyedBy = CodingKeys::class)
        container.encode(id, forKey = CodingKeys.id)
        container.encode(profileIds, forKey = CodingKeys.profileIds)
        container.encode(primaryHospitalId, forKey = CodingKeys.primaryHospitalId)
        container.encode(administratorProfileIds, forKey = CodingKeys.administratorProfileIds)
        container.encode(name, forKey = CodingKeys.name_)
    }

    constructor(from: Decoder) {
        val container = from.container(keyedBy = CodingKeys::class)
        this.id = container.decode(String::class, forKey = CodingKeys.id)
        this.profileIds = container.decode(Array::class, elementType = String::class, forKey = CodingKeys.profileIds)
        this.primaryHospitalId = container.decode(String::class, forKey = CodingKeys.primaryHospitalId)
        this.administratorProfileIds = container.decode(Array::class, elementType = String::class, forKey = CodingKeys.administratorProfileIds)
        this.name = container.decode(String::class, forKey = CodingKeys.name_)
    }

    companion object: DecodableCompanion<Muster> {
        override fun init(from: Decoder): Muster = Muster(from = from)

        private fun CodingKeys(rawValue: String): Muster.CodingKeys? = CodingKeys.init(rawValue = rawValue)
    }
}
