//
//  DeliveryRemoteDataSourceInterface.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// A protocol defining the interface for remote data source interactions related to deliveries.
interface DeliveryRemoteDataSourceInterface {
    /// Creates a new delivery record and returns the newly created `Delivery`.
    ///
    /// - Parameter delivery: The `Delivery` object to create.
    /// - Returns: The newly created `Delivery`.
    /// - Throws: `DeliveryError` if the creation fails.
    suspend fun createDelivery(delivery: Delivery): Delivery

    /// Updates an existing delivery record and returns the updated `Delivery`.
    ///
    /// - Parameter delivery: The `Delivery` object containing the updated data.
    /// - Returns: The updated `Delivery`.
    /// - Throws: `DeliveryError` if the update fails or the delivery does not exist.
    suspend fun updateDelivery(delivery: Delivery): Delivery

    /// Retrieves a single delivery by its unique ID.
    ///
    /// - Parameter id: The unique ID of the delivery to fetch.
    /// - Returns: A `Delivery` object representing the delivery with the specified ID.
    /// - Throws: `DeliveryError` if the delivery cannot be found or another error occurs.
    suspend fun getDelivery(byId: String): Delivery

    /// Lists deliveries based on optional filters.
    ///
    /// - Parameters:
    ///   - userId: An optional filter for id of the user associated with the delivery.
    ///   - userFirstName: An optional filter for the first name of the user associated with the delivery.
    ///   - hospitalId: An optional filter for the hospital ID associated with the delivery. If nil, this filter is ignored.
    ///   - hospitalName: An optional filter for the hospital name. If nil, this filter is ignored.
    ///   - musterId: An optional filter for the muster ID associated with the delivery. If nil, this filter is ignored.
    ///   - date: An optional filter for the delivery date. If nil, this filter is ignored.
    ///   - babyCount: An optional filter for the number of babies in the delivery. If nil, this filter is ignored.
    ///   - deliveryMethod: An optional filter for the delivery method (e.g., vaginal, c-section). If nil, this filter is ignored.
    ///   - epiduralUsed: An optional filter for whether an epidural was used. If nil, this filter is ignored.
    /// - Returns: An array of `Delivery` objects matching the specified filters.
    /// - Throws: `DeliveryError` if the operation fails or no deliveries are found.
    suspend fun listDeliveries(userId: String?, userFirstName: String?, hospitalId: String?, hospitalName: String?, musterId: String?, date: Date?, babyCount: Int?, deliveryMethod: DeliveryMethod?, epiduralUsed: Boolean?): Array<Delivery>

    /// Deletes an existing delivery record.
    ///
    /// - Parameter delivery: The `Delivery` object to delete.
    /// - Throws: `DeliveryError` if the deletion fails or the delivery does not exist.
    suspend fun deleteDelivery(delivery: Delivery): Unit
}
