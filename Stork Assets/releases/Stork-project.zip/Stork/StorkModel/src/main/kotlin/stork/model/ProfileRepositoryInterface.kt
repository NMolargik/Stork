//
//  ProfileRepositoryInterface.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.ui.*
import skip.model.*

/// A protocol defining the repository interface for managing Profile entities.
///
/// This protocol acts as an abstraction layer between the domain and data layers,
/// allowing the application to interact with profile-related data sources consistently.
interface ProfileRepositoryInterface {

    // MARK: - Create & Update

    /// Creates a new profile and returns the newly created `Profile`.
    ///
    /// - Parameter profile: The `Profile` object to create.
    /// - Returns: The newly created `Profile`, including its assigned ID if generated on the server.
    /// - Throws:
    ///   - `ProfileError.creationFailed`: If the creation fails.
    ///   - `ProfileError`: For other errors during the creation operation.
    suspend fun createProfile(profile: Profile): Profile

    /// Updates an existing profile and returns the updated `Profile`.
    ///
    /// - Parameter profile: The `Profile` object containing updated data.
    /// - Returns: The updated `Profile` (potentially reflecting server-side changes).
    /// - Throws:
    ///   - `ProfileError.updateFailed`: If the update fails.
    ///   - `ProfileError.notFound`: If the profile does not exist.
    ///   - `ProfileError`: For other errors during the update operation.
    suspend fun updateProfile(profile: Profile): Profile

    // MARK: - Fetching Profiles

    /// Fetches a single profile by its unique ID.
    ///
    /// - Parameter id: The unique identifier of the profile to fetch.
    /// - Returns: A `Profile` object representing the fetched profile.
    /// - Throws:
    ///   - `ProfileError.notFound`: If the profile cannot be found.
    ///   - `ProfileError`: If another error occurs during the fetch operation.
    suspend fun getProfile(byId: String): Profile

    /// Fetches the currently authenticated profile from the connected data source.
    ///
    /// - Returns: A `Profile` object representing the current authenticated user.
    /// - Throws:
    ///   - `ProfileError.notFound`: If no valid authenticated user or profile is found.
    ///   - `ProfileError`: For other errors during the fetch operation.
    suspend fun getCurrentProfile(): Profile

    /// Lists profiles based on optional filter criteria.
    ///
    /// - Parameters:
    ///   - id: An optional filter for the profile ID.
    ///   - firstName: An optional filter for the profile's first name.
    ///   - lastName: An optional filter for the profile's last name.
    ///   - email: An optional filter for the profile's email address.
    ///   - birthday: An optional filter for the profile's birthday.
    ///   - role: An optional filter for the profile's role.
    ///   - primaryHospital: An optional filter for the profile's primary hospital ID.
    ///   - joinDate: An optional filter for the profile's join date.
    ///   - musterId: An optional filter for the muster ID associated with the profile.
    /// - Returns: An array of `Profile` objects matching the specified filters.
    /// - Throws: `ProfileError` if the operation fails.
    suspend fun listProfiles(id: String?, firstName: String?, lastName: String?, email: String?, birthday: Date?, role: ProfileRole?, primaryHospital: String?, joinDate: Date?, musterId: String?): Array<Profile>

    // MARK: - Deleting Profiles

    /// Deletes an existing profile.
    ///
    /// - Parameter profile: The `Profile` object to delete.
    /// - Throws:
    ///   - `ProfileError.deletionFailed`: If the deletion fails.
    ///   - `ProfileError.notFound`: If the profile does not exist.
    ///   - `ProfileError`: For other errors during the deletion operation.
    suspend fun deleteProfile(profile: Profile): Unit

    // MARK: - Auth Operations

    /// Registers a new user account with an email and password, returning the newly registered user's ID.
    ///
    /// - Parameters:
    ///   - profile: The `Profile` object containing the user's initial data.
    ///   - password: The password for the new user account.
    /// - Returns: An updated `Profile` object
    /// - Throws:
    ///   - `ProfileError.creationFailed`: If registration fails.
    ///   - `ProfileError`: For other errors during the registration process.
    suspend fun registerWithEmail(profile: Profile, password: String): Profile

    /// Signs in an existing user with an email and password, returning the authenticated `Profile`.
    ///
    /// - Parameters:
    ///   - profile: A partial `Profile` object containing the user's email (e.g., `profile.email`).
    ///   - password: The password for the user's account.
    /// - Returns: A `Profile` object representing the authenticated user.
    /// - Throws:
    ///   - `ProfileError.authenticationFailed`: If the credentials are invalid or sign-in fails.
    ///   - `ProfileError`: For other errors during the sign-in process.
    suspend fun signInWithEmail(profile: Profile, password: String): Profile

    /// Signs out the currently authenticated user.
    ///
    /// - Throws: `ProfileError.signOutFailed` if the sign-out operation fails.
    suspend fun signOut(): Unit

    /// Sends a password reset email to the specified address.
    ///
    /// - Parameter email: The email address for which to send a password reset link.
    /// - Throws: `ProfileError.firebaseError` or `ProfileError.unknown` as appropriate if the reset fails.
    suspend fun sendPasswordReset(email: String): Unit
}
