//
//  BabyModel.swift
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*

import skip.foundation.*

/// Represents a baby born during a delivery within the Stork application.
@Suppress("MUST_BE_INITIALIZED")
class Baby: Identifiable<String>, Codable, MutableStruct {

    // MARK: - Properties

    /// Unique identifier for the baby.
    override var id: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier of the delivery associated with the baby.
    var deliveryId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Birthday of the baby.
    var birthday: Date
        get() = field.sref({ this.birthday = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    /// Height of the baby in inches or centimeters, based on app settings.
    var height: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Weight of the baby in ounces or kilograms, based on app settings.
    var weight: Double
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Indicates whether the baby was part of a nurse catch.
    var nurseCatch: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Sex of the baby.
    var sex: Sex
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Converts the `Baby` instance into a dictionary format suitable for Firestore storage.
    ///
    /// - Returns: A dictionary representation of the baby.
    internal val dictionary: Dictionary<String, Any>
        get() = dictionaryOf(
            Tuple2("id", id),
            Tuple2("birthday", birthday.description),
            Tuple2("height", height),
            Tuple2("weight", weight),
            Tuple2("sex", sex.rawValue),
            Tuple2("deliveryId", deliveryId),
            Tuple2("nurseCatch", nurseCatch)
        )

    // MARK: - Initializers

    /// Initializes a `Baby` instance from a Firestore data dictionary.
    ///
    /// - Parameter dictionary: A dictionary containing baby data fetched from Firestore.
    constructor(from: Dictionary<String, Any>) {
        val dictionary = from
        // Debugging: Print the incoming dictionary (consider removing in production)

        val isoFormatter = ISO8601DateFormatter()
        val fallbackFormatter = DateFormatter()
        fallbackFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss Z"
        val id_0 = dictionary["id"] as? String
        if (id_0 == null) {
            print("Initialization failed: Missing or invalid required fields for baby.")
            throw NullReturnException()
        }
        val deliveryId_0 = dictionary["deliveryId"] as? String
        if (deliveryId_0 == null) {
            print("Initialization failed: Missing or invalid required fields for baby.")
            throw NullReturnException()
        }
        val birthdayString_0 = dictionary["birthday"] as? String
        if (birthdayString_0 == null) {
            print("Initialization failed: Missing or invalid required fields for baby.")
            throw NullReturnException()
        }
        val height_0 = dictionary["height"] as? Double
        if (height_0 == null) {
            print("Initialization failed: Missing or invalid required fields for baby.")
            throw NullReturnException()
        }
        val weight_0 = dictionary["weight"] as? Double
        if (weight_0 == null) {
            print("Initialization failed: Missing or invalid required fields for baby.")
            throw NullReturnException()
        }
        val nurseCatch_0 = dictionary["nurseCatch"] as? Boolean
        if (nurseCatch_0 == null) {
            print("Initialization failed: Missing or invalid required fields for baby.")
            throw NullReturnException()
        }
        val sexRawValue_0 = dictionary["sex"] as? String
        if (sexRawValue_0 == null) {
            print("Initialization failed: Missing or invalid required fields for baby.")
            throw NullReturnException()
        }
        val sex_0 = Sex(rawValue = sexRawValue_0)
        if (sex_0 == null) {
            print("Initialization failed: Missing or invalid required fields for baby.")
            throw NullReturnException()
        }
        val birthday_0 = (isoFormatter.date(from = birthdayString_0) ?: fallbackFormatter.date(from = birthdayString_0)).sref()
        if (birthday_0 == null) {
            print("Initialization failed: Invalid birthday format - ${birthdayString_0}")
            throw NullReturnException()
        }

        this.id = id_0
        this.deliveryId = deliveryId_0
        this.birthday = birthday_0
        this.height = height_0
        this.weight = weight_0
        this.nurseCatch = nurseCatch_0
        this.sex = sex_0
    }

    /// Initializes a `Baby` instance with explicit parameters.
    ///
    /// - Parameters:
    ///   - id: Unique identifier for the baby.
    ///   - deliveryId: Identifier of the associated delivery.
    ///   - birthday: Birthday of the baby.
    ///   - height: Height of the baby.
    ///   - weight: Weight of the baby.
    ///   - nurseCatch: Indicates if the baby was part of a nurse catch.
    ///   - sex: Sex of the baby.
    constructor(id: String, deliveryId: String, birthday: Date, height: Double, weight: Double, nurseCatch: Boolean, sex: Sex) {
        this.id = id
        this.deliveryId = deliveryId
        this.birthday = birthday
        this.height = height
        this.weight = weight
        this.nurseCatch = nurseCatch
        this.sex = sex
    }

    constructor(deliveryId: String, nurseCatch: Boolean, sex: Sex, weight: Double, height: Double): this(deliveryId = deliveryId, nurseCatch = nurseCatch, sex = sex) {
        this.weight = weight
        this.height = height
    }

    /// Initializes a `Baby` instance with default values.
    /// Useful for creating placeholder or testing instances.
    ///
    /// - Parameters:
    ///   - deliveryId: Identifier of the associated delivery.
    ///   - nurseCatch: Indicates if the baby was part of a nurse catch.
    ///   - sex: Sex of the baby.
    constructor(deliveryId: String, nurseCatch: Boolean, sex: Sex) {
        this.id = UUID().uuidString
        this.deliveryId = deliveryId
        this.birthday = Date() // Defaults to current date; consider adjusting as needed.
        this.height = 16.0 // Default height; adjust based on unit settings.
        this.weight = 112.0 // Default weight; adjust based on unit settings.
        this.nurseCatch = nurseCatch
        this.sex = sex
    }

    // MARK: - Codable Conformance

    /// Specifies the coding keys for encoding and decoding.
    private enum class CodingKeys(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CodingKey, RawRepresentable<String> {
        id("id"),
        deliveryId("deliveryId"),
        birthday("birthday"),
        height("height"),
        weight("weight"),
        nurseCatch("nurseCatch"),
        sex("sex");

        companion object {
            fun init(rawValue: String): Baby.CodingKeys? {
                return when (rawValue) {
                    "id" -> CodingKeys.id
                    "deliveryId" -> CodingKeys.deliveryId
                    "birthday" -> CodingKeys.birthday
                    "height" -> CodingKeys.height
                    "weight" -> CodingKeys.weight
                    "nurseCatch" -> CodingKeys.nurseCatch
                    "sex" -> CodingKeys.sex
                    else -> null
                }
            }
        }
    }

    // MARK: - Hashable Conformance

    /// Determines equality between two `Baby` instances based on their properties.
    ///
    /// - Parameters:
    ///   - lhs: The left-hand side `Baby` instance.
    ///   - rhs: The right-hand side `Baby` instance.
    /// - Returns: `true` if all properties are equal; otherwise, `false`.
    override fun equals(other: Any?): Boolean {
        if (other !is Baby) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.id == rhs.id && lhs.deliveryId == rhs.deliveryId && lhs.birthday == rhs.birthday && lhs.height == rhs.height && lhs.weight == rhs.weight && lhs.nurseCatch == rhs.nurseCatch && lhs.sex == rhs.sex
    }

    /// Generates a hash value for the `Baby` instance by combining its properties.
    ///
    /// - Parameter hasher: The hasher to use when combining the components of this instance.
    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(id)
        hasher.value.combine(deliveryId)
        hasher.value.combine(birthday)
        hasher.value.combine(height)
        hasher.value.combine(weight)
        hasher.value.combine(nurseCatch)
        hasher.value.combine(sex)
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as Baby
        this.id = copy.id
        this.deliveryId = copy.deliveryId
        this.birthday = copy.birthday
        this.height = copy.height
        this.weight = copy.weight
        this.nurseCatch = copy.nurseCatch
        this.sex = copy.sex
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Baby(this as MutableStruct)

    override fun encode(to: Encoder) {
        val container = to.container(keyedBy = CodingKeys::class)
        container.encode(id, forKey = CodingKeys.id)
        container.encode(deliveryId, forKey = CodingKeys.deliveryId)
        container.encode(birthday, forKey = CodingKeys.birthday)
        container.encode(height, forKey = CodingKeys.height)
        container.encode(weight, forKey = CodingKeys.weight)
        container.encode(nurseCatch, forKey = CodingKeys.nurseCatch)
        container.encode(sex, forKey = CodingKeys.sex)
    }

    constructor(from: Decoder) {
        val container = from.container(keyedBy = CodingKeys::class)
        this.id = container.decode(String::class, forKey = CodingKeys.id)
        this.deliveryId = container.decode(String::class, forKey = CodingKeys.deliveryId)
        this.birthday = container.decode(Date::class, forKey = CodingKeys.birthday)
        this.height = container.decode(Double::class, forKey = CodingKeys.height)
        this.weight = container.decode(Double::class, forKey = CodingKeys.weight)
        this.nurseCatch = container.decode(Boolean::class, forKey = CodingKeys.nurseCatch)
        this.sex = container.decode(Sex::class, forKey = CodingKeys.sex)
    }

    companion object: DecodableCompanion<Baby> {
        override fun init(from: Decoder): Baby = Baby(from = from)

        private fun CodingKeys(rawValue: String): Baby.CodingKeys? = CodingKeys.init(rawValue = rawValue)
    }
}
