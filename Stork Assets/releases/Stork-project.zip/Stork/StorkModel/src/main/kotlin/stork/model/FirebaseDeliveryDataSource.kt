//
//  FirebaseDeliveryDataSource.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.firebase.firestore.*

/// A data source responsible for interacting with the Firebase Firestore database to manage delivery records.
open class FirebaseDeliveryDataSource: DeliveryRemoteDataSourceInterface {
    /// The Firestore database instance.
    private val db: Firestore

    /// Initializes the FirebaseDeliveryDataSource with a Firestore instance.
    constructor() {
        this.db = Firestore.firestore()
    }

    // MARK: - Create a New Delivery Record

    /// Creates a new delivery record in Firestore and returns the newly created `Delivery`.
    ///
    /// - Parameter delivery: The `Delivery` object to create.
    /// - Returns: The newly created `Delivery`, including a newly generated document ID if successful.
    /// - Throws:
    ///   - `DeliveryError.firebaseError`: If an error occurs while creating the delivery.
    override suspend fun createDelivery(delivery: Delivery): Delivery = Async.run l@{
        try {
            // Convert our delivery to a dictionary suitable for Firestore
            val data = delivery.dictionary.sref()

            // Create the new Firestore document
            val docRef = db.collection("Delivery").addDocument(data = data)

            // Build a new Delivery object that includes the Firestore-generated document ID
            var newDelivery = delivery.sref()
            newDelivery.id = docRef.documentID

            return@l newDelivery.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.firebaseError("Failed to create delivery: ${error.localizedDescription}")
        }
    }

    // MARK: - Update an Existing Delivery Record

    /// Updates an existing delivery record in Firestore and returns the updated `Delivery`.
    ///
    /// - Parameter delivery: The `Delivery` object containing updated data.
    /// - Returns: The updated `Delivery`. (If Firestore auto-modifies fields, consider re-fetching the updated document if needed.)
    /// - Throws:
    ///   - `DeliveryError.firebaseError`: If an error occurs while updating the delivery.
    override suspend fun updateDelivery(delivery: Delivery): Delivery = Async.run l@{
        try {
            val data = delivery.dictionary.sref()
            db.collection("Delivery").document(delivery.id).updateData(data)

            return@l delivery.sref()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.firebaseError("Failed to update delivery: ${error.localizedDescription}")
        }
    }

    // MARK: - Retrieve a Single Delivery by ID

    /// Fetches a single delivery by its unique ID, throwing an error if not found.
    ///
    /// - Parameter id: The unique ID of the delivery to fetch.
    /// - Returns: A `Delivery` object representing the delivery with the specified ID.
    /// - Throws:
    ///   - `DeliveryError.notFound`: If no delivery with the specified ID is found.
    ///   - `DeliveryError.firebaseError`: If an error occurs while fetching the delivery.
    override suspend fun getDelivery(byId: String): Delivery = Async.run l@{
        val id = byId
        try {
            val document = db.collection("Delivery").document(id).getDocument()
            val data_0 = document.data()
            if (data_0 == null) {
                throw DeliveryError.notFound(id)
            }
            val delivery_0 = (try { Delivery(from = data_0, id = document.documentID) } catch (_: NullReturnException) { null })
            if (delivery_0 == null) {
                throw DeliveryError.firebaseError("Failed to parse data into Delivery model (ID: ${document.documentID})")
            }
            return@l delivery_0.sref()
        } catch (error: DeliveryError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.firebaseError("Failed to fetch delivery with ID ${id}: ${error.localizedDescription}")
        }
    }

    // MARK: - List Deliveries with Filters

    /// Lists deliveries based on optional filters.
    ///
    /// - Parameters:
    ///   - userId: An optional filter for the ID of the user associated with the delivery.
    ///   - userFirstName: An optional filter for the first name of the user associated with the delivery.
    ///   - hospitalId: An optional filter for the hospital ID associated with the delivery.
    ///   - hospitalName: An optional filter for the hospital name.
    ///   - musterId: An optional filter for the muster ID associated with the delivery.
    ///   - date: An optional filter for the delivery date.
    ///   - babyCount: An optional filter for the number of babies in the delivery.
    ///   - deliveryMethod: An optional filter for the delivery method (e.g., vaginal, c-section).
    ///   - epiduralUsed: An optional filter for whether an epidural was used.
    /// - Returns: An array of `Delivery` objects matching the specified filters.
    /// - Throws:
    ///   - `DeliveryError.firebaseError`: If an error occurs while fetching the deliveries.
    override suspend fun listDeliveries(userId: String?, userFirstName: String?, hospitalId: String?, hospitalName: String?, musterId: String?, date: Date?, babyCount: Int?, deliveryMethod: DeliveryMethod?, epiduralUsed: Boolean?): Array<Delivery> = Async.run l@{
        try {
            var query: Query = db.collection("Delivery")

            if (userId != null) {
                query = query.whereField("userId", isEqualTo = userId)
            }
            if (userFirstName != null) {
                query = query.whereField("userFirstName", isEqualTo = userFirstName)
            }
            if (hospitalId != null) {
                query = query.whereField("hospitalId", isEqualTo = hospitalId)
            }
            if (hospitalName != null) {
                query = query.whereField("hospitalName", isEqualTo = hospitalName)
            }
            if (musterId != null) {
                query = query.whereField("musterId", isEqualTo = musterId)
            }
            if (date != null) {
                // Convert date to a Firestore-friendly format (timestamp in seconds)
                query = query.whereField("date", isEqualTo = date.timeIntervalSince1970)
            }
            if (babyCount != null) {
                query = query.whereField("babyCount", isEqualTo = babyCount)
            }
            if (deliveryMethod != null) {
                query = query.whereField("deliveryMethod", isEqualTo = deliveryMethod.rawValue)
            }
            if (epiduralUsed != null) {
                query = query.whereField("epiduralUsed", isEqualTo = epiduralUsed)
            }

            // Fetch documents that match the query
            val snapshot = query.getDocuments()
            return@l snapshot.documents.compactMap l@{ document ->
                val data = document.data()
                return@l (try { Delivery(from = data, id = document.documentID) } catch (_: NullReturnException) { null })
            }
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.firebaseError("Failed to fetch deliveries: ${error.localizedDescription}")
        }
    }

    // MARK: - Delete an Existing Delivery Record

    /// Deletes an existing delivery record from Firestore.
    ///
    /// - Parameter delivery: The `Delivery` object to delete.
    /// - Throws:
    ///   - `DeliveryError.firebaseError`: If an error occurs while deleting the delivery.
    override suspend fun deleteDelivery(delivery: Delivery): Unit = Async.run {
        try {
            db.collection("Delivery").document(delivery.id).delete()
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw DeliveryError.firebaseError("Failed to delete delivery: ${error.localizedDescription}")
        }
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
