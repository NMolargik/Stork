//
//  Color+fromString.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 12/26/24.
//

package stork.model

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.ui.*
import skip.foundation.*
import skip.model.*

/// Initializes a Color from a string.
/// - Parameter name: The name of the color (e.g., "red", "blue").
/// - Returns: The corresponding Color if the name matches; otherwise, a default color.
fun Color.Companion.from(string: String): Color {
    when (string.lowercased()) {
        "red" -> return Color.red
        "orange" -> return Color.orange
        "yellow" -> return Color.yellow
        "green" -> return Color.green
        "blue" -> return Color.blue
        "purple" -> return Color.purple
        else -> return Color.gray // Default color if no match found
    }
}
