//
//  DeliveryRepositoryInterface.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

interface DeliveryRepositoryInterface {
    /// Creates a new delivery record.
    /// - Parameter delivery: The `Delivery` object to create.
    /// - Returns: The newly created `Delivery` (including its generated ID).
    /// - Throws: `DeliveryError` if the creation fails.
    suspend fun createDelivery(delivery: Delivery): Delivery

    /// Updates an existing delivery record.
    /// - Parameter delivery: The `Delivery` object to update.
    /// - Returns: The updated `Delivery`.
    /// - Throws: `DeliveryError` if the update fails.
    suspend fun updateDelivery(delivery: Delivery): Delivery

    /// Fetches a delivery by its unique ID.
    /// - Parameter id: The unique ID of the delivery.
    /// - Returns: A `Delivery` object for the specified ID.
    /// - Throws: `DeliveryError.notFound` if the delivery cannot be found.
    ///           Other `DeliveryError` if the fetch fails.
    suspend fun getDelivery(byId: String): Delivery

    /// Lists deliveries based on optional filters.
    /// - Parameters:
    ///   - userId: An optional filter for id of the user associated with the delivery
    ///   - userFirstName: An optional filter for first name of the user associated with the delivery
    ///   - hospitalId: An optional hospital ID filter.
    ///   - hospitalName: An optional hospital name filter.
    ///   - musterId: An optional muster ID filter.
    ///   - date: An optional date filter.
    ///   - babyCount: An optional baby count filter.
    ///   - deliveryMethod: An optional delivery method filter.
    ///   - epiduralUsed: An optional epidural usage filter.
    /// - Returns: A list of `Delivery` objects matching the filters.
    /// - Throws: `DeliveryError` if the query fails.
    suspend fun listDeliveries(userId: String?, userFirstName: String?, hospitalId: String?, hospitalName: String?, musterId: String?, date: Date?, babyCount: Int?, deliveryMethod: DeliveryMethod?, epiduralUsed: Boolean?): Array<Delivery>

    /// Deletes an existing delivery record.
    /// - Parameter delivery: The `Delivery` object to delete.
    /// - Throws: `DeliveryError` if the deletion fails.
    suspend fun deleteDelivery(delivery: Delivery): Unit
}
