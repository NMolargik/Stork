//
//  MockDeliveryRepository.swift
//
//
//  Created by Nick Molargik on 11/20/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import skip.foundation.*

/// A mock implementation of the `DeliveryRepositoryInterface` protocol for testing purposes.
@Suppress("MUST_BE_INITIALIZED", "MUST_BE_INITIALIZED_OR_FINAL_OR_ABSTRACT")
open class MockDeliveryRepository: DeliveryRepositoryInterface {
    // MARK: - Properties

    /// A list of mock deliveries used for in-memory storage.
    internal open var deliveries: Array<Delivery>
        get() = field.sref({ this.deliveries = it })
        set(newValue) {
            field = newValue.sref()
        }

    // MARK: - Initializer

    /// Initializes the mock repository with optional sample data.
    ///
    /// - Parameter deliveries: An array of `Delivery` objects to initialize the repository with.
    ///   Defaults to multiple sample deliveries with associated babies.
    constructor(deliveries: Array<Delivery> = arrayOf()) {
        if (deliveries.isEmpty) {
            this.deliveries = MockDeliveryRepository.createSampleDeliveries()
        } else {
            this.deliveries = deliveries
        }
    }

    // MARK: - CRUD Methods (Updated Return Types)

    /// Creates a new delivery and returns the newly created `Delivery`.
    ///
    /// - Parameter delivery: The `Delivery` object to create.
    /// - Returns: The newly created `Delivery`.
    /// - Throws: `DeliveryError.creationFailed` if a delivery with the same ID already exists.
    override suspend fun createDelivery(delivery: Delivery): Delivery = Async.run l@{
        if (deliveries.contains(where = { it -> it.id == delivery.id })) {
            throw DeliveryError.creationFailed("Delivery with ID ${delivery.id} already exists.")
        }
        deliveries.append(delivery)
        return@l delivery.sref()
    }

    /// Updates an existing delivery and returns the updated `Delivery`.
    ///
    /// - Parameter delivery: The `Delivery` object with updated data.
    /// - Returns: The updated `Delivery`.
    /// - Throws: `DeliveryError.notFound` if no delivery with the given ID exists.
    override suspend fun updateDelivery(delivery: Delivery): Delivery = Async.run l@{
        val index_0 = deliveries.firstIndex(where = { it -> it.id == delivery.id })
        if (index_0 == null) {
            throw DeliveryError.notFound("Delivery with ID ${delivery.id} not found.")
        }
        deliveries[index_0] = delivery.sref()
        return@l delivery.sref()
    }

    /// Fetches a delivery by its unique ID.
    ///
    /// - Parameter id: The ID of the delivery to fetch.
    /// - Returns: A `Delivery` object matching the specified ID.
    /// - Throws: `DeliveryError.notFound` if no such delivery exists.
    override suspend fun getDelivery(byId: String): Delivery = Async.run l@{
        val id = byId
        val delivery_0 = deliveries.first(where = { it -> it.id == id })
        if (delivery_0 == null) {
            throw DeliveryError.notFound("Delivery with ID ${id} not found.")
        }
        return@l delivery_0.sref()
    }

    /// Lists deliveries based on optional filter criteria.
    ///
    /// - Parameters:
    ///   - userId: Optional filter by user ID.
    ///   - userFirstName: Optional filter by the user's first name.
    ///   - hospitalId: Optional filter by hospital ID.
    ///   - hospitalName: Optional filter by hospital name.
    ///   - musterId: Optional filter by muster ID.
    ///   - date: Optional filter by exact date (same day).
    ///   - babyCount: Optional filter by baby count.
    ///   - deliveryMethod: Optional filter by delivery method.
    ///   - epiduralUsed: Optional filter by epidural usage.
    /// - Returns: An array of `Delivery` objects matching the specified filters.
    override suspend fun listDeliveries(userId: String?, userFirstName: String?, hospitalId: String?, hospitalName: String?, musterId: String?, date: Date?, babyCount: Int?, deliveryMethod: DeliveryMethod?, epiduralUsed: Boolean?): Array<Delivery> = Async.run l@{
        return@l deliveries.filter { delivery -> (userId == null || delivery.userId == userId) && (userFirstName == null || delivery.userFirstName == userFirstName) && (hospitalId == null || delivery.hospitalId == hospitalId) && (hospitalName == null || delivery.hospitalName == hospitalName) && (musterId == null || delivery.musterId == musterId) && (date == null || Calendar.current.isDate(delivery.date, inSameDayAs = date!!)) && (babyCount == null || delivery.babies.count == babyCount) && (deliveryMethod == null || delivery.deliveryMethod == deliveryMethod) && (epiduralUsed == null || delivery.epiduralUsed == epiduralUsed) }
    }

    /// Deletes a delivery from the mock storage.
    ///
    /// - Parameter delivery: The `Delivery` object to delete.
    /// - Throws: `DeliveryError.deletionFailed` if the delivery cannot be found in the mock storage.
    override suspend fun deleteDelivery(delivery: Delivery): Unit = Async.run {
        val index_1 = deliveries.firstIndex(where = { it -> it.id == delivery.id })
        if (index_1 == null) {
            throw DeliveryError.deletionFailed("Failed to delete delivery with ID ${delivery.id}.")
        }
        deliveries.remove(at = index_1)
    }

    companion object: CompanionClass() {

        // MARK: - Helper: Create Sample Deliveries

        /// Creates multiple sample deliveries with random babies.
        ///
        /// - Returns: An array of `Delivery` objects.
        private fun createSampleDeliveries(): Array<Delivery> {
            val calendar = Calendar.current.sref()
            val currentDate = Date()
            val deliveryMethods: Array<DeliveryMethod> = arrayOf(DeliveryMethod.vaginal, DeliveryMethod.cSection, DeliveryMethod.vBac)

            var sampleDeliveries: Array<Delivery> = arrayOf()

            for (monthOffset in 0..<6) {
                val monthDate_0 = calendar.date(byAdding = Calendar.Component.month, value = -monthOffset, to = currentDate)
                if (monthDate_0 == null) {
                    continue
                }
                val numberOfDeliveries = Int.random(in_ = 1..5) // Randomize number of deliveries per month

                for (unusedbinding in 0..<numberOfDeliveries) {
                    val randomDate: Date = linvoke l@{ ->
                        var components = Calendar.current.dateComponents(setOf(Calendar.Component.year, Calendar.Component.month), from = monthDate_0)
                        components.day = Int.random(in_ = 1..28) // Random day in the range
                        return@l Calendar.current.date(from = components) ?: monthDate_0
                    }

                    // Generate delivery ID
                    val deliveryId = UUID().uuidString

                    // Generate user ID
                    val userId = UUID().uuidString

                    // Generate babies for the delivery
                    val babyCount = Int.random(in_ = 1..4)
                    val babies = (0..<babyCount).map { _ -> Baby(id = UUID().uuidString, deliveryId = deliveryId, birthday = randomDate, height = Double.random(in_ = 17.0..22.0), weight = Double.random(in_ = 5.0..9.0), nurseCatch = true, sex = Sex.male) }

                    // Create the delivery
                    val newDelivery = Delivery(id = deliveryId, userId = userId, userFirstName = "FirstName", hospitalId = UUID().uuidString, hospitalName = "Parkview Regional Medical Center", musterId = UUID().uuidString, date = randomDate, babies = babies, babyCount = babies.count, deliveryMethod = deliveryMethods.randomElement() ?: DeliveryMethod.vaginal, epiduralUsed = true)

                    sampleDeliveries.append(newDelivery)
                }
            }

            return sampleDeliveries.sorted { it, it_1 -> it.date > it_1.date }
        }
    }
    open class CompanionClass {
    }
}
