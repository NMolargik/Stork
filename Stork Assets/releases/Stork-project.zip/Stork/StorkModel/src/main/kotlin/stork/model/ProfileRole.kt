//
//  ProfileRole.swift
//
//  Created by Nick Molargik on 11/26/24.
//

package stork.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*

/// Represents the various roles a user can have within the Stork application.
enum class ProfileRole(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): Codable, CaseIterable, Identifiable<ProfileRole>, RawRepresentable<String> {

    // MARK: - Cases

    /// Represents a nurse role.
    nurse("nurse"),

    /// Represents a doctor role.
    doctor("doctor"),

    /// Represents any other role not explicitly defined.
    other("other");

    // MARK: - Identifiable Conformance

    /// Provides a unique identifier for each `ProfileRole` instance.
    override val id: ProfileRole
        get() = this

    // MARK: - CustomStringConvertible Conformance

    /// A human-readable description of the `ProfileRole`.
    val description: String
        get() {
            when (this) {
                ProfileRole.nurse -> return "Nurse"
                ProfileRole.doctor -> return "Doctor"
                ProfileRole.other -> return "Other" // Updated to provide a meaningful description.
            }
        }

    override fun toString(): String = description

    override fun encode(to: Encoder) {
        val container = to.singleValueContainer()
        container.encode(rawValue)
    }

    companion object: CaseIterableCompanion<ProfileRole>, DecodableCompanion<ProfileRole> {
        override fun init(from: Decoder): ProfileRole = ProfileRole(from = from)

        fun init(rawValue: String): ProfileRole? {
            return when (rawValue) {
                "nurse" -> ProfileRole.nurse
                "doctor" -> ProfileRole.doctor
                "other" -> ProfileRole.other
                else -> null
            }
        }

        override val allCases: Array<ProfileRole>
            get() = arrayOf(nurse, doctor, other)
    }
}

fun ProfileRole(rawValue: String): ProfileRole? = ProfileRole.init(rawValue = rawValue)

fun ProfileRole(from: Decoder): ProfileRole {
    val container = from.singleValueContainer()
    val rawValue = container.decode(String::class)
    return ProfileRole(rawValue = rawValue) ?: throw ErrorException(cause = NullPointerException())
}
