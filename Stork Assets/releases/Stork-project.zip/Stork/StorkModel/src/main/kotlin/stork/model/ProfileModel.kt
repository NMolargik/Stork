//
//  ProfileModel.swift
//
//  Created by Nick Molargik on 11/26/24.
//

package stork.model

import skip.lib.*

import skip.foundation.*

/// Represents a user profile within the Stork application.
@Suppress("MUST_BE_INITIALIZED")
class Profile: Identifiable<String>, Codable, MutableStruct {

    // MARK: - Properties

    /// Unique identifier for the profile.
    override var id: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier for the primary hospital associated with the profile.
    var primaryHospitalId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Identifier for the muster the profile belongs to.
    var musterId: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// First name of the user.
    var firstName: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Last name of the user.
    var lastName: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Email address of the user.
    var email: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Birthday of the user.
    var birthday: Date
        get() = field.sref({ this.birthday = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    /// Join date of the user as a string.
    var joinDate: String
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    /// Role of the user within the application.
    var role: ProfileRole
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    // MARK: - Initializers

    /// Initializes a `Profile` instance from a Firestore data dictionary.
    /// - Parameter dictionary: A dictionary containing profile data fetched from Firestore.
    constructor(from: Dictionary<String, Any>) {
        val dictionary = from
        val formatter = Profile.dateFormatter
        val id_0 = dictionary["id"] as? String
        if (id_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }
        val firstName_0 = dictionary["firstName"] as? String
        if (firstName_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }
        val lastName_0 = dictionary["lastName"] as? String
        if (lastName_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }
        val email_0 = dictionary["email"] as? String
        if (email_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }
        val birthdayString_0 = dictionary["birthday"] as? String
        if (birthdayString_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }
        val joinDateString_0 = dictionary["joinDate"] as? String
        if (joinDateString_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }
        val roleString_0 = dictionary["role"] as? String
        if (roleString_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }
        val role_0 = ProfileRole(rawValue = roleString_0)
        if (role_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }
        val birthday_0 = formatter.date(from = birthdayString_0)
        if (birthday_0 == null) {
            print("Profile initialization failed due to missing or invalid required fields.")
            print("Received dictionary: ${dictionary}")
            throw NullReturnException()
        }

        // Assign optional fields with default values if necessary.
        val primaryHospitalId = dictionary["primaryHospitalId"] as? String ?: ""
        val musterId = dictionary["musterId"] as? String ?: ""

        // Assign all values.
        this.id = id_0
        this.primaryHospitalId = primaryHospitalId
        this.musterId = musterId
        this.firstName = firstName_0
        this.lastName = lastName_0
        this.email = email_0
        this.birthday = birthday_0
        this.joinDate = joinDateString_0
        this.role = role_0
    }

    /// Initializes a `Profile` instance with explicit parameters.
    /// - Parameters:
    ///   - id: Unique identifier for the profile.
    ///   - primaryHospitalId: Primary hospital ID.
    ///   - musterId: Muster ID.
    ///   - firstName: First name.
    ///   - lastName: Last name.
    ///   - email: Email address.
    ///   - birthday: Birthday date.
    ///   - joinDate: Join date as a string.
    ///   - role: User role.
    constructor(id: String, primaryHospitalId: String, musterId: String, firstName: String, lastName: String, email: String, birthday: Date, joinDate: String, role: ProfileRole) {
        this.id = id
        this.primaryHospitalId = primaryHospitalId
        this.musterId = musterId
        this.firstName = firstName
        this.lastName = lastName
        this.email = email
        this.birthday = birthday
        this.joinDate = joinDate
        this.role = role
    }

    /// Initializes a `Profile` instance with default values.
    constructor() {
        this.id = UUID().uuidString
        this.primaryHospitalId = ""
        this.musterId = ""
        this.firstName = ""
        this.lastName = ""
        this.email = ""
        this.birthday = Date()
        this.joinDate = Profile.dateFormatter.string(from = Date())
        this.role = ProfileRole.nurse
    }

    // MARK: - Computed Properties

    /// Converts the profile data into a dictionary suitable for Firestore.
    internal val dictionary: Dictionary<String, Any>
        get() = dictionaryOf(
            Tuple2("id", id),
            Tuple2("primaryHospitalId", primaryHospitalId),
            Tuple2("musterId", musterId),
            Tuple2("firstName", firstName),
            Tuple2("lastName", lastName),
            Tuple2("email", email),
            Tuple2("birthday", Profile.dateFormatter.string(from = birthday)),
            Tuple2("joinDate", joinDate),
            Tuple2("role", role.rawValue)
        )

    // MARK: - Coding Keys

    /// Specifies the coding keys for encoding and decoding.
    private enum class CodingKeys(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CodingKey, RawRepresentable<String> {
        id("id"),
        primaryHospitalId("primaryHospitalId"),
        musterId("musterId"),
        firstName("firstName"),
        lastName("lastName"),
        email("email"),
        birthday("birthday"),
        joinDate("joinDate"),
        role("role");

        companion object {
            fun init(rawValue: String): Profile.CodingKeys? {
                return when (rawValue) {
                    "id" -> CodingKeys.id
                    "primaryHospitalId" -> CodingKeys.primaryHospitalId
                    "musterId" -> CodingKeys.musterId
                    "firstName" -> CodingKeys.firstName
                    "lastName" -> CodingKeys.lastName
                    "email" -> CodingKeys.email
                    "birthday" -> CodingKeys.birthday
                    "joinDate" -> CodingKeys.joinDate
                    "role" -> CodingKeys.role
                    else -> null
                }
            }
        }
    }

    // MARK: - Hashable Conformance

    override fun equals(other: Any?): Boolean {
        if (other !is Profile) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.id == rhs.id && lhs.primaryHospitalId == rhs.primaryHospitalId && lhs.musterId == rhs.musterId && lhs.firstName == rhs.firstName && lhs.lastName == rhs.lastName && lhs.email == rhs.email && lhs.birthday == rhs.birthday && lhs.joinDate == rhs.joinDate && lhs.role == rhs.role
    }

    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(id)
        hasher.value.combine(primaryHospitalId)
        hasher.value.combine(musterId)
        hasher.value.combine(firstName)
        hasher.value.combine(lastName)
        hasher.value.combine(email)
        hasher.value.combine(birthday)
        hasher.value.combine(joinDate)
        hasher.value.combine(role)
    }

    val initials: String
        get() {
            val firstInitial = firstName.first.optionalmap { it -> String(it).uppercased() } ?: ""
            val lastInitial = lastName.first.optionalmap { it -> String(it).uppercased() } ?: ""
            return firstInitial + lastInitial
        }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as Profile
        this.id = copy.id
        this.primaryHospitalId = copy.primaryHospitalId
        this.musterId = copy.musterId
        this.firstName = copy.firstName
        this.lastName = copy.lastName
        this.email = copy.email
        this.birthday = copy.birthday
        this.joinDate = copy.joinDate
        this.role = copy.role
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Profile(this as MutableStruct)

    override fun encode(to: Encoder) {
        val container = to.container(keyedBy = CodingKeys::class)
        container.encode(id, forKey = CodingKeys.id)
        container.encode(primaryHospitalId, forKey = CodingKeys.primaryHospitalId)
        container.encode(musterId, forKey = CodingKeys.musterId)
        container.encode(firstName, forKey = CodingKeys.firstName)
        container.encode(lastName, forKey = CodingKeys.lastName)
        container.encode(email, forKey = CodingKeys.email)
        container.encode(birthday, forKey = CodingKeys.birthday)
        container.encode(joinDate, forKey = CodingKeys.joinDate)
        container.encode(role, forKey = CodingKeys.role)
    }

    constructor(from: Decoder) {
        val container = from.container(keyedBy = CodingKeys::class)
        this.id = container.decode(String::class, forKey = CodingKeys.id)
        this.primaryHospitalId = container.decode(String::class, forKey = CodingKeys.primaryHospitalId)
        this.musterId = container.decode(String::class, forKey = CodingKeys.musterId)
        this.firstName = container.decode(String::class, forKey = CodingKeys.firstName)
        this.lastName = container.decode(String::class, forKey = CodingKeys.lastName)
        this.email = container.decode(String::class, forKey = CodingKeys.email)
        this.birthday = container.decode(Date::class, forKey = CodingKeys.birthday)
        this.joinDate = container.decode(String::class, forKey = CodingKeys.joinDate)
        this.role = container.decode(ProfileRole::class, forKey = CodingKeys.role)
    }

    companion object: DecodableCompanion<Profile> {

        /// Predefined date formatter for standardizing date formats.
        val dateFormatter: DateFormatter = linvoke l@{ ->
            val formatter = DateFormatter()
            formatter.dateFormat = "MM/dd/yyyy"
            formatter.locale = Locale(identifier = "en_US_POSIX")
            return@l formatter
        }

        override fun init(from: Decoder): Profile = Profile(from = from)

        private fun CodingKeys(rawValue: String): Profile.CodingKeys? = CodingKeys.init(rawValue = rawValue)
    }
}
