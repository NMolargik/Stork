//
//  View+backgroundCard.swift
//  skipapp-stork
//
//  Created by Nick Molargik on 1/7/25.
//

package stork.model

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*

import skip.foundation.*
import skip.ui.*
import skip.model.*

fun View.backgroundCard(colorScheme: ColorScheme): View {
    return this.padding(5.0)
        .background { ->
            ComposeBuilder { composectx: ComposeContext ->
                Rectangle()
                    .foregroundStyle(if (colorScheme == ColorScheme.dark) Color.black else Color.white)
                    .cornerRadius(20.0)
                    .shadow(color = if (colorScheme == ColorScheme.dark) Color.white else Color.black, radius = 2.0).Compose(composectx)
                ComposeResult.ok
            }
        }
        .padding(Edge.Set.horizontal, 5.0)
}
