//
//  DefaultProfileRepository.swift
//
//
//  Created by Nick Molargik on 11/4/24.
//

package stork.model

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.ui.*
import skip.model.*

/// A repository implementation for managing profile-related operations.
open class DefaultProfileRepository: ProfileRepositoryInterface {
    // MARK: - Properties

    /// The remote data source for profile operations.
    private val remoteDataSource: ProfileRemoteDataSourceInterface

    // MARK: - Initializer

    /// Initializes the repository with a remote data source.
    ///
    /// - Parameter remoteDataSource: An instance of `ProfileRemoteDataSourceInterface`.
    constructor(remoteDataSource: ProfileRemoteDataSourceInterface) {
        this.remoteDataSource = remoteDataSource.sref()
    }

    // MARK: - Create

    /// Creates a new profile and returns the newly created `Profile`.
    ///
    /// - Parameter profile: The `Profile` object to create.
    /// - Returns: The newly created `Profile`, potentially including a generated `id` if provided by the server.
    /// - Throws:
    ///   - `ProfileError.creationFailed`: If the creation fails.
    ///   - `ProfileError`: For other failures during the creation operation.
    override suspend fun createProfile(profile: Profile): Profile = Async.run l@{
        try {
            val newProfile = remoteDataSource.createProfile(profile = profile)
            return@l newProfile.sref()
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.creationFailed("Failed to create profile: ${error.localizedDescription}")
        }
    }

    // MARK: - Update

    /// Updates an existing profile and returns the updated `Profile`.
    ///
    /// - Parameter profile: The `Profile` object containing updated data.
    /// - Returns: The updated `Profile`, reflecting any server-side changes.
    /// - Throws:
    ///   - `ProfileError.updateFailed`: If the update fails.
    ///   - `ProfileError.notFound`: If the profile does not exist.
    ///   - `ProfileError`: For other failures during the update operation.
    override suspend fun updateProfile(profile: Profile): Profile = Async.run l@{
        try {
            val updatedProfile = remoteDataSource.updateProfile(profile = profile)
            return@l updatedProfile.sref()
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.updateFailed("Failed to update profile: ${error.localizedDescription}")
        }
    }

    // MARK: - Fetch (Single)

    /// Fetches a single profile by its unique ID.
    ///
    /// - Parameter id: The unique identifier of the profile to fetch.
    /// - Returns: A `Profile` object representing the fetched profile.
    /// - Throws:
    ///   - `ProfileError.notFound`: If the profile cannot be found.
    ///   - `ProfileError`: For other failures during the fetch operation.
    override suspend fun getProfile(byId: String): Profile = Async.run l@{
        val id = byId
        try {
            return@l remoteDataSource.getProfile(byId = id)
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.notFound("Failed to find profile with ID ${id}: ${error.localizedDescription}")
        }
    }

    /// Retrieves the currently authenticated profile.
    ///
    /// - Returns: A `Profile` object representing the current authenticated user.
    /// - Throws:
    ///   - `ProfileError.notFound`: If no valid authenticated user or profile is found.
    ///   - `ProfileError`: For other errors during the fetch operation.
    override suspend fun getCurrentProfile(): Profile = Async.run l@{
        try {
            return@l remoteDataSource.getCurrentProfile()
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.notFound("Failed to collect current profile: ${error.localizedDescription}")
        }
    }

    // MARK: - List / Search

    /// Lists profiles based on optional filter criteria.
    ///
    /// - Parameters:
    ///   - id: An optional filter for the profile's ID.
    ///   - firstName: An optional filter for the profile's first name.
    ///   - lastName: An optional filter for the profile's last name.
    ///   - email: An optional filter for the profile's email address.
    ///   - birthday: An optional filter for the profile's birthday.
    ///   - role: An optional filter for the profile's role.
    ///   - primaryHospital: An optional filter for the profile's primary hospital ID.
    ///   - joinDate: An optional filter for the profile's join date.
    ///   - musterId: An optional filter for the muster ID associated with the profile.
    /// - Returns: An array of `Profile` objects matching the specified filters.
    /// - Throws: `ProfileError` if the operation fails.
    override suspend fun listProfiles(id: String?, firstName: String?, lastName: String?, email: String?, birthday: Date?, role: ProfileRole?, primaryHospital: String?, joinDate: Date?, musterId: String?): Array<Profile> = Async.run l@{
        try {
            return@l remoteDataSource.listProfiles(id = id, firstName = firstName, lastName = lastName, email = email, birthday = birthday, role = role, primaryHospital = primaryHospital, joinDate = joinDate, musterId = musterId)
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.fetchFailed("Failed to fetch profiles: ${error.localizedDescription}")
        }
    }

    // MARK: - Auth

    /// Registers a new user account with an email and password, returning the newly registered user's ID (UID).
    ///
    /// - Parameters:
    ///   - profile: The `Profile` object containing the user's data.
    ///   - password: The password for the new user account.
    /// - Returns: The updated `Profile` object
    /// - Throws:
    ///   - `ProfileError.creationFailed`: If registration fails.
    ///   - `ProfileError`: For other errors during the registration process.
    override suspend fun registerWithEmail(profile: Profile, password: String): Profile = Async.run l@{
        try {
            val updatedProfile = remoteDataSource.registerWithEmail(profile = profile, password = password)
            return@l updatedProfile.sref()
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.creationFailed("Failed to register profile: ${error.localizedDescription}")
        }
    }

    /// Signs in an existing user with an email and password, returning the authenticated `Profile`.
    ///
    /// - Parameters:
    ///   - profile: A `Profile` containing at least the user's email.
    ///   - password: The password for the user's account.
    /// - Returns: A `Profile` object representing the authenticated user.
    /// - Throws:
    ///   - `ProfileError.authenticationFailed`: If authentication fails.
    ///   - `ProfileError`: For other errors during sign-in.
    override suspend fun signInWithEmail(profile: Profile, password: String): Profile = Async.run l@{
        try {
            val signedInProfile = remoteDataSource.signInWithEmail(profile = profile, password = password)
            return@l signedInProfile.sref()
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.authenticationFailed("Failed to authenticate profile: ${error.localizedDescription}")
        }
    }

    /// Signs out the currently authenticated user.
    ///
    /// - Throws: `ProfileError.signOutFailed` if the sign-out operation fails.
    override suspend fun signOut(): Unit = Async.run {
        try {
            remoteDataSource.signOut()
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.signOutFailed("Failed to sign out: ${error.localizedDescription}")
        }
    }

    /// Sends a password reset email to the specified address.
    ///
    /// - Parameter email: The email address for which to send a password reset link.
    /// - Throws: `ProfileError.passwordResetFailed` if the reset operation fails.
    override suspend fun sendPasswordReset(email: String): Unit = Async.run {
        try {
            remoteDataSource.sendPasswordReset(email = email)
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.passwordResetFailed("Failed to reset password: ${error.localizedDescription}")
        }
    }

    // MARK: - Delete

    /// Deletes an existing profile.
    ///
    /// - Parameter profile: The `Profile` object to delete.
    /// - Throws:
    ///   - `ProfileError.deletionFailed`: If the deletion fails.
    ///   - `ProfileError.notFound`: If the profile does not exist.
    ///   - `ProfileError`: For other failures during the deletion operation.
    override suspend fun deleteProfile(profile: Profile): Unit = Async.run {
        try {
            remoteDataSource.deleteProfile(profile = profile)
        } catch (error: ProfileError) {
            throw error
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            throw ProfileError.deletionFailed("Failed to delete profile: ${error.localizedDescription}")
        }
    }

    // MARK: - Terminate

    /// Terminates the currently authenticated user's account by re-authenticating with the provided password
    /// and then deleting the user's Auth record and Firestore profile.
    ///
    /// - Parameter password: The password used for re-authentication before deletion.
    /// - Throws:
    ///   - `ProfileError.authenticationFailed`: If re-authentication fails.
    ///   - `ProfileError.deletionFailed`: If deletion fails.
    ///   - `ProfileError.notFound`: If there is no current user to terminate.
    ///   - `ProfileError`: For other errors during the termination process.
    //    public func terminateUser(password: String) async throws {
    //        do {
    //            try await remoteDataSource.terminateUser(password: password)
    //        } catch let error as ProfileError {
    //            throw error
    //        } catch {
    //            throw ProfileError.deletionFailed("Failed to delete user account: \(error.localizedDescription)")
    //        }
    //    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
