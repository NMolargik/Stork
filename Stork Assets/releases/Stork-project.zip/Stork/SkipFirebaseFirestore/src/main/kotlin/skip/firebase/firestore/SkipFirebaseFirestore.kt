// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.firebase.firestore

import skip.lib.*
import skip.lib.Array
import skip.lib.Collection

import skip.foundation.*
import skip.firebase.core.*
import kotlinx.coroutines.tasks.await

class Firestore: KotlinConverting<com.google.firebase.firestore.FirebaseFirestore> {
    val store: com.google.firebase.firestore.FirebaseFirestore

    constructor(store: com.google.firebase.firestore.FirebaseFirestore) {
        this.store = store.sref()
    }

    val description: String
        get() = store.toString()

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.FirebaseFirestore = store.sref()

    fun collection(collectionPath: String): CollectionReference = CollectionReference(ref = store.collection(collectionPath))

    suspend fun terminate(): Unit = Async.run {
        store.terminate().await()
    }

    suspend fun clearPersistence(): Unit = Async.run {
        store.clearPersistence().await()
    }

    suspend fun disableNetwork(): Unit = Async.run {
        store.disableNetwork().await()
    }

    suspend fun enableNetwork(): Unit = Async.run {
        store.enableNetwork().await()
    }

    suspend fun loadBundle(data: Data): LoadBundleTaskProgress = Async.run l@{
        return@l LoadBundleTaskProgress(progress = store.loadBundle(data.kotlin()).await())
    }

    // TODO: SkipFoundation.InputStream
    //    public func loadBundle(_ inputStream: InputStream) async {
    //        store.loadBundle(inputStream.kotlin()).await()
    //    }

    suspend fun getQuery(named: String): Query? = Async.run l@{
        val name = named
        val query_0 = store.getNamedQuery(name).await()
        if (query_0 == null) {
            return@l null
        }
        return@l Query(query = query_0)
    }

    fun collectionGroup(collectionId: String): Query = Query(query = store.collectionGroup(collectionId))

    fun batch(): WriteBatch = WriteBatch(batch = store.batch())

    fun useEmulator(withHost: String, port: Int) {
        val host = withHost
        store.useEmulator(host, port)
    }

    companion object {

        fun firestore(app: FirebaseApp, database: String): Firestore = Firestore(store = com.google.firebase.firestore.FirebaseFirestore.getInstance(app.app, database))

        fun firestore(app: FirebaseApp): Firestore = Firestore(store = com.google.firebase.firestore.FirebaseFirestore.getInstance(app.app))

        fun firestore(): Firestore = Firestore(store = com.google.firebase.firestore.FirebaseFirestore.getInstance())
    }
}

/// A FieldPath refers to a field in a document. The path may consist of a single field name (referring to a top level field in the document), or a list of field names (referring to a nested field in the document).
open class FieldPath: KotlinConverting<com.google.firebase.firestore.FieldPath> {
    val fieldPath: com.google.firebase.firestore.FieldPath

    constructor(fieldPath: com.google.firebase.firestore.FieldPath) {
        this.fieldPath = fieldPath.sref()
    }

    constructor(fieldNames: Array<String>) {
        val fnames: kotlin.Array<String> = fieldNames.toList().toTypedArray()
        this.fieldPath = com.google.firebase.firestore.FieldPath.of(*fnames)
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.FieldPath = fieldPath.sref()

    open val description: String
        get() = fieldPath.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is FieldPath) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.fieldPath == rhs.fieldPath
    }

    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    open fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(fieldPath.hashCode())
    }

    companion object: CompanionClass() {

        /// A special sentinel FieldPath to refer to the ID of a document. It can be used in queries to sort or filter by the document ID.
        override fun documentID(): FieldPath = FieldPath(fieldPath = com.google.firebase.firestore.FieldPath.documentId())
    }
    open class CompanionClass {
        open fun documentID(): FieldPath = FieldPath.documentID()
    }
}

open class LoadBundleTaskProgress: KotlinConverting<com.google.firebase.firestore.LoadBundleTaskProgress> {
    val progress: com.google.firebase.firestore.LoadBundleTaskProgress

    constructor(progress: com.google.firebase.firestore.LoadBundleTaskProgress) {
        this.progress = progress.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.LoadBundleTaskProgress = progress.sref()

    open val description: String
        get() = progress.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is LoadBundleTaskProgress) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.progress == rhs.progress
    }

    open val totalDocuments: Int
        get() = progress.totalDocuments

    open val documentsLoaded: Int
        get() = progress.documentsLoaded

    open val bytesLoaded: Long
        get() = progress.bytesLoaded

    open val totalBytes: Long
        get() = progress.totalBytes

    open val state: LoadBundleTaskState
        get() {
            when (progress.taskState) {
                com.google.firebase.firestore.LoadBundleTaskProgress.TaskState.ERROR -> return LoadBundleTaskState.error
                com.google.firebase.firestore.LoadBundleTaskProgress.TaskState.RUNNING -> return LoadBundleTaskState.inProgress
                com.google.firebase.firestore.LoadBundleTaskProgress.TaskState.SUCCESS -> return LoadBundleTaskState.success
            }
        }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

enum class LoadBundleTaskState {
    error,
    inProgress,
    success;

    companion object {
    }
}

/// A query that calculates aggregations over an underlying query.
open class AggregateQuery: KotlinConverting<com.google.firebase.firestore.AggregateQuery> {
    val query: com.google.firebase.firestore.AggregateQuery

    constructor(query: com.google.firebase.firestore.AggregateQuery) {
        this.query = query.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.AggregateQuery = query.sref()

    open val description: String
        get() = query.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is AggregateQuery) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.query == rhs.query
    }

    open suspend fun getAggregation(source: AggregateSource): AggregateQuerySnapshot = Async.run l@{
        when (source) {
            AggregateSource.server -> return@l AggregateQuerySnapshot(snap = query.get(com.google.firebase.firestore.AggregateSource.SERVER).await())
        }
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class Filter: KotlinConverting<com.google.firebase.firestore.Filter> {
    val filter: com.google.firebase.firestore.Filter

    constructor(filter: com.google.firebase.firestore.Filter = com.google.firebase.firestore.Filter()) {
        this.filter = filter.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.Filter = filter.sref()

    override fun equals(other: Any?): Boolean {
        if (other !is Filter) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.filter == rhs.filter
    }

    companion object: CompanionClass() {

        override fun whereField(field: String, isEqualTo: Any): Filter {
            val value = isEqualTo
            return Filter(filter = com.google.firebase.firestore.Filter.equalTo(field, value.kotlin()))
        }

        override fun whereField(field: String, isNotEqualTo: Any, unusedp_0: Nothing?): Filter {
            val value = isNotEqualTo
            return Filter(filter = com.google.firebase.firestore.Filter.notEqualTo(field, value.kotlin()))
        }

        override fun whereField(field: String, isGreaterThan: Any, unusedp_0: Nothing?, unusedp_1: Nothing?): Filter {
            val value = isGreaterThan
            return Filter(filter = com.google.firebase.firestore.Filter.greaterThan(field, value.kotlin()))
        }

        override fun whereField(field: String, isGreaterThanOrEqualTo: Any, unusedp_0: Nothing?, unusedp_1: Nothing?, unusedp_2: Nothing?): Filter {
            val value = isGreaterThanOrEqualTo
            return Filter(filter = com.google.firebase.firestore.Filter.greaterThanOrEqualTo(field, value.kotlin()))
        }

        override fun whereField(field: String, isLessThan: Any, unusedp_0: Nothing?, unusedp_1: Nothing?, unusedp_2: Nothing?, unusedp_3: Nothing?): Filter {
            val value = isLessThan
            return Filter(filter = com.google.firebase.firestore.Filter.lessThan(field, value.kotlin()))
        }

        override fun whereField(field: String, isLessThanOrEqualTo: Any, unusedp_0: Nothing?, unusedp_1: Nothing?, unusedp_2: Nothing?, unusedp_3: Nothing?, unusedp_4: Nothing?): Filter {
            val value = isLessThanOrEqualTo
            return Filter(filter = com.google.firebase.firestore.Filter.lessThanOrEqualTo(field, value.kotlin()))
        }

        override fun whereField(field: String, arrayContains: Any, unusedp_0: Nothing?, unusedp_1: Nothing?, unusedp_2: Nothing?, unusedp_3: Nothing?, unusedp_4: Nothing?, unusedp_5: Nothing?): Filter {
            val value = arrayContains
            return Filter(filter = com.google.firebase.firestore.Filter.arrayContains(field, value.kotlin()))
        }

        override fun whereField(field: String, arrayContainsAny: Array<Any>): Filter {
            val values = arrayContainsAny
            return Filter(filter = com.google.firebase.firestore.Filter.arrayContainsAny(field, values.kotlin()))
        }

        override fun whereField(field: String, in_: Array<Any>, unusedp_0: Nothing?): Filter {
            val values = in_
            return Filter(filter = com.google.firebase.firestore.Filter.inArray(field, values.kotlin()))
        }

        override fun whereField(field: String, notIn: Array<Any>, unusedp_0: Nothing?, unusedp_1: Nothing?): Filter {
            val values = notIn
            return Filter(filter = com.google.firebase.firestore.Filter.notInArray(field, values.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, isEqualTo: Any): Filter {
            val value = isEqualTo
            return Filter(filter = com.google.firebase.firestore.Filter.equalTo(fieldPath.fieldPath, value.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, isNotEqualTo: Any, unusedp_0: Nothing?): Filter {
            val value = isNotEqualTo
            return Filter(filter = com.google.firebase.firestore.Filter.notEqualTo(fieldPath.fieldPath, value.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, isGreaterThan: Any, unusedp_0: Nothing?, unusedp_1: Nothing?): Filter {
            val value = isGreaterThan
            return Filter(filter = com.google.firebase.firestore.Filter.greaterThan(fieldPath.fieldPath, value.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, isGreaterThanOrEqualTo: Any, unusedp_0: Nothing?, unusedp_1: Nothing?, unusedp_2: Nothing?): Filter {
            val value = isGreaterThanOrEqualTo
            return Filter(filter = com.google.firebase.firestore.Filter.greaterThanOrEqualTo(fieldPath.fieldPath, value.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, isLessThan: Any, unusedp_0: Nothing?, unusedp_1: Nothing?, unusedp_2: Nothing?, unusedp_3: Nothing?): Filter {
            val value = isLessThan
            return Filter(filter = com.google.firebase.firestore.Filter.lessThan(fieldPath.fieldPath, value.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, isLessThanOrEqualTo: Any, unusedp_0: Nothing?, unusedp_1: Nothing?, unusedp_2: Nothing?, unusedp_3: Nothing?, unusedp_4: Nothing?): Filter {
            val value = isLessThanOrEqualTo
            return Filter(filter = com.google.firebase.firestore.Filter.lessThanOrEqualTo(fieldPath.fieldPath, value.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, arrayContains: Any, unusedp_0: Nothing?, unusedp_1: Nothing?, unusedp_2: Nothing?, unusedp_3: Nothing?, unusedp_4: Nothing?, unusedp_5: Nothing?): Filter {
            val value = arrayContains
            return Filter(filter = com.google.firebase.firestore.Filter.arrayContains(fieldPath.fieldPath, value.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, arrayContainsAny: Array<Any>): Filter {
            val values = arrayContainsAny
            return Filter(filter = com.google.firebase.firestore.Filter.arrayContainsAny(fieldPath.fieldPath, values.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, in_: Array<Any>, unusedp_0: Nothing?): Filter {
            val values = in_
            return Filter(filter = com.google.firebase.firestore.Filter.inArray(fieldPath.fieldPath, values.kotlin()))
        }

        override fun whereField(fieldPath: FieldPath, notIn: Array<Any>, unusedp_0: Nothing?, unusedp_1: Nothing?): Filter {
            val values = notIn
            return Filter(filter = com.google.firebase.firestore.Filter.notInArray(fieldPath.fieldPath, values.kotlin()))
        }

        override fun orFilter(filters: Array<Filter>): Filter {
            val platformFilters = filters.map({ it.filter }).toList().toTypedArray()
            return Filter(filter = com.google.firebase.firestore.Filter.or(*platformFilters))
        }

        override fun andFilter(filters: Array<Filter>): Filter {
            val platformFilters = filters.map({ it.filter }).toList().toTypedArray()
            return Filter(filter = com.google.firebase.firestore.Filter.and(*platformFilters))
        }
    }
    open class CompanionClass {
        open fun whereField(field: String, isEqualTo: Any): Filter = Filter.whereField(field, isEqualTo = isEqualTo)
        open fun whereField(field: String, isNotEqualTo: Any, unusedp_0: Nothing? = null): Filter = Filter.whereField(field, isNotEqualTo = isNotEqualTo, unusedp_0 = unusedp_0)
        open fun whereField(field: String, isGreaterThan: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null): Filter = Filter.whereField(field, isGreaterThan = isGreaterThan, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1)
        open fun whereField(field: String, isGreaterThanOrEqualTo: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null, unusedp_2: Nothing? = null): Filter = Filter.whereField(field, isGreaterThanOrEqualTo = isGreaterThanOrEqualTo, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1, unusedp_2 = unusedp_2)
        open fun whereField(field: String, isLessThan: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null, unusedp_2: Nothing? = null, unusedp_3: Nothing? = null): Filter = Filter.whereField(field, isLessThan = isLessThan, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1, unusedp_2 = unusedp_2, unusedp_3 = unusedp_3)
        open fun whereField(field: String, isLessThanOrEqualTo: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null, unusedp_2: Nothing? = null, unusedp_3: Nothing? = null, unusedp_4: Nothing? = null): Filter = Filter.whereField(field, isLessThanOrEqualTo = isLessThanOrEqualTo, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1, unusedp_2 = unusedp_2, unusedp_3 = unusedp_3, unusedp_4 = unusedp_4)
        open fun whereField(field: String, arrayContains: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null, unusedp_2: Nothing? = null, unusedp_3: Nothing? = null, unusedp_4: Nothing? = null, unusedp_5: Nothing? = null): Filter = Filter.whereField(field, arrayContains = arrayContains, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1, unusedp_2 = unusedp_2, unusedp_3 = unusedp_3, unusedp_4 = unusedp_4, unusedp_5 = unusedp_5)
        open fun whereField(field: String, arrayContainsAny: Array<Any>): Filter = Filter.whereField(field, arrayContainsAny = arrayContainsAny)
        open fun whereField(field: String, in_: Array<Any>, unusedp_0: Nothing? = null): Filter = Filter.whereField(field, in_ = in_, unusedp_0 = unusedp_0)
        open fun whereField(field: String, notIn: Array<Any>, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null): Filter = Filter.whereField(field, notIn = notIn, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1)
        open fun whereField(fieldPath: FieldPath, isEqualTo: Any): Filter = Filter.whereField(fieldPath, isEqualTo = isEqualTo)
        open fun whereField(fieldPath: FieldPath, isNotEqualTo: Any, unusedp_0: Nothing? = null): Filter = Filter.whereField(fieldPath, isNotEqualTo = isNotEqualTo, unusedp_0 = unusedp_0)
        open fun whereField(fieldPath: FieldPath, isGreaterThan: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null): Filter = Filter.whereField(fieldPath, isGreaterThan = isGreaterThan, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1)
        open fun whereField(fieldPath: FieldPath, isGreaterThanOrEqualTo: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null, unusedp_2: Nothing? = null): Filter = Filter.whereField(fieldPath, isGreaterThanOrEqualTo = isGreaterThanOrEqualTo, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1, unusedp_2 = unusedp_2)
        open fun whereField(fieldPath: FieldPath, isLessThan: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null, unusedp_2: Nothing? = null, unusedp_3: Nothing? = null): Filter = Filter.whereField(fieldPath, isLessThan = isLessThan, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1, unusedp_2 = unusedp_2, unusedp_3 = unusedp_3)
        open fun whereField(fieldPath: FieldPath, isLessThanOrEqualTo: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null, unusedp_2: Nothing? = null, unusedp_3: Nothing? = null, unusedp_4: Nothing? = null): Filter = Filter.whereField(fieldPath, isLessThanOrEqualTo = isLessThanOrEqualTo, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1, unusedp_2 = unusedp_2, unusedp_3 = unusedp_3, unusedp_4 = unusedp_4)
        open fun whereField(fieldPath: FieldPath, arrayContains: Any, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null, unusedp_2: Nothing? = null, unusedp_3: Nothing? = null, unusedp_4: Nothing? = null, unusedp_5: Nothing? = null): Filter = Filter.whereField(fieldPath, arrayContains = arrayContains, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1, unusedp_2 = unusedp_2, unusedp_3 = unusedp_3, unusedp_4 = unusedp_4, unusedp_5 = unusedp_5)
        open fun whereField(fieldPath: FieldPath, arrayContainsAny: Array<Any>): Filter = Filter.whereField(fieldPath, arrayContainsAny = arrayContainsAny)
        open fun whereField(fieldPath: FieldPath, in_: Array<Any>, unusedp_0: Nothing? = null): Filter = Filter.whereField(fieldPath, in_ = in_, unusedp_0 = unusedp_0)
        open fun whereField(fieldPath: FieldPath, notIn: Array<Any>, unusedp_0: Nothing? = null, unusedp_1: Nothing? = null): Filter = Filter.whereField(fieldPath, notIn = notIn, unusedp_0 = unusedp_0, unusedp_1 = unusedp_1)
        open fun orFilter(filters: Array<Filter>): Filter = Filter.orFilter(filters)
        open fun andFilter(filters: Array<Filter>): Filter = Filter.andFilter(filters)
    }
}

open class SnapshotMetadata: KotlinConverting<com.google.firebase.firestore.SnapshotMetadata> {
    val meta: com.google.firebase.firestore.SnapshotMetadata

    constructor(meta: com.google.firebase.firestore.SnapshotMetadata) {
        this.meta = meta.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.SnapshotMetadata = meta.sref()

    open val description: String
        get() = meta.toString()

    open val hasPendingWrites: Boolean
        get() = meta.hasPendingWrites()

    override fun equals(other: Any?): Boolean {
        if (other !is SnapshotMetadata) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.meta == rhs.meta
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class Query: KotlinConverting<com.google.firebase.firestore.Query> {
    val query: com.google.firebase.firestore.Query

    constructor(query: com.google.firebase.firestore.Query) {
        this.query = query.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.Query = query.sref()

    open val description: String
        get() = query.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is Query) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.query == rhs.query
    }

    open suspend fun getDocuments(): QuerySnapshot = Async.run l@{
        return@l QuerySnapshot(snap = query.get().await())
    }

    open suspend fun getDocuments(source: FirestoreSource): QuerySnapshot = Async.run l@{
        return@l QuerySnapshot(snap = query.get(source.source).await())
    }

    open val count: AggregateQuery
        get() = AggregateQuery(query = query.count())

    open fun limit(to: Long): Query {
        val count = to
        return Query(query = query.limit(count))
    }

    open fun order(by: String): Query {
        val fieldName = by
        return Query(query = query.orderBy(fieldName))
    }

    open fun order(by: String, descending: Boolean): Query {
        val fieldName = by
        return Query(query = query.orderBy(fieldName, if (descending) com.google.firebase.firestore.Query.Direction.DESCENDING else com.google.firebase.firestore.Query.Direction.ASCENDING))
    }

    open fun whereFilter(filter: Filter): Query = Query(query = query.where(filter.filter))

    open fun whereField(field: String, in_: Array<Any>): Query {
        val array = in_
        return Query(query = query.whereIn(field, array.kotlin()))
    }

    fun whereField(field: String, notIn: Array<Any>, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null): Query = Query(query = query.whereNotIn(field, notIn.kotlin()))

    open fun whereField(field: String, isEqualTo: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null): Query = Query(query = query.whereEqualTo(field, isEqualTo.kotlin()))

    open fun whereField(field: String, isGreaterThan: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null): Query = Query(query = query.whereGreaterThan(field, isGreaterThan.kotlin()))

    open fun whereField(field: String, isGreaterThanOrEqualTo: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_3: Nothing? = null): Query = Query(query = query.whereGreaterThanOrEqualTo(field, isGreaterThanOrEqualTo.kotlin()))

    open fun whereField(field: String, isNotEqualTo: Any): Query = Query(query = query.whereNotEqualTo(field, isNotEqualTo.kotlin()))

    open fun whereField(field: String, isLessThanOrEqualTo: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_3: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_4: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_5: Nothing? = null): Query = Query(query = query.whereLessThanOrEqualTo(field, isLessThanOrEqualTo.kotlin()))

    open fun whereField(field: String, isLessThan: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_3: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_4: Nothing? = null): Query = Query(query = query.whereLessThan(field, isLessThan.kotlin()))

    open fun whereField(field: String, arrayContains: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null): Query = Query(query = query.whereArrayContains(field, arrayContains.kotlin()))

    open fun whereField(field: FieldPath, in_: Array<Any>): Query {
        val array = in_
        return Query(query = query.whereIn(field.fieldPath, array.kotlin()))
    }

    fun whereField(field: String, arrayContainsAny: Array<Any>, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null): Query = Query(query = query.whereArrayContainsAny(field, arrayContainsAny.kotlin()))

    fun whereField(field: FieldPath, notIn: Array<Any>, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null): Query = Query(query = query.whereNotIn(field.fieldPath, notIn.kotlin()))

    open fun whereField(field: FieldPath, isEqualTo: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null): Query = Query(query = query.whereEqualTo(field.fieldPath, isEqualTo.kotlin()))

    open fun whereField(field: FieldPath, isGreaterThan: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null): Query = Query(query = query.whereGreaterThan(field.fieldPath, isGreaterThan.kotlin()))

    open fun whereField(field: FieldPath, isGreaterThanOrEqualTo: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_3: Nothing? = null): Query = Query(query = query.whereGreaterThanOrEqualTo(field.fieldPath, isGreaterThanOrEqualTo.kotlin()))

    open fun whereField(field: FieldPath, isNotEqualTo: Any): Query = Query(query = query.whereNotEqualTo(field.fieldPath, isNotEqualTo.kotlin()))

    open fun whereField(field: FieldPath, isLessThanOrEqualTo: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_3: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_4: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_5: Nothing? = null): Query = Query(query = query.whereLessThanOrEqualTo(field.fieldPath, isLessThanOrEqualTo.kotlin()))

    open fun whereField(field: FieldPath, isLessThan: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_1: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_2: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_3: Nothing? = null, @Suppress("UNUSED_PARAMETER") unusedp_4: Nothing? = null): Query = Query(query = query.whereLessThan(field.fieldPath, isLessThan.kotlin()))

    open fun whereField(field: FieldPath, arrayContains: Any, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null): Query = Query(query = query.whereArrayContains(field.fieldPath, arrayContains.kotlin()))

    open fun whereField(field: FieldPath, arrayContainsAny: Array<Any>, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null): Query = Query(query = query.whereArrayContainsAny(field.fieldPath, arrayContainsAny.kotlin()))

    open fun start(afterDocument: DocumentSnapshot): Query = Query(query = query.startAfter(afterDocument.kotlin()))

    open fun addSnapshotListener(listener: (QuerySnapshot?, Error?) -> Unit): ListenerRegistration {
        return ListenerRegistration(reg = query.addSnapshotListener { snapshot, error ->
            val qs: QuerySnapshot? = if (snapshot == null) null else QuerySnapshot(snap = snapshot!!)
            val err: Error? = error?.aserror()
            listener(qs, err)
        })
    }

    open fun addSnapshotListener(includeMetadataChanges: Boolean, listener: (QuerySnapshot?, Error?) -> Unit): ListenerRegistration {
        return ListenerRegistration(reg = query.addSnapshotListener(if (includeMetadataChanges) com.google.firebase.firestore.MetadataChanges.INCLUDE else com.google.firebase.firestore.MetadataChanges.EXCLUDE) { snapshot, error ->
            val qs: QuerySnapshot? = if (snapshot == null) null else QuerySnapshot(snap = snapshot!!)
            val err: Error? = error?.aserror()
            listener(qs, err)
        })
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class CollectionReference: Query {
    //public let ref: com.google.firebase.firestore.CollectionReference
    open val ref: com.google.firebase.firestore.CollectionReference
        get() = this.query as com.google.firebase.firestore.CollectionReference

    constructor(ref: com.google.firebase.firestore.CollectionReference): super(query = ref) {
    }

    open val firestore: Firestore
        get() = Firestore(store = ref.firestore)

    open val collectionID: String
        get() = ref.getId()

    open val parent: DocumentReference?
        get() {
            val parent_0 = ref.parent.sref()
            if (parent_0 == null) {
                return null
            }
            return DocumentReference(ref = parent_0)
        }

    open val path: String
        get() = ref.path

    open fun document(path: String): DocumentReference = DocumentReference(ref = ref.document(path))

    open fun document(): DocumentReference = DocumentReference(ref = ref.document())

    open suspend fun addDocument(data: Dictionary<String, Any>): DocumentReference = Async.run l@{
        return@l DocumentReference(ref = ref.add(data.kotlin()).await())
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass: Query.CompanionClass() {
    }
}

open class ListenerRegistration: KotlinConverting<com.google.firebase.firestore.ListenerRegistration> {
    val reg: com.google.firebase.firestore.ListenerRegistration

    constructor(reg: com.google.firebase.firestore.ListenerRegistration) {
        this.reg = reg.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.ListenerRegistration = reg.sref()

    open val description: String
        get() = reg.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is ListenerRegistration) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.reg == rhs.reg
    }

    open fun remove(): Unit = reg.remove()

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class Transaction: KotlinConverting<com.google.firebase.firestore.Transaction> {
    val transaction: com.google.firebase.firestore.Transaction

    constructor(transaction: com.google.firebase.firestore.Transaction) {
        this.transaction = transaction.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.Transaction = transaction.sref()

    open val description: String
        get() = transaction.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is Transaction) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.transaction == rhs.transaction
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class QuerySnapshot: KotlinConverting<com.google.firebase.firestore.QuerySnapshot> {
    val snap: com.google.firebase.firestore.QuerySnapshot

    constructor(snap: com.google.firebase.firestore.QuerySnapshot) {
        this.snap = snap.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.QuerySnapshot = snap.sref()

    open val description: String
        get() = snap.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is QuerySnapshot) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.snap == rhs.snap
    }

    open val count: Int
        get() = snap.size()

    open val isEmpty: Boolean
        get() = snap.isEmpty()

    open val metadata: SnapshotMetadata
        get() = SnapshotMetadata(snap.metadata)

    open val query: Query
        get() = Query(query = snap.query)

    open val documents: Array<QueryDocumentSnapshot>
        get() {
            return Array(snap.documents.map({ it -> QueryDocumentSnapshot(snapshot = it as com.google.firebase.firestore.QueryDocumentSnapshot) }))
        }

    open val documentChanges: Array<DocumentChange>
        get() {
            return Array(snap.getDocumentChanges().map({ it -> DocumentChange(change = it) }))
        }

    open fun documentChanges(includeMetadataChanges: Boolean): Array<DocumentChange> {
        return Array(snap.getDocumentChanges(if (includeMetadataChanges) com.google.firebase.firestore.MetadataChanges.INCLUDE else com.google.firebase.firestore.MetadataChanges.EXCLUDE)
            .map({ it -> DocumentChange(change = it) }))
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

enum class AggregateSource {
    server;

    companion object {
    }
}

enum class FirestoreSource {
    default,
    server,
    cache;

    val source: com.google.firebase.firestore.Source
        get() {
            when (this) {
                default -> return com.google.firebase.firestore.Source.DEFAULT
                cache -> return com.google.firebase.firestore.Source.CACHE
                server -> return com.google.firebase.firestore.Source.SERVER
            }
        }

    companion object {
    }
}

class AggregateField: KotlinConverting<com.google.firebase.firestore.AggregateField> {
    val agg: com.google.firebase.firestore.AggregateField

    constructor(agg: com.google.firebase.firestore.AggregateField) {
        this.agg = agg.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.AggregateField = agg.sref()

    val description: String
        get() = agg.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is AggregateField) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.agg == rhs.agg
    }

    companion object {

        fun count(): AggregateField = AggregateField(agg = com.google.firebase.firestore.AggregateField.count())

        fun average(fieldName: String): AggregateField = AggregateField(agg = com.google.firebase.firestore.AggregateField.average(fieldName))

        fun average(field: FieldPath): AggregateField = AggregateField(agg = com.google.firebase.firestore.AggregateField.average(field.fieldPath))

        fun sum(fieldName: String): AggregateField = AggregateField(agg = com.google.firebase.firestore.AggregateField.sum(fieldName))

        fun sum(field: FieldPath): AggregateField = AggregateField(agg = com.google.firebase.firestore.AggregateField.sum(field.fieldPath))
    }
}

open class AggregateQuerySnapshot: KotlinConverting<com.google.firebase.firestore.AggregateQuerySnapshot> {
    val snap: com.google.firebase.firestore.AggregateQuerySnapshot

    constructor(snap: com.google.firebase.firestore.AggregateQuerySnapshot) {
        this.snap = snap.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.AggregateQuerySnapshot = snap.sref()

    open val description: String
        get() = snap.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is AggregateQuerySnapshot) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.snap == rhs.snap
    }

    open val count: Long
        get() = snap.count

    open val query: AggregateQuery
        get() = AggregateQuery(query = snap.query)

    open fun get(aggregateField: AggregateField): Any? {
        val value_0 = snap.get(aggregateField.agg)
        if (value_0 == null) {
            return null
        }
        return deepSwift(value = value_0)
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class DocumentChange: KotlinConverting<com.google.firebase.firestore.DocumentChange> {
    val change: com.google.firebase.firestore.DocumentChange

    constructor(change: com.google.firebase.firestore.DocumentChange) {
        this.change = change.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.DocumentChange = change.sref()

    open val description: String
        get() = change.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is DocumentChange) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.change == rhs.change
    }

    open val document: QueryDocumentSnapshot
        get() = QueryDocumentSnapshot(snapshot = change.document)

    open val type: DocumentChangeType
        get() {
            when (change.type) {
                com.google.firebase.firestore.DocumentChange.Type.ADDED -> return DocumentChangeType.added
                com.google.firebase.firestore.DocumentChange.Type.MODIFIED -> return DocumentChangeType.modified
                com.google.firebase.firestore.DocumentChange.Type.REMOVED -> return DocumentChangeType.removed
            }
        }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

enum class DocumentChangeType {
    added,
    modified,
    removed;

    companion object {
    }
}

open class DocumentSnapshot: KotlinConverting<com.google.firebase.firestore.DocumentSnapshot> {
    val doc: com.google.firebase.firestore.DocumentSnapshot

    constructor(doc: com.google.firebase.firestore.DocumentSnapshot) {
        this.doc = doc.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.DocumentSnapshot = doc.sref()

    open val description: String
        get() = doc.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is DocumentSnapshot) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.doc == rhs.doc
    }

    open val documentID: String
        get() = doc.getId()

    open val exists: Boolean
        get() = doc.exists()

    open fun data(): Dictionary<String, Any>? {
        val matchtarget_0 = doc.getData()
        if (matchtarget_0 != null) {
            val data = matchtarget_0
            return deepSwift(map = data)
        } else {
            return null
        }
    }

    open fun get(fieldName: String): Any? {
        val value_1 = doc.get(fieldName)
        if (value_1 == null) {
            return null
        }
        return deepSwift(value = value_1)
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class QueryDocumentSnapshot: DocumentSnapshot {
    open val snapshot: com.google.firebase.firestore.QueryDocumentSnapshot
        get() = doc as com.google.firebase.firestore.QueryDocumentSnapshot

    constructor(snapshot: com.google.firebase.firestore.QueryDocumentSnapshot): super(doc = snapshot) {
    }

    open val reference: DocumentReference
        get() = DocumentReference(ref = snapshot.reference)

    override fun data(): Dictionary<String, Any> {
        val matchtarget_1 = doc.getData()
        if (matchtarget_1 != null) {
            val data = matchtarget_1
            return deepSwift(map = data)
        } else {
            return dictionaryOf()
        }
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass: DocumentSnapshot.CompanionClass() {
    }
}

open class DocumentReference: KotlinConverting<com.google.firebase.firestore.DocumentReference> {
    val ref: com.google.firebase.firestore.DocumentReference

    constructor(ref: com.google.firebase.firestore.DocumentReference) {
        this.ref = ref.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.firestore.DocumentReference = ref.sref()

    open val description: String
        get() = ref.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is DocumentReference) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.ref == rhs.ref
    }

    open val firestore: Firestore
        get() = Firestore(store = ref.firestore)

    open suspend fun getDocument(): DocumentSnapshot = Async.run l@{
        return@l DocumentSnapshot(doc = ref.get().await())
    }

    open fun getDocument(completion: (DocumentSnapshot?, Error?) -> Unit) {
        ref.get().addOnSuccessListener { documentSnapshot -> completion(DocumentSnapshot(doc = documentSnapshot), null) }
            .addOnFailureListener { exception -> completion(null, ErrorException(exception)) }
    }

    open val parent: CollectionReference
        get() = CollectionReference(ref = ref.parent)

    open val documentID: String
        get() = ref.getId()

    open val path: String
        get() = ref.path

    open suspend fun delete(): Unit = Async.run {
        ref.delete().await()
    }

    open suspend fun setData(keyValues: Dictionary<String, Any>, merge: Boolean = false): Unit = Async.run {
        if (merge == true) {
            ref.set(keyValues.kotlin(), com.google.firebase.firestore.SetOptions.merge()).await()
        } else {
            ref.set(keyValues.kotlin()).await()
        }
    }

    open suspend fun updateData(keyValues: Dictionary<String, Any>): Unit = Async.run {
        ref.update(keyValues.kotlin() as Map<String, Any>).await()
    }

    open fun collection(collectionPath: String): CollectionReference = CollectionReference(ref = ref.collection(collectionPath))

    open fun addSnapshotListener(listener: (DocumentSnapshot?, Error?) -> Unit): ListenerRegistration {
        return ListenerRegistration(reg = ref.addSnapshotListener { snapshot, error ->
            val ds: DocumentSnapshot? = if (snapshot == null) null else DocumentSnapshot(doc = snapshot!!)
            val err: Error? = error?.aserror()
            listener(ds, err)
        })
    }

    open fun addSnapshotListener(includeMetadataChanges: Boolean, listener: (DocumentSnapshot?, Error?) -> Unit): ListenerRegistration {
        return ListenerRegistration(reg = ref.addSnapshotListener(if (includeMetadataChanges) com.google.firebase.firestore.MetadataChanges.INCLUDE else com.google.firebase.firestore.MetadataChanges.EXCLUDE) { snapshot, error ->
            val ds: DocumentSnapshot? = if (snapshot == null) null else DocumentSnapshot(doc = snapshot!!)
            val err: Error? = error?.aserror()
            listener(ds, err)
        })
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class Timestamp: KotlinConverting<com.google.firebase.Timestamp> {
    val timestamp: com.google.firebase.Timestamp

    constructor(timestamp: com.google.firebase.Timestamp) {
        this.timestamp = timestamp.sref()
    }

    constructor(date: Date) {
        this.timestamp = com.google.firebase.Timestamp(date.kotlin())
    }

    constructor(seconds: Long, nanoseconds: Int) {
        this.timestamp = com.google.firebase.Timestamp(seconds, nanoseconds)
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.Timestamp = timestamp.sref()

    open val description: String
        get() = timestamp.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is Timestamp) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.timestamp == rhs.timestamp
    }

    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    open fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(timestamp.hashCode())
    }

    open fun dateValue(): Date = Date(platformValue = timestamp.toDate())

    open fun toDate(): Date = dateValue()

    open val seconds: Long
        get() = timestamp.seconds

    open val nanoseconds: Int
        get() = timestamp.nanoseconds

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class WriteBatch {
    val batch: com.google.firebase.firestore.WriteBatch

    constructor(batch: com.google.firebase.firestore.WriteBatch) {
        this.batch = batch.sref()
    }

    open suspend fun commit(): Unit = Async.run {
        batch.commit().await()
    }

    open fun deleteDocument(document: DocumentReference): WriteBatch {
        val newBatch = batch.delete(document.ref)
        return WriteBatch(batch = newBatch)
    }

    open fun setData(data: Dictionary<String, Any>, forDocument: DocumentReference): WriteBatch {
        val document = forDocument
        val newBatch = batch.set(document.ref, data.kotlin())
        return WriteBatch(batch = newBatch)
    }

    open fun setData(data: Dictionary<String, Any>, forDocument: DocumentReference, mergeFields: Array<String>): WriteBatch {
        val document = forDocument
        val newBatch = batch.set(document.ref, data.kotlin(), com.google.firebase.firestore.SetOptions.mergeFields(mergeFields.toList()))
        return WriteBatch(batch = newBatch)
    }

    open fun updateData(fields: Dictionary<AnyHashable, Any>, forDocument: DocumentReference): WriteBatch {
        val document = forDocument
        val newBatch = batch.update(document.ref, fields.kotlin() as Map<String, Any>)
        return WriteBatch(batch = newBatch)
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class FieldValue {

    companion object: CompanionClass() {
        override fun arrayRemove(elements: Array<Any>): com.google.firebase.firestore.FieldValue {
            val elementsArray: kotlin.Array<Any> = elements.toList().toTypedArray()
            return com.google.firebase.firestore.FieldValue.arrayRemove(*elementsArray)
        }

        override fun arrayUnion(elements: Array<Any>): com.google.firebase.firestore.FieldValue {
            val elementsArray: kotlin.Array<Any> = elements.toList().toTypedArray()
            return com.google.firebase.firestore.FieldValue.arrayUnion(*elementsArray)
        }

        override fun delete(): com.google.firebase.firestore.FieldValue = com.google.firebase.firestore.FieldValue.delete()

        override fun increment(d: Double): com.google.firebase.firestore.FieldValue = com.google.firebase.firestore.FieldValue.increment(d)

        override fun increment(l: Long): com.google.firebase.firestore.FieldValue = com.google.firebase.firestore.FieldValue.increment(l)

        override fun serverTimestamp(): com.google.firebase.firestore.FieldValue = com.google.firebase.firestore.FieldValue.serverTimestamp()
    }
    open class CompanionClass {
        open fun arrayRemove(elements: Array<Any>): com.google.firebase.firestore.FieldValue = FieldValue.arrayRemove(elements)
        open fun arrayUnion(elements: Array<Any>): com.google.firebase.firestore.FieldValue = FieldValue.arrayUnion(elements)
        open fun delete(): com.google.firebase.firestore.FieldValue = FieldValue.delete()
        open fun increment(d: Double): com.google.firebase.firestore.FieldValue = FieldValue.increment(d)
        open fun increment(l: Long): com.google.firebase.firestore.FieldValue = FieldValue.increment(l)
        open fun serverTimestamp(): com.google.firebase.firestore.FieldValue = FieldValue.serverTimestamp()
    }
}

// MARK: Utilies for converting between Swift and Kotlin types

private fun deepSwift(value: Any): Any {
    val matchtarget_2 = value as? String
    if (matchtarget_2 != null) {
        val str = matchtarget_2
        return str // needed to not be treated as a Collection
    } else {
        val matchtarget_3 = value as? com.google.firebase.Timestamp
        if (matchtarget_3 != null) {
            val ts = matchtarget_3
            return Timestamp(timestamp = ts)
        } else {
            val matchtarget_4 = value as? kotlin.collections.Map<Any, Any>
            if (matchtarget_4 != null) {
                val map = matchtarget_4
                return deepSwift(map = map)
            } else {
                val matchtarget_5 = value as? kotlin.collections.Collection<Any>
                if (matchtarget_5 != null) {
                    val collection = matchtarget_5
                    return deepSwift(collection = collection)
                } else {
                    return value.sref()
                }
            }
        }
    }
}

private fun <T> deepSwift(map: kotlin.collections.Map<T, Any>): Dictionary<T, Any> {
    var dict = Dictionary<T, Any>()
    for ((key, value) in map.sref()) {
        dict[key] = deepSwift(value = value)
    }
    return dict.sref()
}

private fun deepSwift(collection: kotlin.collections.Collection<Any>): Array<Any> {
    var array = Array<Any>()
    for (value in collection.sref()) {
        array.append(deepSwift(value = value))
    }
    return array.sref()
}

