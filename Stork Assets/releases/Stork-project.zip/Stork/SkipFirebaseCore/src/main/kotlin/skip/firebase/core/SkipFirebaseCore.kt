// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.firebase.core

import skip.lib.*

import skip.foundation.*

// https://firebase.google.com/docs/reference/swift/firebasecore/api/reference/Classes/FirebaseApp
// https://firebase.google.com/docs/reference/android/com/google/firebase/FirebaseApp

class FirebaseApp: KotlinConverting<com.google.firebase.FirebaseApp> {
    val app: com.google.firebase.FirebaseApp

    constructor(app: com.google.firebase.FirebaseApp) {
        this.app = app.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.FirebaseApp = app.sref()

    val description: String
        get() = app.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is FirebaseApp) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.app == rhs.app
    }

    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(app.hashCode())
    }

    val name: String
        get() = app.name

    val options: FirebaseOptions
        get() = FirebaseOptions(options = app.options)

    var isDataCollectionDefaultEnabled: Boolean
        get() = app.isDataCollectionDefaultEnabled()
        set(newValue) {
            app.setDataCollectionDefaultEnabled(newValue)
        }

    fun delete(): Boolean {
        app.delete()
        return true
    }

    companion object {

        fun configure(name: String, options: FirebaseOptions) {
            com.google.firebase.FirebaseApp.initializeApp(skip.foundation.ProcessInfo.processInfo.androidContext, options.buildOptions(), name)
            return
        }

        fun configure(options: FirebaseOptions) {
            com.google.firebase.FirebaseApp.initializeApp(skip.foundation.ProcessInfo.processInfo.androidContext, options.buildOptions())
            return
        }

        fun configure() {
            com.google.firebase.FirebaseApp.initializeApp(skip.foundation.ProcessInfo.processInfo.androidContext)
            return
        }

        fun app(): FirebaseApp? {
            try {
                val app_0 = com.google.firebase.FirebaseApp.getInstance()
                if (app_0 == null) {
                    return null // Firebase throws an exception if getInstance fails, but Swift expects just a nil return
                }
                return FirebaseApp(app = app_0)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                android.util.Log.e("SkipFirebaseCore", "error getting FirebaseApp instance", error as? Throwable)
                return null
            }
        }

        fun app(name: String): FirebaseApp? {
            try {
                val app_1 = try { com.google.firebase.FirebaseApp.getInstance(name) } catch (_: Throwable) { null }
                if (app_1 == null) {
                    return null // Firebase throws an exception if getInstance fails, but Swift expects just a nil return
                }
                return FirebaseApp(app = app_1)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                // the Swift API raises an NSException, which will crash a Swft app
                android.util.Log.e("SkipFirebaseCore", "error getting FirebaseApp instance named '${name}'", error as? Throwable)
                return null
            }
        }
    }
}


// https://firebase.google.com/docs/reference/swift/firebasecore/api/reference/Classes/FirebaseOptions
// https://firebase.google.com/docs/reference/android/com/google/firebase/FirebaseOptions

class FirebaseOptions {
    var googleAppID: String
    lateinit var gcmSenderID: String
    var projectID: String? = null
    var storageBucket: String? = null
    var apiKey: String? = null
    var databaseURL: String? = null

    constructor(googleAppID: String, gcmSenderID: String) {
        this.googleAppID = googleAppID
        this.gcmSenderID = gcmSenderID
    }

    constructor(options: com.google.firebase.FirebaseOptions) {
        this.googleAppID = options.applicationId
        this.gcmSenderID = options.gcmSenderId ?: ""
        this.projectID = options.projectId
        this.storageBucket = options.storageBucket
        this.apiKey = options.apiKey
        this.databaseURL = options.databaseUrl
    }

    internal fun buildOptions(): com.google.firebase.FirebaseOptions {
        var builder = com.google.firebase.FirebaseOptions.Builder()
            .setApplicationId(googleAppID)
            .setGcmSenderId(gcmSenderID)
        projectID?.let { projectID ->
            builder = builder.setProjectId(projectID)
        }

        storageBucket?.let { storageBucket ->
            builder = builder.setStorageBucket(storageBucket)
        }

        apiKey?.let { apiKey ->
            builder = builder.setApiKey(apiKey)
        }

        databaseURL?.let { databaseURL ->
            builder = builder.setDatabaseUrl(databaseURL)
        }

        return builder.build()
    }

    companion object {
    }
}

