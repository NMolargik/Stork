// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.firebase.auth

import skip.lib.*

import skip.foundation.*
import skip.firebase.core.*
import kotlinx.coroutines.tasks.await
import android.net.Uri

// https://firebase.google.com/docs/reference/swift/firebaseauth/api/reference/Classes/Auth
// https://firebase.google.com/docs/reference/android/com/google/firebase/auth/FirebaseAuth

class Auth {
    val platformValue: com.google.firebase.auth.FirebaseAuth

    constructor(platformValue: com.google.firebase.auth.FirebaseAuth) {
        this.platformValue = platformValue.sref()
    }

    val app: FirebaseApp
        get() = FirebaseApp(app = platformValue.getApp())

    val currentUser: User?
        get() {
            val user_0 = platformValue.currentUser.sref()
            if (user_0 == null) {
                return null
            }
            return User(user_0)
        }

    suspend fun signIn(withEmail: String, password: String): AuthDataResult = Async.run l@{
        val email = withEmail
        val result = platformValue.signInWithEmailAndPassword(email, password).await()
        return@l AuthDataResult(result)
    }

    suspend fun createUser(withEmail: String, password: String): AuthDataResult = Async.run l@{
        val email = withEmail
        val result = platformValue.createUserWithEmailAndPassword(email, password).await()
        return@l AuthDataResult(result)
    }

    fun signOut(): Unit = platformValue.signOut()

    suspend fun sendPasswordReset(withEmail: String): Unit = Async.run {
        val email = withEmail
        platformValue.sendPasswordResetEmail(email).await()
    }

    suspend fun signInAnonymously(): AuthDataResult = Async.run l@{
        val result = platformValue.signInAnonymously().await()
        return@l AuthDataResult(result)
    }

    fun useEmulator(withHost: String, port: Int) {
        val host = withHost
        platformValue.useEmulator(host, port)
    }

    fun addStateDidChangeListener(listener: (Auth, User?) -> Unit): AuthStateListener {
        val stateListener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { auth ->
            val user = if (auth.currentUser != null) User(auth.currentUser!!) else null
            listener(Auth(platformValue = auth), user)
        }
        platformValue.addAuthStateListener(stateListener)
        return AuthStateListener(platformValue = stateListener)
    }

    fun removeStateDidChangeListener(listenerHandle: NSObjectProtocol): Unit = platformValue.removeAuthStateListener((listenerHandle as AuthStateListener).platformValue)

    companion object {

        fun auth(): Auth = Auth(platformValue = com.google.firebase.auth.FirebaseAuth.getInstance())

        fun auth(app: FirebaseApp): Auth = Auth(platformValue = com.google.firebase.auth.FirebaseAuth.getInstance(app.app))
    }
}

open class AuthDataResult: KotlinConverting<com.google.firebase.auth.AuthResult> {
    val platformValue: com.google.firebase.auth.AuthResult

    constructor(platformValue: com.google.firebase.auth.AuthResult) {
        this.platformValue = platformValue.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.auth.AuthResult = platformValue.sref()

    open val description: String
        get() = platformValue.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is AuthDataResult) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.platformValue == rhs.platformValue
    }

    open val user: User
        get() = User(platformValue.user!!)

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class AuthStateListener: NSObjectProtocol {
    val platformValue: com.google.firebase.auth.FirebaseAuth.AuthStateListener

    constructor(platformValue: com.google.firebase.auth.FirebaseAuth.AuthStateListener) {
        this.platformValue = platformValue.sref()
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class User: KotlinConverting<com.google.firebase.auth.FirebaseUser> {
    val platformValue: com.google.firebase.auth.FirebaseUser

    constructor(platformValue: com.google.firebase.auth.FirebaseUser) {
        this.platformValue = platformValue.sref()
    }

    override fun kotlin(nocopy: Boolean): com.google.firebase.auth.FirebaseUser = platformValue.sref()

    open val description: String
        get() = platformValue.toString()

    override fun equals(other: Any?): Boolean {
        if (other !is User) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.platformValue == rhs.platformValue
    }

    open val isAnonymous: Boolean
        get() = platformValue.isAnonymous

    open val providerID: String?
        get() = platformValue.providerId

    open val uid: String
        get() = platformValue.uid

    open val displayName: String?
        get() = platformValue.displayName

    open val photoURL: URL?
        get() {
            val uri_0 = platformValue.photoUrl.sref()
            if (uri_0 == null) {
                return null
            }
            return URL(string = uri_0.toString())
        }

    open val email: String?
        get() = platformValue.email

    open val phoneNumber: String?
        get() = platformValue.phoneNumber

    open fun createProfileChangeRequest(): UserProfileChangeRequest = UserProfileChangeRequest(this)

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

@Suppress("MUST_BE_INITIALIZED_OR_FINAL_OR_ABSTRACT")
open class UserProfileChangeRequest {
    internal open var user: User

    internal constructor(user: User) {
        this.user = user
    }

    open var displayName: String? = null

    open suspend fun commitChanges(): Unit = Async.run {
        val builder = com.google.firebase.auth.UserProfileChangeRequest.Builder()

        displayName?.let { displayName ->
            builder.setDisplayName(displayName)
        }

        val platformChangeRequest: com.google.firebase.auth.UserProfileChangeRequest = builder.build()

        user.platformValue.updateProfile(platformChangeRequest).await()
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

