// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*
import skip.lib.Array

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.ContentAlpha
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonColors
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class Picker<SelectionValue>: View, ListItemAdapting {
    internal val selection: Binding<SelectionValue>
    internal val label: ComposeBuilder
    internal val content: ComposeBuilder

    constructor(selection: Binding<SelectionValue>, content: () -> View, label: () -> View) {
        this.selection = selection.sref()
        this.content = ComposeBuilder.from(content)
        this.label = ComposeBuilder.from(label)
    }

    constructor(titleKey: LocalizedStringKey, selection: Binding<SelectionValue>, content: () -> View): this(selection = selection, content = content, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(titleKey).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    constructor(title: String, selection: Binding<SelectionValue>, content: () -> View): this(selection = selection, content = content, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(verbatim = title).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    @Composable
    override fun ComposeContent(context: ComposeContext) {
        val style = EnvironmentValues.shared._pickerStyle ?: PickerStyle.automatic
        if (style == PickerStyle.segmented) {
            ComposeSegmentedValue(context = context)
        } else if (EnvironmentValues.shared._labelsHidden || style != PickerStyle.navigationLink) {
            // Most picker styles do not display their label outside of a Form (see ComposeListItem)
            val (selectedView, tagViews) = processPickerContent(content = content, selection = selection, context = context)
            ComposeSelectedValue(selectedView = selectedView, tagViews = tagViews, context = context, style = style)
        } else {
            // Navigation link style outside of a List. This style does display its label
            ComposeLabeledValue(context = context, style = style)
        }
    }

    @Composable
    private fun ComposeLabeledValue(context: ComposeContext, style: PickerStyle) {
        val (selectedView, tagViews) = processPickerContent(content = content, selection = selection, context = context)
        val contentContext = context.content()
        val navigator = LocalNavigator.current.sref()
        val title = titleFromLabel(context = contentContext)
        val modifier = context.modifier.clickable(onClick = { ->
            navigator?.navigateToView(PickerSelectionView(title = title, content = content, selection = selection))
        }, enabled = EnvironmentValues.shared.isEnabled)
        ComposeContainer(modifier = modifier, fillWidth = true) { modifier ->
            Row(modifier = modifier, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) { ->
                Box(modifier = Modifier.padding(end = 8.dp).weight(1.0f)) { -> Button.ComposeTextButton(label = label, context = contentContext) }
                ComposeSelectedValue(selectedView = selectedView, tagViews = tagViews, context = contentContext, style = style, performsAction = false)
            }
        }
    }

    @Composable
    private fun ComposeSelectedValue(selectedView: View, tagViews: Array<TagModifierView>?, context: ComposeContext, style: PickerStyle, performsAction: Boolean = true) {
        val selectedValueView = (selectedView ?: processPickerContent(content = content, selection = selection, context = context).element0).sref()
        val selectedValueLabel: View
        val isMenu: Boolean
        if (style == PickerStyle.automatic || style == PickerStyle.menu) {
            selectedValueLabel = HStack(spacing = 2.0) { ->
                ComposeBuilder { composectx: ComposeContext ->
                    selectedValueView.Compose(composectx)
                    Image(systemName = "chevron.down").accessibilityHidden(true).Compose(composectx)
                    ComposeResult.ok
                }
            }
            isMenu = true
        } else {
            selectedValueLabel = selectedValueView.sref()
            isMenu = false
        }
        if (performsAction) {
            val isMenuExpanded = remember { -> mutableStateOf(false) }
            Box { ->
                Button.ComposeTextButton(label = selectedValueLabel, context = context) { -> isMenuExpanded.value = !isMenuExpanded.value }
                if (isMenu) {
                    ComposePickerSelectionMenu(tagViews = tagViews, isExpanded = isMenuExpanded, context = context.content())
                }
            }
        } else {
            var foregroundStyle = (EnvironmentValues.shared._tint ?: Color(colorImpl = { -> MaterialTheme.colorScheme.outline })).sref()
            if (!EnvironmentValues.shared.isEnabled) {
                foregroundStyle = foregroundStyle.opacity(Double(ContentAlpha.disabled))
            }
            selectedValueLabel.foregroundStyle(foregroundStyle).Compose(context = context)
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun ComposeSegmentedValue(context: ComposeContext) {
        val (_, tagViews) = processPickerContent(content = content, selection = selection, context = context, requireTagViews = true)
        val selectedIndex = tagViews?.firstIndex { it -> it.value == selection.wrappedValue }
        val isEnabled = EnvironmentValues.shared.isEnabled
        val colors: SegmentedButtonColors
        val disabledBorderColor = Color.primary.colorImpl().copy(alpha = ContentAlpha.disabled)
        val matchtarget_0 = EnvironmentValues.shared._tint
        if (matchtarget_0 != null) {
            val tint = matchtarget_0
            colors = SegmentedButtonDefaults.colors(activeContainerColor = tint.colorImpl().copy(alpha = 0.15f), disabledActiveBorderColor = disabledBorderColor, disabledInactiveBorderColor = disabledBorderColor)
        } else {
            colors = SegmentedButtonDefaults.colors(disabledActiveBorderColor = disabledBorderColor, disabledInactiveBorderColor = disabledBorderColor)
        }

        val contentContext = context.content()
        val updateOptions = EnvironmentValues.shared._material3SegmentedButton
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillWidth().then(context.modifier)) { ->
            if (tagViews != null) {
                for ((index, tagView) in tagViews.enumerated()) {
                    val isSelected = index == selectedIndex
                    val onClick: () -> Unit = { -> selection.wrappedValue = tagView.value as SelectionValue }
                    val shape = SegmentedButtonDefaults.itemShape(index = index, count = tagViews.count)
                    val borderColor = (if (isSelected) (if (isEnabled) colors.activeBorderColor else colors.disabledActiveBorderColor) else (if (isEnabled) colors.inactiveBorderColor else colors.disabledInactiveBorderColor)).sref()
                    val border = SegmentedButtonDefaults.borderStroke(borderColor)
                    val icon: @Composable () -> Unit = { -> SegmentedButtonDefaults.Icon(isSelected) }
                    var options = Material3SegmentedButtonOptions(index = index, count = tagViews.count, selected = isSelected, onClick = onClick, modifier = Modifier, enabled = isEnabled, shape = shape, colors = colors, border = border, icon = icon)
                    if (updateOptions != null) {
                        options = updateOptions(options)
                    }
                    SegmentedButton(selected = options.selected, onClick = options.onClick, modifier = options.modifier, enabled = options.enabled, shape = options.shape, colors = options.colors, border = options.border, icon = options.icon) { ->
                        val matchtarget_1 = tagView.view as? Label
                        if (matchtarget_1 != null) {
                            val label = matchtarget_1
                            label.ComposeTitle(context = contentContext)
                        } else {
                            tagView.view.Compose(context = contentContext)
                        }
                    }
                }
            }
        }
    }

    @Composable
    override fun shouldComposeListItem(): Boolean = EnvironmentValues.shared._pickerStyle != PickerStyle.segmented

    @Composable
    override fun ComposeListItem(context: ComposeContext, contentModifier: Modifier) {
        val (selectedView, tagViews) = processPickerContent(content = content, selection = selection, context = context)
        val style = EnvironmentValues.shared._pickerStyle ?: PickerStyle.automatic
        var isMenu = false
        val isMenuExpanded = remember { -> mutableStateOf(false) }
        val onClick: () -> Unit
        if (style == PickerStyle.navigationLink) {
            val navigator = LocalNavigator.current.sref()
            val title = titleFromLabel(context = context)
            onClick = { ->
                navigator?.navigateToView(PickerSelectionView(title = title, content = content, selection = selection))
            }
        } else {
            isMenu = true
            onClick = { -> isMenuExpanded.value = !isMenuExpanded.value }
        }
        val modifier = Modifier.clickable(onClick = onClick, enabled = EnvironmentValues.shared.isEnabled).then(contentModifier)
        Row(modifier = modifier, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) { ->
            if (!EnvironmentValues.shared._labelsHidden) {
                Box(modifier = Modifier.padding(end = 8.dp).weight(1.0f)) { -> label.Compose(context = context) }
            }
            Box { ->
                ComposeSelectedValue(selectedView = selectedView, tagViews = tagViews, context = context, style = style, performsAction = false)
                if (isMenu) {
                    ComposePickerSelectionMenu(tagViews = tagViews, isExpanded = isMenuExpanded, context = context)
                }
            }
            if (style == PickerStyle.navigationLink) {
                NavigationLink.ComposeChevron()
            }
        }
    }

    @Composable
    private fun ComposePickerSelectionMenu(tagViews: Array<TagModifierView>?, isExpanded: MutableState<Boolean>, context: ComposeContext) {
        // Create selectable views from the *content* of each tag view, preserving the enclosing tag
        val views = (tagViews ?: processPickerContent(content = content, selection = selection, context = context, requireTagViews = true).element1 ?: arrayOf()).sref()
        val menuItems = views.map l@{ tagView ->
            val button = Button(action = { -> selection.wrappedValue = tagView.value as SelectionValue }, label = { ->
                ComposeBuilder { composectx: ComposeContext ->
                    tagView.view.Compose(composectx)
                    ComposeResult.ok
                }
            })
            return@l TagModifierView(view = button, value = tagView.value, role = ComposeModifierRole.tag) as View
        }
        DropdownMenu(expanded = isExpanded.value, onDismissRequest = { -> isExpanded.value = false }) { ->
            val coroutineScope = rememberCoroutineScope()
            Menu.ComposeDropdownMenuItems(for_ = menuItems, selection = selection.wrappedValue, context = context, replaceMenu = { _ ->
                coroutineScope.launch { ->
                    delay(200) // Allow menu item selection animation to be visible
                    isExpanded.value = false
                }
            })
        }
    }

    @Composable
    private fun titleFromLabel(context: ComposeContext): Text {
        return label.collectViews(context = context).compactMap { it ->
            it.strippingModifiers(perform = { it -> it as? Text })
        }.first ?: Text(verbatim = String(describing = selection.wrappedValue))
    }

    companion object {
    }
}

class PickerStyle: RawRepresentable<Int> {
    override val rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override fun equals(other: Any?): Boolean {
        if (other !is PickerStyle) return false
        return rawValue == other.rawValue
    }

    companion object {

        val automatic = PickerStyle(rawValue = 1)
        val navigationLink = PickerStyle(rawValue = 2)
        val segmented = PickerStyle(rawValue = 3)

        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val inline = PickerStyle(rawValue = 4)

        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val wheel = PickerStyle(rawValue = 5)

        val menu = PickerStyle(rawValue = 6)

        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val palette = PickerStyle(rawValue = 7)
    }
}

@Composable
internal fun <SelectionValue> processPickerContent(content: ComposeBuilder, selection: Binding<SelectionValue>, context: ComposeContext, requireTagViews: Boolean = false): Tuple2<View, Array<TagModifierView>?> {
    val selectedTag = selection.wrappedValue.sref()
    val viewCollectingComposer = PickerViewCollectingComposer(selectedTag = selectedTag, requireTagViews = requireTagViews)
    val viewCollector = context.content(composer = viewCollectingComposer)

    EnvironmentValues.shared.setValues({ it -> it.set_placement(ViewPlacement.tagged) }, in_ = { -> content.Compose(viewCollector) })
    var selectedView = viewCollectingComposer.selectedView.sref()

    val tagViews: Array<TagModifierView>?
    val matchtarget_2 = viewCollectingComposer.tagViews
    if (matchtarget_2 != null) {
        val views = matchtarget_2
        tagViews = Array(views, nocopy = true)
    } else {
        tagViews = null
    }
    if ((selectedView == null) && (tagViews != null)) {
        selectedView = tagViews.first { it -> it.value == selectedTag }
    }
    return Tuple2((selectedView ?: EmptyView()).sref(), tagViews.sref())
}

internal class PickerViewCollectingComposer<SelectionValue>: SideEffectComposer, ForEachComposer {
    internal val selectedTag: SelectionValue
    internal val requireTagViews: Boolean
    internal var selectedView: View? = null
        get() = field.sref({ this.selectedView = it })
        set(newValue) {
            field = newValue.sref()
        }
    internal var tagViews: MutableList<TagModifierView>? = null
        get() = field.sref({ this.tagViews = it })
        set(newValue) {
            field = newValue.sref()
        }
    private var isFirstView = true

    internal constructor(selectedTag: SelectionValue, requireTagViews: Boolean): super() {
        this.selectedTag = selectedTag.sref()
        this.requireTagViews = requireTagViews
    }

    @Composable
    override fun Compose(view: View, context: (Boolean) -> ComposeContext): ComposeResult {
        val isFirstView = this.isFirstView
        this.isFirstView = false
        val matchtarget_3 = view as? ForEach
        if (matchtarget_3 != null) {
            val forEach = matchtarget_3
            if (isFirstView && !requireTagViews) {
                val matchtarget_4 = forEach.untaggedView(forTag = selectedTag, context = context(false))
                if (matchtarget_4 != null) {
                    val selectedView = matchtarget_4
                    this.selectedView = selectedView
                } else if (selectedView == null) {
                    forEach.ComposeContent(context = context(true))
                }
            } else if (selectedView == null) {
                forEach.ComposeContent(context = context(true))
            }
        } else {
            if (selectedView == null) {
                TagModifierView.strip(from = view, role = ComposeModifierRole.tag)?.let { taggedView ->
                    if (tagViews == null) {
                        tagViews = mutableListOf()
                    }
                    tagViews!!.add(taggedView)
                }
            }
        }
        return ComposeResult.ok
    }

    companion object: SideEffectComposer.CompanionClass() {
    }
}

internal class PickerSelectionView<SelectionValue>: View {
    internal val title: Text
    internal val content: View
    internal val selection: Binding<SelectionValue>

    private var selectionValue: SelectionValue
        get() = _selectionValue.wrappedValue.sref({ this.selectionValue = it })
        set(newValue) {
            _selectionValue.wrappedValue = newValue.sref()
        }
    private var _selectionValue: skip.ui.State<SelectionValue>
    private lateinit var dismiss: DismissAction

    internal constructor(title: Text, content: View, selection: Binding<SelectionValue>) {
        this.title = title
        this.content = content.sref()
        this.selection = selection.sref()
        this._selectionValue = State(initialValue = selection.wrappedValue)
    }

    override fun body(): View {
        return ComposeBuilder { composectx: ComposeContext ->
            List(fixedContent = content, itemTransformer = { it -> rowView(label = it) })
                .environment({ it -> EnvironmentValues.shared.set_placement(it) }, ViewPlacement.tagged)
                .navigationTitle(title).Compose(composectx)
        }
    }

    @Composable
    @Suppress("UNCHECKED_CAST")
    override fun ComposeContent(composectx: ComposeContext) {
        val rememberedselectionValue by rememberSaveable(stateSaver = composectx.stateSaver as Saver<skip.ui.State<SelectionValue>, Any>) { mutableStateOf(_selectionValue) }
        _selectionValue = rememberedselectionValue

        dismiss = EnvironmentValues.shared.dismiss

        super.ComposeContent(composectx)
    }

    private fun rowView(label: View): View {
        return ComposeBuilder l@{ composectx: ComposeContext ->
            val labelValue = (TagModifierView.strip(from = label, role = ComposeModifierRole.tag)?.value as? SelectionValue).sref()
            return@l Button(action = { ->
                if (labelValue != null) {
                    selection.wrappedValue = labelValue
                    this.selectionValue = labelValue // Update the checkmark in the UI while we dismiss
                }
                dismiss()
            }, label = { ->
                ComposeBuilder { composectx: ComposeContext ->
                    HStack { ->
                        ComposeBuilder { composectx: ComposeContext ->
                            // The embedded ZStack allows us to fill the width without a Spacer, which in Compose will share equal space with
                            // the label if it also wants to expand to fill space
                            ZStack { ->
                                ComposeBuilder { composectx: ComposeContext ->
                                    label.Compose(composectx)
                                    ComposeResult.ok
                                }
                            }
                            .frame(maxWidth = Double.infinity, alignment = Alignment.leading).Compose(composectx)
                            Image(systemName = "checkmark")
                                .foregroundStyle(EnvironmentValues.shared._tint ?: Color.accentColor)
                                .opacity(if (labelValue == selectionValue) 1.0 else 0.0).Compose(composectx)
                            ComposeResult.ok
                        }
                    }.Compose(composectx)
                    ComposeResult.ok
                }
            })
            .buttonStyle(ButtonStyle.plain).Compose(composectx)
            ComposeResult.ok
        }
    }
}

@Suppress("MUST_BE_INITIALIZED")
class Material3SegmentedButtonOptions: MutableStruct {
    val index: Int
    val count: Int
    var selected: Boolean
        get() = field.sref({ this.selected = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var onClick: () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var modifier: Modifier
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var enabled: Boolean
        get() = field.sref({ this.enabled = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var shape: androidx.compose.ui.graphics.Shape
        get() = field.sref({ this.shape = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var colors: SegmentedButtonColors
        get() = field.sref({ this.colors = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var border: BorderStroke
        get() = field.sref({ this.border = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var contentPadding: PaddingValues
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var interactionSource: MutableInteractionSource? = null
        get() = field.sref({ this.interactionSource = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var icon: @Composable () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    fun copy(selected: Boolean = this.selected, onClick: () -> Unit = this.onClick, modifier: Modifier = this.modifier, enabled: Boolean = this.enabled, shape: androidx.compose.ui.graphics.Shape = this.shape, colors: SegmentedButtonColors = this.colors, border: BorderStroke = this.border, contentPadding: PaddingValues = this.contentPadding, interactionSource: MutableInteractionSource? = this.interactionSource, icon: @Composable () -> Unit = this.icon): Material3SegmentedButtonOptions = Material3SegmentedButtonOptions(index = index, count = count, selected = selected, onClick = onClick, modifier = modifier, enabled = enabled, shape = shape, colors = colors, border = border, contentPadding = contentPadding, interactionSource = interactionSource, icon = icon)

    constructor(index: Int, count: Int, selected: Boolean, onClick: () -> Unit, modifier: Modifier, enabled: Boolean, shape: androidx.compose.ui.graphics.Shape, colors: SegmentedButtonColors, border: BorderStroke, contentPadding: PaddingValues = SegmentedButtonDefaults.ContentPadding, interactionSource: MutableInteractionSource? = null, icon: @Composable () -> Unit) {
        this.index = index
        this.count = count
        this.selected = selected
        this.onClick = onClick
        this.modifier = modifier
        this.enabled = enabled
        this.shape = shape
        this.colors = colors
        this.border = border
        this.contentPadding = contentPadding
        this.interactionSource = interactionSource
        this.icon = icon
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Material3SegmentedButtonOptions(index, count, selected, onClick, modifier, enabled, shape, colors, border, contentPadding, interactionSource, icon)

    companion object {
    }
}

