// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*
import skip.lib.Set

import skip.foundation.*
import android.content.Intent
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import java.lang.ref.WeakReference

internal val logger: SkipLogger = SkipLogger(subsystem = "skip.ui", category = "SkipUI") // adb logcat '*:S' 'skip.ui.SkipUI:V'

open class UIApplication {

    private constructor() {
        suppresssideeffects = true
        try {
            val lifecycle = ProcessLifecycleOwner.get().lifecycle.sref()
            lifecycle.addObserver(UIApplicationLifecycleEventObserver(application = this))
        } finally {
            suppresssideeffects = false
        }
    }

    /// The Android main activity.
    ///
    /// This API mirrors `ProcessInfo.androidContext` for the application context.
    open var androidActivity: AppCompatActivity?
        get() {
            val activity = androidActivityReference?.get()
            return (if (activity?.isDestroyed == false) activity else null).sref({ this.androidActivity = it })
        }
        internal set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            if (newValue != null) {
                androidActivityReference = WeakReference(newValue)
            } else {
                androidActivityReference = null
            }
            if (isIdleTimerDisabled) {
                setWindowFlagsForIsIdleTimerDisabled()
            }
        }
    private var androidActivityReference: WeakReference<AppCompatActivity>? = null
        get() = field.sref({ this.androidActivityReference = it })
        set(newValue) {
            field = newValue.sref()
        }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open var delegate: Any?
        get() {
            fatalError()
        }
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
        }

    open var isIdleTimerDisabled = false
        set(newValue) {
            field = newValue
            if (!suppresssideeffects) {
                setWindowFlagsForIsIdleTimerDisabled()
            }
        }

    private fun setWindowFlagsForIsIdleTimerDisabled() {
        val flags = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.sref()
        if (isIdleTimerDisabled) {
            androidActivity?.window?.addFlags(flags)
        } else {
            androidActivity?.window?.clearFlags(flags)
        }
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun canOpenURL(url: URL): Boolean {
        fatalError()
    }

    open suspend fun open(url: URL, options: Dictionary<UIApplication.OpenExternalURLOptionsKey, Any> = dictionaryOf()): Boolean = MainActor.run l@{
        val context = ProcessInfo.processInfo.androidContext.sref()
        try {
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url.absoluteString))
            // needed or else: android.util.AndroidRuntimeException: Calling startActivity() from outside of an Activity context requires the FLAG_ACTIVITY_NEW_TASK flag. Is this really what you want?
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return@l true
        } catch (error: Throwable) {
            @Suppress("NAME_SHADOWING") val error = error.aserror()
            logger.warning("UIApplication.launch error: ${error}")
            return@l false
        }
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun sendEvent(event: Any) = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun sendAction(action: Any, to: Any?, from: Any?, for_: Any?): Boolean {
        val target = to
        val sender = from
        val event = for_
        fatalError()
    }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun supportedInterfaceOrientations(for_: Any?): Any {
        val window = for_
        fatalError()
    }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open var applicationSupportsShakeToEdit: Boolean
        get() {
            fatalError()
        }
        set(newValue) {
        }

    open var applicationState: UIApplication.State
        get() = _applicationState.value
        internal set(newValue) {
            _applicationState.value = newValue
        }
    private val _applicationState: MutableState<UIApplication.State> = mutableStateOf(UIApplication.State.active)

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val backgroundTimeRemaining: Double
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun beginBackgroundTask(expirationHandler: (() -> Unit)? = null): Any {
        val handler = expirationHandler
        fatalError()
    }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun beginBackgroundTask(withName: String?, expirationHandler: (() -> Unit)? = null): Any {
        val taskName = withName
        val handler = expirationHandler
        fatalError()
    }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun endBackgroundTask(identifier: Any) = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val backgroundRefreshStatus: Any
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val isProtectedDataAvailable: Boolean
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val userInterfaceLayoutDirection: Any
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val preferredContentSizeCategory: Any
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val connectedScenes: Set<AnyHashable>
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val openSessions: Set<AnyHashable>
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val supportsMultipleScenes: Boolean
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun requestSceneSessionDestruction(sceneSession: Any, options: Any?, errorHandler: ((Error) -> Unit)? = null) = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun requestSceneSessionRefresh(sceneSession: Any) = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun activateSceneSession(for_: Any, errorHandler: ((Error) -> Unit)? = null) = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun registerForRemoteNotifications() = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun unregisterForRemoteNotifications() = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val isRegisteredForRemoteNotifications: Boolean
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun beginReceivingRemoteControlEvents() = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun endReceivingRemoteControlEvents() = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val shortcutItems: Any?
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val supportsAlternateIcons: Boolean
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun setAlternateIconName(alternateIconName: String?, completionHandler: ((Error?) -> Unit)? = null) = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open suspend fun setAlternateIconName(alternateIconName: String?): Unit = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open val alternateIconName: String?
        get() {
            fatalError()
        }
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun extendStateRestoration() = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun completeStateRestoration() = Unit
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun ignoreSnapshotOnNextApplicationLaunch() = Unit

    enum class State(override val rawValue: Int, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): RawRepresentable<Int> {
        active(0),
        inactive(1),
        background(2);

        companion object {
            fun init(rawValue: Int): UIApplication.State? {
                return when (rawValue) {
                    0 -> State.active
                    1 -> State.inactive
                    2 -> State.background
                    else -> null
                }
            }
        }
    }

    class OpenExternalURLOptionsKey: RawRepresentable<String> {
        override val rawValue: String
        constructor(rawValue: String) {
            this.rawValue = rawValue
        }

        override fun equals(other: Any?): Boolean {
            if (other !is UIApplication.OpenExternalURLOptionsKey) return false
            return rawValue == other.rawValue
        }

        override fun hashCode(): Int {
            var result = 1
            result = Hasher.combine(result, rawValue)
            return result
        }

        companion object {

            val universalLinksOnly = OpenExternalURLOptionsKey(rawValue = "universalLinksOnly")
            val eventAttribution = OpenExternalURLOptionsKey(rawValue = "eventAttribution")
        }
    }

    private var suppresssideeffects = false

    companion object: CompanionClass() {
        override val shared = UIApplication()

        /// Setup the Android main activity.
        ///
        /// This API mirrors `ProcessInfo.launch` for the application context.
        override fun launch(activity: AppCompatActivity) {
            if (activity !== shared.androidActivity) {
                shared.androidActivity = activity
                UNUserNotificationCenter.launch(activity)
            }
        }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val openNotificationSettingsURLString: String
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        fun registerObject(forStateRestoration: Any, restorationIdentifier: String) = Unit
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val didEnterBackgroundNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val willEnterForegroundNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val didFinishLaunchingNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val didBecomeActiveNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val willResignActiveNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val didReceiveMemoryWarningNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val willTerminateNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val significantTimeChangeNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val backgroundRefreshStatusDidChangeNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val protectedDataWillBecomeUnavailableNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val protectedDataDidBecomeAvailableNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val openSettingsURLString: String
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val userDidTakeScreenshotNotification: Notification.Name
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val invalidInterfaceOrientationException: Any
            get() {
                fatalError()
            }

        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val backgroundFetchIntervalMinimum: Double
            get() {
                fatalError()
            }
        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val backgroundFetchIntervalNever: Double
            get() {
                fatalError()
            }

        override fun State(rawValue: Int): UIApplication.State? = State.init(rawValue = rawValue)
    }
    open class CompanionClass {
        open val shared
            get() = UIApplication.shared
        open fun launch(activity: AppCompatActivity) = UIApplication.launch(activity)
        open fun State(rawValue: Int): UIApplication.State? = UIApplication.State(rawValue = rawValue)
    }
}

internal class UIApplicationLifecycleEventObserver: LifecycleEventObserver, DefaultLifecycleObserver {
    internal val application: UIApplication

    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        for (unusedi in 0..0) {
            when (event) {
                Lifecycle.Event.ON_CREATE -> break
                Lifecycle.Event.ON_START -> break
                Lifecycle.Event.ON_RESUME -> application.applicationState = UIApplication.State.active
                Lifecycle.Event.ON_PAUSE -> application.applicationState = UIApplication.State.inactive
                Lifecycle.Event.ON_STOP -> application.applicationState = UIApplication.State.background
                Lifecycle.Event.ON_DESTROY -> break
                Lifecycle.Event.ON_ANY -> break
            }
        }
    }

    constructor(application: UIApplication) {
        this.application = application
    }
}
