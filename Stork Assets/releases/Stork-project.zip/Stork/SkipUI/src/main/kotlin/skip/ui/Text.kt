// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.DrawModifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.UrlAnnotation
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import skip.foundation.LocalizedStringResource
import skip.foundation.Bundle
import skip.foundation.Locale

class Text: View {
    private val textView: _Text
    private val modifiedView: View

    constructor(verbatim: String) {
        textView = _Text(verbatim = verbatim)
        modifiedView = textView
    }

    constructor(attributedContent: AttributedString) {
        textView = _Text(attributedString = attributedContent)
        modifiedView = textView
    }

    constructor(key: LocalizedStringKey, tableName: String? = null, bundle: Bundle? = Bundle.main, comment: String? = null) {
        textView = _Text(key = key, tableName = tableName, bundle = bundle)
        modifiedView = textView
    }

    constructor(key: String, tableName: String? = null, bundle: Bundle? = Bundle.main, comment: String? = null) {
        textView = _Text(key = LocalizedStringKey(stringLiteral = key), tableName = tableName, bundle = bundle)
        modifiedView = textView
    }

    constructor(date: Date, style: Text.DateStyle): this(verbatim = style.format(date)) {
    }

    internal constructor(textView: _Text, modifiedView: View) {
        this.textView = textView
        // Don't copy view
        this.modifiedView = modifiedView
    }

    /// Interpret the key against the given bundle and the environment's current locale.
    @Composable
    fun localizedTextString(): String = textView.localizedTextString()

    @Composable
    override fun ComposeContent(context: ComposeContext) {
        modifiedView.Compose(context = context)
    }

    override fun equals(other: Any?): Boolean {
        if (other !is Text) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.textView == rhs.textView
    }

    // Text-specific implementations of View modifiers

    override fun accessibilityLabel(label: Text): Text = Text(textView = textView, modifiedView = modifiedView.accessibilityLabel(label))

    override fun accessibilityLabel(label: String): Text = Text(textView = textView, modifiedView = modifiedView.accessibilityLabel(label))

    override fun foregroundColor(color: Color?): Text = Text(textView = textView, modifiedView = modifiedView.foregroundColor(color))

    override fun foregroundStyle(style: ShapeStyle): Text = Text(textView = textView, modifiedView = modifiedView.foregroundStyle(style))

    override fun font(font: Font?): Text = Text(textView = textView, modifiedView = modifiedView.font(font))

    override fun fontWeight(weight: Font.Weight?): Text = Text(textView = textView, modifiedView = modifiedView.fontWeight(weight))

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    override fun fontWidth(width: Font.Width?): Text = this

    override fun bold(isActive: Boolean): Text = Text(textView = textView, modifiedView = modifiedView.bold(isActive))

    override fun italic(isActive: Boolean): Text = Text(textView = textView, modifiedView = modifiedView.italic(isActive))

    override fun monospaced(isActive: Boolean): Text = Text(textView = textView, modifiedView = modifiedView.monospaced(isActive))

    override fun fontDesign(design: Font.Design?): Text = Text(textView = textView, modifiedView = modifiedView.fontDesign(design))

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    override fun monospacedDigit(): Text = this

    override fun strikethrough(isActive: Boolean, pattern: Text.LineStyle.Pattern, color: Color?): Text = Text(textView = textView, modifiedView = modifiedView.strikethrough(isActive, pattern = pattern, color = color))

    override fun underline(isActive: Boolean, pattern: Text.LineStyle.Pattern, color: Color?): Text = Text(textView = textView, modifiedView = modifiedView.underline(isActive, pattern = pattern, color = color))

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    override fun kerning(kerning: Double): Text = this

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    override fun tracking(tracking: Double): Text = this

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    override fun baselineOffset(baselineOffset: Double): Text = this

    enum class Case: Sendable {
        uppercase,
        lowercase;

        companion object {
        }
    }

    class LineStyle: Sendable {
        val pattern: Text.LineStyle.Pattern
        val color: Color?

        constructor(pattern: Text.LineStyle.Pattern = Text.LineStyle.Pattern.solid, color: Color? = null) {
            this.pattern = pattern
            this.color = color.sref()
        }

        enum class Pattern: Sendable {
            solid,
            dot,
            dash,
            dashot,
            dashDotDot;

            companion object {
            }
        }

        override fun equals(other: Any?): Boolean {
            if (other !is Text.LineStyle) return false
            return pattern == other.pattern && color == other.color
        }

        override fun hashCode(): Int {
            var result = 1
            result = Hasher.combine(result, pattern)
            result = Hasher.combine(result, color)
            return result
        }

        companion object {

            val single = Text.LineStyle()
        }
    }

    enum class Scale: Sendable {
        default,
        secondary;

        companion object {
        }
    }

    enum class TruncationMode: Sendable {
        head,
        tail,
        middle;

        companion object {
        }
    }

    class DateStyle {

        internal val format: (Date) -> String

        private constructor(format: (Date) -> String) {
            this.format = format
        }

        companion object {
            val time = DateStyle(format = l@{ date ->
                val formatter = DateFormatter()
                formatter.timeStyle = DateFormatter.Style.medium
                return@l formatter.string(from = date)
            })

            val date = DateStyle(format = l@{ date ->
                val formatter = DateFormatter()
                formatter.dateStyle = DateFormatter.Style.medium
                return@l formatter.string(from = date)
            })

            @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
            val relative = DateStyle(format = { _ ->
                fatalError()
            })

            @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
            val offset = DateStyle(format = { _ ->
                fatalError()
            })

            @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
            val timer = DateStyle(format = { _ ->
                fatalError()
            })
        }
    }

    companion object {

        /// Gather text style information for the current environment.
        @Composable
        internal fun styleInfo(textEnvironment: TextEnvironment, redaction: RedactionReasons, context: ComposeContext): TextStyleInfo {
            var isUppercased = textEnvironment.textCase == Text.Case.uppercase
            val isLowercased = textEnvironment.textCase == Text.Case.lowercase
            var font: Font
            val matchtarget_0 = EnvironmentValues.shared.font
            if (matchtarget_0 != null) {
                val environmentFont = matchtarget_0
                font = environmentFont
            } else {
                val matchtarget_1 = EnvironmentValues.shared._listSectionHeaderStyle
                if (matchtarget_1 != null) {
                    val sectionHeaderStyle = matchtarget_1
                    font = Font.callout
                    if (sectionHeaderStyle == ListStyle.plain) {
                        font = font.bold()
                    } else {
                        isUppercased = true
                    }
                } else {
                    val matchtarget_2 = EnvironmentValues.shared._listSectionFooterStyle
                    if (matchtarget_2 != null) {
                        val sectionFooterStyle = matchtarget_2
                        if (sectionFooterStyle != ListStyle.plain) {
                            font = Font.footnote
                        } else {
                            font = Font(fontImpl = { -> LocalTextStyle.current })
                        }
                    } else {
                        font = Font(fontImpl = { -> LocalTextStyle.current })
                    }
                }
            }
            textEnvironment.fontWeight?.let { weight ->
                font = font.weight(weight)
            }
            textEnvironment.fontDesign?.let { design ->
                font = font.design(design)
            }
            if (textEnvironment.isItalic == true) {
                font = font.italic()
            }

            var textColor: androidx.compose.ui.graphics.Color? = null
            var textBrush: Brush? = null
            val matchtarget_3 = EnvironmentValues.shared._foregroundStyle
            if (matchtarget_3 != null) {
                val foregroundStyle = matchtarget_3
                val matchtarget_4 = foregroundStyle.asColor(opacity = 1.0, animationContext = context)
                if (matchtarget_4 != null) {
                    val color = matchtarget_4
                    textColor = color
                } else if (!redaction.isEmpty) {
                    textColor = Color.primary.colorImpl()
                } else {
                    textBrush = foregroundStyle.asBrush(opacity = 1.0, animationContext = context)
                }
            } else if (EnvironmentValues.shared._listSectionHeaderStyle != null) {
                textColor = Color.secondary.colorImpl()
            } else {
                val matchtarget_5 = EnvironmentValues.shared._listSectionFooterStyle
                if (matchtarget_5 != null) {
                    val sectionFooterStyle = matchtarget_5
                    if (sectionFooterStyle != ListStyle.plain) {
                        textColor = Color.secondary.colorImpl()
                    } else {
                        textColor = if (EnvironmentValues.shared._placement.contains(ViewPlacement.systemTextColor)) androidx.compose.ui.graphics.Color.Unspecified else Color.primary.colorImpl()
                    }
                } else {
                    textColor = if (EnvironmentValues.shared._placement.contains(ViewPlacement.systemTextColor)) androidx.compose.ui.graphics.Color.Unspecified else Color.primary.colorImpl()
                }
            }

            var style = font.fontImpl()
            // Trim the line height padding to mirror SwiftUI.Text layout. For now we only do this here on the Text component
            // rather than in Font to de-risk this aberration from Compose default text style behavior
            style = style.copy(lineHeightStyle = LineHeightStyle(alignment = LineHeightStyle.Alignment.Center, trim = LineHeightStyle.Trim.Both))
            if (textBrush != null) {
                style = style.copy(brush = textBrush)
            }
            if (redaction.contains(RedactionReasons.placeholder)) {
                if (textColor != null) {
                    style = style.copy(background = textColor.copy(alpha = textColor.alpha * Float(Color.placeholderOpacity)))
                }
                textColor = androidx.compose.ui.graphics.Color.Transparent
            }
            return TextStyleInfo(style = style, color = textColor, isUppercased = isUppercased, isLowercased = isLowercased)
        }
    }
}

internal class _Text: View {
    internal val verbatim: String?
    internal val attributedString: AttributedString?
    internal val key: LocalizedStringKey?
    internal val tableName: String?
    internal val bundle: Bundle?

    internal constructor(verbatim: String? = null, attributedString: AttributedString? = null, key: LocalizedStringKey? = null, tableName: String? = null, bundle: Bundle? = null) {
        this.verbatim = verbatim
        this.attributedString = attributedString
        this.key = key.sref()
        this.tableName = tableName
        this.bundle = bundle
    }

    @Composable
    internal fun localizedTextString(): String {
        val (locfmt, _, interpolations) = localizedTextInfo()
        if ((interpolations != null) && !interpolations.isEmpty()) {
            return locfmt.format(*interpolations.toTypedArray())
        } else {
            return locfmt
        }
    }

    @Composable
    private fun localizedTextInfo(): Tuple3<String, MarkdownNode?, kotlin.collections.List<AnyHashable>?> {
        if (verbatim != null) {
            return Tuple3(verbatim, null, null)
        }
        if (attributedString != null) {
            return Tuple3(attributedString.string, attributedString.markdownNode, null)
        }
        if (key == null) {
            return Tuple3("", null, null)
        }

        // localize and Kotlin-ize the format string. the string is cached by the bundle, and we
        // cache the Kotlin-ized version too so that we don't have to convert it on every compose
        val locale = EnvironmentValues.shared.locale
        val matchtarget_6 = this.bundle?.localizedBundle(locale = locale)
        if (matchtarget_6 != null) {
            val bundle = matchtarget_6
            val (_, locfmt, locnode) = bundle.localizedInfo(forKey = key.patternFormat, value = null, table = this.tableName)
            return Tuple3(locfmt.sref(), locnode.sref(), key.stringInterpolation.values.sref())
        } else {
            return Tuple3(key.patternFormat.kotlinFormatString, MarkdownNode.from(string = key.patternFormat), key.stringInterpolation.values.sref())
        }
    }

    @OptIn(ExperimentalTextApi::class)
    @Composable
    override fun ComposeContent(context: ComposeContext) {
        val (locfmt, locnode, interpolations) = localizedTextInfo()
        val textEnvironment = EnvironmentValues.shared._textEnvironment.sref()
        val textDecoration = textEnvironment.textDecoration.sref()
        val textAlign = EnvironmentValues.shared.multilineTextAlignment.asTextAlign()
        val maxLines = max(1, EnvironmentValues.shared.lineLimit ?: Int.MAX_VALUE)
        val redaction = EnvironmentValues.shared.redactionReasons.sref()
        val styleInfo = Text.styleInfo(textEnvironment = textEnvironment, redaction = redaction, context = context)
        val animatable = styleInfo.style.asAnimatable(context = context)
        var options: Material3TextOptions
        if (locnode != null) {
            val layoutResult = remember { -> mutableStateOf<TextLayoutResult?>(null) }
            val isPlaceholder = redaction.contains(RedactionReasons.placeholder)
            var linkColor = EnvironmentValues.shared._tint?.colorImpl?.invoke() ?: Color.accentColor.colorImpl()
            if (isPlaceholder) {
                linkColor = linkColor.copy(alpha = linkColor.alpha * Float(Color.placeholderOpacity))
            }
            val annotatedText = annotatedString(markdown = locnode, interpolations = interpolations, linkColor = linkColor, isUppercased = styleInfo.isUppercased, isLowercased = styleInfo.isLowercased, isRedacted = isPlaceholder)
            val links = annotatedText.getUrlAnnotations(start = 0, end = annotatedText.length)
            var modifier = context.modifier
            if (!links.isEmpty()) {
                val currentText = rememberUpdatedState(annotatedText)
                val currentHandler = rememberUpdatedState(EnvironmentValues.shared.openURL)
                val currentIsEnabled = rememberUpdatedState(EnvironmentValues.shared.isEnabled)
                modifier = modifier.pointerInput(true) { ->
                    detectTapGestures { pos ->
                        if (currentIsEnabled.value) {
                            layoutResult.value?.getOffsetForPosition(pos)?.let { offset ->
                                currentText.value.getUrlAnnotations(offset, offset).firstOrNull()?.item?.url.sref()?.let { urlString ->
                                    (try { URL(string = urlString) } catch (_: NullReturnException) { null })?.let { url ->
                                        currentHandler.value.invoke(url)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            options = Material3TextOptions(annotatedText = annotatedText, modifier = modifier, color = styleInfo.color ?: androidx.compose.ui.graphics.Color.Unspecified, maxLines = maxLines, style = animatable.value, textDecoration = textDecoration, textAlign = textAlign, onTextLayout = { it -> layoutResult.value = it })
        } else {
            var text: String
            if (interpolations != null) {
                text = locfmt.format(*interpolations.toTypedArray())
            } else {
                text = locfmt
            }
            if (styleInfo.isUppercased) {
                text = text.uppercased()
            } else if (styleInfo.isLowercased) {
                text = text.lowercased()
            }
            options = Material3TextOptions(text = text, modifier = context.modifier, color = styleInfo.color ?: androidx.compose.ui.graphics.Color.Unspecified, maxLines = maxLines, style = animatable.value, textDecoration = textDecoration, textAlign = textAlign)
        }
        EnvironmentValues.shared._material3Text?.let { updateOptions ->
            options = updateOptions(options)
        }
        val matchtarget_7 = options.annotatedText
        if (matchtarget_7 != null) {
            val annotatedText = matchtarget_7
            val matchtarget_8 = options.onTextLayout
            if (matchtarget_8 != null) {
                val onTextLayout = matchtarget_8
                androidx.compose.material3.Text(text = annotatedText, modifier = options.modifier, color = options.color, fontSize = options.fontSize, fontStyle = options.fontStyle, fontWeight = options.fontWeight, fontFamily = options.fontFamily, letterSpacing = options.letterSpacing, textDecoration = options.textDecoration, textAlign = options.textAlign, lineHeight = options.lineHeight, overflow = options.overflow, softWrap = options.softWrap, maxLines = options.maxLines, minLines = options.minLines, onTextLayout = onTextLayout, style = options.style)
            } else {
                androidx.compose.material3.Text(text = options.text ?: "", modifier = options.modifier, color = options.color, fontSize = options.fontSize, fontStyle = options.fontStyle, fontWeight = options.fontWeight, fontFamily = options.fontFamily, letterSpacing = options.letterSpacing, textDecoration = options.textDecoration, textAlign = options.textAlign, lineHeight = options.lineHeight, overflow = options.overflow, softWrap = options.softWrap, maxLines = options.maxLines, minLines = options.minLines, onTextLayout = options.onTextLayout, style = options.style)
            }
        } else {
            androidx.compose.material3.Text(text = options.text ?: "", modifier = options.modifier, color = options.color, fontSize = options.fontSize, fontStyle = options.fontStyle, fontWeight = options.fontWeight, fontFamily = options.fontFamily, letterSpacing = options.letterSpacing, textDecoration = options.textDecoration, textAlign = options.textAlign, lineHeight = options.lineHeight, overflow = options.overflow, softWrap = options.softWrap, maxLines = options.maxLines, minLines = options.minLines, onTextLayout = options.onTextLayout, style = options.style)
        }
    }

    private fun annotatedString(markdown: MarkdownNode, interpolations: kotlin.collections.List<AnyHashable>?, linkColor: androidx.compose.ui.graphics.Color, isUppercased: Boolean, isLowercased: Boolean, isRedacted: Boolean): AnnotatedString {
        return buildAnnotatedString { -> append(markdown = markdown, to = this, interpolations = interpolations, linkColor = linkColor, isUppercased = isUppercased, isLowercased = isLowercased, isRedacted = isRedacted) }
    }

    @OptIn(ExperimentalTextApi::class)
    private fun append(markdown: MarkdownNode, to: AnnotatedString.Builder, interpolations: kotlin.collections.List<AnyHashable>?, isFirstChild: Boolean = true, linkColor: androidx.compose.ui.graphics.Color, isUppercased: Boolean, isLowercased: Boolean, isRedacted: Boolean) {
        val builder = to
        fun appendChildren() {
            markdown.children?.forEachIndexed { it, it_1 -> append(markdown = it_1, to = builder, interpolations = interpolations, isFirstChild = it == 0, linkColor = linkColor, isUppercased = isUppercased, isLowercased = isLowercased, isRedacted = isRedacted) }
        }

        when (markdown.type) {
            MarkdownNode.NodeType.bold -> {
                builder.pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                appendChildren()
                builder.pop()
            }
            MarkdownNode.NodeType.code -> {
                markdown.formattedString(interpolations)?.let { text ->
                    builder.pushStyle(SpanStyle(fontFamily = FontFamily.Monospace))
                    if (isUppercased) {
                        builder.append(text.uppercased())
                    } else if (isLowercased) {
                        builder.append(text.lowercased())
                    } else {
                        builder.append(text)
                    }
                    builder.pop()
                }
            }
            MarkdownNode.NodeType.italic -> {
                builder.pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                appendChildren()
                builder.pop()
            }
            MarkdownNode.NodeType.link -> {
                if (isRedacted) {
                    builder.pushStyle(SpanStyle(background = linkColor))
                } else {
                    builder.pushStyle(SpanStyle(color = linkColor))
                }
                builder.pushUrlAnnotation(UrlAnnotation(markdown.formattedString(interpolations) ?: ""))
                appendChildren()
                builder.pop()
                builder.pop()
            }
            MarkdownNode.NodeType.paragraph -> {
                if (!isFirstChild) {
                    builder.append("\n\n")
                }
                appendChildren()
            }
            MarkdownNode.NodeType.root -> appendChildren()
            MarkdownNode.NodeType.strikethrough -> {
                builder.pushStyle(SpanStyle(textDecoration = TextDecoration.LineThrough))
                appendChildren()
                builder.pop()
            }
            MarkdownNode.NodeType.text -> {
                markdown.formattedString(interpolations)?.let { text ->
                    if (isUppercased) {
                        builder.append(text.uppercased())
                    } else if (isLowercased) {
                        builder.append(text.lowercased())
                    } else {
                        builder.append(text)
                    }
                }
            }
            MarkdownNode.NodeType.unknown -> appendChildren()
        }
    }

    override fun equals(other: Any?): Boolean {
        if (other !is _Text) return false
        return verbatim == other.verbatim && attributedString == other.attributedString && key == other.key && tableName == other.tableName && bundle == other.bundle
    }
}

enum class TextAlignment: CaseIterable, Sendable {
    leading,
    center,
    trailing;

    /// Convert this enum to a Compose `TextAlign` value.
    fun asTextAlign(): TextAlign {
        return when (this) {
            TextAlignment.leading -> TextAlign.Start
            TextAlignment.center -> TextAlign.Center
            TextAlignment.trailing -> TextAlign.End
        }
    }

    companion object: CaseIterableCompanion<TextAlignment> {
        override val allCases: Array<TextAlignment>
            get() = arrayOf(leading, center, trailing)
    }
}

internal class TextEnvironment: MutableStruct {
    internal var fontWeight: Font.Weight? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var fontDesign: Font.Design? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var isItalic: Boolean? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var isUnderline: Boolean? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var isStrikethrough: Boolean? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    internal var textCase: Text.Case? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }

    internal val textDecoration: TextDecoration?
        get() {
            if ((isUnderline == true) && (isStrikethrough == true)) {
                return TextDecoration.Underline + TextDecoration.LineThrough
            } else if (isUnderline == true) {
                return TextDecoration.Underline
            } else if (isStrikethrough == true) {
                return TextDecoration.LineThrough
            } else {
                return null
            }
        }

    constructor(fontWeight: Font.Weight? = null, fontDesign: Font.Design? = null, isItalic: Boolean? = null, isUnderline: Boolean? = null, isStrikethrough: Boolean? = null, textCase: Text.Case? = null) {
        this.fontWeight = fontWeight
        this.fontDesign = fontDesign
        this.isItalic = isItalic
        this.isUnderline = isUnderline
        this.isStrikethrough = isStrikethrough
        this.textCase = textCase
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = TextEnvironment(fontWeight, fontDesign, isItalic, isUnderline, isStrikethrough, textCase)

    override fun equals(other: Any?): Boolean {
        if (other !is TextEnvironment) return false
        return fontWeight == other.fontWeight && fontDesign == other.fontDesign && isItalic == other.isItalic && isUnderline == other.isUnderline && isStrikethrough == other.isStrikethrough && textCase == other.textCase
    }
}

internal fun textEnvironment(for_: View, update: (InOut<TextEnvironment>) -> Unit): View {
    val view = for_
    return ComposeModifierView(contentView = view) { view, context ->
        EnvironmentValues.shared.setValues({ it ->
            var textEnvironment = it._textEnvironment.sref()
            update(InOut({ textEnvironment }, { textEnvironment = it }))
            it.set_textEnvironment(textEnvironment)
        }, in_ = { -> view.Compose(context = context) })
    }
}

internal class TextStyleInfo {
    internal val style: TextStyle
    internal val color: androidx.compose.ui.graphics.Color?
    internal val isUppercased: Boolean
    internal val isLowercased: Boolean

    constructor(style: TextStyle, color: androidx.compose.ui.graphics.Color? = null, isUppercased: Boolean, isLowercased: Boolean) {
        this.style = style.sref()
        this.color = color
        this.isUppercased = isUppercased
        this.isLowercased = isLowercased
    }
}

@Suppress("MUST_BE_INITIALIZED")
class Material3TextOptions: MutableStruct {
    var text: String? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var annotatedText: AnnotatedString? = null
        get() = field.sref({ this.annotatedText = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var modifier: Modifier
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var color: androidx.compose.ui.graphics.Color
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var fontSize: TextUnit
        get() = field.sref({ this.fontSize = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var fontStyle: FontStyle? = null
        get() = field.sref({ this.fontStyle = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var fontWeight: FontWeight? = null
        get() = field.sref({ this.fontWeight = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var fontFamily: FontFamily? = null
        get() = field.sref({ this.fontFamily = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var letterSpacing: TextUnit
        get() = field.sref({ this.letterSpacing = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var textDecoration: TextDecoration? = null
        get() = field.sref({ this.textDecoration = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var textAlign: TextAlign? = null
        get() = field.sref({ this.textAlign = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var lineHeight: TextUnit
        get() = field.sref({ this.lineHeight = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var overflow: TextOverflow
        get() = field.sref({ this.overflow = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var softWrap: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var maxLines: Int
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var minLines: Int
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var onTextLayout: ((TextLayoutResult) -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var style: TextStyle
        get() = field.sref({ this.style = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    fun copy(text: String? = this.text, annotatedText: AnnotatedString? = this.annotatedText, modifier: Modifier = this.modifier, color: androidx.compose.ui.graphics.Color = this.color, fontSize: TextUnit = this.fontSize, fontStyle: FontStyle? = this.fontStyle, fontWeight: FontWeight? = this.fontWeight, fontFamily: FontFamily? = this.fontFamily, letterSpacing: TextUnit = this.letterSpacing, textDecoration: TextDecoration? = this.textDecoration, textAlign: TextAlign? = this.textAlign, lineHeight: TextUnit = this.lineHeight, overflow: TextOverflow = this.overflow, softWrap: Boolean = this.softWrap, maxLines: Int = this.maxLines, minLines: Int = this.minLines, onTextLayout: ((TextLayoutResult) -> Unit)? = this.onTextLayout, style: TextStyle = this.style): Material3TextOptions = Material3TextOptions(text = text, annotatedText = annotatedText, modifier = modifier, color = color, fontSize = fontSize, fontStyle = fontStyle, fontWeight = fontWeight, fontFamily = fontFamily, letterSpacing = letterSpacing, textDecoration = textDecoration, textAlign = textAlign, lineHeight = lineHeight, overflow = overflow, softWrap = softWrap, maxLines = maxLines, minLines = minLines, onTextLayout = onTextLayout, style = style)

    constructor(text: String? = null, annotatedText: AnnotatedString? = null, modifier: Modifier = Modifier, color: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Unspecified, fontSize: TextUnit = TextUnit.Unspecified.sref(), fontStyle: FontStyle? = null, fontWeight: FontWeight? = null, fontFamily: FontFamily? = null, letterSpacing: TextUnit = TextUnit.Unspecified.sref(), textDecoration: TextDecoration? = null, textAlign: TextAlign? = null, lineHeight: TextUnit = TextUnit.Unspecified.sref(), overflow: TextOverflow = TextOverflow.Clip.sref(), softWrap: Boolean = true, maxLines: Int = Int.max, minLines: Int = 1, onTextLayout: ((TextLayoutResult) -> Unit)? = null, style: TextStyle) {
        this.text = text
        this.annotatedText = annotatedText
        this.modifier = modifier
        this.color = color
        this.fontSize = fontSize
        this.fontStyle = fontStyle
        this.fontWeight = fontWeight
        this.fontFamily = fontFamily
        this.letterSpacing = letterSpacing
        this.textDecoration = textDecoration
        this.textAlign = textAlign
        this.lineHeight = lineHeight
        this.overflow = overflow
        this.softWrap = softWrap
        this.maxLines = maxLines
        this.minLines = minLines
        this.onTextLayout = onTextLayout
        this.style = style
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Material3TextOptions(text, annotatedText, modifier, color, fontSize, fontStyle, fontWeight, fontFamily, letterSpacing, textDecoration, textAlign, lineHeight, overflow, softWrap, maxLines, minLines, onTextLayout, style)

    companion object {
    }
}

class RedactionReasons: OptionSet<RedactionReasons, Int>, Sendable, MutableStruct {
    override var rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override val rawvaluelong: ULong
        get() = ULong(rawValue)
    override fun makeoptionset(rawvaluelong: ULong): RedactionReasons = RedactionReasons(rawValue = Int(rawvaluelong))
    override fun assignoptionset(target: RedactionReasons) {
        willmutate()
        try {
            assignfrom(target)
        } finally {
            didmutate()
        }
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as RedactionReasons
        this.rawValue = copy.rawValue
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = RedactionReasons(this as MutableStruct)

    private fun assignfrom(target: RedactionReasons) {
        this.rawValue = target.rawValue
    }

    companion object {

        val placeholder = RedactionReasons(rawValue = 1 shl 0)

        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val privacy = RedactionReasons(rawValue = 1 shl 1)

        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val invalidated = RedactionReasons(rawValue = 1 shl 2)

        fun of(vararg options: RedactionReasons): RedactionReasons {
            val value = options.fold(Int(0)) { result, option -> result or option.rawValue }
            return RedactionReasons(rawValue = value)
        }
    }
}

