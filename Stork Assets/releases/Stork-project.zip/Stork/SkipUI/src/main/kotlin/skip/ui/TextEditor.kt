// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*

import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.VisualTransformation

class TextEditor: View {
    internal val text: Binding<String>

    constructor(text: Binding<String>) {
        this.text = text.sref()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ComposeContent(context: ComposeContext) {
        val contentContext = context.content()
        val textEnvironment = EnvironmentValues.shared._textEnvironment.sref()
        val redaction = EnvironmentValues.shared.redactionReasons.sref()
        val styleInfo = Text.styleInfo(textEnvironment = textEnvironment, redaction = redaction, context = context)
        val animatable = styleInfo.style.asAnimatable(context = context)
        val keyboardOptions = (EnvironmentValues.shared._keyboardOptions ?: KeyboardOptions.Default).sref()
        val keyboardActions = KeyboardActions(EnvironmentValues.shared._onSubmitState, LocalFocusManager.current)
        val colors = TextField.colors(styleInfo = styleInfo, outline = Color.clear)
        val visualTransformation = VisualTransformation.None.sref()
        OutlinedTextField(value = text.wrappedValue, onValueChange = { it -> text.wrappedValue = it }, modifier = context.modifier.fillSize(), textStyle = animatable.value, enabled = EnvironmentValues.shared.isEnabled, singleLine = false, keyboardOptions = keyboardOptions, keyboardActions = keyboardActions, colors = colors, visualTransformation = visualTransformation)
    }

    companion object {
    }
}

class TextEditorStyle: RawRepresentable<Int> {
    override val rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override fun equals(other: Any?): Boolean {
        if (other !is TextEditorStyle) return false
        return rawValue == other.rawValue
    }

    companion object {

        val automatic = TextEditorStyle(rawValue = 0)
        val plain = TextEditorStyle(rawValue = 1)
    }
}

