// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import skip.foundation.*
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.registerForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.random.Random

class UNUserNotificationCenter {
    private var requestPermissionLauncher: ActivityResultLauncher<String>? = null
        get() = field.sref({ this.requestPermissionLauncher = it })
        set(newValue) {
            field = newValue.sref()
        }
    private val waitingContinuations: MutableList<Continuation<Boolean>> = mutableListOf<Continuation<Boolean>>()

    private constructor() {
    }


    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    suspend fun getNotificationSettings(): Any = Async.run {
        fatalError()
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    suspend fun setBadgeCount(count: Int): Unit = Unit

    suspend fun requestAuthorization(options: UNAuthorizationOptions): Boolean = Async.run l@{
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return@l false
        }
        val activity_0 = UIApplication.shared.androidActivity.sref()
        if ((activity_0 == null) || (ContextCompat.checkSelfPermission(activity_0, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
            return@l true
        }
        suspendCoroutine { continuation ->
            var count = 0
            synchronized(waitingContinuations) { ->
                waitingContinuations.add(continuation)
                count = waitingContinuations.count()
            }
            if (count == 1) {
                requestPermissionLauncher?.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    var delegate: UNUserNotificationCenterDelegate? = null
        get() = field.sref({ this.delegate = it })
        set(newValue) {
            field = newValue.sref()
        }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    val supportsContentExtensions: Boolean
        get() {
            fatalError()
        }

    suspend fun add(request: UNNotificationRequest): Unit = MainActor.run l@{
        val delegate_0 = delegate.sref()
        if (delegate_0 == null) {
            return@l
        }
        val notification = UNNotification(request = request, date = Date.now)
        val options = delegate_0.userNotificationCenter(this, willPresent = notification)
        if (!options.contains(UNNotificationPresentationOptions.banner) && !options.contains(UNNotificationPresentationOptions.alert)) {
            return@l
        }

        val activity_1 = UIApplication.shared.androidActivity.sref()
        if (activity_1 == null) {
            return@l
        }
        val intent = Intent(activity_1, type(of = activity_1).java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val extras = android.os.Bundle()
        for ((key, value) in request.content.userInfo.sref()) {
            val matchtarget_0 = value as? String
            if (matchtarget_0 != null) {
                val s = matchtarget_0
                extras.putString(key.toString(), s)
            } else {
                val matchtarget_1 = value as? Boolean
                if (matchtarget_1 != null) {
                    val b = matchtarget_1
                    extras.putBoolean(key.toString(), b)
                } else {
                    val matchtarget_2 = value as? Int
                    if (matchtarget_2 != null) {
                        val i = matchtarget_2
                        extras.putInt(key.toString(), i)
                    } else {
                        val matchtarget_3 = value as? Double
                        if (matchtarget_3 != null) {
                            val d = matchtarget_3
                            extras.putDouble(key.toString(), d)
                        } else {
                            extras.putString(key.toString(), value.toString())
                        }
                    }
                }
            }
        }
        intent.putExtras(extras)

        val pendingFlags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val pendingIntent = PendingIntent.getActivity(activity_1, 0, intent, pendingFlags)

        val channelID = "tools.skip.firebase.messaging" // Match AndroidManifest.xml
        val notificationBuilder = NotificationCompat.Builder(activity_1, channelID)
            .setContentTitle(request.content.title)
            .setContentText(request.content.body)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
        val application = activity_1.application.sref()
        val matchtarget_4 = request.content.attachments.first(where = { it -> it.type == "public.image" })
        if (matchtarget_4 != null) {
            val imageAttachment = matchtarget_4
            notificationBuilder.setSmallIcon(IconCompat.createWithContentUri(imageAttachment.url.absoluteString))
        } else {
            val packageName = application.getPackageName()
            val resId = application.resources.getIdentifier("ic_launcher", "mipmap", packageName)
            notificationBuilder.setSmallIcon(IconCompat.createWithResource(application, resId))
        }

        val manager = (activity_1.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).sref()
        val appName = application.packageManager.getApplicationLabel(application.applicationInfo)
        val channel = NotificationChannel(channelID, appName, NotificationManager.IMPORTANCE_DEFAULT)
        manager.createNotificationChannel(channel)
        manager.notify(Random.nextInt(), notificationBuilder.build())
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    suspend fun getPendingNotificationRequests(): Array<Any> = Async.run {
        fatalError()
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    fun removePendingNotificationRequests(withIdentifiers: Array<String>) = Unit

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    fun removeAllPendingNotificationRequests() = Unit

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    suspend fun getDeliveredNotifications(): Array<Any> = Async.run {
        fatalError()
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    fun removeDeliveredNotifications(withIdentifiers: Array<String>) = Unit

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    fun removeAllDeliveredNotifications() = Unit

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    fun setNotificationCategories(categories: Set<AnyHashable>) = Unit

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    suspend fun getNotificationCategories(): Set<AnyHashable> = Async.run {
        fatalError()
    }

    companion object {
        private val shared = UNUserNotificationCenter()

        fun current(): UNUserNotificationCenter = shared
        /// Called by `UIApplication` when it receives its activity reference.
        internal fun launch(activity: AppCompatActivity) {
            val shared = this.shared
            // Must registerForActivityResult on or before Activity.onCreate
            try {
                val contract = ActivityResultContracts.RequestPermission()
                shared.requestPermissionLauncher = activity.registerForActivityResult(contract) { isGranted ->
                    var continuations: ArrayList<Continuation<Boolean>>? = null
                    synchronized(shared.waitingContinuations) { ->
                        continuations = ArrayList(shared.waitingContinuations)
                        shared.waitingContinuations.clear()
                    }
                    continuations?.forEach { it -> it.resume(isGranted) }
                }
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                android.util.Log.w("SkipUI", "error initializing permission launcher", error as? Throwable)
            }
        }
    }
}

interface UNUserNotificationCenterDelegate {
    suspend fun userNotificationCenter(center: UNUserNotificationCenter, didReceive: UNNotificationResponse): Unit = Unit

    suspend fun userNotificationCenter(center: UNUserNotificationCenter, willPresent: UNNotification): UNNotificationPresentationOptions = MainActor.run l@{
        val notification = willPresent
        return@l UNNotificationPresentationOptions.of()
    }

    fun userNotificationCenter(center: UNUserNotificationCenter, openSettingsFor: UNNotification?) = Unit
}

class UNAuthorizationOptions: OptionSet<UNAuthorizationOptions, Int>, MutableStruct {
    override var rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override val rawvaluelong: ULong
        get() = ULong(rawValue)
    override fun makeoptionset(rawvaluelong: ULong): UNAuthorizationOptions = UNAuthorizationOptions(rawValue = Int(rawvaluelong))
    override fun assignoptionset(target: UNAuthorizationOptions) {
        willmutate()
        try {
            assignfrom(target)
        } finally {
            didmutate()
        }
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as UNAuthorizationOptions
        this.rawValue = copy.rawValue
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = UNAuthorizationOptions(this as MutableStruct)

    private fun assignfrom(target: UNAuthorizationOptions) {
        this.rawValue = target.rawValue
    }

    companion object {

        val badge = UNAuthorizationOptions(rawValue = 1 shl 0)
        val sound = UNAuthorizationOptions(rawValue = 1 shl 1)
        val alert = UNAuthorizationOptions(rawValue = 1 shl 2)
        val carPlay = UNAuthorizationOptions(rawValue = 1 shl 3)
        val criticalAlert = UNAuthorizationOptions(rawValue = 1 shl 4)
        val providesAppNotificationSettings = UNAuthorizationOptions(rawValue = 1 shl 5)
        var provisional = UNAuthorizationOptions(rawValue = 1 shl 6)
            get() = field.sref({ this.provisional = it })
            set(newValue) {
                field = newValue.sref()
            }

        fun of(vararg options: UNAuthorizationOptions): UNAuthorizationOptions {
            val value = options.fold(Int(0)) { result, option -> result or option.rawValue }
            return UNAuthorizationOptions(rawValue = value)
        }
    }
}

class UNNotification {
    val request: UNNotificationRequest
    val date: Date

    constructor(request: UNNotificationRequest, date: Date) {
        this.request = request
        this.date = date.sref()
    }

    companion object {
    }
}

class UNNotificationRequest {
    val identifier: String
    val content: UNNotificationContent
    val trigger: UNNotificationTrigger?

    constructor(identifier: String, content: UNNotificationContent, trigger: UNNotificationTrigger?) {
        this.identifier = identifier
        this.content = content
        this.trigger = trigger
    }

    companion object {
    }
}

val UNNotificationDefaultActionIdentifier = "UNNotificationDefaultActionIdentifier"
val UNNotificationDismissActionIdentifier = "UNNotificationDismissActionIdentifier"

class UNNotificationResponse {
    val actionIdentifier: String
    val notification: UNNotification

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    val targetScene: Any?
        get() {
            fatalError()
        }

    constructor(actionIdentifier: String = UNNotificationDefaultActionIdentifier, notification: UNNotification) {
        this.actionIdentifier = actionIdentifier
        this.notification = notification
    }

    companion object {
    }
}

class UNNotificationPresentationOptions: OptionSet<UNNotificationPresentationOptions, Int>, MutableStruct {
    override var rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override val rawvaluelong: ULong
        get() = ULong(rawValue)
    override fun makeoptionset(rawvaluelong: ULong): UNNotificationPresentationOptions = UNNotificationPresentationOptions(rawValue = Int(rawvaluelong))
    override fun assignoptionset(target: UNNotificationPresentationOptions) {
        willmutate()
        try {
            assignfrom(target)
        } finally {
            didmutate()
        }
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as UNNotificationPresentationOptions
        this.rawValue = copy.rawValue
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = UNNotificationPresentationOptions(this as MutableStruct)

    private fun assignfrom(target: UNNotificationPresentationOptions) {
        this.rawValue = target.rawValue
    }

    companion object {

        val badge = UNNotificationPresentationOptions(rawValue = 1 shl 0)
        val banner = UNNotificationPresentationOptions(rawValue = 1 shl 1)
        val list = UNNotificationPresentationOptions(rawValue = 1 shl 2)
        val sound = UNNotificationPresentationOptions(rawValue = 1 shl 3)
        val alert = UNNotificationPresentationOptions(rawValue = 1 shl 4)

        fun of(vararg options: UNNotificationPresentationOptions): UNNotificationPresentationOptions {
            val value = options.fold(Int(0)) { result, option -> result or option.rawValue }
            return UNNotificationPresentationOptions(rawValue = value)
        }
    }
}

@Suppress("MUST_BE_INITIALIZED", "MUST_BE_INITIALIZED_OR_FINAL_OR_ABSTRACT")
open class UNNotificationContent {
    open var title: String
        internal set
    open var subtitle: String
        internal set
    open var body: String
        internal set
    open var badge: java.lang.Number? = null
        internal set
    open var sound: UNNotificationSound? = null
        internal set
    open var launchImageName: String
        internal set
    open var userInfo: Dictionary<AnyHashable, Any>
        get() = field.sref({ this.userInfo = it })
        internal set(newValue) {
            field = newValue.sref()
        }
    open var attachments: Array<UNNotificationAttachment>
        get() = field.sref({ this.attachments = it })
        internal set(newValue) {
            field = newValue.sref()
        }
    open var categoryIdentifier: String
        internal set
    open var threadIdentifier: String
        internal set
    open var targetContentIdentifier: String? = null
        internal set
    open var summaryArgument: String
        internal set
    open var summaryArgumentCount: Int
        internal set
    open var filterCriteria: String? = null
        internal set

    constructor(title: String = "", subtitle: String = "", body: String = "", badge: java.lang.Number? = null, sound: UNNotificationSound? = UNNotificationSound.default, launchImageName: String = "", userInfo: Dictionary<AnyHashable, Any> = dictionaryOf(), attachments: Array<UNNotificationAttachment> = arrayOf(), categoryIdentifier: String = "", threadIdentifier: String = "", targetContentIdentifier: String? = null, summaryArgument: String = "", summaryArgumentCount: Int = 0, filterCriteria: String? = null) {
        this.title = title
        this.subtitle = subtitle
        this.body = body
        this.badge = badge
        this.sound = sound
        this.launchImageName = launchImageName
        this.userInfo = userInfo
        this.attachments = attachments
        this.categoryIdentifier = categoryIdentifier
        this.threadIdentifier = threadIdentifier
        this.targetContentIdentifier = targetContentIdentifier
        this.summaryArgument = summaryArgument
        this.summaryArgumentCount = summaryArgumentCount
        this.filterCriteria = filterCriteria
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

class UNMutableNotificationContent: UNNotificationContent {
    override var title: String
        get() = super.title
        set(newValue) {
            super.title = newValue
        }
    override var subtitle: String
        get() = super.subtitle
        set(newValue) {
            super.subtitle = newValue
        }
    override var body: String
        get() = super.body
        set(newValue) {
            super.body = newValue
        }
    override var badge: java.lang.Number?
        get() = super.badge
        set(newValue) {
            super.badge = newValue
        }
    override var sound: UNNotificationSound?
        get() = super.sound
        set(newValue) {
            super.sound = newValue
        }
    override var launchImageName: String
        get() = super.launchImageName
        set(newValue) {
            super.launchImageName = newValue
        }
    override var userInfo: Dictionary<AnyHashable, Any>
        get() = super.userInfo.sref({ this.userInfo = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            super.userInfo = newValue
        }
    override var attachments: Array<UNNotificationAttachment>
        get() = super.attachments.sref({ this.attachments = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            super.attachments = newValue
        }
    override var categoryIdentifier: String
        get() = super.categoryIdentifier
        set(newValue) {
            super.categoryIdentifier = newValue
        }
    override var threadIdentifier: String
        get() = super.threadIdentifier
        set(newValue) {
            super.threadIdentifier = newValue
        }
    override var targetContentIdentifier: String?
        get() = super.targetContentIdentifier
        set(newValue) {
            super.targetContentIdentifier = newValue
        }
    override var summaryArgument: String
        get() = super.summaryArgument
        set(newValue) {
            super.summaryArgument = newValue
        }
    override var summaryArgumentCount: Int
        get() = super.summaryArgumentCount
        set(newValue) {
            super.summaryArgumentCount = newValue
        }
    override var filterCriteria: String?
        get() = super.filterCriteria
        set(newValue) {
            super.filterCriteria = newValue
        }

    constructor(title: String = "", subtitle: String = "", body: String = "", badge: java.lang.Number? = null, sound: UNNotificationSound? = UNNotificationSound.default, launchImageName: String = "", userInfo: Dictionary<AnyHashable, Any> = dictionaryOf(), attachments: Array<UNNotificationAttachment> = arrayOf(), categoryIdentifier: String = "", threadIdentifier: String = "", targetContentIdentifier: String? = null, summaryArgument: String = "", summaryArgumentCount: Int = 0, filterCriteria: String? = null): super(title, subtitle, body, badge, sound, launchImageName, userInfo, attachments, categoryIdentifier, threadIdentifier, targetContentIdentifier, summaryArgument, summaryArgumentCount, filterCriteria) {
    }

    companion object: UNNotificationContent.CompanionClass() {
    }
}

class UNNotificationSound {
    val name: UNNotificationSoundName
    val volume: Float

    constructor(named: UNNotificationSoundName, volume: Float = 0.0f) {
        val name = named
        this.name = name
        this.volume = volume
    }

    companion object {

        val default: UNNotificationSound
            get() = UNNotificationSound(named = UNNotificationSoundName(rawValue = "default"))

        val defaultCriticalSound: UNNotificationSound
            get() = UNNotificationSound(named = UNNotificationSoundName(rawValue = "default_critical"))

        fun defaultCriticalSound(withAudioVolume: Float): UNNotificationSound {
            val volume = withAudioVolume
            return UNNotificationSound(named = UNNotificationSoundName(rawValue = "default_critical"), volume = volume)
        }

        fun soundNamed(name: UNNotificationSoundName): UNNotificationSound = UNNotificationSound(named = name)
    }
}

class UNNotificationSoundName: RawRepresentable<String> {
    override val rawValue: String

    constructor(rawValue: String) {
        this.rawValue = rawValue
    }

    override fun equals(other: Any?): Boolean {
        if (other !is UNNotificationSoundName) return false
        return rawValue == other.rawValue
    }

    override fun hashCode(): Int {
        var result = 1
        result = Hasher.combine(result, rawValue)
        return result
    }

    companion object {
    }
}

val UNNotificationAttachmentOptionsTypeHintKey = "UNNotificationAttachmentOptionsTypeHintKey"
val UNNotificationAttachmentOptionsThumbnailHiddenKey = "UNNotificationAttachmentOptionsThumbnailHiddenKey"
val UNNotificationAttachmentOptionsThumbnailClippingRectKey = "UNNotificationAttachmentOptionsThumbnailClippingRectKey"
val UNNotificationAttachmentOptionsThumbnailTimeKey = "UNNotificationAttachmentOptionsThumbnailTimeKey"

open class UNNotificationAttachment {
    val identifier: String
    val url: URL
    val type: String
    val timeShift: Double

    constructor(identifier: String, url: URL, type: String = "public.data", timeShift: Double = 0.0) {
        this.identifier = identifier
        this.url = url.sref()
        this.type = type
        this.timeShift = timeShift
    }

    companion object: CompanionClass() {

        override fun attachment(withIdentifier: String, url: URL, options: Dictionary<AnyHashable, Any>?): UNNotificationAttachment {
            val identifier = withIdentifier
            return UNNotificationAttachment(identifier = identifier, url = url, type = "public.data")
        }
    }
    open class CompanionClass {
        open fun attachment(withIdentifier: String, url: URL, options: Dictionary<AnyHashable, Any>? = null): UNNotificationAttachment = UNNotificationAttachment.attachment(withIdentifier = withIdentifier, url = url, options = options)
    }
}

open class UNNotificationTrigger {
    val repeats: Boolean

    constructor(repeats: Boolean) {
        this.repeats = repeats
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

class UNTimeIntervalNotificationTrigger: UNNotificationTrigger {
    val timeInterval: Double

    constructor(timeInterval: Double, repeats: Boolean): super(repeats = repeats) {
        this.timeInterval = timeInterval
    }

    companion object: UNNotificationTrigger.CompanionClass() {
    }
}

class UNCalendarNotificationTrigger: UNNotificationTrigger {
    val dateComponents: DateComponents

    constructor(dateComponents: DateComponents, repeats: Boolean): super(repeats = repeats) {
        this.dateComponents = dateComponents.sref()
    }

    companion object: UNNotificationTrigger.CompanionClass() {
    }
}

class UNLocationNotificationTrigger: UNNotificationTrigger {
    val region: Any /* CLRegion */

    constructor(region: Any, repeats: Boolean): super(repeats = repeats) {
        this.region = region.sref()
    }

    companion object: UNNotificationTrigger.CompanionClass() {
    }
}

class UNPushNotificationTrigger: UNNotificationTrigger {
    constructor(repeats: Boolean): super(repeats = repeats) {
    }

    companion object: UNNotificationTrigger.CompanionClass() {
    }
}
