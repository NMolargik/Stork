// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*

import skip.foundation.*
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.util.Consumer

internal class OnNewIntentListener: Consumer<Intent> {
    internal val newIntent: MutableState<Intent?>

    override fun accept(value: Intent) {
        newIntent.value = value
    }

    constructor(newIntent: MutableState<Intent?>) {
        this.newIntent = newIntent.sref()
    }
}

