// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*

import androidx.compose.ui.draw.DrawModifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas

internal open class GrayscaleModifier: DrawModifier {
    internal val amount: Double

    internal constructor(amount: Double) {
        this.amount = amount
    }

    override fun ContentDrawScope.draw() {
        val saturationMatrix = ColorMatrix().apply { -> setToSaturation(Float(max(0.0, 1.0 - amount))) }
        val saturationFilter = ColorFilter.colorMatrix(saturationMatrix)
        val paint = Paint().apply { -> colorFilter = saturationFilter.sref() }
        drawIntoCanvas { it ->
            it.saveLayer(Rect(0.0f, 0.0f, size.width, size.height), paint)
            drawContent()
            it.restore()
        }
    }
}
