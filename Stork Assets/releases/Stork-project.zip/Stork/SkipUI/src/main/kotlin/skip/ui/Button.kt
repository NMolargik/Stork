// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.ContentAlpha
import androidx.compose.material.ripple.RippleAlpha
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.RippleConfiguration
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class Button: View, ListItemAdapting {
    internal val action: () -> Unit
    internal val label: ComposeBuilder
    internal val role: ButtonRole?

    constructor(action: () -> Unit, label: () -> View): this(role = null, action = action, label = label) {
    }

    constructor(title: String, action: () -> Unit): this(action = action, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(verbatim = title).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    constructor(titleKey: LocalizedStringKey, action: () -> Unit): this(action = action, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(titleKey).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    constructor(role: ButtonRole?, action: () -> Unit, label: () -> View) {
        this.role = role
        this.action = action
        this.label = ComposeBuilder.from(label)
    }

    constructor(title: String, role: ButtonRole?, action: () -> Unit): this(role = role, action = action, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(verbatim = title).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    constructor(titleKey: LocalizedStringKey, role: ButtonRole?, action: () -> Unit): this(role = role, action = action, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(titleKey).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    @Composable
    override fun ComposeContent(context: ComposeContext): Unit = Companion.ComposeButton(label = label, context = context, role = role, action = action)

    @Composable
    override fun shouldComposeListItem(): Boolean {
        val buttonStyle = EnvironmentValues.shared._buttonStyle
        return buttonStyle == null || buttonStyle == ButtonStyle.automatic || buttonStyle == ButtonStyle.plain
    }

    @Composable
    override fun ComposeListItem(context: ComposeContext, contentModifier: Modifier) {
        val isEnabled = EnvironmentValues.shared.isEnabled
        val modifier = Modifier.clickable(onClick = action, enabled = isEnabled).then(contentModifier)
        Box(modifier = modifier, contentAlignment = androidx.compose.ui.Alignment.CenterStart) { -> Companion.ComposeTextButton(label = label, context = context, isPlain = EnvironmentValues.shared._buttonStyle == ButtonStyle.plain, role = role, isEnabled = isEnabled) }
    }

    companion object {

        /// Compose a button in the current style.
        @Composable
        internal fun ComposeButton(label: View, context: ComposeContext, role: ButtonRole? = null, isEnabled: Boolean = EnvironmentValues.shared.isEnabled, action: () -> Unit) {
            val buttonStyle = EnvironmentValues.shared._buttonStyle
            ComposeContainer(modifier = context.modifier) { modifier ->
                when (buttonStyle) {
                    ButtonStyle.bordered -> {
                        val tint = (if (role == ButtonRole.destructive) Color.red else EnvironmentValues.shared._tint).sref()
                        val colors: ButtonColors
                        if (tint != null) {
                            val tintColor = tint.colorImpl()
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = tintColor.copy(alpha = 0.15f), contentColor = tintColor, disabledContainerColor = tintColor.copy(alpha = 0.15f), disabledContentColor = tintColor.copy(alpha = ContentAlpha.medium))
                        } else {
                            colors = ButtonDefaults.filledTonalButtonColors()
                        }
                        var options = Material3ButtonOptions(onClick = action, modifier = modifier, enabled = isEnabled, shape = ButtonDefaults.filledTonalShape, colors = colors, elevation = ButtonDefaults.filledTonalButtonElevation())
                        EnvironmentValues.shared._material3Button?.let { updateOptions ->
                            options = updateOptions(options)
                        }
                        val placement = EnvironmentValues.shared._placement.sref()
                        val contentContext = context.content()
                        EnvironmentValues.shared.setValues({ it ->
                            if (tint != null) {
                                val foregroundStyle = (if (isEnabled) tint else tint.opacity(Double(ContentAlpha.disabled))).sref()
                                it.set_foregroundStyle(foregroundStyle)
                            } else {
                                it.set_placement(placement.union(ViewPlacement.systemTextColor))
                            }
                        }, in_ = { ->
                            FilledTonalButton(onClick = options.onClick, modifier = options.modifier, enabled = options.enabled, shape = options.shape, colors = options.colors, elevation = options.elevation, border = options.border, contentPadding = options.contentPadding, interactionSource = options.interactionSource) { -> label.Compose(context = contentContext) }
                        })
                    }
                    ButtonStyle.borderedProminent -> {
                        val tint = (if (role == ButtonRole.destructive) Color.red else EnvironmentValues.shared._tint).sref()
                        val colors: ButtonColors
                        if (tint != null) {
                            val tintColor = tint.colorImpl()
                            colors = ButtonDefaults.buttonColors(containerColor = tintColor, disabledContainerColor = tintColor.copy(alpha = ContentAlpha.disabled))
                        } else {
                            colors = ButtonDefaults.buttonColors()
                        }
                        var options = Material3ButtonOptions(onClick = action, modifier = modifier, enabled = isEnabled, shape = ButtonDefaults.shape, colors = colors, elevation = ButtonDefaults.buttonElevation())
                        EnvironmentValues.shared._material3Button?.let { updateOptions ->
                            options = updateOptions(options)
                        }
                        val placement = EnvironmentValues.shared._placement.sref()
                        val contentContext = context.content()
                        EnvironmentValues.shared.setValues({ it -> it.set_placement(placement.union(ViewPlacement.systemTextColor).union(ViewPlacement.onPrimaryColor)) }, in_ = { ->
                            androidx.compose.material3.Button(onClick = options.onClick, modifier = options.modifier, enabled = options.enabled, shape = options.shape, colors = options.colors, elevation = options.elevation, border = options.border, contentPadding = options.contentPadding, interactionSource = options.interactionSource) { -> label.Compose(context = contentContext) }
                        })
                    }
                    ButtonStyle.plain -> ComposeTextButton(label = label, context = context.content(modifier = modifier), role = role, isPlain = true, isEnabled = isEnabled, action = action)
                    else -> ComposeTextButton(label = label, context = context.content(modifier = modifier), role = role, isEnabled = isEnabled, action = action)
                }
            }
        }

        /// Render a plain-style button.
        ///
        /// - Parameters:
        ///   - action: Pass nil if the given modifier already includes `clickable`
        @Composable
        internal fun ComposeTextButton(label: View, context: ComposeContext, role: ButtonRole? = null, isPlain: Boolean = false, isEnabled: Boolean = EnvironmentValues.shared.isEnabled, action: (() -> Unit)? = null) {
            var foregroundStyle: ShapeStyle
            if (role == ButtonRole.destructive) {
                foregroundStyle = Color.red.sref()
            } else {
                foregroundStyle = (EnvironmentValues.shared._foregroundStyle ?: (if (isPlain) Color.primary else (EnvironmentValues.shared._tint ?: Color.accentColor))).sref()
            }
            if (!isEnabled) {
                val disabledAlpha = Double(ContentAlpha.disabled)
                foregroundStyle = AnyShapeStyle(foregroundStyle, opacity = disabledAlpha)
            }

            var modifier = context.modifier
            if (action != null) {
                modifier = modifier.clickable(onClick = action, enabled = isEnabled)
            }
            val contentContext = context.content(modifier = modifier)

            EnvironmentValues.shared.setValues({ it -> it.set_foregroundStyle(foregroundStyle) }, in_ = { -> label.Compose(context = contentContext) })
        }
    }
}

class ButtonStyle: RawRepresentable<Int> {
    override val rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override fun equals(other: Any?): Boolean {
        if (other !is ButtonStyle) return false
        return rawValue == other.rawValue
    }

    companion object {

        val automatic = ButtonStyle(rawValue = 0)
        val plain = ButtonStyle(rawValue = 1)
        val borderless = ButtonStyle(rawValue = 2)
        val bordered = ButtonStyle(rawValue = 3)
        val borderedProminent = ButtonStyle(rawValue = 4)
    }
}

enum class ButtonRepeatBehavior: Sendable {
    automatic,
    enabled,
    disabled;

    companion object {
    }
}

enum class ButtonRole: Sendable {
    destructive,
    cancel;

    companion object {
    }
}

@Suppress("MUST_BE_INITIALIZED")
class Material3ButtonOptions: MutableStruct {
    var onClick: () -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var modifier: Modifier
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var enabled: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var shape: androidx.compose.ui.graphics.Shape
        get() = field.sref({ this.shape = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var colors: ButtonColors
        get() = field.sref({ this.colors = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var elevation: ButtonElevation? = null
        get() = field.sref({ this.elevation = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var border: BorderStroke? = null
        get() = field.sref({ this.border = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var contentPadding: PaddingValues
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var interactionSource: MutableInteractionSource? = null
        get() = field.sref({ this.interactionSource = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    fun copy(onClick: () -> Unit = this.onClick, modifier: Modifier = this.modifier, enabled: Boolean = this.enabled, shape: androidx.compose.ui.graphics.Shape = this.shape, colors: ButtonColors = this.colors, elevation: ButtonElevation? = this.elevation, border: BorderStroke? = this.border, contentPadding: PaddingValues = this.contentPadding, interactionSource: MutableInteractionSource? = this.interactionSource): Material3ButtonOptions = Material3ButtonOptions(onClick = onClick, modifier = modifier, enabled = enabled, shape = shape, colors = colors, elevation = elevation, border = border, contentPadding = contentPadding, interactionSource = interactionSource)

    constructor(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, shape: androidx.compose.ui.graphics.Shape, colors: ButtonColors, elevation: ButtonElevation? = null, border: BorderStroke? = null, contentPadding: PaddingValues = ButtonDefaults.ContentPadding, interactionSource: MutableInteractionSource? = null) {
        this.onClick = onClick
        this.modifier = modifier
        this.enabled = enabled
        this.shape = shape
        this.colors = colors
        this.elevation = elevation
        this.border = border
        this.contentPadding = contentPadding
        this.interactionSource = interactionSource
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Material3ButtonOptions(onClick, modifier, enabled, shape, colors, elevation, border, contentPadding, interactionSource)

    companion object {
    }
}

@Suppress("MUST_BE_INITIALIZED")
class Material3RippleOptions: MutableStruct {
    var color: androidx.compose.ui.graphics.Color
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var rippleAlpha: RippleAlpha? = null
        get() = field.sref({ this.rippleAlpha = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    constructor(color: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Unspecified, rippleAlpha: RippleAlpha? = null) {
        this.color = color
        this.rippleAlpha = rippleAlpha
    }

    @OptIn(ExperimentalMaterial3Api::class)
    internal constructor(configuration: RippleConfiguration) {
        this.color = configuration.color
        this.rippleAlpha = configuration.rippleAlpha
    }

    fun copy(color: androidx.compose.ui.graphics.Color = this.color, rippleAlpha: RippleAlpha? = this.rippleAlpha): Material3RippleOptions = Material3RippleOptions(color = color, rippleAlpha = rippleAlpha)

    @OptIn(ExperimentalMaterial3Api::class)
    internal fun asConfiguration(): RippleConfiguration = RippleConfiguration(color = color, rippleAlpha = rippleAlpha)

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as Material3RippleOptions
        this.color = copy.color
        this.rippleAlpha = copy.rippleAlpha
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Material3RippleOptions(this as MutableStruct)

    companion object {
    }
}

