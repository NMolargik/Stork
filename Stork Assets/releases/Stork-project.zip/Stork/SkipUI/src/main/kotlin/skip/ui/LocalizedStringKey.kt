// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*

import skip.foundation.*

@Suppress("MUST_BE_INITIALIZED")
class LocalizedStringKey: ExpressibleByStringInterpolation<LocalizedStringKey.StringInterpolation>, MutableStruct {

    internal var stringInterpolation: LocalizedStringKey.StringInterpolation
        get() = field.sref({ this.stringInterpolation = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    constructor(string: String): this(stringLiteral = string) {
    }

    constructor(stringLiteral: String, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null) {
        val value = stringLiteral
        var interp = LocalizedStringKey.StringInterpolation(literalCapacity = 0, interpolationCount = 0)
        interp.appendLiteral(value)
        this.stringInterpolation = interp
    }

    constructor(stringInterpolation: LocalizedStringKey.StringInterpolation) {
        this.stringInterpolation = stringInterpolation
    }

    /// Returns the pattern string to use for looking up localized values in the `.xcstrings` file
    val patternFormat: String
        get() = stringInterpolation.pattern


    class StringInterpolation: StringInterpolationProtocol, MutableStruct {

        internal val values: MutableList<AnyHashable>
        internal var pattern = ""
            set(newValue) {
                willmutate()
                field = newValue
                didmutate()
            }

        constructor(literalCapacity: Int, interpolationCount: Int) {
            this.values = mutableListOf()
        }

        override fun appendLiteral(literal: String) {
            willmutate()
            try {
                // need to escape out Java-specific format marker
                pattern += literal.replacingOccurrences(of = "%", with = "%%")
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(string: String) {
            willmutate()
            try {
                values.add(string)
                pattern += "%@"
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(int: Int) {
            willmutate()
            try {
                values.add(int)
                pattern += "%lld"
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(int: Short) {
            willmutate()
            try {
                values.add(int)
                pattern += "%d"
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(int: Long) {
            willmutate()
            try {
                values.add(int)
                pattern += "%lld"
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(int: UInt) {
            willmutate()
            try {
                values.add(int)
                pattern += "%llu"
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(int: UShort) {
            willmutate()
            try {
                values.add(int)
                pattern += "%u"
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(int: ULong) {
            willmutate()
            try {
                values.add(int)
                pattern += "%llu"
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(double: Double) {
            willmutate()
            try {
                values.add(double)
                pattern += "%lf"
            } finally {
                didmutate()
            }
        }

        fun appendInterpolation(float: Float) {
            willmutate()
            try {
                values.add(float)
                pattern += "%f"
            } finally {
                didmutate()
            }
        }

        override fun <T> appendInterpolation(value: T) {
            willmutate()
            try {
                values.add(value as AnyHashable)
                pattern += "%@"
            } finally {
                didmutate()
            }
        }

        //public mutating func appendInterpolation(_ string: String) { fatalError() }
        //public mutating func appendInterpolation<Subject>(_ subject: Subject, formatter: Formatter? = nil) where Subject : ReferenceConvertible { fatalError() }
        //public mutating func appendInterpolation<Subject>(_ subject: Subject, formatter: Formatter? = nil) where Subject : NSObject { fatalError() }
        //public mutating func appendInterpolation<F>(_ input: F.FormatInput, format: F) where F : FormatStyle, F.FormatInput : Equatable, F.FormatOutput == String { fatalError() }
        //public mutating func appendInterpolation<T>(_ value: T) where T : _FormatSpecifiable { fatalError() }
        //public mutating func appendInterpolation<T>(_ value: T, specifier: String) where T : _FormatSpecifiable { fatalError() }
        //public mutating func appendInterpolation(_ text: Text) { fatalError() }
        //public mutating func appendInterpolation(_ attributedString: AttributedString) { fatalError() }
        //public mutating func appendInterpolation(_ image: Image) { fatalError() }
        //public mutating func appendInterpolation(_ date: Date, style: Text.DateStyle) { fatalError() }
        //public mutating func appendInterpolation(_ dates: ClosedRange<Date>) { fatalError() }
        //public mutating func appendInterpolation(_ interval: DateInterval) { fatalError() }
        //public mutating func appendInterpolation(timerInterval: ClosedRange<Date>, pauseTime: Date? = nil, countsDown: Bool = true, showsHours: Bool = true) { fatalError() }
        //public mutating func appendInterpolation(_ resource: LocalizedStringResource) { fatalError() }

        private constructor(copy: MutableStruct) {
            @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as LocalizedStringKey.StringInterpolation
            this.values = copy.values
            this.pattern = copy.pattern
        }

        override var supdate: ((Any) -> Unit)? = null
        override var smutatingcount = 0
        override fun scopy(): MutableStruct = LocalizedStringKey.StringInterpolation(this as MutableStruct)

        override fun equals(other: Any?): Boolean {
            if (other !is LocalizedStringKey.StringInterpolation) return false
            return values == other.values && pattern == other.pattern
        }

        companion object {
        }
    }

    private constructor(copy: MutableStruct) {
        @Suppress("NAME_SHADOWING", "UNCHECKED_CAST") val copy = copy as LocalizedStringKey
        this.stringInterpolation = copy.stringInterpolation
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = LocalizedStringKey(this as MutableStruct)

    override fun equals(other: Any?): Boolean {
        if (other !is LocalizedStringKey) return false
        return stringInterpolation == other.stringInterpolation
    }

    companion object {
    }
}
