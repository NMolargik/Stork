// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*
import skip.lib.Array

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext

enum class ColorScheme: CaseIterable, Sendable {
    light,
    dark;


    /// Return the material color scheme for this scheme.
    @Composable
    fun asMaterialTheme(): androidx.compose.material3.ColorScheme {
        val context = LocalContext.current.sref()
        val isDarkMode = this == ColorScheme.dark
        // Dynamic color is available on Android 12+
        val isDynamicColor = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S
        val colorScheme: androidx.compose.material3.ColorScheme
        if (isDarkMode) {
            colorScheme = if (isDynamicColor) dynamicDarkColorScheme(context) else darkColorScheme()
        } else {
            colorScheme = if (isDynamicColor) dynamicLightColorScheme(context) else lightColorScheme()
        }
        val customization_0 = EnvironmentValues.shared._material3ColorScheme
        if (customization_0 == null) {
            return colorScheme.sref()
        }
        return customization_0(colorScheme, isDarkMode)
    }

    companion object: CaseIterableCompanion<ColorScheme> {
        /// Return the color scheme for the current material color scheme.
        @Composable
        fun fromMaterialTheme(colorScheme: androidx.compose.material3.ColorScheme = MaterialTheme.colorScheme): ColorScheme {
            // Material3 doesn't have a built-in light vs dark property, so use the luminance of the background
            return if (colorScheme.background.luminance() > 0.5f) ColorScheme.light else ColorScheme.dark
        }

        override val allCases: Array<ColorScheme>
            get() = arrayOf(light, dark)
    }
}

@Composable
fun MaterialColorScheme(scheme: (@Composable (androidx.compose.material3.ColorScheme, Boolean) -> androidx.compose.material3.ColorScheme)?, content: @Composable () -> Unit): Unit = Material3ColorScheme(scheme, content = content)

@Composable
fun Material3ColorScheme(scheme: (@Composable (androidx.compose.material3.ColorScheme, Boolean) -> androidx.compose.material3.ColorScheme)?, content: @Composable () -> Unit) {
    EnvironmentValues.shared.setValues({ it -> it.set_material3ColorScheme(scheme) }, in_ = { -> content() })
}

internal class PreferredColorSchemePreferenceKey: PreferenceKey<PreferredColorScheme> {

    companion object: PreferenceKeyCompanion<PreferredColorScheme> {
        override val defaultValue = PreferredColorScheme(colorScheme = null)
        override fun reduce(value: InOut<PreferredColorScheme>, nextValue: () -> PreferredColorScheme) {
            value.value = nextValue()
        }
    }
}

internal class PreferredColorScheme {
    internal val colorScheme: ColorScheme?

    constructor(colorScheme: ColorScheme? = null) {
        this.colorScheme = colorScheme
    }

    override fun equals(other: Any?): Boolean {
        if (other !is PreferredColorScheme) return false
        return colorScheme == other.colorScheme
    }
}
