// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*
import skip.lib.Array

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.ContentAlpha
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation

class TextField: View {
    internal val text: Binding<String>
    internal val label: ComposeBuilder
    internal val prompt: Text?
    internal val isSecure: Boolean

    constructor(text: Binding<String>, prompt: Text? = null, isSecure: Boolean = false, label: () -> View) {
        this.text = text.sref()
        this.label = ComposeBuilder.from(label)
        this.prompt = prompt
        this.isSecure = isSecure
    }

    constructor(title: String, text: Binding<String>, prompt: Text? = null): this(text = text, prompt = prompt, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(verbatim = title).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    constructor(titleKey: LocalizedStringKey, text: Binding<String>, prompt: Text? = null): this(text = text, prompt = prompt, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(titleKey).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    constructor(titleKey: LocalizedStringKey, text: Binding<String>, axis: Axis): this(titleKey, text = text) {
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    constructor(titleKey: LocalizedStringKey, text: Binding<String>, prompt: Text?, axis: Axis): this(titleKey, text = text, prompt = prompt) {
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    constructor(title: String, text: Binding<String>, axis: Axis): this(title, text = text) {
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    constructor(title: String, text: Binding<String>, prompt: Text?, axis: Axis): this(title, text = text, prompt = prompt) {
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    constructor(text: Binding<String>, prompt: Text? = null, axis: Axis, label: () -> View): this(text = text, prompt = prompt, label = label) {
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ComposeContent(context: ComposeContext) {
        val contentContext = context.content()
        val textEnvironment = EnvironmentValues.shared._textEnvironment.sref()
        val redaction = EnvironmentValues.shared.redactionReasons.sref()
        val styleInfo = Text.styleInfo(textEnvironment = textEnvironment, redaction = redaction, context = context)
        val animatable = styleInfo.style.asAnimatable(context = context)
        val colors = Companion.colors(styleInfo = styleInfo)
        val keyboardOptions = (EnvironmentValues.shared._keyboardOptions ?: KeyboardOptions.Default).sref()
        val keyboardActions = KeyboardActions(EnvironmentValues.shared._onSubmitState, LocalFocusManager.current)

        val visualTransformation = (if (isSecure) PasswordVisualTransformation() else VisualTransformation.None).sref()
        val currentText = text.wrappedValue.sref()
        val defaultTextFieldValue = TextFieldValue(text = currentText, selection = TextRange(currentText.count))
        val textFieldValue = remember { -> mutableStateOf(defaultTextFieldValue) }
        var currentTextFieldValue = textFieldValue.value.sref()
        // If the text has been updated externally, use the default value for the current text,
        // which also places the cursor at the end. This mimics SwiftUI behavior for external modifications,
        // such as when applying formatting to the user input
        if (currentTextFieldValue.text != currentText) {
            currentTextFieldValue = defaultTextFieldValue.sref()
        }
        var options = Material3TextFieldOptions(value = currentTextFieldValue, onValueChange = { it ->
            textFieldValue.value = it
            text.wrappedValue = it.text
        }, placeholder = { -> Companion.Placeholder(prompt = prompt ?: label, context = contentContext) }, modifier = context.modifier.fillWidth(), textStyle = animatable.value, enabled = EnvironmentValues.shared.isEnabled, singleLine = true, visualTransformation = visualTransformation, keyboardOptions = keyboardOptions, keyboardActions = keyboardActions, maxLines = 1, shape = OutlinedTextFieldDefaults.shape, colors = colors)
        EnvironmentValues.shared._material3TextField?.let { updateOptions ->
            options = updateOptions(options)
        }
        OutlinedTextField(value = options.value, onValueChange = options.onValueChange, modifier = options.modifier, enabled = options.enabled, readOnly = options.readOnly, textStyle = options.textStyle, label = options.label, placeholder = options.placeholder, leadingIcon = options.leadingIcon, trailingIcon = options.trailingIcon, prefix = options.prefix, suffix = options.suffix, supportingText = options.supportingText, isError = options.isError, visualTransformation = options.visualTransformation, keyboardOptions = options.keyboardOptions, keyboardActions = options.keyboardActions, singleLine = options.singleLine, maxLines = options.maxLines, minLines = options.minLines, interactionSource = options.interactionSource, shape = options.shape, colors = options.colors)
    }

    @OptIn(ExperimentalMaterial3Api::class)

    companion object {

        @Composable
        internal fun textColor(styleInfo: TextStyleInfo, enabled: Boolean): androidx.compose.ui.graphics.Color {
            val color_0 = styleInfo.color
            if (color_0 == null) {
                return androidx.compose.ui.graphics.Color.Unspecified
            }
            return if (enabled) color_0 else color_0.copy(alpha = ContentAlpha.disabled)
        }
        @Composable
        internal fun colors(styleInfo: TextStyleInfo, outline: Color? = null): TextFieldColors {
            val textColor = textColor(styleInfo = styleInfo, enabled = true)
            val disabledTextColor = textColor(styleInfo = styleInfo, enabled = false)
            val isPlainStyle = EnvironmentValues.shared._textFieldStyle == TextFieldStyle.plain
            if (isPlainStyle) {
                val clearColor = androidx.compose.ui.graphics.Color.Transparent.sref()
                val matchtarget_0 = EnvironmentValues.shared._tint
                if (matchtarget_0 != null) {
                    val tint = matchtarget_0
                    val tintColor = tint.colorImpl()
                    return OutlinedTextFieldDefaults.colors(focusedTextColor = textColor, unfocusedTextColor = textColor, disabledTextColor = disabledTextColor, cursorColor = tintColor, focusedBorderColor = clearColor, unfocusedBorderColor = clearColor, disabledBorderColor = clearColor, errorBorderColor = clearColor)
                } else {
                    return OutlinedTextFieldDefaults.colors(focusedTextColor = textColor, unfocusedTextColor = textColor, disabledTextColor = disabledTextColor, focusedBorderColor = clearColor, unfocusedBorderColor = clearColor, disabledBorderColor = clearColor, errorBorderColor = clearColor)
                }
            } else {
                val borderColor = (outline ?: Color.primary.opacity(0.3)).colorImpl()
                val matchtarget_1 = EnvironmentValues.shared._tint
                if (matchtarget_1 != null) {
                    val tint = matchtarget_1
                    val tintColor = tint.colorImpl()
                    return OutlinedTextFieldDefaults.colors(focusedTextColor = textColor, unfocusedTextColor = textColor, disabledTextColor = disabledTextColor, cursorColor = tintColor, focusedBorderColor = tintColor, unfocusedBorderColor = borderColor, disabledBorderColor = Color.separator.colorImpl())
                } else {
                    return OutlinedTextFieldDefaults.colors(focusedTextColor = textColor, unfocusedTextColor = textColor, disabledTextColor = disabledTextColor, unfocusedBorderColor = borderColor, disabledBorderColor = Color.separator.colorImpl())
                }
            }
        }

        @Composable
        internal fun Placeholder(prompt: View?, context: ComposeContext) {
            if (prompt == null) {
                return
            }
            EnvironmentValues.shared.setValues({ it ->
                it.set_foregroundStyle(Color(colorImpl = { -> Color.primary.colorImpl().copy(alpha = ContentAlpha.disabled) }))
            }, in_ = { -> prompt.Compose(context = context) })
        }
    }
}

class TextFieldStyle: RawRepresentable<Int> {
    override val rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override fun equals(other: Any?): Boolean {
        if (other !is TextFieldStyle) return false
        return rawValue == other.rawValue
    }

    companion object {

        val automatic = TextFieldStyle(rawValue = 0)
        val roundedBorder = TextFieldStyle(rawValue = 1)
        val plain = TextFieldStyle(rawValue = 2)
    }
}

@Suppress("MUST_BE_INITIALIZED")
class Material3TextFieldOptions: MutableStruct {
    var value: TextFieldValue
        get() = field.sref({ this.value = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var onValueChange: (TextFieldValue) -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var modifier: Modifier
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var enabled: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var readOnly: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var textStyle: TextStyle
        get() = field.sref({ this.textStyle = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var label: (@Composable () -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var placeholder: (@Composable () -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var leadingIcon: (@Composable () -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var trailingIcon: (@Composable () -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var prefix: (@Composable () -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var suffix: (@Composable () -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var supportingText: (@Composable () -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var isError: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var visualTransformation: VisualTransformation
        get() = field.sref({ this.visualTransformation = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var keyboardOptions: KeyboardOptions
        get() = field.sref({ this.keyboardOptions = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var keyboardActions: KeyboardActions
        get() = field.sref({ this.keyboardActions = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var singleLine: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var maxLines: Int
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var minLines: Int
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var interactionSource: MutableInteractionSource? = null
        get() = field.sref({ this.interactionSource = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var shape: androidx.compose.ui.graphics.Shape
        get() = field.sref({ this.shape = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var colors: TextFieldColors
        get() = field.sref({ this.colors = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    fun copy(value: TextFieldValue = this.value, onValueChange: (TextFieldValue) -> Unit = this.onValueChange, modifier: Modifier = this.modifier, enabled: Boolean = this.enabled, readOnly: Boolean = this.readOnly, textStyle: TextStyle = this.textStyle, label: (@Composable () -> Unit)? = this.label, placeholder: (@Composable () -> Unit)? = this.placeholder, leadingIcon: (@Composable () -> Unit)? = this.leadingIcon, trailingIcon: (@Composable () -> Unit)? = this.trailingIcon, prefix: (@Composable () -> Unit)? = this.prefix, suffix: (@Composable () -> Unit)? = this.suffix, supportingText: (@Composable () -> Unit)? = this.supportingText, isError: Boolean = this.isError, visualTransformation: VisualTransformation = this.visualTransformation, keyboardOptions: KeyboardOptions = this.keyboardOptions, keyboardActions: KeyboardActions = this.keyboardActions, singleLine: Boolean = this.singleLine, maxLines: Int = Int.MAX_VALUE, minLines: Int = this.minLines, interactionSource: MutableInteractionSource? = this.interactionSource, shape: androidx.compose.ui.graphics.Shape = this.shape, colors: TextFieldColors = this.colors): Material3TextFieldOptions = Material3TextFieldOptions(value = value, onValueChange = onValueChange, modifier = modifier, enabled = enabled, readOnly = readOnly, textStyle = textStyle, label = label, placeholder = placeholder, leadingIcon = leadingIcon, trailingIcon = trailingIcon, prefix = prefix, suffix = suffix, supportingText = supportingText, isError = isError, visualTransformation = visualTransformation, keyboardOptions = keyboardOptions, keyboardActions = keyboardActions, singleLine = singleLine, maxLines = maxLines, minLines = minLines, interactionSource = interactionSource, shape = shape, colors = colors)

    constructor(value: TextFieldValue, onValueChange: (TextFieldValue) -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, readOnly: Boolean = false, textStyle: TextStyle, label: (@Composable () -> Unit)? = null, placeholder: (@Composable () -> Unit)? = null, leadingIcon: (@Composable () -> Unit)? = null, trailingIcon: (@Composable () -> Unit)? = null, prefix: (@Composable () -> Unit)? = null, suffix: (@Composable () -> Unit)? = null, supportingText: (@Composable () -> Unit)? = null, isError: Boolean = false, visualTransformation: VisualTransformation = VisualTransformation.None.sref(), keyboardOptions: KeyboardOptions = KeyboardOptions.Default.sref(), keyboardActions: KeyboardActions = KeyboardActions.Default.sref(), singleLine: Boolean = false, maxLines: Int = Int.max, minLines: Int = 1, interactionSource: MutableInteractionSource? = null, shape: androidx.compose.ui.graphics.Shape, colors: TextFieldColors) {
        this.value = value
        this.onValueChange = onValueChange
        this.modifier = modifier
        this.enabled = enabled
        this.readOnly = readOnly
        this.textStyle = textStyle
        this.label = label
        this.placeholder = placeholder
        this.leadingIcon = leadingIcon
        this.trailingIcon = trailingIcon
        this.prefix = prefix
        this.suffix = suffix
        this.supportingText = supportingText
        this.isError = isError
        this.visualTransformation = visualTransformation
        this.keyboardOptions = keyboardOptions
        this.keyboardActions = keyboardActions
        this.singleLine = singleLine
        this.maxLines = maxLines
        this.minLines = minLines
        this.interactionSource = interactionSource
        this.shape = shape
        this.colors = colors
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Material3TextFieldOptions(value, onValueChange, modifier, enabled, readOnly, textStyle, label, placeholder, leadingIcon, trailingIcon, prefix, suffix, supportingText, isError, visualTransformation, keyboardOptions, keyboardActions, singleLine, maxLines, minLines, interactionSource, shape, colors)

    companion object {
    }
}

/// State for `onSubmit` actions.
internal class OnSubmitState {
    internal val actions: Array<Tuple2<SubmitTriggers, () -> Unit>>

    internal constructor(triggers: SubmitTriggers, action: () -> Unit) {
        actions = arrayOf(Tuple2(triggers.sref(), action))
    }

    private constructor(actions: Array<Tuple2<SubmitTriggers, () -> Unit>>) {
        this.actions = actions.sref()
    }

    internal fun appending(triggers: SubmitTriggers, action: () -> Unit): OnSubmitState = OnSubmitState(actions = actions + arrayOf(Tuple2(triggers.sref(), action)))

    internal fun appending(state: OnSubmitState): OnSubmitState = OnSubmitState(actions = actions + state.actions)

    internal fun onSubmit(trigger: SubmitTriggers) {
        for (action in actions.sref()) {
            if (action.element0.contains(trigger)) {
                action.element1()
            }
        }
    }
}

/// Create keyboard actions that execute the given submit state.
internal fun KeyboardActions(submitState: OnSubmitState?, clearFocusWith: FocusManager? = null): KeyboardActions {
    return KeyboardActions(onDone = { ->
        clearFocusWith?.clearFocus()
        submitState?.onSubmit(trigger = SubmitTriggers.text)
    }, onGo = { ->
        clearFocusWith?.clearFocus()
        submitState?.onSubmit(trigger = SubmitTriggers.text)
    }, onNext = { ->
        clearFocusWith?.clearFocus()
        submitState?.onSubmit(trigger = SubmitTriggers.text)
    }, onPrevious = { ->
        clearFocusWith?.clearFocus()
        submitState?.onSubmit(trigger = SubmitTriggers.text)
    }, onSearch = { ->
        clearFocusWith?.clearFocus()
        submitState?.onSubmit(trigger = SubmitTriggers.search)
    }, onSend = { ->
        clearFocusWith?.clearFocus()
        submitState?.onSubmit(trigger = SubmitTriggers.text)
    })
}

