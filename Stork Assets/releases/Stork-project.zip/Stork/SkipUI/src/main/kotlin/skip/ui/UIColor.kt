// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*


class UIColor {
    internal val red: Double
    internal val green: Double
    internal val blue: Double
    internal val alpha: Double

    constructor(red: Double, green: Double, blue: Double, alpha: Double) {
        this.red = red
        this.green = green
        this.blue = blue
        this.alpha = alpha
    }

    companion object {
    }
}
