// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.ContentAlpha
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.outlined.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.unit.dp

class DisclosureGroup: View, ListItemAdapting, LazyItemFactory {
    internal val label: ComposeBuilder
    internal val content: ComposeBuilder
    internal val expandedBinding: Binding<Boolean>

    // We cannot support this constructor because we have not been able to get expansion working reliably
    // in Lists without an external Binding
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    constructor(content: () -> View, label: () -> View) {
        this.label = ComposeBuilder.from(label)
        this.content = ComposeBuilder.from(content)
        this.expandedBinding = Binding(get = { -> false }, set = { _ ->  })
    }

    constructor(isExpanded: Binding<Boolean>, content: () -> View, label: () -> View) {
        this.label = ComposeBuilder.from(label)
        this.content = ComposeBuilder.from(content)
        this.expandedBinding = isExpanded.sref()
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    constructor(titleKey: LocalizedStringKey, content: () -> View) {
        this.label = ComposeBuilder.from({ -> Text(titleKey) })
        this.content = ComposeBuilder.from(content)
        this.expandedBinding = Binding(get = { -> false }, set = { _ ->  })
    }

    constructor(titleKey: LocalizedStringKey, isExpanded: Binding<Boolean>, content: () -> View): this(isExpanded = isExpanded, content = content, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(titleKey).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    constructor(label: String, content: () -> View) {
        this.label = ComposeBuilder.from({ -> Text(verbatim = label) })
        this.content = ComposeBuilder.from(content)
        this.expandedBinding = Binding(get = { -> false }, set = { _ ->  })
    }

    constructor(label: String, isExpanded: Binding<Boolean>, content: () -> View): this(isExpanded = isExpanded, content = content, label = { ->
        ComposeBuilder { composectx: ComposeContext ->
            Text(verbatim = label).Compose(composectx)
            ComposeResult.ok
        }
    }) {
    }

    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    override fun ComposeContent(context: ComposeContext) {
        val columnArrangement = Arrangement.spacedBy(8.dp, alignment = androidx.compose.ui.Alignment.CenterVertically)
        val contentContext = context.content()
        ComposeContainer(axis = Axis.vertical, modifier = context.modifier, fillWidth = true) { modifier ->
            Column(modifier = modifier, verticalArrangement = columnArrangement, horizontalAlignment = androidx.compose.ui.Alignment.Start) { ->
                ComposeLabel(context = contentContext)
                // Note: we can't seem to turn *off* animation when in AnimatedContent, so we've removed the code that
                // tries. We could take a separate code path to avoid AnimatedContent, but then a change in animation
                // status could cause us to lose state
                AnimatedContent(targetState = expandedBinding.wrappedValue) { isExpanded ->
                    if (isExpanded) {
                        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = columnArrangement, horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) { -> content.Compose(context = contentContext) }
                    }
                }
            }
        }
    }

    @Composable
    override fun shouldComposeListItem(): Boolean = true

    @Composable
    override fun ComposeListItem(context: ComposeContext, contentModifier: Modifier): Unit = ComposeLabel(context = context, listItemModifier = contentModifier)

    @Composable
    private fun ComposeLabel(context: ComposeContext, listItemModifier: Modifier? = null) {
        val contentContext = context.content()
        val isListItem = rememberUpdatedState(listItemModifier != null)
        val isEnabled = EnvironmentValues.shared.isEnabled
        val (foregroundStyle, accessoryColor) = ComposeStyles(isEnabled = isEnabled, isListItem = isListItem.value)
        val rotationAngle = Float(if (expandedBinding.wrappedValue) 90 else 0).asAnimatable(context = contentContext)
        val isRTL = EnvironmentValues.shared.layoutDirection == LayoutDirection.rightToLeft
        var modifier: Modifier = if (isEnabled) Modifier.clickable(onClick = { ->
            if (isListItem.value) {
                // Attempting to animate the list expansion and contraction doesn't work well and causes artifacts
                // in other list items
                expandedBinding.wrappedValue = !expandedBinding.wrappedValue
            } else {
                withAnimation { -> expandedBinding.wrappedValue = !expandedBinding.wrappedValue }
            }
        }) else Modifier
        if (listItemModifier != null) {
            modifier = modifier.then(listItemModifier)
        }
        Row(modifier = modifier, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) { ->
            Box(modifier = Modifier.padding(end = 8.dp).weight(1.0f)) { ->
                EnvironmentValues.shared.setValues({ it ->
                    if (foregroundStyle != null) {
                        it.set_foregroundStyle(foregroundStyle)
                    }
                }, in_ = { -> label.Compose(context = contentContext) })
            }
            Icon(modifier = Modifier.rotate(rotationAngle.value), imageVector = if (isRTL) Icons.Outlined.KeyboardArrowLeft else Icons.Outlined.KeyboardArrowRight, contentDescription = null, tint = accessoryColor)
        }
    }

    @Composable
    private fun ComposeStyles(isEnabled: Boolean, isListItem: Boolean): Tuple2<ShapeStyle?, androidx.compose.ui.graphics.Color> {
        var foregroundStyle: ShapeStyle? = null
        if (!isListItem) {
            foregroundStyle = (EnvironmentValues.shared._foregroundStyle ?: EnvironmentValues.shared._tint ?: Color.accentColor).sref()
        }
        var accessoryColor = foregroundStyle?.asColor(opacity = 1.0, animationContext = null) ?: EnvironmentValues.shared._tint?.colorImpl?.invoke() ?: Color.accentColor.colorImpl()
        if (!isEnabled) {
            if (isListItem) {
                accessoryColor = MaterialTheme.colorScheme.outlineVariant
            } else {
                val disabledAlpha = ContentAlpha.disabled.sref()
                if (foregroundStyle != null) {
                    foregroundStyle = AnyShapeStyle(foregroundStyle!!, opacity = Double(disabledAlpha))
                }
                accessoryColor = accessoryColor.copy(alpha = disabledAlpha)
            }
        }
        return Tuple2(foregroundStyle.sref(), accessoryColor)
    }

    @Composable
    override fun appendLazyItemViews(to: LazyItemCollectingComposer, appendingContext: ComposeContext): ComposeResult {
        val composer = to
        composer.append(this)
        if (expandedBinding.wrappedValue) {
            composer.pushLevel()
            content.Compose(context = appendingContext)
            composer.popLevel()
        }
        return ComposeResult.ok
    }

    override fun composeLazyItems(context: LazyItemFactoryContext, level: Int): Unit = context.item(this, level)

    companion object {
    }
}

class DisclosureGroupStyle: RawRepresentable<Int> {
    override val rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override fun equals(other: Any?): Boolean {
        if (other !is DisclosureGroupStyle) return false
        return rawValue == other.rawValue
    }

    companion object {

        val automatic = DisclosureGroupStyle(rawValue = 0)
    }
}

