// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*
import skip.lib.Array
import skip.lib.Set

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemColors
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

class TabView: View {
    internal val selection: Binding<Any>?
    internal val content: ComposeBuilder

    constructor(content: () -> View) {
        this.selection = null
        this.content = ComposeBuilder.from(content)
    }

    constructor(selection: Any?, content: () -> View) {
        this.selection = (selection as Binding<Any>?).sref()
        this.content = ComposeBuilder.from(content)
    }

    @OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
    @Composable
    override fun ComposeContent(context: ComposeContext) {
        // WARNING: This function is a potential recomposition hotspot. It should not need to be called on every tab
        // change. Test after any modification

        val tabItemContext = context.content()
        var tabViews: Array<View> = arrayOf()
        EnvironmentValues.shared.setValues({ it -> it.set_placement(ViewPlacement.tagged) }, in_ = { ->
            tabViews = content.collectViews(context = tabItemContext).filter { it -> !it.isSwiftUIEmptyView }
        })
        val tabItems = tabViews.map { view ->
            view.strippingModifiers(until = { it -> it is TabItemModifierView }, perform = { it -> it as? TabItemModifierView })
        }

        val navController = rememberNavController()
        // Isolate access to current route within child Composable so route nav does not force us to recompose
        navigateToCurrentRoute(controller = navController, tabViews = tabViews)

        val tabBarPreferences = rememberSaveable(stateSaver = context.stateSaver as Saver<Preference<ToolbarBarPreferences>, Any>) { -> mutableStateOf(Preference<ToolbarBarPreferences>(key = TabBarPreferenceKey::class)) }
        val tabBarPreferencesCollector = PreferenceCollector<ToolbarBarPreferences>(key = TabBarPreferenceKey::class, state = tabBarPreferences)

        val safeArea = EnvironmentValues.shared._safeArea
        val density = LocalDensity.current.sref()
        val defaultBottomBarHeight = 80.dp.sref()
        val bottomBarTopPx = remember { ->
            // Default our initial value to the expected value, which helps avoid visual artifacts as we measure actual values and
            // recompose with adjusted layouts
            if (safeArea != null) {
                mutableStateOf(with(density) { -> safeArea.presentationBoundsPx.bottom - defaultBottomBarHeight.toPx() })
            } else {
                mutableStateOf(0.0f)
            }
        }
        val bottomBarHeightPx = remember { ->
            mutableStateOf(with(density) { -> defaultBottomBarHeight.toPx() })
        }

        // Reduce the tab bar preferences outside the bar composable. Otherwise the reduced value may change
        // when the bottom bar recomposes
        val reducedTabBarPreferences = tabBarPreferences.value.reduced.sref()
        val bottomBar: @Composable () -> Unit = l@{ ->
            if (!tabItems.contains(where = { it -> it != null }) || reducedTabBarPreferences.visibility == Visibility.hidden) {
                SideEffect { ->
                    bottomBarTopPx.value = 0.0f
                    bottomBarHeightPx.value = 0.0f
                }
                return@l
            }
            var tabBarModifier = Modifier.fillMaxWidth()
                .onGloballyPositionedInWindow { bounds ->
                    bottomBarTopPx.value = bounds.top
                    bottomBarHeightPx.value = bounds.bottom - bounds.top
                }
            val tint = EnvironmentValues.shared._tint.sref()
            val hasColorScheme = reducedTabBarPreferences.colorScheme != null
            val isSystemBackground = reducedTabBarPreferences.isSystemBackground == true
            val showScrolledBackground = reducedTabBarPreferences.backgroundVisibility == Visibility.visible || reducedTabBarPreferences.scrollableState?.canScrollForward == true
            val materialColorScheme: androidx.compose.material3.ColorScheme
            if (showScrolledBackground) {
                val matchtarget_0 = reducedTabBarPreferences.colorScheme?.asMaterialTheme()
                if (matchtarget_0 != null) {
                    val customColorScheme = matchtarget_0
                    materialColorScheme = customColorScheme.sref()
                } else {
                    materialColorScheme = MaterialTheme.colorScheme.sref()
                }
            } else {
                materialColorScheme = MaterialTheme.colorScheme.sref()
            }
            MaterialTheme(colorScheme = materialColorScheme) { ->
                val indicatorColor: androidx.compose.ui.graphics.Color
                if (tint != null) {
                    indicatorColor = tint.asComposeColor().copy(alpha = 0.35f)
                } else {
                    indicatorColor = if (ColorScheme.fromMaterialTheme(colorScheme = materialColorScheme) == ColorScheme.dark) androidx.compose.ui.graphics.Color.White.copy(alpha = 0.1f) else androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.1f)
                }
                val tabBarBackgroundColor: androidx.compose.ui.graphics.Color
                val unscrolledTabBarBackgroundColor: androidx.compose.ui.graphics.Color
                val tabBarBackgroundForBrush: ShapeStyle?
                val tabBarItemColors: NavigationBarItemColors
                if (reducedTabBarPreferences.backgroundVisibility == Visibility.hidden) {
                    tabBarBackgroundColor = androidx.compose.ui.graphics.Color.Transparent
                    unscrolledTabBarBackgroundColor = androidx.compose.ui.graphics.Color.Transparent
                    tabBarBackgroundForBrush = null
                    tabBarItemColors = NavigationBarItemDefaults.colors(indicatorColor = indicatorColor)
                } else {
                    val matchtarget_1 = reducedTabBarPreferences.background
                    if (matchtarget_1 != null) {
                        val background = matchtarget_1
                        val matchtarget_2 = background.asColor(opacity = 1.0, animationContext = null)
                        if (matchtarget_2 != null) {
                            val color = matchtarget_2
                            tabBarBackgroundColor = color
                            unscrolledTabBarBackgroundColor = if (isSystemBackground) Color.systemBarBackground.colorImpl() else color.copy(alpha = 0.0f)
                            tabBarBackgroundForBrush = null
                        } else {
                            unscrolledTabBarBackgroundColor = if (isSystemBackground) Color.systemBarBackground.colorImpl() else androidx.compose.ui.graphics.Color.Transparent
                            tabBarBackgroundColor = unscrolledTabBarBackgroundColor.copy(alpha = 0.0f)
                            tabBarBackgroundForBrush = background.sref()
                        }
                        tabBarItemColors = NavigationBarItemDefaults.colors(indicatorColor = indicatorColor)
                    } else {
                        tabBarBackgroundColor = Color.systemBarBackground.colorImpl()
                        unscrolledTabBarBackgroundColor = if (isSystemBackground) tabBarBackgroundColor else tabBarBackgroundColor.copy(alpha = 0.0f)
                        tabBarBackgroundForBrush = null
                        if (tint == null) {
                            tabBarItemColors = NavigationBarItemDefaults.colors()
                        } else {
                            tabBarItemColors = NavigationBarItemDefaults.colors(indicatorColor = indicatorColor)
                        }
                    }
                }
                if (showScrolledBackground && (tabBarBackgroundForBrush != null)) {
                    tabBarBackgroundForBrush.asBrush(opacity = 1.0, animationContext = null)?.let { tabBarBackgroundBrush ->
                        tabBarModifier = tabBarModifier.background(tabBarBackgroundBrush)
                    }
                }

                val currentRoute = currentRoute(for_ = navController) // Note: forces recompose of this context on tab navigation
                // Pull the tab bar below the keyboard
                val bottomPadding = with(density) { -> min(bottomBarHeightPx.value, Float(WindowInsets.ime.getBottom(density))).toDp() }
                PaddingLayout(padding = EdgeInsets(top = 0.0, leading = 0.0, bottom = Double(-bottomPadding.value), trailing = 0.0), context = context.content()) { context ->
                    val tabItemsState = rememberUpdatedState(tabItems)
                    val containerColor = if (showScrolledBackground) tabBarBackgroundColor else unscrolledTabBarBackgroundColor
                    val onItemClick: (Int) -> Unit = { tabIndex ->
                        val route = String(describing = tabIndex)
                        if (selection != null) {
                            val matchtarget_3 = tagValue(route = route, in_ = tabViews)
                            if (matchtarget_3 != null) {
                                val tagValue = matchtarget_3
                                selection.wrappedValue = tagValue
                            } else {
                                navigate(controller = navController, route = route)
                            }
                        } else {
                            navigate(controller = navController, route = route)
                        }
                    }
                    val itemIcon: @Composable (Int) -> Unit = { tabIndex ->
                        val tabItem = tabItemsState.value[tabIndex].sref()
                        tabItem?.ComposeImage(context = tabItemContext)
                    }
                    val itemLabel: @Composable (Int) -> Unit = { tabIndex ->
                        val tabItem = tabItemsState.value[tabIndex].sref()
                        tabItem?.ComposeTitle(context = tabItemContext)
                    }
                    var options = Material3NavigationBarOptions(modifier = context.modifier.then(tabBarModifier), containerColor = containerColor, contentColor = MaterialTheme.colorScheme.contentColorFor(containerColor), onItemClick = onItemClick, itemIcon = itemIcon, itemLabel = itemLabel, itemColors = tabBarItemColors)
                    EnvironmentValues.shared._material3NavigationBar?.let { updateOptions ->
                        options = updateOptions(options)
                    }
                    NavigationBar(modifier = options.modifier, containerColor = options.containerColor, contentColor = options.contentColor, tonalElevation = options.tonalElevation) { ->
                        for (tabIndex in 0..<tabViews.count) {
                            val route = String(describing = tabIndex)
                            val label: (@Composable () -> Unit)?
                            val matchtarget_4 = options.itemLabel
                            if (matchtarget_4 != null) {
                                val itemLabel = matchtarget_4
                                label = { -> itemLabel(tabIndex) }
                            } else {
                                label = null
                            }
                            NavigationBarItem(selected = route == currentRoute, onClick = { -> options.onItemClick(tabIndex) }, icon = { -> options.itemIcon(tabIndex) }, modifier = options.itemModifier(tabIndex), enabled = options.itemEnabled(tabIndex), label = label, alwaysShowLabel = options.alwaysShowItemLabels, colors = options.itemColors, interactionSource = options.itemInteractionSource)
                        }
                    }
                }
            }
        }

        // When we layout, extend into the safe area if it is due to system bars, not into any app chrome. We extend
        // into the top bar too so that tab content can also extend into the top area without getting cut off during
        // tab switches
        var ignoresSafeAreaEdges: Edge.Set = Edge.Set.of(Edge.Set.bottom, Edge.Set.top)
        ignoresSafeAreaEdges.formIntersection(safeArea?.absoluteSystemBarEdges ?: Edge.Set.of())
        IgnoresSafeAreaLayout(expandInto = ignoresSafeAreaEdges) { _, _ ->
            ComposeContainer(modifier = context.modifier, fillWidth = true, fillHeight = true) { modifier ->
                // Don't use a Scaffold: it clips content beyond its bounds and prevents .ignoresSafeArea modifiers from working
                Column(modifier = modifier.background(Color.background.colorImpl())) { ->
                    NavHost(navController, modifier = Modifier.fillMaxWidth().weight(1.0f), startDestination = "0", enterTransition = { -> EnterTransition.None }, exitTransition = { -> ExitTransition.None }) { ->
                        // Use a constant number of routes. Changing routes causes a NavHost to reset its state
                        for (tabIndex in 0..<100) {
                            composable(String(describing = tabIndex)) { _ ->
                                // Inset manually where our container ignored the safe area, but we aren't showing a bar
                                val topPadding = (if (ignoresSafeAreaEdges.contains(Edge.Set.top)) WindowInsets.safeDrawing.asPaddingValues().calculateTopPadding() else 0.dp).sref()
                                var bottomPadding = 0.dp.sref()
                                if (bottomBarTopPx.value <= 0.0f && ignoresSafeAreaEdges.contains(Edge.Set.bottom)) {
                                    bottomPadding = max(0.dp, WindowInsets.safeDrawing.asPaddingValues().calculateBottomPadding() - WindowInsets.ime.asPaddingValues().calculateBottomPadding())
                                }
                                val contentModifier = Modifier.fillMaxSize().padding(top = topPadding, bottom = bottomPadding)
                                val contentSafeArea = safeArea?.insetting(Edge.bottom, to = bottomBarTopPx.value)

                                // Special-case the first composition to avoid seeing the layout adjust. This is a common
                                // issue with nav stacks in particular, and they're common enough that we need to cater to them.
                                // Use an extra container to avoid causing the content itself to recompose
                                val hasComposed = remember { -> mutableStateOf(false) }
                                SideEffect { -> hasComposed.value = true }
                                val alpha = if (hasComposed.value) 1.0f else 0.0f
                                Box(modifier = Modifier.alpha(alpha), contentAlignment = androidx.compose.ui.Alignment.Center) { ->
                                    // This block is called multiple times on tab switch. Use stable arguments that will prevent our entry from
                                    // recomposing when called with the same values
                                    val arguments = TabEntryArguments(tabIndex = tabIndex, modifier = contentModifier, safeArea = contentSafeArea)
                                    PreferenceValues.shared.collectPreferences(arrayOf(tabBarPreferencesCollector)) { -> ComposeEntry(with = arguments, context = context) }
                                }
                            }
                        }
                    }
                    bottomBar()
                }
            }
        }
    }

    @Composable
    private fun ComposeEntry(with: TabEntryArguments, context: ComposeContext) {
        val arguments = with
        // WARNING: This function is a potential recomposition hotspot. It should not need to be called
        // multiple times for the same tab on tab change. Test after modifications
        Box(modifier = arguments.modifier, contentAlignment = androidx.compose.ui.Alignment.Center) { ->
            EnvironmentValues.shared.setValues({ it ->
                arguments.safeArea?.let { safeArea ->
                    it.set_safeArea(safeArea)
                }
            }, in_ = { ->
                // Use a custom composer to only render the tabIndex'th view
                content.Compose(context = context.content(composer = TabIndexComposer(index = arguments.tabIndex)))
            })
        }
    }

    private fun tagValue(route: String, in_: Array<View>): Any? {
        val tabViews = in_
        val tabIndex_0 = Int(string = route)
        if ((tabIndex_0 == null) || (tabIndex_0 < 0) || (tabIndex_0 >= tabViews.count)) {
            return null
        }
        return TagModifierView.strip(from = tabViews[tabIndex_0], role = ComposeModifierRole.tag)?.value.sref()
    }

    private fun route(tagValue: Any, in_: Array<View>): String? {
        val tabViews = in_
        for (tabIndex in 0..<tabViews.count) {
            val tabTagValue = TagModifierView.strip(from = tabViews[tabIndex], role = ComposeModifierRole.tag)?.value.sref()
            if (tagValue == tabTagValue) {
                return String(describing = tabIndex)
            }
        }
        return null
    }

    private fun navigate(controller: NavHostController, route: String) {
        val navController = controller
        navController.navigate(route) { ->
            // Clear back stack so that tabs don't participate in Android system back button
            val destinationID = (navController.currentBackStackEntry?.destination?.id ?: navController.graph.startDestinationId).sref()
            popUpTo(destinationID) { ->
                inclusive = true
                saveState = true
            }
            // Avoid multiple copies of the same destination when reselecting the same item
            launchSingleTop = true
            // Restore state when reselecting a previously selected item
            restoreState = true
        }
    }

    @Composable
    private fun navigateToCurrentRoute(controller: NavHostController, tabViews: Array<View>) {
        val navController = controller
        val currentRoute = currentRoute(for_ = navController)
        if ((selection != null) && (currentRoute != null) && (selection.wrappedValue != tagValue(route = currentRoute, in_ = tabViews))) {
            route(tagValue = selection.wrappedValue, in_ = tabViews)?.let { route ->
                navigate(controller = navController, route = route)
            }
        }
    }

    @Composable
    private fun currentRoute(for_: NavHostController): String? {
        val navController = for_
        // In your BottomNavigation composable, get the current NavBackStackEntry using the currentBackStackEntryAsState() function. This entry gives you access to the current NavDestination. The selected state of each BottomNavigationItem can then be determined by comparing the item's route with the route of the current destination and its parent destinations (to handle cases when you are using nested navigation) via the NavDestination hierarchy.
        return navController.currentBackStackEntryAsState().value?.destination?.route
    }

    companion object {
    }
}

@Stable
internal class TabEntryArguments {
    internal val tabIndex: Int
    internal val modifier: Modifier
    internal val safeArea: SafeArea?

    constructor(tabIndex: Int, modifier: Modifier, safeArea: SafeArea? = null) {
        this.tabIndex = tabIndex
        this.modifier = modifier
        this.safeArea = safeArea
    }

    override fun equals(other: Any?): Boolean {
        if (other !is TabEntryArguments) return false
        return tabIndex == other.tabIndex && modifier == other.modifier && safeArea == other.safeArea
    }
}

internal class TabBarPreferenceKey: PreferenceKey<ToolbarBarPreferences> {

    companion object: PreferenceKeyCompanion<ToolbarBarPreferences> {
        override val defaultValue = ToolbarBarPreferences()
        override fun reduce(value: InOut<ToolbarBarPreferences>, nextValue: () -> ToolbarBarPreferences) {
            value.value = value.value.reduce(nextValue())
        }
    }
}

internal class TabItemModifierView: ComposeModifierView {
    internal val label: ComposeBuilder

    internal constructor(view: View, label: () -> View): super(view = view) {
        this.label = ComposeBuilder.from(label)
    }

    @Composable
    override fun ComposeContent(context: ComposeContext) {
        view.Compose(context = context)
    }

    @Composable
    internal fun ComposeTitle(context: ComposeContext) {
        label.Compose(context = context.content(composer = RenderingComposer { view, context ->
            val stripped = view.strippingModifiers { it -> it }
            val matchtarget_5 = stripped as? Label
            if (matchtarget_5 != null) {
                val label = matchtarget_5
                label.ComposeTitle(context = context(false))
            } else if (stripped is Text) {
                view.ComposeContent(context = context(false))
            }
        }))
    }

    @Composable
    internal fun ComposeImage(context: ComposeContext) {
        label.Compose(context = context.content(composer = RenderingComposer { view, context ->
            val stripped = view.strippingModifiers { it -> it }
            val matchtarget_6 = stripped as? Label
            if (matchtarget_6 != null) {
                val label = matchtarget_6
                label.ComposeImage(context = context(false))
            } else if (stripped is Image) {
                view.ComposeContent(context = context(false))
            }
        }))
    }

    companion object: ComposeModifierView.CompanionClass() {
    }
}

internal class TabIndexComposer: RenderingComposer {
    internal val index: Int
    internal var currentIndex = 0

    internal constructor(index: Int): super() {
        this.index = index
    }

    override fun willCompose() {
        currentIndex = 0
    }

    @Composable
    override fun Compose(view: View, context: (Boolean) -> ComposeContext) {
        if (view.isSwiftUIEmptyView) {
            return
        }
        if (currentIndex == index) {
            view.ComposeContent(context = context(false))
        }
        currentIndex += 1
    }

    companion object: RenderingComposer.CompanionClass() {
    }
}

class TabViewStyle: RawRepresentable<Int> {
    override val rawValue: Int

    constructor(rawValue: Int) {
        this.rawValue = rawValue
    }

    override fun equals(other: Any?): Boolean {
        if (other !is TabViewStyle) return false
        return rawValue == other.rawValue
    }

    companion object {

        val automatic = TabViewStyle(rawValue = 0)

        @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
        val page = TabViewStyle(rawValue = 1)
    }
}

@Suppress("MUST_BE_INITIALIZED")
class Material3NavigationBarOptions: MutableStruct {
    var modifier: Modifier
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var containerColor: androidx.compose.ui.graphics.Color
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var contentColor: androidx.compose.ui.graphics.Color
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var tonalElevation: Dp
        get() = field.sref({ this.tonalElevation = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var onItemClick: (Int) -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var itemIcon: @Composable (Int) -> Unit
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var itemModifier: @Composable (Int) -> Modifier
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var itemEnabled: (Int) -> Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var itemLabel: (@Composable (Int) -> Unit)? = null
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var alwaysShowItemLabels: Boolean
        set(newValue) {
            willmutate()
            field = newValue
            didmutate()
        }
    var itemColors: NavigationBarItemColors
        get() = field.sref({ this.itemColors = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }
    var itemInteractionSource: MutableInteractionSource? = null
        get() = field.sref({ this.itemInteractionSource = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            willmutate()
            field = newValue
            didmutate()
        }

    fun copy(modifier: Modifier = this.modifier, containerColor: androidx.compose.ui.graphics.Color = this.containerColor, contentColor: androidx.compose.ui.graphics.Color = this.contentColor, tonalElevation: Dp = this.tonalElevation, onItemClick: (Int) -> Unit = this.onItemClick, itemIcon: @Composable (Int) -> Unit = this.itemIcon, itemModifier: @Composable (Int) -> Modifier = this.itemModifier, itemEnabled: (Int) -> Boolean = this.itemEnabled, itemLabel: (@Composable (Int) -> Unit)? = this.itemLabel, alwaysShowItemLabels: Boolean = this.alwaysShowItemLabels, itemColors: NavigationBarItemColors = this.itemColors, itemInteractionSource: MutableInteractionSource? = this.itemInteractionSource): Material3NavigationBarOptions = Material3NavigationBarOptions(modifier = modifier, containerColor = containerColor, contentColor = contentColor, tonalElevation = tonalElevation, onItemClick = onItemClick, itemIcon = itemIcon, itemModifier = itemModifier, itemEnabled = itemEnabled, itemLabel = itemLabel, alwaysShowItemLabels = alwaysShowItemLabels, itemColors = itemColors, itemInteractionSource = itemInteractionSource)

    constructor(modifier: Modifier = Modifier, containerColor: androidx.compose.ui.graphics.Color, contentColor: androidx.compose.ui.graphics.Color, tonalElevation: Dp = NavigationBarDefaults.Elevation.sref(), onItemClick: (Int) -> Unit, itemIcon: @Composable (Int) -> Unit, itemModifier: @Composable (Int) -> Modifier = { _ -> Modifier }, itemEnabled: (Int) -> Boolean = { _ -> true }, itemLabel: (@Composable (Int) -> Unit)? = null, alwaysShowItemLabels: Boolean = true, itemColors: NavigationBarItemColors, itemInteractionSource: MutableInteractionSource? = null) {
        this.modifier = modifier
        this.containerColor = containerColor
        this.contentColor = contentColor
        this.tonalElevation = tonalElevation
        this.onItemClick = onItemClick
        this.itemIcon = itemIcon
        this.itemModifier = itemModifier
        this.itemEnabled = itemEnabled
        this.itemLabel = itemLabel
        this.alwaysShowItemLabels = alwaysShowItemLabels
        this.itemColors = itemColors
        this.itemInteractionSource = itemInteractionSource
    }

    override var supdate: ((Any) -> Unit)? = null
    override var smutatingcount = 0
    override fun scopy(): MutableStruct = Material3NavigationBarOptions(modifier, containerColor, contentColor, tonalElevation, onItemClick, itemIcon, itemModifier, itemEnabled, itemLabel, alwaysShowItemLabels, itemColors, itemInteractionSource)

    companion object {
    }
}

