// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*
import skip.lib.Array

import androidx.compose.runtime.Stable
import androidx.compose.ui.Modifier

/// Used in our containers to prevent recomposing animated content unnecessarily.
@Stable
internal class AnimatedContentArguments {
    internal val views: Array<View>
    internal val idMap: (View) -> Any?
    internal val ids: Array<Any>
    internal val rememberedIds: MutableSet<Any>
    internal val newIds: Array<Any>
    internal val rememberedNewIds: MutableSet<Any>
    internal val composer: RenderingComposer?

    override fun equals(other: Any?): Boolean {
        if (other !is AnimatedContentArguments) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.ids == rhs.ids && lhs.rememberedIds == rhs.rememberedIds && lhs.newIds == rhs.newIds && lhs.rememberedNewIds == rhs.rememberedNewIds
    }

    constructor(views: Array<View>, idMap: (View) -> Any?, ids: Array<Any>, rememberedIds: MutableSet<Any>, newIds: Array<Any>, rememberedNewIds: MutableSet<Any>, composer: RenderingComposer? = null) {
        this.views = views.sref()
        this.idMap = idMap
        this.ids = ids.sref()
        this.rememberedIds = rememberedIds.sref()
        this.newIds = newIds.sref()
        this.rememberedNewIds = rememberedNewIds.sref()
        this.composer = composer
    }
}
