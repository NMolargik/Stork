// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.firebase.messaging

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.firebase.core.*
import skip.ui.*
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import androidx.core.util.Consumer
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.tasks.await
import skip.model.*

// https://firebase.google.com/docs/reference/swift/firebasemessaging/api/reference/Classes/Messaging
// https://firebase.google.com/docs/reference/android/com/google/firebase/messaging/FirebaseMessaging

class Messaging: Consumer<Intent>, KotlinConverting<FirebaseMessaging> {

    val messaging: FirebaseMessaging

    constructor(messaging: FirebaseMessaging) {
        suppresssideeffects = true
        try {
            this.messaging = messaging.sref()
        } finally {
            suppresssideeffects = false
        }
    }

    val description: String
        get() = messaging.toString()

    override fun kotlin(nocopy: Boolean): FirebaseMessaging = messaging.sref()

    var delegate: MessagingDelegate? = null
        get() = field.sref({ this.delegate = it })
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            field = newValue
            if (!suppresssideeffects) {
                delegate.sref()?.let { delegate ->
                    fcmToken?.let { token ->
                        delegate.messaging(this, didReceiveRegistrationToken = token)
                    }
                }
            }
        }

    /// Call this function after activity is created and initialized.
    fun onActivityCreated(activity: AppCompatActivity) {
        activity.addOnNewIntentListener(this)
        onIntent(activity.intent)
    }

    /// Called automatically from `onActivityCreated` and its `onNewActivity` callback.
    fun onIntent(intent: Intent?) {
        val extras_0 = intent?.extras.sref()
        if (extras_0 == null) {
            return
        }
        val identifier_0 = extras_0.getString("google.message_id")
        if (identifier_0 == null) {
            return
        }
        val notificationCenter = UNUserNotificationCenter.current()
        val delegate_0 = notificationCenter.delegate.sref()
        if (delegate_0 == null) {
            return
        }

        var userInfo: Dictionary<AnyHashable, Any> = dictionaryOf()
        for (key in extras_0.keySet()) {
            userInfo[key] = extras_0.get(key)
        }
        val content = UNNotificationContent(userInfo = userInfo)
        val request = UNNotificationRequest(identifier = identifier_0, content = content, trigger = UNPushNotificationTrigger(repeats = false))
        val sentTime = extras_0.getLong("google.sent_time")
        val date = (if (sentTime == 0L) Date.now else Date(timeIntervalSince1970 = Double(sentTime) / 1000.0)).sref()
        val notification = UNNotification(request = request, date = date)
        val response = UNNotificationResponse(notification = notification)
        Task(isMainActor = true) { -> delegate_0.userNotificationCenter(notificationCenter, didReceive = response) }
    }

    var apnsToken: Data? = null
        get() = field.sref({ this.apnsToken = it })
        private set(newValue) {
            field = newValue.sref()
        }

    fun setAPNSToken(apnsToken: Data, type: MessagingAPNSTokenType) {
        this.apnsToken = apnsToken
    }

    var isAutoInitEnabled: Boolean
        get() = messaging.isAutoInitEnabled
        set(newValue) {
            messaging.isAutoInitEnabled = newValue
        }

    var fcmToken: String? = null
        internal set(newValue) {
            field = newValue
            if (!suppresssideeffects) {
                delegate?.messaging(this, didReceiveRegistrationToken = fcmToken)
            }
        }

    suspend fun token(): String = Async.run l@{
        return@l messaging.token.await()
    }

    suspend fun deleteToken(): Unit = Async.run {
        messaging.deleteToken().await()
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    suspend fun retrieveFCMToken(forSenderID: String): String = Async.run l@{
        val senderID = forSenderID
        return@l ""
    }

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    suspend fun deleteFCMToken(forSenderID: String): Unit = Unit

    suspend fun subscribe(toTopic: String): Unit = Async.run {
        val topic = toTopic
        messaging.subscribeToTopic(topic).await()
    }

    suspend fun unsubscribe(fromTopic: String): Unit = Async.run {
        val topic = fromTopic
        messaging.unsubscribeFromTopic(topic).await()
    }

    fun appDidReceiveMessage(message: Dictionary<AnyHashable, Any>): MessagingMessageInfo = MessagingMessageInfo(status = MessagingMessageStatus.unknown)

    suspend fun deleteData(): Unit = Async.run {
        deleteToken()
    }

    // Called on Activity.onNewIntent
    override fun accept(intent: Intent): Unit = onIntent(intent = intent)

    private var suppresssideeffects = false

    companion object {
        private val sharedLock: Object = Object()
        private var shared: Messaging? = null

        fun messaging(): Messaging {
            var isFirstAccess = false
            synchronized(sharedLock) { ->
                if (shared == null) {
                    isFirstAccess = true
                    shared = Messaging(messaging = FirebaseMessaging.getInstance())
                }
            }
            if (isFirstAccess) {
                Task(isMainActor = true) { ->
                    try {
                        shared!!.fcmToken = shared!!.token()
                    } catch (error: Throwable) {
                        @Suppress("NAME_SHADOWING") val error = error.aserror()
                        android.util.Log.e("SkipFirebaseMessaging", "await token() error", error as? Throwable)
                    }
                }
            }
            return shared!!
        }

        fun serviceExtension(): MessagingExtensionHelper = MessagingExtensionHelper()
    }
}

open class MessagingService: FirebaseMessagingService {
    constructor(): super() {
    }

    override fun onDeletedMessages(): Unit = super.onDeletedMessages()

    override fun onDestroy(): Unit = super.onDestroy()

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val activity_0 = UIApplication.shared.androidActivity.sref()
        if (activity_0 == null) {
            return
        }
        val notification_0 = message.notification.sref()
        if (notification_0 == null) {
            return
        }
        val notificationCenter = UNUserNotificationCenter.current()
        val delegate_1 = notificationCenter.delegate.sref()
        if (delegate_1 == null) {
            return
        }

        // We recognize notification intents by the google.message_id key
        val messageID = message.messageId ?: "0"
        var userInfo: Dictionary<AnyHashable, Any> = dictionaryOf(Tuple2("google.message_id", messageID))
        for ((key, value) in message.data.sref()) {
            userInfo[key] = value.sref()
        }
        val attachments: Array<UNNotificationAttachment>
        val matchtarget_0 = notification_0.imageUrl
        if (matchtarget_0 != null) {
            val imageUri = matchtarget_0
            val matchtarget_1 = (try { URL(string = imageUri.toString()) } catch (_: NullReturnException) { null })
            if (matchtarget_1 != null) {
                val url = matchtarget_1
                attachments = arrayOf(UNNotificationAttachment(identifier = message.messageId ?: "", url = url, type = "public.image"))
            } else {
                attachments = arrayOf()
            }
        } else {
            attachments = arrayOf()
        }
        val content = UNNotificationContent(title = notification_0.title ?: "", body = notification_0.body ?: "", userInfo = userInfo, attachments = attachments)
        val request = UNNotificationRequest(identifier = messageID, content = content, trigger = UNPushNotificationTrigger(repeats = false))
        val date = Date(timeIntervalSince1970 = Double(message.sentTime) / 1000.0)
        val notification = UNNotification(request = request, date = date)

        Task(isMainActor = true) { ->
            try {
                notificationCenter.add(request)
            } catch (error: Throwable) {
                @Suppress("NAME_SHADOWING") val error = error.aserror()
                android.util.Log.e("SkipFirebaseMessaging", "onMessageReceived error", error as? Throwable)
            }
        }
    }

    override fun onMessageSent(msgId: String): Unit = super.onMessageSent(msgId)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val messaging = Messaging.messaging()
        messaging.fcmToken = token
    }

    override fun onSendError(msgId: String, exception: Exception) {
        super.onSendError(msgId, exception)
        android.util.Log.e("SkipFirebaseMessaging", "onSendError: ${msgId}", exception)
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

interface MessagingDelegate {
    fun messaging(messaging: Messaging, didReceiveRegistrationToken: String?) = Unit
}

enum class MessagingAPNSTokenType(override val rawValue: Int, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): RawRepresentable<Int> {
    unknown(0),
    sandbox(1),
    prod(2);

    companion object {
        fun init(rawValue: Int): MessagingAPNSTokenType? {
            return when (rawValue) {
                0 -> MessagingAPNSTokenType.unknown
                1 -> MessagingAPNSTokenType.sandbox
                2 -> MessagingAPNSTokenType.prod
                else -> null
            }
        }
    }
}

fun MessagingAPNSTokenType(rawValue: Int): MessagingAPNSTokenType? = MessagingAPNSTokenType.init(rawValue = rawValue)

enum class MessagingMessageStatus(override val rawValue: Int, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): RawRepresentable<Int> {
    unknown(0),
    new(1);

    companion object {
        fun init(rawValue: Int): MessagingMessageStatus? {
            return when (rawValue) {
                0 -> MessagingMessageStatus.unknown
                1 -> MessagingMessageStatus.new
                else -> null
            }
        }
    }
}

fun MessagingMessageStatus(rawValue: Int): MessagingMessageStatus? = MessagingMessageStatus.init(rawValue = rawValue)

open class MessagingExtensionHelper {
    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun populateNotificationContent(content: UNMutableNotificationContent, withContentHandler: (UNNotificationContent) -> Unit) = Unit

    @Deprecated("This API is not yet available in Skip. Consider placing it within a #if !SKIP block. You can file an issue against the owning library at https://github.com/skiptools, or see the library README for information on adding support", level = DeprecationLevel.ERROR)
    open fun exportDeliveryMetricsToBigQuery(withMessageInfo: Dictionary<AnyHashable, Any>) = Unit

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}

open class MessagingMessageInfo {
    val status: MessagingMessageStatus

    internal constructor(status: MessagingMessageStatus) {
        this.status = status
    }

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
