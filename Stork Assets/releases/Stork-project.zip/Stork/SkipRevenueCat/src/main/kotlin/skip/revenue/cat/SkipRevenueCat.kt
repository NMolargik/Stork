// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.revenue.cat

import skip.lib.*

// Skip transpiles this to: import multi.platform.library.*


import com.revenuecat.purchases.kmp.*
// I cannot re-export packages here, so I use typealiases
typealias Purchases = com.revenuecat.purchases.kmp.Purchases
typealias CustomerInfo = com.revenuecat.purchases.kmp.models.CustomerInfo
typealias Offerings = com.revenuecat.purchases.kmp.models.Offerings
typealias StoreProduct = com.revenuecat.purchases.kmp.models.StoreProduct
typealias PurchasesDelegate = com.revenuecat.purchases.kmp.PurchasesDelegate
typealias PurchasesError = com.revenuecat.purchases.kmp.models.PurchasesError
typealias StoreTransaction = com.revenuecat.purchases.kmp.models.StoreTransaction
typealias KotlinBoolean = Boolean
typealias KotlinUnit = Unit
typealias LogLevel = com.revenuecat.purchases.kmp.LogLevel


fun com.revenuecat.purchases.kmp.Purchases.Companion.configure(apiKey: String, builder: (PurchasesConfiguration.Builder) -> Unit = { _ ->  }) {
    com.revenuecat.purchases.kmp.Purchases.configure(PurchasesConfiguration(apiKey = apiKey, builder = builder))
    Unit
}
